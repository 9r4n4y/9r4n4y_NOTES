#!/bin/bash
# Builds Notenoid.apk from the static web export + native Android shell.
# Pure aapt2/d8/apksigner pipeline (no Gradle).
#
# Usage:  bash scripts/build_apk.sh
# Needs:  android-sdk/ (run scripts/setup-sdk.sh once) + JDK 21 (javac, jar, keytool)
set -euo pipefail

BASE="$(cd "$(dirname "$0")/.." && pwd)"
SDK=${ANDROID_SDK:-$BASE/android-sdk}
BUILD_TOOLS=$SDK/build-tools/35.0.0
PLATFORM=$SDK/platforms/android-34/android.jar
PROJ=$BASE/android
ASSETS=$PROJ/assets
OUT=$BASE/out
KEYSTORE=${APK_KEYSTORE:-$BASE/keystore/release.keystore}
KEY_ALIAS=${APK_KEY_ALIAS:-notes}
: "${APK_STORE_PASSWORD:?Set APK_STORE_PASSWORD for your signing keystore}"
: "${APK_KEY_PASSWORD:=$APK_STORE_PASSWORD}"
export APK_STORE_PASSWORD APK_KEY_PASSWORD
if [ ! -f "$KEYSTORE" ]; then
  echo "ERROR: provide an existing private signing keystore through APK_KEYSTORE." >&2
  exit 1
fi

rm -rf "$OUT"
mkdir -p "$OUT/classes" "$OUT/dex"

if [ ! -f "$ASSETS/index.html" ]; then
  echo "ERROR: android/assets is empty — run scripts/build_web_export.sh first." >&2
  exit 1
fi

echo "[1/9] Using web assets from $ASSETS"
find "$ASSETS" -name "*.map" -delete 2>/dev/null || true

echo "[2/9] aapt2 compile resources..."
"$BUILD_TOOLS/aapt2" compile --dir "$PROJ/res" -o "$OUT/res.zip"

echo "[3/9] aapt2 link (base apk)..."
"$BUILD_TOOLS/aapt2" link \
  -o "$OUT/base.apk" \
  -I "$PLATFORM" \
  --manifest "$PROJ/AndroidManifest.xml" \
  -R "$OUT/res.zip" \
  -A "$ASSETS" \
  --auto-add-overlay \
  --min-sdk-version 24 \
  --target-sdk-version 34 \
  --version-code 160 \
  --version-name "16.0" 

echo "[4/9] javac compile..."
if [ -n "${JAVA_HOME:-}" ] && [ -x "$JAVA_HOME/bin/javac" ]; then
  JDK="$JAVA_HOME"
elif [ -x "$BASE/jdk21/bin/javac" ]; then
  JDK="$BASE/jdk21"
else
  JDK="$(dirname "$(dirname "$(readlink -f "$(command -v javac)")")")"
fi
export JAVA_HOME="$JDK"
PATH="$JDK/bin:$PATH"
find "$OUT/classes" -name "*.class" -delete 2>/dev/null || true
javac -g:none -source 8 -target 8 \
  -bootclasspath "$PLATFORM" \
  -classpath "$PLATFORM" \
  -d "$OUT/classes" \
  $(find "$PROJ/src" -name "*.java") 2> >(grep -v "^warning:" | grep -v "bootstrap class path" | grep -v "deprecat" >&2 || true)

echo "[5/9] d8 dex..."
jar cf "$OUT/classes.jar" -C "$OUT/classes" .
"$BUILD_TOOLS/d8" --release \
  --lib "$PLATFORM" \
  --min-api 24 \
  --output "$OUT/dex" \
  "$OUT/classes.jar"

echo "[6/9] Package classes.dex into apk..."
cd "$OUT/dex"
zip -q "$OUT/base.apk" classes.dex
cd "$BASE"

echo "[7/9] zipalign..."
"$BUILD_TOOLS/zipalign" -f -p 4 "$OUT/base.apk" "$OUT/aligned.apk"

echo "[8/9] Signing key..."
echo "[9/9] apksigner sign + verify..."
"$BUILD_TOOLS/apksigner" sign \
  --ks "$KEYSTORE" \
  --ks-key-alias "$KEY_ALIAS" \
  --ks-pass env:APK_STORE_PASSWORD \
  --key-pass env:APK_KEY_PASSWORD \
  --out "$OUT/Notenoid.apk" \
  "$OUT/aligned.apk"

"$BUILD_TOOLS/apksigner" verify "$OUT/Notenoid.apk" && echo "APK signature verified"

echo ""
echo "============================================"
ls -lh "$OUT/Notenoid.apk"
echo "BUILD COMPLETE: $OUT/Notenoid.apk"
