# Recovery guide

## Normal folder recovery in the app

1. Keep the complete `notenoid.encrypted` directory, not just a few `.bin` files.
2. Install a trusted Notenoid build, grant file permissions, and choose the folder containing that directory (or the directory itself).
3. If the device key is unavailable, the app displays **Recover your encrypted notes**.
4. Enter the original seed password. No vault password/answer is required merely to restore the encrypted storage state.
5. Open the vault later with its original password, or reset that password using a correct recorded answer. Its configuration was restored without a new setup.

If a valid remembered device key is still available, the folder opens automatically. A browser may request folder-access permission again independently of the seed password.

## Encrypted recovery ZIP

Use **Settings → Export → Save encrypted recovery copy**. No seed prompt is needed because the current storage key is already available. The vault files remain independently encrypted, so creating this opaque copy does not need to unlock their contents.

Extract the ZIP to a safe location, keeping `notenoid.encrypted/` intact, then use the folder recovery steps above. A readable-note import intentionally refuses this encrypted format and directs you to folder recovery.

## Without Notenoid

Requirements: Python 3.10+ and the `cryptography` package. Install the dependency ahead of time if you need fully offline use:

```sh
python -m pip install -r scripts/requirements-recovery.txt
python scripts/recover.py "/path/notenoid.encrypted" "/path/recovered-new"
```

Passwords are prompted with `getpass` and not printed. Output must be a new directory; existing directories are refused to avoid overwriting data. All selected objects authenticate before output creation.

With only the seed:

- Ordinary notes/media recover as readable files.
- Preferences recover to `.notenoid-recovered-preferences.json`.
- Vault objects remain inner-encrypted under `.vault-locked/`, with a manifest and original credential wrappers. They have not been omitted or unlocked.

To recover readable vault contents too:

```sh
python scripts/recover.py "/path/notenoid.encrypted" "/path/recovered-all-new" --include-vault
```

This also prompts for the separate vault password. If you forgot it but know a recorded answer, restore the folder in the app and reset the vault password there first.

Recovered plaintext and readable exports are sensitive. Keep them private or delete them when no longer needed; deleting them is not a promise of forensic erasure.

## Damaged or interrupted storage

- A corrupted remembered device key: use **Recover with seed password** on the loading-error screen to replace it using the original seed. If data authentication still fails, preserve the folder for independent recovery.
- Incorrect seed or authentication failure: stop; do not overwrite, rename random objects, or repeatedly initialize over the folder. Copy the entire directory to safety first.
- Interrupted migration cleanup: reconnect the folder and recover; the authenticated cleanup list permits remaining original-file deletions to finish. Encryption setup must complete before normal editing.
- Missing `key.json`: the recovery wrapper is missing. Restore it from a matching complete backup; guessing a new seed cannot reconstruct a random lost key.
- Damaged newest checkpoint or a concurrent-writer fork: the app fails closed instead of silently discarding recent changes. Preserve all files. The standalone utility permits explicit recovery of a retained older checkpoint:

```sh
python scripts/recover.py folder new-output --checkpoint index-000000000123-0123456789abcdef0123456789abcdef.bin
```

Choose an actual retained filename, not the example. Older-checkpoint recovery intentionally rolls back recent changes. If neither checkpoint and its referenced objects authenticate, a separate backup may be needed.

## Uninstall warning

A seed password recovers **existing encrypted bytes**, not erased files. App-private Android storage and browser OPFS can be removed when uninstalling, clearing site data, or deleting a browser profile. Use an external chosen folder and/or keep encrypted recovery ZIPs on another device. Test recovery with a copy before relying on it.
