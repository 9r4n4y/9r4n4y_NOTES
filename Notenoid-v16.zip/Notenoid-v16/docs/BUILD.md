# Build and test Notenoid v16

## Requirements

- Node.js 20.20+ and npm (Node.js 22 LTS recommended)
- JDK 21; put its `bin` directory on `PATH` and set `JAVA_HOME`
- Android build-tools 35.0.0 and platform android-34
- Linux host for the included native packaging scripts
- A signing keystore that you manage securely; none is included in this source ZIP

## Web build

```sh
npm ci
npm run typecheck
bash scripts/build_web_export.sh
```

The static export is copied to `android/assets/`. The build uses webpack and one Next.js worker to reduce peak memory. Font files are downloaded during build by Next.js and bundled for runtime use. Building needs network access for dependencies/fonts; storage encryption and recovery do not use a server.

## Android APK

```sh
bash scripts/setup-sdk.sh
export ANDROID_SDK=/path/to/android-sdk  # optional override
export JAVA_HOME=/path/to/jdk21
export PATH="$JAVA_HOME/bin:$PATH"
export APK_KEYSTORE=/secure/path/release.keystore
export APK_KEY_ALIAS=notes
read -s -p 'Keystore password: ' APK_STORE_PASSWORD; echo
export APK_STORE_PASSWORD
# APK_KEY_PASSWORD may be set separately; defaults to APK_STORE_PASSWORD.
bash scripts/build_apk.sh
unset APK_STORE_PASSWORD APK_KEY_PASSWORD
```

Output: `out/Notenoid.apk`, version name 16.0, version code 160. The scripts use aapt2 → javac → d8 → zipalign → apksigner, not Gradle. Signature verification is part of packaging.

A new private signing identity can be generated interactively with `keytool -genkeypair`, but a differently signed APK will not automatically update an existing installation. Do not encourage users to uninstall without verified backups. The delivered APK keeps the original application's identity for compatibility; its source-distributed key is not a private production key. Read `docs/SECURITY.md`.

`setup-sdk.sh` downloads the SDK tools and accepts Android SDK licenses automatically. Review those licenses before running it.

## Automated tests

```sh
npm run typecheck
npm run test:storage
npm run test:security
python -m pip install -r scripts/requirements-recovery.txt
npm run test:recovery
npx playwright install --with-deps chromium
```

The security suite produces synthetic fixtures under `test/.generated/` for the independent recovery test. These fixtures contain only test data and deliberately documented test passwords; never point the tests at real notes.

Serve the production assets, then test against them:

```sh
python -m http.server 3001 --bind 0.0.0.0 --directory android/assets
# Separate terminal:
TEST_URL=http://localhost:3001 npm run test:security-ui
TEST_URL=http://localhost:3001 npm run test:smoke
TEST_URL=http://localhost:3001 npm run test:selection
```

The browser tests create isolated browser contexts and local storage. They are not native Android tests. The available environment did not provide a physical device/emulator, so native Keystore, actual device permissions, OEM WebViews and power-loss behavior require additional device validation.
