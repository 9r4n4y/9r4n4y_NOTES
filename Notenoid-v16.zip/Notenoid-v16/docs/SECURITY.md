# Storage security and format — Notenoid v16

## Threat model

Primary protection: a person copying the encrypted notes folder should not be able to read note contents, filenames, attachment bytes, folder/label metadata, settings, or vault credentials without a storage key or a strong seed password. All cryptographic operations are performed locally with WebCrypto; Android's device-key wrapping uses Android Keystore and the platform crypto provider. No server receives passwords or keys.

This is **not** a guarantee against a compromised operating system, root access, an attacker controlling the app/browser origin/profile, malware reading live process memory, a malicious signed update, or a user operating the already-unlocked app. Automatic unlocking was an explicit product requirement and necessarily weakens protection against those threats.

## Key hierarchy

- Storage master key: 32 cryptographically random bytes, imported as a non-extractable AES-256-GCM WebCrypto key.
- Seed recovery: PBKDF2-HMAC-SHA-256, 600,000 iterations, random 16-byte salt; derived AES-256-GCM key wraps the storage master key. Minimum seed length is 16 characters, but length alone does not imply entropy. Use a unique random multiword passphrase.
- Device remembering: Android encrypts the storage key using a non-exportable Android Keystore AES-256-GCM key. Hardware backing depends on the device and is not claimed universally. The wrapped value lives in app-private preferences. Browsers persist a non-extractable CryptoKey via IndexedDB structured cloning. Browser non-extractability is not protection against same-origin code calling `decrypt` or a compromised browser profile.
- Vault key: a distinct random 32-byte key. Its password and each recovery answer independently wrap that key using separate salts and domain-separated authenticated contexts. Either answer remains sufficient for recovery, matching the requested behavior.
- Vault migration: existing PBKDF2 verifiers are used once as wrapping keys; those bare verifiers are then removed. Their original KDF parameters are retained for compatibility. New credentials use 600,000 iterations. Legacy SHA-256-only password records use a compatibility wrapping slot until the password is changed. Change weak legacy passwords/answers to strong new ones.
- The seed restores the outer storage state and the still-wrapped vault credential record; it does not directly unlock vault file contents. Vault logical path names are protected by the outer storage key, while vault file contents and attachments have an additional inner vault-key layer.

## AES-GCM encoding

Every sealed value is `12-byte random IV || ciphertext || 16-byte authentication tag`. Random IVs are generated afresh for every encryption. Byte encoding is UTF-8 for JSON/text, base64 for values embedded in JSON. File contents themselves use binary ciphertext.

Authenticated additional-data strings:

- Master-key recovery: `notenoid:recovery:<storage-id>`
- Index checkpoint: `notenoid:index:<storage-id>:<revision>`
- File object: `notenoid:object:<storage-id>:<object-id>`
- Inner vault file: `notenoid:vault-object:<object-id>`
- Vault password wrapping: `notenoid:vault:<vault-id>:password`
- Vault answer wrapping: `notenoid:vault:<vault-id>:answer:<question-id>`

The index authenticates a SHA-256 digest of the canonical header field array `[format, version, id, kdf, iterations, salt, wrappedKey]`. This detects recovery-header changes even during remembered-key automatic unlock.

## Physical layout

```
notenoid.encrypted/
  key.json
  index-000000000123-<random-id>.bin
  index-000000000124-<random-id>.bin
  objects/
    <random-object-id>.bin
```

`key.json` format is `notenoid-storage`, format version 1; it contains the storage ID, KDF parameters, salt and wrapped master key—not the seed password. The encrypted index maps logical directories and filenames to opaque immutable object IDs and carries encrypted application preferences and any pending migration-cleanup list.

Public metadata necessarily remains: ciphertext sizes/counts and filesystem timestamps; format versions; random storage/object identifiers; salt/KDF parameters/wrapped-key bytes; the selected-root locator/permission handle and adapter choice; static application assets; and the remembered key mechanism. This is **encrypted app data**, not full-disk encryption or a promise to encrypt every OS/browser artifact. An external folder's location itself is not concealed.

Encrypted recovery copies hold the write mutex while capturing one authenticated checkpoint and all its referenced objects. Large collections/archives require available memory; encryption and ZIP assembly are not a streaming, arbitrarily-large-data solution.

The two most recent committed encrypted checkpoints are retained. Object collection keeps ciphertext referenced by either. Deleted/changed data may consequently remain in a prior encrypted checkpoint or old filesystem blocks. There is no claim of forensic erasure or rollback prevention; an attacker controlling the filesystem can replay a complete older valid snapshot or delete data.

## Writes and migration

1. Write each immutable encrypted object and verify the bytes read back.
2. Commit an authenticated index under a new revision/random filename and authenticate it by reading it back.
3. Detect changed heads and duplicate-revision forks rather than silently choosing a concurrent update.
4. Retain two checkpoints; best-effort ciphertext garbage collection removes unreferenced objects.

Browser FileSystemWritableFileStream closes atomically according to its platform implementation. The Android bridge writes a temporary file, synchronizes file data, renames it, and attempts directory synchronization. Failure to rename never falls back to overwriting the original in place. These mechanisms do not establish a universal power-loss guarantee on all filesystems.

Migration copies only app-managed note directories and `.notes` metadata, not unrelated user files in a chosen folder. It verifies copied content before publishing the recovery header, then removes readable originals. The pending cleanup list permits interruption recovery. Remaining copied ciphertext is authenticated before cleanup resumes. Existing browser preferences are removed only after the encrypted store is available. Old plaintext blocks, backups and external caches may remain physically recoverable after deletion, especially on flash media.

Web Locks reject a second writer in the same browser origin where supported. Do not edit one folder simultaneously from multiple devices/browser profiles/apps, or sync it while writing. Fork detection is a diagnostic safeguard, not distributed synchronization. Preserve the folder and explicitly recover a checkpoint if a fork is reported.

## UI and export boundaries

- Plaintext exists in memory while notes are being displayed/edited. Explicit clipboard copies and attachment downloads leave readable data outside the encrypted store; the app cannot guarantee encryption of keyboard learning, OS swap, browser internals or other software’s caches.
- Vault lock flushes pending saves, removes vaulted note models, clears the in-memory vault key, and revokes repository media URLs. JavaScript cannot guarantee physical memory erasure of every string/copy.
- Android disables WebView disk caching for content and uses `FLAG_SECURE` to inhibit screenshots/recent-task previews. It disables app backup. These are platform requests, not proven protection against a compromised OS; they require physical-device validation.
- Markdown preview strips unsafe HTML such as scripts, iframes, embedded objects and event-handler attributes. Some previously accepted raw HTML may no longer render. Source/export text remains unchanged.
- Ordinary ZIP exports deliberately contain readable notes, including vault notes. Anyone who can access that ZIP can read them; the app's vault-password prompt is not ZIP encryption. This disclosure is shown before exporting.
- An encrypted disaster-recovery copy contains all current objects and credential configuration, but does not expose plaintext note content.
- Vault passwords/security answers do not reset the seed password. Losing both the seed and all remembered key copies makes recovery unavailable.

## Signing and audit status — important

For install/update compatibility, the supplied APK uses the original package's signing identity. The original source distribution included that signing key. **It must not be considered a private production key.** An attacker obtaining it could sign a malicious replacement APK; install only trusted builds. The v16 source bundle does not include a signing keystore or a hard-coded keystore password. A real production release should use a private, securely managed signing identity and a carefully planned signing-key rotation/migration; simply changing the key can prevent in-place updates and endanger app-private data if users uninstall.

This implementation has automated functional/security-regression tests and an independent recovery implementation, **not an independent cryptographic/security audit**. It is not described as unhackable, quantum-proof, universally secure, or bug-free. Native Android runtime/Keystore tests were not available in the build environment. Test on your own device using expendable notes and verified backups before migrating irreplaceable data.
