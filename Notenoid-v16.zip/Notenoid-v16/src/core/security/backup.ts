import JSZip from "jszip";
import { NoteRepository } from "../repo";
import {
  NOTE_FILE,
  ATTACHMENT_DIR,
  noteToMarkdown,
  markdownToNote,
  sanitizeName,
} from "../markdown";
import { createMutex } from "../fs/adapter";
import {
  readVaultRecord,
  writeVaultRecord,
  vaultPasswordExists,
  verifyVaultPassword,
  lockVault,
} from "../../lib/vault";
import type { VaultRecord } from "../../lib/vault";
import { derive, open, unb64, utf8, text, b64, digest } from "./crypto";
import { EncryptedFS } from "./encrypted-fs";
import { flushPreferences } from "./preferences";

async function loadSafeZip(bytes: Uint8Array) {
  if (bytes.byteLength > 256 * 1024 * 1024)
    throw Error("ZIP exceeds the 256 MiB input limit");
  const inspected = await JSZip.loadAsync(bytes);
  const entries = Object.values(inspected.files);
  if (entries.length > 20000) throw Error("Too many ZIP entries");
  let declared = 0;
  for (const file of entries) {
    const size =
      (file as unknown as { _data?: { uncompressedSize?: number } })._data
        ?.uncompressedSize ?? 0;
    if (!Number.isSafeInteger(size) || size < 0)
      throw Error("Invalid ZIP size");
    declared += size;
    if (declared > 128 * 1024 * 1024)
      throw Error(
        "ZIP exceeds the 128 MiB expanded safety limit; split it into smaller exports",
      );
  }
  return JSZip.loadAsync(bytes, { checkCRC32: true });
}

/** Exports fail, rather than silently omitting unreadable notes or attachments. */
export async function readableBackup(
  repo: NoteRepository,
  options: {
    vaultPassword?: string;
    includeImages?: boolean;
    includeArchive?: boolean;
    folder?: string | null;
  } = {},
) {
  await flushPreferences();
  let scanned = await repo.scan();
  const protectedNotes = scanned.notes.some((n) => n.vaulted);
  if (
    protectedNotes &&
    !(await verifyVaultPassword(options.vaultPassword ?? ""))
  )
    throw Error(
      "Correct vault password required to export vault notes. Nothing was exported.",
    );
  scanned = await repo.scan();
  if (scanned.skippedDirs.length)
    throw Error(
      "Some note folders could not be read. Export stopped instead of silently omitting them.",
    );
  const zip = new JSZip();
  let count = 0;
  const names = new Set<string>();
  for (const n of scanned.notes) {
    if (n.trashed && !n.vaulted) continue;
    if (!n.vaulted && options.includeArchive === false && n.archived) continue;
    if (!n.vaulted && options.folder && n.folderId !== options.folder) continue;
    const stem = sanitizeName(n.title || "Untitled") || "Untitled";
    let name = stem,
      i = 2;
    const prefix = n.vaulted ? "_vault/" : "notes/";
    while (names.has(prefix + name.toLowerCase())) name = `${stem} (${i++})`;
    names.add(prefix + name.toLowerCase());
    const directory = zip.folder(prefix + name)!;
    directory.file(NOTE_FILE, await repo.fs.readText(`${n.dir}/${NOTE_FILE}`));
    if (options.includeImages !== false)
      for (const att of n.attachments)
        directory.file(
          `${ATTACHMENT_DIR}/${att.name}`,
          await repo.fs.readBinary(`${n.dir}/${att.file}`),
        );
    count++;
  }
  zip.file("config.json", JSON.stringify(scanned.config, null, 2));
  // This restores the same vault credential/recovery configuration on a new install.
  // The key itself is still password/answer-wrapped; the exported NOTE FILES ARE PLAINTEXT.
  if (protectedNotes)
    zip.file("vault-record.json", JSON.stringify(readVaultRecord()));
  zip.file(
    "manifest.json",
    JSON.stringify({
      app: "Notenoid",
      format: 4,
      readable: true,
      notes: count,
      vault: protectedNotes,
    }),
  );
  zip.file(
    "README.txt",
    "READABLE EXPORT — NOT ENCRYPTED. All exported notes and attachments, including vault notes, are readable without any password. Keep this ZIP private. Vault credentials only gate importing into the app; they cannot protect a plaintext ZIP.",
  );
  return {
    bytes: await zip.generateAsync({
      type: "uint8array",
      compression: "DEFLATE",
    }),
    count,
  };
}
export async function encryptedBackup(repo: NoteRepository) {
  await flushPreferences();
  const fs = repo.fs as EncryptedFS;
  const zip = new JSZip();
  for (const [path, bytes] of Object.entries(await fs.encryptedBackup()))
    zip.file(`notenoid.encrypted/${path}`, bytes);
  zip.file(
    "RECOVERY.txt",
    "Keep the entire notenoid.encrypted folder. Reconnect that folder’s parent in Notenoid and enter the seed password, or use the independent recover.py utility. Vault content retains separate vault encryption.",
  );
  return zip.generateAsync({ type: "uint8array", compression: "STORE" });
}

async function verifyForeignVault(record: VaultRecord, password: string) {
  if (record.v !== 3 || !record.id || !record.password)
    throw Error("Unsupported vault credential record");
  const slot = record.password;
  const key = slot.legacy
    ? await (
        await import("./crypto")
      ).aes(
        new Uint8Array(await crypto.subtle.digest("SHA-256", utf8(password))),
      )
    : await derive(password, unb64(slot.salt), slot.iterations);
  const raw = await open(
    key,
    unb64(slot.box),
    `notenoid:vault:${record.id}:password`,
  );
  raw.fill(0);
}
export async function inspectReadableBackup(bytes: Uint8Array) {
  const zip = await loadSafeZip(bytes);
  if (zip.file("notenoid.encrypted/key.json"))
    throw Error(
      "This is an encrypted folder backup. Extract it and choose its parent folder for seed recovery. It is not a readable note ZIP.",
    );
  let vault = false,
    notes = 0;
  for (const f of Object.values(zip.files))
    if (!f.dir && /(^|\/)node\.md$/.test(f.name)) {
      notes++;
      const parsed = markdownToNote(await f.async("string"), "Imported");
      if (f.name.split("/").includes("_vault") || parsed.model.vaulted)
        vault = true;
    }
  if (!notes) throw Error("No node.md notes were found");
  return { vault, notes, foreignVault: !!zip.file("vault-record.json") };
}
const importLock = createMutex();
export async function importReadableBackup(
  repo: NoteRepository,
  bytes: Uint8Array,
  options: { vaultPassword?: string; destinationVaultPassword?: string } = {},
) {
  return importLock(async () => {
    const zip = await loadSafeZip(bytes);
    const files = Object.values(zip.files).filter((f) => !f.dir);
    if (files.some((f) => f.name === "notenoid.encrypted/key.json"))
      throw Error("Use folder recovery for an encrypted backup");
    if (files.length > 20000) throw Error("Too many ZIP entries");
    const prepared: {
      model: ReturnType<typeof markdownToNote>["model"];
      extraMeta: ReturnType<typeof markdownToNote>["extraMeta"];
      name: string;
      attachments: { name: string; bytes: Uint8Array }[];
    }[] = [];
    let total = 0;
    // Parse and validate the ENTIRE archive before the first storage mutation.
    for (const f of files) {
      const unsafe =
        (f as JSZip.JSZipObject & { unsafeOriginalName?: string })
          .unsafeOriginalName ?? f.name;
      if (
        unsafe !== f.name ||
        unsafe.startsWith("/") ||
        unsafe.split("/").some((p) => p === "..") ||
        unsafe.includes("\\")
      )
        throw Error("Unsafe ZIP path");
    }
    for (const f of files.filter((f) => /(^|\/)node\.md$/.test(f.name))) {
      const raw = await f.async("string");
      total += raw.length;
      const parts = f.name.split("/");
      const name = parts.at(-2) || "Imported";
      const { model, extraMeta } = markdownToNote(raw, name);
      if (parts.includes("_vault")) model.vaulted = true;
      const attachments: { name: string; bytes: Uint8Array }[] = [];
      const prefix = f.name.slice(0, -NOTE_FILE.length) + ATTACHMENT_DIR + "/";
      for (const a of files.filter((a) => a.name.startsWith(prefix))) {
        const name = a.name.slice(prefix.length);
        if (!name || name.includes("/")) continue;
        const data = await a.async("uint8array");
        total += data.length;
        if (total > 128 * 1024 * 1024)
          throw Error("Import exceeds the 128 MiB safety limit");
        attachments.push({ name, bytes: data });
      }
      prepared.push({ model, extraMeta, name, attachments });
    }
    if (!prepared.length) throw Error("No notes found");
    const hasVault = prepared.some((p) => p.model.vaulted);
    let installRecord: VaultRecord | null = null;
    if (hasVault) {
      const entry = zip.file("vault-record.json");
      const foreign = entry
        ? (JSON.parse(await entry.async("string")) as VaultRecord)
        : null;
      if (foreign) {
        try {
          await verifyForeignVault(foreign, options.vaultPassword ?? "");
        } catch {
          throw Error("Incorrect source vault password. Nothing was imported.");
        }
      }
      if (vaultPasswordExists()) {
        if (
          !(await verifyVaultPassword(
            options.destinationVaultPassword ?? options.vaultPassword ?? "",
          ))
        )
          throw Error(
            "Correct destination vault password required. Nothing was imported.",
          );
      } else {
        if (!foreign)
          throw Error(
            "Set up a destination vault first; this ZIP has no recoverable vault credentials.",
          );
        installRecord = foreign;
      }
    }
    const incomingConfig =
      zip.file("config.json") ?? zip.file(".notes/config.json");
    let config = await repo.loadConfig();
    if (incomingConfig) {
      const c = JSON.parse(await incomingConfig.async("string"));
      for (const folder of Array.isArray(c.folders) ? c.folders : [])
        if (
          typeof folder?.name === "string" &&
          !config.folders.some(
            (f) => f.name.toLowerCase() === folder.name.toLowerCase(),
          )
        )
          config.folders.push({
            name: folder.name,
            emoji: folder.emoji || "📁",
            color: folder.color || "default",
          });
      for (const label of Array.isArray(c.labels) ? c.labels : [])
        if (typeof label === "string" && !config.labels.includes(label))
          config.labels.push(label);
    }
    if (installRecord) {
      await writeVaultRecord(installRecord);
      if (!(await verifyVaultPassword(options.vaultPassword ?? "")))
        throw Error("Vault import verification failed");
    }
    const existing = new Set(
      (await repo.fs.listDir("")).map((e) => e.name.toLowerCase()),
    );
    const written: string[] = [];
    try {
      for (const note of prepared) {
        let name = sanitizeName(note.name) || "Imported",
          suffix = 2;
        const base = name;
        while (existing.has(name.toLowerCase())) name = `${base} (${suffix++})`;
        existing.add(name.toLowerCase());
        written.push(name);
        await repo.fs.makeDir(name);
        await repo.fs.writeText(
          `${name}/node.md`,
          noteToMarkdown(note.model, note.extraMeta),
        );
        for (const a of note.attachments)
          await repo.fs.writeBinary(
            `${name}/${ATTACHMENT_DIR}/${a.name}`,
            a.bytes,
          );
      }
      await repo.saveConfig(config);
    } catch (e) {
      for (const path of written)
        await repo.fs.remove(path, true).catch(() => {});
      throw Error(
        `Import failed; no success reported. Reopen storage and inspect before retrying. ${String(e)}`,
      );
    }
    return {
      notes: prepared.length,
      vault: prepared.filter((n) => n.model.vaulted).length,
    };
  });
}
