import { aes, b64, unb64 } from "./crypto";
type Bridge = {
  rememberStorageKey?: (id: string, key: string) => string;
  recallStorageKey?: (id: string) => string;
};
const bridge = () =>
  typeof window === "undefined"
    ? null
    : (window as unknown as { AndroidBridge?: Bridge }).AndroidBridge;
async function db() {
  return new Promise<IDBDatabase>((resolve, reject) => {
    const r = indexedDB.open("notenoid-device-keys", 1);
    r.onupgradeneeded = () => r.result.createObjectStore("keys");
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}
export async function rememberKey(id: string, raw: Uint8Array) {
  const native = bridge();
  if (native?.rememberStorageKey) {
    const result = JSON.parse(native.rememberStorageKey(id, b64(raw)));
    if (!result.ok)
      throw Error("Android Keystore could not remember this storage key");
    return;
  }
  const key = await aes(raw);
  const d = await db();
  try {
    await new Promise<void>((resolve, reject) => {
      const tx = d.transaction("keys", "readwrite");
      tx.objectStore("keys").put(key, id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  } finally {
    d.close();
  }
}
export async function recalledKey(id: string): Promise<CryptoKey | null> {
  const native = bridge();
  if (native?.recallStorageKey) {
    try {
      const r = JSON.parse(native.recallStorageKey(id));
      return r.ok && r.key ? aes(unb64(r.key)) : null;
    } catch {
      return null;
    }
  }
  const d = await db();
  try {
    return await new Promise<CryptoKey | null>((resolve, reject) => {
      const tx = d.transaction("keys", "readonly");
      const r = tx.objectStore("keys").get(id);
      r.onsuccess = () => resolve(r.result ?? null);
      r.onerror = () => reject(r.error);
    });
  } finally {
    d.close();
  }
}
