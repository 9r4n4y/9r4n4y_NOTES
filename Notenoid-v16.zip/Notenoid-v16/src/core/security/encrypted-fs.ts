import { parseNoteFile, fm } from "../frontmatter";
import { FSAdapter, DirEntry, createMutex } from "../fs/adapter";
import {
  aes,
  b64,
  unb64,
  random,
  id,
  derive,
  seal,
  open,
  utf8,
  text,
  digest,
  ITERATIONS,
} from "./crypto";
import {
  attachPreferences,
  detachPreferences,
  sensitiveKeys,
} from "./preferences";
import { rememberKey, recalledKey } from "./remember";
import {
  getVaultKey,
  lockVault,
  migrateVaultPreferences,
} from "../../lib/vault";

export const ENCRYPTED_DIR = "notenoid.encrypted";
type Header = {
  format: "notenoid-storage";
  version: 1;
  id: string;
  kdf: "PBKDF2-SHA256";
  iterations: number;
  salt: string;
  wrappedKey: string;
};
type Entry =
  | { kind: "dir" }
  | {
      kind: "file";
      object: string;
      size: number;
      vault: boolean;
      cipherHash: string;
    };
type Index = {
  version: 1;
  revision: number;
  headerHash: string;
  entries: Record<string, Entry>;
  prefs: Record<string, string>;
  cleanup: string[];
};
function put(index: Index, path: string, entry: Entry) {
  Object.defineProperty(index.entries, path, {
    value: entry,
    enumerable: true,
    configurable: true,
    writable: true,
  });
}
function headerBytes(h: Header) {
  return utf8(
    JSON.stringify([
      h.format,
      h.version,
      h.id,
      h.kdf,
      h.iterations,
      h.salt,
      h.wrappedKey,
    ]),
  );
}
function safe(path: string) {
  if (path === "") return "";
  if (
    path.startsWith("/") ||
    path.split("/").some((p) => !p || p === "." || p === "..") ||
    /[\\\u0000-\u001f]/.test(path)
  )
    throw Error("Unsafe path");
  return path;
}
const parent = (s: string) => s.slice(0, Math.max(0, s.lastIndexOf("/")));
export class EncryptedFS implements FSAdapter {
  readonly kind: FSAdapter["kind"];
  private container = ENCRYPTED_DIR;
  private path(relative: string) {
    return this.container ? `${this.container}/${relative}` : relative;
  }
  private objectPath(object: string) {
    return this.path(`objects/${object}.bin`);
  }
  private key: CryptoKey | null = null;
  private header: Header | null = null;
  private index: Index | null = null;
  private label = "";
  private head = "";
  private mutation = createMutex();
  private releaseLock: (() => void) | null = null;
  private failed = false;
  state: "new" | "recover" | "ready" = "new";
  warning = "";
  requestRecovery() {
    if (!this.header)
      throw Error(
        "No valid recovery header is loaded. Choose the complete encrypted folder.",
      );
    this.releaseLock?.();
    this.releaseLock = null;
    this.key = null;
    this.index = null;
    this.failed = false;
    this.state = "recover";
    lockVault();
    detachPreferences();
  }
  private async remember(raw: Uint8Array) {
    this.warning = "";
    try {
      await rememberKey(this.header!.id, raw);
    } catch {
      this.warning =
        "Automatic unlock could not be saved on this device. Your notes are encrypted and available for this session, but the seed password will be required again. Keep it and a recovery backup safe.";
    }
  }
  constructor(readonly raw: FSAdapter) {
    this.kind = raw.kind;
  }
  rootLabel() {
    return this.raw.rootLabel();
  }
  hasRoot() {
    return this.raw.hasRoot();
  }
  needsPermission() {
    return this.raw.needsPermission();
  }
  async pickRoot() {
    const ok = await this.raw.pickRoot();
    if (ok) this.invalidate();
    return ok;
  }
  restoreRoot() {
    return this.raw.restoreRoot();
  }
  invalidate() {
    this.releaseLock?.();
    this.releaseLock = null;
    this.label = "";
    this.key = null;
    this.index = null;
    this.failed = false;
    lockVault();
    detachPreferences();
  }
  private assertReady() {
    if (!this.key || !this.index || this.failed)
      throw Error("Encrypted storage is unavailable. Reopen it before saving.");
  }
  private async acquire(folderId: string) {
    if (this.releaseLock) return;
    if (typeof navigator !== "undefined" && navigator.locks) {
      await new Promise<void>((resolve, reject) => {
        void navigator.locks
          .request(
            `notenoid-storage:${folderId}`,
            { ifAvailable: true },
            async (lock) => {
              if (!lock) {
                reject(
                  Error(
                    "This encrypted folder is already open in another tab. Close that tab first.",
                  ),
                );
                return;
              }
              await new Promise<void>((release) => {
                this.releaseLock = release;
                resolve();
              });
            },
          )
          .catch(reject);
      });
    }
  }
  async prepare(): Promise<boolean> {
    if (
      this.label === this.rootLabel() &&
      this.key &&
      this.index &&
      !this.failed
    )
      return true;
    this.releaseLock?.();
    this.releaseLock = null;
    this.key = null;
    this.index = null;
    this.failed = false;
    this.label = this.rootLabel();
    lockVault();
    detachPreferences();
    this.container = ENCRYPTED_DIR;
    if (
      !(await this.raw.exists(this.path("key.json"))) &&
      (await this.raw.exists("key.json"))
    ) {
      try {
        if (
          JSON.parse(await this.raw.readText("key.json")).format ===
          "notenoid-storage"
        )
          this.container = "";
      } catch {
        /* unrelated file */
      }
    }
    if (!(await this.raw.exists(this.path("key.json")))) {
      if (
        (await this.raw.listDir("")).some((e) =>
          /^index-\d{12}-[a-f0-9]{32}\.bin$/.test(e.name),
        )
      )
        throw Error(
          "Encrypted files were found but key.json is missing. Preserve the entire folder and restore its recovery header from a backup.",
        );
      this.state = "new";
      return false;
    }
    this.header = JSON.parse(await this.raw.readText(this.path("key.json")));
    this.validateHeader(this.header!);
    this.state = "recover";
    const saved = await recalledKey(this.header!.id).catch(() => null);
    if (!saved) return false;
    await this.load(saved);
    return true;
  }
  private validateHeader(h: Header) {
    if (
      h.format !== "notenoid-storage" ||
      h.version !== 1 ||
      h.kdf !== "PBKDF2-SHA256" ||
      !/^[a-f0-9]{32}$/.test(h.id) ||
      h.iterations < 100_000 ||
      h.iterations > 2_000_000
    )
      throw Error("Unsupported or damaged encrypted folder");
  }
  private async indexes() {
    return (await this.raw.listDir(this.container))
      .filter(
        (e) =>
          e.kind === "file" && /^index-\d{12}-[a-f0-9]{32}\.bin$/.test(e.name),
      )
      .map((e) => e.name)
      .sort();
  }
  private async readIndex(name: string, key: CryptoKey) {
    const revision = Number(name.split("-")[1]);
    const bytes = await this.raw.readBinary(this.path(name));
    const parsed = JSON.parse(
      text(
        await open(key, bytes, `notenoid:index:${this.header!.id}:${revision}`),
      ),
    ) as Index;
    if (parsed.headerHash !== (await digest(headerBytes(this.header!))))
      throw Error("Recovery header authentication failed");
    if (
      parsed.version !== 1 ||
      parsed.revision !== revision ||
      !parsed.entries ||
      !parsed.prefs ||
      !Array.isArray(parsed.cleanup)
    )
      throw Error("Damaged encrypted index");
    Object.setPrototypeOf(parsed.entries, null);
    for (const [path, e] of Object.entries(parsed.entries)) {
      safe(path);
      if (e.kind === "file" && !/^[a-f0-9]{32}$/.test(e.object))
        throw Error("Invalid object identifier");
    }
    return parsed;
  }
  private async load(key: CryptoKey) {
    await this.acquire(this.header!.id);
    try {
      const names = await this.indexes();
      if (!names.length)
        throw Error(
          "Encrypted index is missing. Keep the entire folder together.",
        );
      const head = names.at(-1)!;
      if (
        names.filter((n) => n.split("-")[1] === head.split("-")[1]).length !== 1
      )
        throw Error(
          "Conflicting encrypted checkpoints detected. Keep a copy and use explicit checkpoint recovery.",
        );
      const data = await this.readIndex(head, key);
      this.key = key;
      this.index = data;
      this.head = head;
      await this.finishMigration();
      this.activatePreferences();
      this.state = "ready";
    } catch (e) {
      this.releaseLock?.();
      this.releaseLock = null;
      this.key = null;
      this.index = null;
      throw e;
    }
  }
  private activatePreferences() {
    attachPreferences(this.index!.prefs, (values) =>
      this.mutation(async () => {
        this.assertReady();
        const next = structuredClone(this.index!);
        next.prefs = values;
        await this.commit(next);
      }),
    );
  }
  async recover(password: string) {
    if (!this.header) {
      this.header = JSON.parse(await this.raw.readText(this.path("key.json")));
      this.validateHeader(this.header!);
    }
    let raw: Uint8Array;
    try {
      const passwordKey = await derive(
        password,
        unb64(this.header!.salt),
        this.header!.iterations,
      );
      raw = await open(
        passwordKey,
        unb64(this.header!.wrappedKey),
        `notenoid:recovery:${this.header!.id}`,
      );
    } catch {
      throw Error(
        "Incorrect seed password, or damaged recovery key. Nothing was changed.",
      );
    }
    try {
      await this.load(await aes(raw));
      await this.remember(raw);
    } finally {
      raw.fill(0);
    }
  }
  async initialize(password: string, legacyPrefs: Record<string, string>) {
    if (password.length < 16)
      throw Error(
        "Use at least 16 characters; a unique random passphrase of 5–6 words is recommended.",
      );
    if (await this.raw.exists(this.path("key.json")))
      throw Error("An encrypted folder already exists. Recover it instead.");
    const rawKey = random(),
      salt = random(16),
      storageId = id();
    await this.acquire(storageId);
    try {
      this.header = {
        format: "notenoid-storage",
        version: 1,
        id: storageId,
        kdf: "PBKDF2-SHA256",
        iterations: ITERATIONS,
        salt: b64(salt),
        wrappedKey: b64(
          await seal(
            await derive(password, salt),
            rawKey,
            `notenoid:recovery:${storageId}`,
          ),
        ),
      };
      this.key = await aes(rawKey);
      this.index = {
        version: 1,
        revision: 0,
        headerHash: "",
        entries: Object.create(null),
        prefs: { ...legacyPrefs },
        cleanup: [],
      };
      this.head = "";
      const vaultKey = await migrateVaultPreferences(this.index.prefs);
      // Only the dedicated staging directory may be replaced; originals remain intact.
      if (await this.raw.exists(ENCRYPTED_DIR)) {
        const prior = await this.raw.listDir(this.container);
        const marker = this.path("staging.json");
        if (
          prior.length &&
          (!(await this.raw.exists(marker)) ||
            JSON.parse(await this.raw.readText(marker)).format !==
              "notenoid-staging")
        )
          throw Error(
            "A folder named notenoid.encrypted already exists but is not a recoverable container. It was left untouched.",
          );
        await this.raw.remove(ENCRYPTED_DIR, true);
      }
      await this.raw.makeDir(this.path("objects"));
      await this.raw.writeText(
        this.path("staging.json"),
        JSON.stringify({ format: "notenoid-staging", id: storageId }),
      );
      const entries = await this.raw.listDir("");
      const copy = async (path: string, inVault: boolean) => {
        await this.addParents(this.index!, path);
        for (const e of await this.raw.listDir(path)) {
          const p = path ? `${path}/${e.name}` : e.name;
          safe(p);
          if (e.kind === "dir") {
            this.index!.entries[p] = { kind: "dir" };
            await copy(p, inVault);
          } else {
            const bytes = await this.raw.readBinary(p);
            await this.storeObject(this.index!, p, bytes, inVault, vaultKey);
          }
        }
      };
      for (const entry of entries) {
        if (entry.kind !== "dir" || entry.name === ENCRYPTED_DIR) continue;
        const owned =
          entry.name === ".notes" ||
          (await this.raw.exists(`${entry.name}/node.md`));
        if (!owned) continue;
        const inVault =
          entry.name !== ".notes" &&
          fm.bool(
            parseNoteFile(await this.raw.readText(`${entry.name}/node.md`))
              .meta,
            "vaulted",
          );
        if (inVault && !vaultKey)
          throw Error(
            "Vault credentials are missing. Migration stopped; original files are intact.",
          );
        this.index.entries[entry.name] = { kind: "dir" };
        await copy(entry.name, inVault);
        this.index.cleanup.push(entry.name);
      }
      await this.commit(structuredClone(this.index), true);
      // Verify each original byte before any plaintext originals are deleted.
      for (const [p, e] of Object.entries(this.index.entries))
        if (e.kind === "file") {
          const recovered = await this.readEntry(e, vaultKey);
          if (
            (await digest(recovered)) !==
            (await digest(await this.raw.readBinary(p)))
          )
            throw Error("Migration verification failed; original retained.");
        }
      await this.raw.writeText(
        this.path("key.json"),
        JSON.stringify(this.header),
      );
      this.validateHeader(
        JSON.parse(await this.raw.readText(this.path("key.json"))),
      );
      await this.finishMigration();
      await this.raw.remove(this.path("staging.json")).catch(() => {});
      await this.remember(rawKey);
      this.label = this.rootLabel();
      this.activatePreferences();
      this.state = "ready";
      lockVault();
    } catch (e) {
      this.key = null;
      this.index = null;
      this.releaseLock?.();
      this.releaseLock = null;
      throw e;
    } finally {
      rawKey.fill(0);
    }
  }
  private async finishMigration() {
    this.assertReady();
    if (!this.index!.cleanup.length) return;
    // Authenticate all copied ciphertext before deleting any remaining originals.
    for (const e of Object.values(this.index!.entries))
      if (
        e.kind === "file" &&
        (await digest(await this.raw.readBinary(this.objectPath(e.object)))) !==
          e.cipherHash
      )
        throw Error(
          "Migration data is damaged. Original files have been retained.",
        );
    // Header and authenticated index already exist. A stopped deletion resumes here.
    for (const path of this.index!.cleanup) {
      safe(path);
      if (path === ENCRYPTED_DIR || !path)
        throw Error("Invalid migration path");
      if (await this.raw.exists(path)) await this.raw.remove(path, true);
    }
    const next = structuredClone(this.index!);
    next.cleanup = [];
    await this.commit(next);
  }
  private async addParents(index: Index, path: string) {
    let p = parent(path);
    while (p) {
      if (index.entries[p]?.kind === "file") throw Error("Parent is a file");
      put(index, p, { kind: "dir" });
      p = parent(p);
    }
  }
  private async storeObject(
    index: Index,
    path: string,
    bytes: Uint8Array,
    vault: boolean,
    override: CryptoKey | null = null,
  ) {
    const object = id();
    let payload = bytes;
    if (vault) {
      const key = override ?? getVaultKey();
      if (!key)
        throw Error("Unlock the vault before modifying protected files");
      payload = await seal(key, bytes, `notenoid:vault-object:${object}`);
    }
    const encrypted = await seal(
      this.key!,
      payload,
      `notenoid:object:${this.header!.id}:${object}`,
    );
    await this.raw.writeBinary(this.objectPath(object), encrypted);
    if (
      (await digest(await this.raw.readBinary(this.objectPath(object)))) !==
      (await digest(encrypted))
    )
      throw Error("Encrypted file verification failed");
    await this.addParents(index, path);
    put(index, path, {
      kind: "file",
      object,
      size: bytes.length,
      vault,
      cipherHash: await digest(encrypted),
    });
  }
  private async readEntry(
    entry: Extract<Entry, { kind: "file" }>,
    override: CryptoKey | null = null,
  ) {
    let plain = await open(
      this.key!,
      await this.raw.readBinary(this.objectPath(entry.object)),
      `notenoid:object:${this.header!.id}:${entry.object}`,
    );
    if (entry.vault) {
      const key = override ?? getVaultKey();
      if (!key) throw Error("Vault is locked");
      plain = await open(key, plain, `notenoid:vault-object:${entry.object}`);
    }
    return plain;
  }
  private async commit(next: Index, initial = false) {
    if (!this.key) throw Error("Storage locked");
    const disk = await this.indexes();
    if (!initial && (disk.at(-1) ?? "") !== this.head)
      throw Error(
        "Folder changed in another app or tab. Reopen before saving.",
      );
    next.revision = (this.index?.revision ?? 0) + 1;
    next.headerHash = await digest(headerBytes(this.header!));
    const name = `index-${String(next.revision).padStart(12, "0")}-${id()}.bin`;
    try {
      await this.raw.writeBinary(
        this.path(name),
        await seal(
          this.key,
          utf8(JSON.stringify(next)),
          `notenoid:index:${this.header!.id}:${next.revision}`,
        ),
      );
      await this.readIndex(name, this.key);
    } catch (e) {
      this.failed = true;
      throw e;
    }
    const completed = await this.indexes();
    if (
      completed.filter((n) => n.split("-")[1] === name.split("-")[1]).length !==
      1
    ) {
      this.failed = true;
      throw Error(
        "Concurrent storage writes detected. Preserve the folder and recover a checkpoint.",
      );
    }
    Object.setPrototypeOf(next.entries, null);
    this.index = next;
    this.head = name;
    // Keep two authenticated checkpoints; ciphertext objects referenced by either stay.
    const old = (await this.indexes()).slice(0, -2);
    for (const n of old) await this.raw.remove(this.path(n)).catch(() => {});
    // Best-effort ciphertext collection; a cleanup failure cannot undo a valid commit.
    try {
      const retained = new Set<string>();
      for (const n of await this.indexes()) {
        const state = await this.readIndex(n, this.key);
        for (const e of Object.values(state.entries))
          if (e.kind === "file") retained.add(e.object + ".bin");
      }
      for (const e of await this.raw.listDir(this.path("objects")))
        if (e.kind === "file" && !retained.has(e.name))
          await this.raw.remove(this.path(`objects/${e.name}`));
    } catch {
      /* leave orphan ciphertext for the next commit */
    }
  }
  isVaultPath(path: string) {
    return Object.entries(this.index?.entries ?? {}).some(
      ([p, e]) =>
        e.kind === "file" &&
        e.vault &&
        (p === path || p.startsWith(path + "/")),
    );
  }
  async exists(path: string) {
    this.assertReady();
    safe(path);
    return path === "" || !!this.index!.entries[path];
  }
  async listDir(path: string) {
    this.assertReady();
    safe(path);
    if (path && this.index!.entries[path]?.kind !== "dir")
      throw Error("Directory missing");
    const prefix = path ? path + "/" : "";
    return Object.entries(this.index!.entries)
      .filter(
        ([p]) => p.startsWith(prefix) && !p.slice(prefix.length).includes("/"),
      )
      .map(
        ([p, e]) =>
          ({
            name: p.slice(prefix.length),
            kind: e.kind,
            ...(e.kind === "file" ? { size: e.size } : {}),
          }) as DirEntry,
      )
      .sort((a, b) => a.name.localeCompare(b.name));
  }
  async readBinary(path: string) {
    this.assertReady();
    safe(path);
    const entry = this.index!.entries[path];
    if (entry?.kind !== "file") throw Error("File not found");
    return this.readEntry(entry);
  }
  async readText(path: string) {
    return text(await this.readBinary(path));
  }
  async writeText(path: string, value: string) {
    return this.writeBinary(path, utf8(value));
  }
  async writeBinary(path: string, bytes: Uint8Array) {
    return this.mutation(async () => {
      this.assertReady();
      safe(path);
      if (!path || this.index!.entries[path]?.kind === "dir")
        throw Error("Invalid file path");
      const next = structuredClone(this.index!);
      let vault = this.isVaultPath(path.split("/")[0]);
      if (path.endsWith("/node.md")) {
        const selected = fm.bool(parseNoteFile(text(bytes)).meta, "vaulted");
        const dir = parent(path);
        if (selected !== vault) {
          if (!getVaultKey())
            throw Error(
              "Unlock the vault before moving notes into or out of it",
            );
          for (const [p, e] of Object.entries(next.entries)) {
            if (p.startsWith(dir + "/") && e.kind === "file" && p !== path)
              await this.storeObject(
                next,
                p,
                await this.readEntry(e),
                selected,
              );
          }
          vault = selected;
        }
      }
      await this.storeObject(next, path, bytes, vault);
      await this.commit(next);
    });
  }
  async makeDir(path: string) {
    return this.mutation(async () => {
      this.assertReady();
      safe(path);
      if (!path) return;
      if (this.index!.entries[path]?.kind === "file")
        throw Error("Path is a file");
      if (this.index!.entries[path]) return;
      const next = structuredClone(this.index!);
      await this.addParents(next, path);
      put(next, path, { kind: "dir" });
      await this.commit(next);
    });
  }
  async remove(path: string, recursive = true) {
    return this.mutation(async () => {
      this.assertReady();
      safe(path);
      if (!path) throw Error("Cannot delete storage root");
      if (this.isVaultPath(path) && !getVaultKey())
        throw Error("Unlock vault before deleting protected data");
      const next = structuredClone(this.index!);
      if (
        !recursive &&
        Object.keys(next.entries).some((p) => p.startsWith(path + "/"))
      )
        throw Error("Directory not empty");
      for (const p of Object.keys(next.entries))
        if (p === path || p.startsWith(path + "/")) delete next.entries[p];
      await this.commit(next);
    });
  }
  async rename(from: string, to: string) {
    return this.mutation(async () => {
      this.assertReady();
      safe(from);
      safe(to);
      if (!from || !to || to.startsWith(from + "/"))
        throw Error("Invalid rename");
      if (from === to) return;
      if (!this.index!.entries[from] || this.index!.entries[to])
        throw Error("Rename source missing or destination exists");
      if (this.isVaultPath(from) && !getVaultKey())
        throw Error("Unlock vault before renaming protected data");
      const next = structuredClone(this.index!);
      await this.addParents(next, to);
      for (const [p, e] of Object.entries(this.index!.entries))
        if (p === from || p.startsWith(from + "/")) {
          put(next, to + p.slice(from.length), e);
          delete next.entries[p];
        }
      await this.commit(next);
    });
  }
  async flush() {
    await this.mutation(async () => {
      this.assertReady();
    });
  }
  async encryptedBackup() {
    return this.mutation(async () => {
      this.assertReady();
      const snapshot = this.index!;
      const head = this.head;
      if ((await this.indexes()).at(-1) !== head)
        throw Error("Storage changed externally. Reopen it before backing up.");
      const files: Record<string, Uint8Array> = {};
      files["key.json"] = await this.raw.readBinary(this.path("key.json"));
      const header = JSON.parse(text(files["key.json"])) as Header;
      this.validateHeader(header);
      if ((await digest(headerBytes(header))) !== snapshot.headerHash)
        throw Error("Recovery header was changed or damaged. Backup stopped.");
      await this.readIndex(head, this.key!);
      files[head] = await this.raw.readBinary(this.path(head));
      for (const entry of Object.values(snapshot.entries))
        if (entry.kind === "file") {
          const bytes = await this.raw.readBinary(
            this.objectPath(entry.object),
          );
          if ((await digest(bytes)) !== entry.cipherHash)
            throw Error(
              "An encrypted object was damaged. Backup stopped rather than exporting an incomplete recovery copy.",
            );
          files[`objects/${entry.object}.bin`] = bytes;
        }
      return files;
    });
  }
  async close() {
    await this.flush();
    this.releaseLock?.();
    this.releaseLock = null;
    this.key = null;
    this.index = null;
    lockVault();
    detachPreferences();
  }
}
/** Preserve platform picker APIs without exposing them as plaintext repository IO. */
export function encryptedAdapter(raw: FSAdapter): EncryptedFS {
  return new Proxy(new EncryptedFS(raw), {
    get(target, key) {
      if (key === "setRoot")
        return (...args: unknown[]) => {
          target.invalidate();
          return Reflect.get(raw, key).apply(raw, args);
        };
      const source = key in target ? target : raw;
      const value = Reflect.get(source, key, source);
      return typeof value === "function" ? value.bind(source) : value;
    },
  });
}
export function legacyPreferences() {
  const prefs: Record<string, string> = {};
  for (const k of sensitiveKeys) {
    const v = localStorage.getItem(k);
    if (v != null) prefs[k] = v;
  }
  return prefs;
}
export function clearLegacyPreferences() {
  for (const k of sensitiveKeys) localStorage.removeItem(k);
  sessionStorage.removeItem("notes-vault-open");
}
