"use client";
import { useBackLayer } from "@/lib/back-nav";
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useKeepStore, getRepo } from "./store";
import { readableBackup, encryptedBackup } from "@/core/security/backup";
import { saveBlob } from "@/lib/save-blob";
import { getVaultKey, lockVault } from "@/lib/vault";
import { toast } from "sonner";
export function ExportDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const notes = useKeepStore((s) => s.notes),
    folders = useKeepStore((s) => s.folders);
  const [password, setPassword] = useState(""),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [ack, setAck] = useState(false),
    [images, setImages] = useState(true),
    [archive, setArchive] = useState(true),
    [scope, setScope] = useState("");
  useBackLayer(open, () => {
    if (!busy) {
      setPassword("");
      onOpenChange(false);
    }
  });
  const hasVault = notes.some((n) => n.vaulted);
  async function run(encrypted: boolean) {
    setBusy(true);
    setError("");
    const wasOpen = useKeepStore.getState().vaultOpen;
    try {
      await useKeepStore.getState().flushAll();
      const data = encrypted
        ? await encryptedBackup(getRepo())
        : (
            await readableBackup(getRepo(), {
              vaultPassword: password,
              includeArchive: archive,
              includeImages: images,
              folder: scope || null,
            })
          ).bytes;
      await saveBlob(
        encrypted
          ? "notenoid-encrypted-recovery.zip"
          : "notenoid-readable-notes.zip",
        new Blob([new Uint8Array(data)], { type: "application/zip" }),
      );
      setPassword("");
      toast.success("Export ready");
      onOpenChange(false);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Export failed");
    } finally {
      if (!wasOpen) lockVault();
      setBusy(false);
    }
  }
  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!busy) {
          setPassword("");
          setError("");
          onOpenChange(o);
        }
      }}
    >
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Export notes</DialogTitle>
          <DialogDescription>
            No seed password is requested. Choose a readable ZIP for other apps,
            or an encrypted recovery copy of the entire folder.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <label className="block text-sm">
            Ordinary notes to export
            <select
              aria-label="Export scope"
              className="mt-1 w-full rounded border bg-background p-2"
              value={scope}
              onChange={(e) => setScope(e.target.value)}
            >
              <option value="">All notes</option>
              {folders.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name}
                </option>
              ))}
            </select>
          </label>
          <label className="flex gap-2 text-sm">
            <input
              type="checkbox"
              checked={images}
              onChange={(e) => setImages(e.target.checked)}
            />
            Include images and attachments
          </label>
          <label className="flex gap-2 text-sm">
            <input
              type="checkbox"
              checked={archive}
              onChange={(e) => setArchive(e.target.checked)}
            />
            Include archived ordinary notes
          </label>
          {hasVault && (
            <div className="space-y-2 rounded border p-3">
              <p className="text-sm">
                Vault notes are always included in readable exports. Enter the
                vault password; wrong passwords stop the export rather than
                skipping notes.
              </p>
              <Input
                aria-label="Export vault password"
                placeholder="Vault password"
                type="password"
                autoComplete="off"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          )}
          <label className="flex items-start gap-2 text-sm">
            <input
              type="checkbox"
              checked={ack}
              onChange={(e) => setAck(e.target.checked)}
            />
            <span>
              I understand the readable ZIP contains{" "}
              <strong>
                unencrypted notes and attachments, including vault notes
              </strong>
              . Anyone with this ZIP can read them.
            </span>
          </label>
          {error && (
            <p role="alert" className="text-sm text-destructive">
              {error}
            </p>
          )}
          <Button
            className="w-full"
            disabled={busy || !ack || (hasVault && !password)}
            onClick={() => void run(false)}
          >
            {busy ? "Working…" : "Export readable ZIP"}
          </Button>
          <Button
            variant="outline"
            className="w-full"
            disabled={busy}
            onClick={() => void run(true)}
          >
            Save encrypted recovery copy
          </Button>
          <p className="text-xs text-muted-foreground">
            Encrypted recovery copies always include all stored notes, trash,
            attachments, settings and vault credentials. Restore them using the
            original seed password. Do not lose it.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
