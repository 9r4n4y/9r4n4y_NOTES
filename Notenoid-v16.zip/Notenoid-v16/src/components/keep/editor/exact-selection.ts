import { diffChars } from "diff";

/** Map each UTF-16 character of rendered/transformed text to its source range.
 * Inserted characters have no identity: never guess another matching word. */
export function sourceMap(source: string, displayed: string): [number, number][] {
  const map: [number, number][] = [];
  let offset = 0;
  for (const part of diffChars(source, displayed)) {
    if (part.removed) { offset += part.value.length; continue; }
    for (let i = 0; i < part.value.length; i++) {
      map.push(part.added ? [-1, -1] : [offset, offset + 1]);
      if (!part.added) offset++;
    }
  }
  return map;
}

type Ast = { type: string; value?: string; tagName?: string; properties?: Record<string, unknown>; children?: Ast[]; position?: { start: { offset?: number }; end: { offset?: number } } };
/** Runs after raw HTML parsing. Text leaves retain the parser's exact offsets. */
export function rehypeExactSelection(options: { source: string }) {
  return (tree: Ast, file: { value: unknown }) => {
    const input = String(file.value);
    const inputMap = sourceMap(options.source, input);
    const visit = (parent: Ast) => {
      if (!parent.children || ["script", "style", "math", "svg"].includes(parent.tagName ?? "")) return;
      parent.children = parent.children.map((child) => {
        if (child.type !== "text") { visit(child); return child; }
        let start = child.position?.start?.offset;
        let end = child.position?.end?.offset;
        if (start == null && end != null && child.value && input.slice(end - child.value.length, end) === child.value) {
          start = end - child.value.length;
        }
        if (start == null && parent.tagName === "code") {
          start = parent.position?.start?.offset;
          end = parent.position?.end?.offset;
          // Fenced code has no text-leaf position. Exclude the opening fence
          // and language label before aligning, even when they repeat the code.
          if (start != null && end != null && /^ {0,3}(`{3,}|~{3,})/.test(input.slice(start, end))) {
            start = input.indexOf("\n", start) + 1;
          }
        }
        if (start == null || end == null || !child.value?.trim()) return child;
        const raw = input.slice(start, end);
        const local = sourceMap(raw, child.value);
        const mapped = local.map(([a, b]) => a < 0 ? [-1, -1] : [inputMap[start + a]?.[0] ?? -1, inputMap[start + b - 1]?.[1] ?? -1]);
        return { type: "element", tagName: "span", properties: { "data-exact-map": JSON.stringify(mapped) }, children: [child] };
      });
    };
    visit(tree);
  };
}

export function previewRange(root: HTMLElement, start: number, end: number): Range | null {
  let first: { node: Text; offset: number } | undefined;
  let last: { node: Text; offset: number } | undefined;
  for (const span of root.querySelectorAll<HTMLElement>("[data-exact-map]")) {
    const map: [number, number][] = JSON.parse(span.dataset.exactMap!);
    const walker = document.createTreeWalker(span, NodeFilter.SHOW_TEXT);
    let index = 0;
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      for (let i = 0; i < (node as Text).length; i++, index++) {
        const [a, b] = map[index] ?? [-1, -1];
        if (a >= start && b <= end && a >= 0) {
          first ??= { node: node as Text, offset: i };
          last = { node: node as Text, offset: i + 1 };
        }
      }
    }
  }
  if (!first || !last) return null;
  const range = document.createRange();
  range.setStart(first.node, first.offset); range.setEnd(last.node, last.offset);
  return range;
}

export function sourceAtPoint(root: HTMLElement, x: number, y: number): number | null {
  const doc = document as Document & { caretPositionFromPoint?: (x: number, y: number) => { offsetNode: Node; offset: number } | null };
  const caret = doc.caretPositionFromPoint?.(x, y);
  const range = !caret ? doc.caretRangeFromPoint?.(x, y) : null;
  const node = caret?.offsetNode ?? range?.startContainer;
  const offset = caret?.offset ?? range?.startOffset ?? 0;
  if (!node || node.nodeType !== Node.TEXT_NODE || !root.contains(node)) return null;
  const span = node.parentElement?.closest<HTMLElement>("[data-exact-map]");
  if (!span) return null;
  const before = document.createRange(); before.selectNodeContents(span); before.setEnd(node, offset);
  const index = before.toString().length;
  const map: [number, number][] = JSON.parse(span.dataset.exactMap!);
  const entry = map[Math.min(index, map.length - 1)];
  return entry && entry[0] >= 0 ? entry[0] : null;
}
