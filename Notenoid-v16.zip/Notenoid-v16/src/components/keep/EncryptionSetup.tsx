"use client";
import { useBackLayer } from "@/lib/back-nav";
import { toast } from "sonner";
import { useState } from "react";
import { ShieldCheck, Loader2 } from "lucide-react";
import { getRepo, useKeepStore } from "./store";
import {
  EncryptedFS,
  legacyPreferences,
  clearLegacyPreferences,
} from "@/core/security/encrypted-fs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
export function EncryptionSetup() {
  const fs = getRepo().fs as EncryptedFS;
  const [password, setPassword] = useState(""),
    [repeat, setRepeat] = useState(""),
    [confirmed, setConfirmed] = useState(false),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  useBackLayer(busy, () => {});
  const recover = fs.state === "recover";
  async function submit() {
    if (busy) return;
    setBusy(true);
    setError("");
    try {
      if (recover) await fs.recover(password);
      else {
        if (password !== repeat) throw Error("Seed passwords do not match");
        await fs.initialize(password, legacyPreferences());
      }
      if (fs.warning) toast.warning(fs.warning, { duration: Infinity });
      clearLegacyPreferences();
      setPassword("");
      setRepeat("");
      await useKeepStore.getState().rescan();
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : "Storage setup failed. Keep your original folder.",
      );
      await fs.prepare().catch(() => {});
    } finally {
      setBusy(false);
    }
  }
  return (
    <main className="flex min-h-screen items-center justify-center bg-background px-6 py-10">
      <section className="w-full max-w-md space-y-5">
        <ShieldCheck className="h-10 w-10 text-primary" />
        <div>
          <h1 className="text-2xl font-semibold">
            {recover
              ? "Recover your encrypted notes"
              : "Protect your local notes"}
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            {recover
              ? "An encrypted Notenoid folder was found. Restore it exactly as it was using its original seed password. Your vault keeps its separate password and security questions."
              : "Choose a strong seed password. All app-managed notes, attachments and preferences will be encrypted locally. Existing notes will be verified before their readable originals are removed."}
          </p>
        </div>
        <p className="rounded-lg border p-3 text-sm">
          <strong>Remember this password.</strong> Use a unique random
          passphrase of 5–6 words (at least 16 characters). There is no
          seed-password reset. Save it safely outside this app. The vault
          password cannot replace it.
        </p>
        <label className="block text-sm">
          Seed password
          <Input
            aria-label="Seed password"
            type="password"
            autoComplete={recover ? "current-password" : "new-password"}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            disabled={busy}
          />
        </label>
        {!recover && (
          <>
            <label className="block text-sm">
              Confirm seed password
              <Input
                aria-label="Confirm seed password"
                type="password"
                autoComplete="new-password"
                value={repeat}
                onChange={(e) => setRepeat(e.target.value)}
                disabled={busy}
              />
            </label>
            <label className="flex items-start gap-2 text-sm">
              <input
                type="checkbox"
                checked={confirmed}
                onChange={(e) => setConfirmed(e.target.checked)}
                disabled={busy}
              />
              <span>
                I saved my seed password and backed up any existing notes. I
                understand forgotten passwords cannot be recovered.
              </span>
            </label>
          </>
        )}
        <p className="text-xs text-muted-foreground">
          Automatic unlock will be remembered on this device. Anyone able to
          open this app can read ordinary notes. Android uses Keystore; browser
          automatic unlock relies on browser-profile security.
          Uninstalling/clearing app-private storage can delete the files
          themselves—keep an external folder or an encrypted backup.
        </p>
        {error && (
          <p role="alert" className="text-sm text-destructive">
            {error}
          </p>
        )}
        <Button
          className="w-full"
          disabled={
            busy ||
            !password ||
            (!recover &&
              (!confirmed || password.length < 16 || password !== repeat))
          }
          onClick={() => void submit()}
        >
          {busy ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Encrypting / verifying…
            </>
          ) : recover ? (
            "Recover encrypted folder"
          ) : (
            "Encrypt local storage"
          )}
        </Button>
        {busy && (
          <p className="text-xs text-muted-foreground">
            Keep the app open until verification finishes. Large attachment
            collections can take time.
          </p>
        )}
      </section>
    </main>
  );
}
