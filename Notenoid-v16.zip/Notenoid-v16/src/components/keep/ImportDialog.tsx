"use client";
import { useBackLayer } from "@/lib/back-nav";
import { useState, useRef } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useKeepStore, getRepo } from "./store";
import {
  inspectReadableBackup,
  importReadableBackup,
} from "@/core/security/backup";
import { vaultPasswordExists, lockVault } from "@/lib/vault";
import { toast } from "sonner";
export function ImportDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [bytes, setBytes] = useState<Uint8Array | null>(null),
    [info, setInfo] = useState<{
      vault: boolean;
      notes: number;
      foreignVault: boolean;
    } | null>(null),
    [password, setPassword] = useState(""),
    [destination, setDestination] = useState(""),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [summary, setSummary] = useState("");
  const input = useRef<HTMLInputElement>(null);
  useBackLayer(open, () => {
    if (!busy) {
      setPassword("");
      setDestination("");
      setBytes(null);
      setInfo(null);
      onOpenChange(false);
    }
  });
  async function choose(file: File) {
    setError("");
    setSummary("");
    setInfo(null);
    setBytes(null);
    setBusy(true);
    try {
      if (file.size > 256 * 1024 * 1024)
        throw Error("ZIP exceeds the 256 MiB input limit");
      const data = new Uint8Array(await file.arrayBuffer());
      setInfo(await inspectReadableBackup(data));
      setBytes(data);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Unreadable ZIP");
    } finally {
      setBusy(false);
    }
  }
  async function run() {
    if (!bytes) return;
    setBusy(true);
    setError("");
    const wasOpen = useKeepStore.getState().vaultOpen;
    try {
      await useKeepStore.getState().flushAll();
      const result = await importReadableBackup(getRepo(), bytes, {
        vaultPassword: password,
        destinationVaultPassword: destination || undefined,
      });
      setSummary(
        `${result.notes} notes restored, including ${result.vault} vault notes. No vault notes were silently skipped.`,
      );
      setPassword("");
      setDestination("");
      setBytes(null);
      setInfo(null);
      toast.success("Import complete");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Import failed");
    } finally {
      if (!wasOpen) lockVault();
      await useKeepStore.getState().rescan();
      setBusy(false);
    }
  }
  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!busy) {
          setPassword("");
          setDestination("");
          setBytes(null);
          setInfo(null);
          setError("");
          setSummary("");
          onOpenChange(o);
        }
      }}
    >
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Import backup</DialogTitle>
          <DialogDescription>
            Readable ZIPs are automatically encrypted into local storage. No
            seed password is requested. Existing notes and vault credentials are
            not overwritten.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <input
            ref={input}
            type="file"
            accept=".zip,application/zip"
            aria-label="Backup ZIP"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void choose(f);
              e.target.value = "";
            }}
            disabled={busy}
          />
          {info && (
            <p className="text-sm">
              {info.notes} notes found
              {info.vault ? ", including vault notes" : ""}.
            </p>
          )}
          {info?.vault && (
            <>
              <p className="text-sm">
                All vault notes will be imported. Enter{" "}
                {info.foreignVault ? "the source backup’s" : "your destination"}{" "}
                vault password. For a new vault, the backup’s password and
                security questions are restored unchanged.
              </p>
              <Input
                type="password"
                aria-label="Import vault password"
                placeholder="Vault password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              {info.foreignVault && vaultPasswordExists() && (
                <Input
                  type="password"
                  aria-label="Destination vault password"
                  placeholder="Destination vault password (if different)"
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                />
              )}
            </>
          )}
          {summary && (
            <p role="status" className="text-sm">
              {summary}
            </p>
          )}
          {error && (
            <p role="alert" className="text-sm text-destructive">
              {error}
            </p>
          )}
          <Button
            disabled={busy || !bytes || (!!info?.vault && !password)}
            onClick={() => void run()}
          >
            {busy ? "Verifying / importing…" : "Import all found notes"}
          </Button>
          <p className="text-xs text-muted-foreground">
            To restore an encrypted folder backup, extract its
            notenoid.encrypted folder, select its parent as storage, and enter
            the original seed password. That restores settings and vault
            credentials too—without setting them up again. Private app storage
            can be deleted by uninstalling; keep an external recovery copy.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
