# Notenoid v16.0

Android version code **160** · Package **com.notes.app**

## Encrypted local storage

- App-managed notes, attachments, logical filenames, configuration, preferences and credential records are encrypted locally using AES-256-GCM.
- First-run seed-password setup follows storage selection/permission handling. The seed wraps a random storage key; it is not stored directly.
- Automatic unlock uses Android Keystore-protected key storage or a non-extractable browser CryptoKey. A persistence failure warns explicitly rather than saving a plaintext key or losing encrypted data.
- Existing plaintext notes are copied, encrypted and verified before originals are removed. Interrupted cleanup resumes from an authenticated checkpoint.
- External encrypted folders are recognized whether the user chooses their parent or the container itself. Seed recovery restores settings and existing vault credentials without re-running vault setup.
- Explicit seed recovery is available after a remembered-key error.
- Encrypted indexes/objects authenticate before use. Corrupt headers, modified objects, and concurrent checkpoint forks are not silently accepted.

## Independent vault protection

- Vault note files and attachments have their own inner AES-256-GCM layer with a separate random key.
- Existing password/security-answer derivations migrate to key-wrapping records without asking users to change their credentials.
- Current-password changes, either-answer recovery, question replacement and vault import/recovery preserve the underlying vault key/content.
- Vault locking flushes saves first and clears vault models, key references and repository media URLs.
- Vault detection uses the actual frontmatter parser: quoted booleans are handled correctly, and a sample `vaulted: true` line in note body text cannot accidentally vault a note.

## Backups and imports

- Ordinary ZIP exports remain readable and never request the seed password. Vault notes, including vaulted trash, are included after vault-password verification; they are not silently skipped.
- Readable export warns that even vault content in that ZIP is unencrypted.
- A separately labelled encrypted recovery copy includes the entire current storage state. It is copied as a consistent, authenticated snapshot under the storage write mutex.
- Readable imports re-encrypt data automatically, verify source/destination vault credentials, preserve existing destination credentials, retain custom frontmatter, and reject unsafe or oversized archives.
- Individual attachment downloads decrypt the original stored bytes.
- `scripts/recover.py` independently recovers the storage format without importing app code. It can recover ordinary files with the seed and vault files with the additional vault password.

## Hardening and regression fixes

- Unsafe raw Markdown HTML is sanitized in preview.
- Browser history handling uses one app guard, preventing multi-layer UI closures from queuing Back calls that leave the app.
- Same-origin second writers are refused where Web Locks are available. Cross-device/profile simultaneous editing remains unsupported.
- Native encrypted-file writes synchronize temporary file data and refuse unsafe overwrite fallback after rename failure.
- Android disables app backup and requests screenshot/recents protection; device behavior still requires physical testing.
- TypeScript validation remains enabled. The exact-word edit/preview selection flow remains covered by desktop and touch regression tests.

## Read before using

See `VALIDATION-V16.md`, `docs/SECURITY.md` and `docs/RECOVERY.md`. Back up and verify recovery before migrating irreplaceable notes. This is not an independent security audit, not a physical Android certification, and not an assurance of unhackability or zero bugs. Existing signing identity is retained for compatibility; its source-distributed key is not a private production key. No signing keystore is included in the source bundle.
