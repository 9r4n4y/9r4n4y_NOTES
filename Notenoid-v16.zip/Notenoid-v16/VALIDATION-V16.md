# Notenoid v16 validation

Validation date: **28 September 2026**. These results describe the tests actually run, not a claim that all possible bugs or device combinations have been ruled out.

## Final build results

| Check | Result |
|---|---|
| TypeScript (`npx tsc --noEmit`) | Passed |
| Known production dependency advisories (`npm audit --omit=dev`) | 0 reported at check time; not a proof of absence of vulnerabilities |
| Production static webpack build with type checking | Passed |
| Android resource compile/link, Java compile, DEX generation, alignment | Passed |
| APK signature verification | Passed, signature schemes 2 and 3 |
| App metadata | `com.notes.app`, version name `16.0`, version code `160`, min API 24, target API 34 |
| APK vs production-tested web assets | All **190** asset files match byte-for-byte |
| APK ZIP integrity | Passed |
| Production preview server | HTTP 200 on port 3001 |
| Test-data/signing-password scan of shipped web assets | No synthetic fixture passwords/data or keystore password found |

The complete final test sequence was run against the final production web assets, not just a development build.

## Storage/security service tests — 46 scenario groups passed

`npm run test:security` uses an in-memory filesystem adapter and a test IndexedDB implementation, exercising the production encryption, preferences, repository, vault and backup code.

Coverage includes:

- Encryption and verified migration of ordinary notes, configuration, media and sensitive preferences.
- Absence of fixture plaintext contents, logical names, preferences and seed password in raw physical ciphertext files.
- Remembered-key reopening, loss of remembered key, wrong seed, seed recovery and restored preferences.
- Separate vault encryption for note content and attachment bytes; locked reads are denied and scans use placeholders.
- Wrong/current password handling, password changes, either-answer reset, question replacement and retired-answer rejection.
- Credential migration using existing verifiers without changing existing passwords/answers.
- Readable exports that contain ordinary and vault files/attachments without a seed prompt; wrong vault passwords stop export.
- Full encrypted recovery copies, authenticated coherent snapshots during queued saves, and refusal to copy damaged current objects.
- Readable imports into new and existing vaults, differing source/destination passwords, preserved destination credentials, restored folder/label configuration and exact media bytes.
- Rename, archive, duplication, deletion, concurrent saves and path-traversal rejection.
- Migration interruption/resume, failed index commits retaining prior committed data, object/header/index tampering and checkpoint-fork rejection.
- Ordinary-to-vault and vault-to-ordinary moves retaining content and media.
- Reserved-looking virtual names, protection of an unrelated same-named physical folder, and recognizing the encrypted directory itself.
- Vault notes remain exported even when ordinary archive filtering is disabled; vaulted trash is included.
- A `vaulted: true` line in body text is not interpreted as metadata; quoted-boolean frontmatter is handled consistently.
- Unknown custom frontmatter survives readable import.
- Failure to persist a remembered device key warns without losing encrypted data or writing a plaintext key.
- Explicit seed recovery replaces a corrupted remembered key.

## Production touch-browser security/UI tests — 10 groups passed

Chromium, mobile/touch emulation, **393×851** viewport, isolated contexts:

1. Downloaded an individual vault attachment and verified the original bytes.
2. Created a vault, created a protected note, uploaded media, locked, reloaded and verified automatic storage unlock did not unlock the vault.
3. Rejected a wrong export password, then downloaded a readable ZIP containing the vault note and exact uploaded media; no seed prompt.
4. Scanned actual browser OPFS file contents/names and localStorage for fixture plaintext secrets; none were present.
5. Downloaded an encrypted recovery ZIP without seed/vault prompts; verified container presence and no fixture plaintext.
6. Deleted remembered-key storage while retaining encrypted OPFS files, recovered with the seed, and unlocked using the original vault credentials without setup.
7. Opened a second same-origin writer and verified the Web Locks guard refused it without changing data.
8. Rejected a wrong source vault import password; successfully imported note/media/credentials into a fresh encrypted store and unlocked with the original password.
9. Reset the imported vault password using a security answer and retained access through reload.
10. Changed the password in Settings, replaced questions, rejected the retired answer and recovered with the new answer.

No uncaught browser page errors were recorded. Expected wrong-credential/refused-writer cases were deliberate tests, not ignored failures.

## Independent recovery — passed

`python scripts/recover.py` is a separate implementation using Python's `hashlib.pbkdf2_hmac` and `cryptography` AESGCM, not app imports or test hooks. Tests verified:

- Seed-only recovery of ordinary files/preferences from a copied physical encrypted folder.
- Vault objects remain separately encrypted without the vault password.
- Seed plus the separate vault password recovers exact vault text and binary media.
- Wrong seed returns failure without creating output.

The fixture is synthetic; no real user notes were used.

## Other regression checks

- **30** existing repository/storage-naming assertions passed, including attachment preservation and collision handling.
- **40** edit/preview mode transfers passed: 20 selected-source cases across desktop 1280×900 and touch 393×851, each tested in both directions. Includes first/last words, duplicates, multiline text, emphasis, links, inline/fenced code, tasks, tables and Hindi marks. Checks exact identity, pending highlight, centering, pulse duration and source preservation.
- Smoke tests passed for bold/italic/link rendering, tables, KaTeX, code copying, task updates, save/reload and unsafe iframe/script removal from preview.

Concise raw results are under `test/results/`.

## Important limits

- **No physical Android device or Android emulator was available.** Native Keystore behavior, Android filesystem permissions, actual OEM WebViews, install/update/reinstall behavior, Android download integration and true device crashes/power loss were not runtime-tested. Native code compiled and APK signatures verified; that is not equivalent to device testing.
- This is **not an independent cryptographic/security audit**. The test suite cannot prove unhackability, absence of all bugs, resistance to every malicious archive, or success with arbitrarily large collections.
- Browser automatic unlock relies on browser-profile security; non-extractability does not block malicious same-origin code from using a stored CryptoKey.
- Automatic unlock exposes ordinary notes to anyone able to operate the app. Readable exports, recovered plaintext, explicit attachment downloads and clipboard copies are not protected by storage encryption.
- Either-answer vault recovery is only as strong as its weaker answer. Use long non-obvious answers and strong unique passwords.
- Deleting plaintext originals does not guarantee forensic erasure, especially on flash media or from older backups. App-private data can itself be removed by uninstalling/clearing storage.
- Imports validate and authenticate before normal writes, but a genuine storage failure during a multi-file import can require inspection/retry. Such failures are reported rather than presented as successful; universal whole-import/power-loss atomicity is not claimed.
- Multi-device/profile simultaneous editing and rollback protection are not provided. Two encrypted checkpoints are retained; older checkpoints can retain previous/deleted content.
- The delivered APK retains the original source-distributed signing identity for update compatibility. Its signing keystore/private key was not secret in the original source. Install only trusted APKs; use a properly managed private signing identity and a planned migration for production distribution. No signing keystore is included in this source ZIP.

Certificate SHA-256: `adebabf1676d88d4b8ed1caea8a068e86612a058dc498299558a2455393a6c63`.

## Before using real data

Back up first. Test installation, migration, seed recovery from a copied external folder, vault unlock/reset/question changes, readable and encrypted exports, import, permissions, media downloads, background/resume and keyboard/display behavior on your Android device. Verify the recovered content and media before deleting any backup. Do not uninstall solely to bypass a signature mismatch.
