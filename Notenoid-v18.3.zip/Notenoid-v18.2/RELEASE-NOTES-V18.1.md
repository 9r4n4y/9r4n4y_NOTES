# Notenoid v18.1

Android package `com.notes.app` · version code 181.

## Search fixes

- In-note search now has one source-offset result list shared by the result counter, Preview highlights, and Edit selections. Next/previous arrows no longer use an unrelated rendered-DOM ordinal.
- Search navigation is verified for inline code, fenced backtick code, tilde-fenced code, ordinary text, repeated hits, and hidden fence-language labels. The hidden label remains a literal Markdown-source match, but it cannot shift a visible result to the wrong code block.
- Edit-mode navigation measures the target range with the editor's text-layout mirror, so wrapped paragraphs and long code lines scroll to the exact occurrence rather than estimating a row from source line count.
- Matching and card highlights preserve original UTF-16 offsets through NFKC normalization, including full-width compatibility characters and composed/decomposed accents.
- Global search continues to cover titles, body source/rendered text, checklist text, labels, folder names, and attachment names. Fenced-code bodies are retained in card previews and highlighted when they match.

## Large-note and WebView improvements

- Preview source maps are parsed once per preview-DOM revision and cached as an indexed text/source map. Repeated range lookups reuse it; source-map caches invalidate after relevant text/DOM changes.
- Search-arrow navigation updates only the active match and scroll position. It does not rebuild every mark or reparse every map on each arrow press; match ranges are cached for the current draft/query.
- Word hit-testing uses cached text-node ranges and glyph geometry instead of `caretRangeFromPoint` / `caretPositionFromPoint`. Scroll-anchor capture also avoids those browser-specific caret APIs.
- Markdown-fence source anchors snap to visible code text, preventing Preview/Edit drift at fence delimiters.

## Validation

- `npm run typecheck` — PASS.
- `npm run test:search-unit` — PASS (inline/fenced Markdown, Unicode offsets, code preview, and large-note offsets).
- `TEST_URL=http://localhost:3000 npm run test:search` — PASS (Preview arrows, Edit selection/scroll, and global code/checklist search).
- `node test/wordtap-e2e.mjs` — PASS with both caret APIs disabled (Range-based word hit-testing).
- `node test/selection-e2e.mjs` — PASS on desktop and touch layouts.
- `node test/preview-scroll-e2e.mjs` — PASS; paragraph, table, and fenced-code anchors remain within 12 px.

## Build

The APK uses version name **18.1** and version code **181**. This release uses a new signing identity, so Android will reject it as an in-place update over an existing v18 installation. Back up/export notes and attachments before uninstalling v18; uninstalling may erase app-private data. Keep the v18.1 keystore and password for future updates. See [`docs/BUILD.md`](docs/BUILD.md) for build prerequisites and signing details.
