# Notenoid v18.2
1. Edit-mode search highlights: boxes measured from the editor's exact character mirror and painted above the textarea (click-through), so they always show. Preview search untouched.
2. Big-note speed: preview opens from a first slice and streams the rest after paint; search hits beyond the slice pull the slice forward, so results are never lost. Character source map no longer diffs the whole document (line-wise fast path). Attachments load progressively, deduplicated, images decode async. No quality/data changes.
