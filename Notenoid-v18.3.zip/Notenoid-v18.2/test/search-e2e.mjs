import { chromium } from "@playwright/test";
import assert from "node:assert/strict";

const browser = await chromium.launch({ headless: true });
const errors = [];
const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
page.on("pageerror", (error) => errors.push(error.message));

await page.goto(process.env.TEST_URL || "http://localhost:3000");
await page.getByText("Use in-app local storage").click();
await page.getByLabel("Seed password", { exact: true }).fill("amber lantern meadow orbit copper river");
await page.getByLabel("Confirm seed password", { exact: true }).fill("amber lantern meadow orbit copper river");
await page.getByRole("checkbox").check();
await page.getByRole("button", { name: "Encrypt local storage", exact: true }).click();
await page.getByText("New note — tap to write").click();
await page.getByRole("button", { name: "Edit Markdown", exact: true }).click();

const paragraphs = Array.from(
  { length: 36 },
  (_, i) => `Paragraph ${i + 1} keeps the search fixture long enough to test exact scrolling across wrapped preview and editor text.`,
).join("\n\n");
const source = [
  "# Search fixture",
  "",
  paragraphs,
  "",
  "Inline `SeekNeedle` occurrence.",
  "",
  "```SeekNeedle",
  "const fenced = 'seekneedle';",
  "```",
  "",
  "~~~js",
  "console.log('SEEKNEEDLE');",
  "~~~",
  "",
  "Plain seekneedle occurrence.",
  "",
  "- [ ] globalItemNeedle",
].join("\n");
const ta = page.locator("textarea.md-textarea");
await ta.fill(source);
await page.getByRole("button", { name: "Preview rendered note", exact: true }).click();
await page.locator(".md-preview").waitFor();
await page.waitForTimeout(800); // let the first draft save/materialize before opening the find bar

// Note-level search covers source literals, including inline/fenced code.
await page.getByRole("button", { name: "Search in note", exact: true }).click();
const find = page.getByLabel("Find in note", { exact: true });
await find.fill("seekneedle");
await page.getByText("1/5", { exact: true }).waitFor();
await page.waitForTimeout(300);

const marks = page.locator(".md-preview mark.search-hit");

assert.equal(await marks.count(), 4, "the unrendered code-fence language label is counted but is not falsely highlighted");
const indices = await marks.evaluateAll((els) => [...new Set(els.map((el) => Number(el.dataset.searchIndex)))].sort((a, b) => a - b));
assert.deepEqual(indices, [0, 2, 3, 4], "visible matches keep their original source-order result indexes");

const next = page.getByRole("button", { name: "Next match", exact: true });
const counter = async (expected) => page.getByText(expected, { exact: true }).waitFor();
const activeIndex = async () => page.locator(".md-preview mark.search-hit-active").first().getAttribute("data-search-index");
const activeIsVisible = async () => {
  await page.waitForTimeout(450);
  return page.locator(".md-preview mark.search-hit-active").first().evaluate((el) => {
    const r = el.getBoundingClientRect();
    const c = el.closest(".md-editor").querySelector(".overflow-y-auto").getBoundingClientRect();
    return r.bottom > c.top && r.top < c.bottom;
  });
};

// Result 1 is the visible inline-code hit. Result 2 is the invisible fence
// info label; it must not activate a later rendered match by DOM ordinal.
assert.equal(await activeIndex(), "0");
await next.click();
await counter("2/5");
assert.equal(await page.locator(".md-preview mark.search-hit-active").count(), 0, "hidden Markdown syntax has no rendered mark");
await next.click();
await counter("3/5");
assert.equal(await activeIndex(), "2");
assert.equal(await page.locator(".md-preview mark.search-hit-active").first().evaluate((el) => !!el.closest("pre")), true, "arrow lands on the fenced code body");
assert.equal(await activeIsVisible(), true, "active fenced-code result scrolls into view");

await next.click();
await counter("4/5");
assert.equal(await activeIndex(), "3");
assert.equal(await page.locator(".md-preview mark.search-hit-active").first().evaluate((el) => !!el.closest("pre")), true, "tilde-fenced code is searchable too");
await next.click();
await counter("5/5");
assert.equal(await activeIndex(), "4", "ordinary text follows both code forms");
await next.click();
await counter("1/5");
assert.equal(await activeIndex(), "0", "arrow navigation wraps to the first inline-code hit");

// Edit mode selects the exact raw-source occurrence and uses measured text
// geometry for scrolling (including wrapped lines), not line-number estimates.
await page.getByRole("button", { name: "Edit Markdown", exact: true }).click();
await ta.waitFor();
await next.click();
await counter("2/5");
const hiddenFenceOffset = source.indexOf("SeekNeedle", source.indexOf("```"));
assert.equal(await ta.evaluate((el) => el.selectionStart), hiddenFenceOffset);
assert.equal(await ta.evaluate((el) => el.selectionEnd), hiddenFenceOffset + "seekneedle".length);
await next.click();
await counter("3/5");
const fencedBodyOffset = source.indexOf("seekneedle", source.indexOf("const fenced"));
assert.equal(await ta.evaluate((el) => el.selectionStart), fencedBodyOffset);
assert.ok(await page.locator(".md-editor .overflow-y-auto").evaluate((el) => el.scrollTop > 0), "edit-mode arrow scrolls to a later code match");

// Global/list search must find and visibly highlight code-block and checklist
// text in the same note instead of filtering the note out or hiding the hit.
await page.getByRole("button", { name: "Back to notes", exact: true }).click();
const globalSearch = page.getByLabel("Search notes", { exact: true });
await globalSearch.fill("seekneedle");
await page.locator(".note-card").first().waitFor();
assert.equal(await page.locator(".note-card").count(), 1, "global search returns the note containing code hits");
assert.ok(await page.locator(".note-card mark.search-chip").count() >= 4, "global card preview highlights code and ordinary text");
await globalSearch.fill("globalItemNeedle");
assert.ok(await page.locator(".note-card mark.search-chip").count() >= 1, "global search includes checklist body text");
await globalSearch.fill("does-not-exist-xyz");
await page.getByText('Nothing matches "does-not-exist-xyz" in this view', { exact: true }).waitFor();

assert.deepEqual(errors, [], "no client runtime errors");
console.log("PASS: note search arrows land on inline/fenced/tilde code and plain text; edit scrolling and global code/checklist search verified.");
await browser.close();
