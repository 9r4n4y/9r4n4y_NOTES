import assert from "node:assert/strict";
import {
  findMarkdownMatchRanges,
  findMarkdownMatches,
  markdownToPlain,
} from "../src/core/markdown";

const markdown = [
  "inline `SpiralNeedle`",
  "```SpiralNeedle",
  "const SpiralNeedle = 1;",
  "```",
  "~~~ts",
  "console.log('spiralneedle');",
  "~~~",
  "ordinary spiralneedle",
].join("\n");

const matches = findMarkdownMatchRanges(markdown, "spiralneedle");
assert.equal(matches.length, 5, "inline code, fence label, fenced body, tilde-fenced body and ordinary text are all literal matches");
assert.deepEqual(
  matches.map(({ start, end }) => markdown.slice(start, end).toLocaleLowerCase()),
  ["spiralneedle", "spiralneedle", "spiralneedle", "spiralneedle", "spiralneedle"],
);
assert.deepEqual(findMarkdownMatches("aa AA", "a"), [0, 1, 3, 4]);
assert.deepEqual(findMarkdownMatchRanges("aaaa", "aa"), [
  { start: 0, end: 2 },
  { start: 2, end: 4 },
]);

const fullWidth = "before ＮＯＴＥ after";
const fullWidthHit = findMarkdownMatchRanges(fullWidth, "note")[0];
assert.deepEqual(fullWidthHit, { start: 7, end: 11 }, "NFKC offsets still address the original source");
assert.equal(fullWidth.slice(fullWidthHit.start, fullWidthHit.end), "ＮＯＴＥ");

const composed = "Café and Cafe\u0301";
const accentHits = findMarkdownMatchRanges(composed, "café");
assert.equal(accentHits.length, 2, "composed and decomposed accents compare equally");
assert.equal(composed.slice(accentHits[0].start, accentHits[0].end), "Café");
assert.equal(composed.slice(accentHits[1].start, accentHits[1].end), "Cafe\u0301");

const ligature = "x ﬃ y";
const ligatureHit = findMarkdownMatchRanges(ligature, "fi")[0];
assert.deepEqual(ligatureHit, { start: 2, end: 3 }, "a compatibility expansion maps back to its complete source grapheme");

const plain = markdownToPlain("Before `inline-code`.\n\n```js\nconst fencedCode = 42;\n```\n\nAfter.");
assert.match(plain, /inline-code/);
assert.match(plain, /const fencedCode = 42;/, "global card previews keep searchable fenced-code content");
assert.doesNotMatch(plain, /```js/, "fence label is presentation syntax, not body text");

const large = `header\n${"filler text ".repeat(80_000)}lastUniqueNeedle`;
const last = findMarkdownMatchRanges(large, "lastUniqueNeedle")[0];
assert.equal(large.slice(last.start, last.end), "lastUniqueNeedle", "large-note offsets remain exact");

console.log("PASS: Markdown search ranges, inline/fenced code, Unicode offsets, code previews, and large-note lookup.");
