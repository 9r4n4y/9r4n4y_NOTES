# Notenoid v18.1 — validation record

## Release identity

- Web/source package: `notenoid@18.1.0`.
- Android package: `com.notes.app`, version name **18.1**, version code **181**, minimum API 24, target API 34.
- APK: `Notenoid-v18.1.apk` — **3.7 MB**, signed and verified; SHA-256 `8b92a99e8a10289923136f18d0660766da8de6b007e20302c4fe8b827d7aaeac`.
- Signing: alias `notes` in `keystore/v18.1-release.keystore`; SHA-256 certificate fingerprint `d6072475145f1e19d8f3a87f48ece65cfb34bae355af4fde4f394eb60f4e606e`.
- The v18.1 signer differs from v18's signer. Android will not accept this as an in-place update over v18. Back up/export notes and attachments before uninstalling; removing the old app may erase Android-private app data.

## Search and selection

- `npm run typecheck` — PASS.
- `npm run test:search-unit` — PASS (inline/fenced Markdown, Unicode source offsets, fenced-code previews, and large-note ranges).
- `TEST_URL=http://localhost:3000 node test/search-e2e.mjs` — PASS (next/previous through inline/backtick/tilde code and plain text, edit selection/scroll, and global code/checklist search).
- `node test/wordtap-e2e.mjs` — PASS (instant and Done-confirmed flows; both caret APIs patched to throw).
- `node test/selection-e2e.mjs` — PASS (desktop and touch layouts across ten source offsets, including code, tables, lists, links, and Unicode).
- `node test/preview-scroll-e2e.mjs` — PASS; paragraph, table, and fenced-code anchors each had **0 px** viewport drift.
- `node test/smoke.mjs` — PASS (rendering, KaTeX, code copy, checkbox/source update, save/reload; no runtime errors).
- Targeted ESLint on changed search/selection files — **0 errors**; 15 existing unused-disable warnings remain.

## Production export and Android toolchain

- `bash scripts/build_web_export.sh` — PASS; optimized static export generated and copied to `android/assets/`.
- Android SDK platform 34 and build-tools 35.0.0 installed; JDK 17 used.
- `npm run build:apk` — PASS; `apksigner verify`, `zipalign -c -v 4`, package/version metadata inspection, and ZIP integrity checks all pass.
