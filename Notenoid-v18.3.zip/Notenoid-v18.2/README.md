# Notenoid v18.1

Local-first, cross-platform Markdown notes with attachments, encrypted storage, and a separately protected vault.

- **Android app:** version 18.1, version code 181, package `com.notes.app`. v18.1 uses a new signing key; Android won't install it over v18 in place. Back up notes/attachments before uninstalling the old app (private app data may be removed), then install v18.1.
- **Web app:** the same Next.js/React source and local-first storage model.
- **Storage:** encrypted at rest after setup; no account or server is required for notes.

## v18.1 search and navigation fixes

See [`RELEASE-NOTES-V18.1.md`](RELEASE-NOTES-V18.1.md) for the release summary.

- Note search uses one source-offset match list in edit and preview, so arrow navigation remains aligned across inline code, fenced backtick/tilde code, and ordinary Markdown.
- Preview marks are associated with source offsets; hidden fence labels no longer shift the active result to the wrong rendered match. Edit-mode jumps use measured character geometry rather than line-number estimates.
- Preview source maps are parsed and indexed once per DOM revision, then reused for range lookup and word selection. Map caches are invalidated by relevant DOM mutations; arrow presses no longer walk/parse the full preview.
- Word hit-testing uses cached `Range` glyph geometry instead of `caretRangeFromPoint` / `caretPositionFromPoint` quirks.
- Global search and card highlights now find and visibly include fenced-code content; matching/highlighting share Unicode NFKC-aware source offsets.

The v18.0 features are summarized in [`RELEASE-NOTES-V18.md`](RELEASE-NOTES-V18.md).

## Build

See [`docs/BUILD.md`](docs/BUILD.md). The source ZIP includes the build scripts and Android shell. Build a web app with `npm ci && npm run build`; create the Android APK with the documented Android SDK prerequisites and `npm run build:apk`.

## Tests

The v18.1 search validation is recorded in [`VALIDATION-V18.1.md`](VALIDATION-V18.1.md). Relevant commands include:

```sh
npm run typecheck
npm run test:search-unit
TEST_URL=http://localhost:3000 npm run test:search
TEST_URL=http://localhost:3000 node test/selection-e2e.mjs
TEST_URL=http://localhost:3000 node test/preview-scroll-e2e.mjs
```

The browser tests require a running dev server and Playwright Chromium. They exercise inline/fenced-code search arrows, exact edit-mode scrolling, global code/checklist search, and Preview/Edit position retention in long Markdown.

## Security and backups

Readable exports are intentionally portable, plain ZIPs; treat them as sensitive files. A ZIP is not encrypted just because vault notes came from a protected vault. For disaster recovery, the separate encrypted-container recovery workflow is documented in [`docs/RECOVERY.md`](docs/RECOVERY.md). Keep external backups before uninstalling or changing devices.
