import { diffChars } from "diff";

/** Map each UTF-16 character of rendered/transformed text to its source range.
 * Inserted characters have no identity: never guess another matching word. */
export function sourceMap(source: string, displayed: string): [number, number][] {
  const map: [number, number][] = [];
  // Fast path 1: identical text (the overwhelmingly common case).
  if (source === displayed) {
    for (let i = 0; i < displayed.length; i++) map.push([i, i + 1]);
    return map;
  }
  // Fast path 2: same line structure (math/attachment rewrites keep lines).
  // Identical lines map 1:1; only lines that changed are diffed, so a huge
  // note never pays for a whole-document character diff.
  const sl = source.split("\n");
  const dl = displayed.split("\n");
  if (sl.length === dl.length && source.length > 2000) {
    let offset = 0;
    for (let i = 0; i < sl.length; i++) {
      const a = sl[i], b = dl[i];
      if (a === b) {
        for (let k = 0; k < b.length; k++) map.push([offset + k, offset + k + 1]);
      } else {
        appendDiff(map, a, b, offset);
      }
      offset += a.length;
      if (i < sl.length - 1) { map.push([offset, offset + 1]); offset++; }
    }
    return map;
  }
  appendDiff(map, source, displayed, 0);
  return map;
}

function appendDiff(map: [number, number][], source: string, displayed: string, base: number): void {
  let offset = base;
  for (const part of diffChars(source, displayed)) {
    if (part.removed) { offset += part.value.length; continue; }
    for (let i = 0; i < part.value.length; i++) {
      map.push(part.added ? [-1, -1] : [offset, offset + 1]);
      if (!part.added) offset++;
    }
  }
}

type Ast = { type: string; value?: string; tagName?: string; properties?: Record<string, unknown>; children?: Ast[]; position?: { start: { offset?: number }; end: { offset?: number } } };
/** Runs after raw HTML parsing. Text leaves retain the parser's exact offsets. */
export function rehypeExactSelection(options: { source: string }) {
  return (tree: Ast, file: { value: unknown }) => {
    const input = String(file.value);
    const inputMap = sourceMap(options.source, input);
    const visit = (parent: Ast) => {
      if (!parent.children || ["script", "style", "math", "svg"].includes(parent.tagName ?? "")) return;
      parent.children = parent.children.map((child) => {
        if (child.type !== "text") { visit(child); return child; }
        let start = child.position?.start?.offset;
        let end = child.position?.end?.offset;
        if (start == null && end != null && child.value && input.slice(end - child.value.length, end) === child.value) {
          start = end - child.value.length;
        }
        if (start == null && parent.tagName === "code") {
          start = parent.position?.start?.offset;
          end = parent.position?.end?.offset;
          // Fenced code has no text-leaf position. Exclude the opening fence
          // and language label before aligning, even when they repeat the code.
          if (start != null && end != null && /^ {0,3}(`{3,}|~{3,})/.test(input.slice(start, end))) {
            const newline = input.indexOf("\n", start);
            start = newline < 0 ? end : newline + 1;
          }
        }
        if (start == null || end == null || !child.value?.trim()) return child;
        const raw = input.slice(start, end);
        const local = sourceMap(raw, child.value);
        const mapped = local.map(([a, b]) => a < 0 ? [-1, -1] : [inputMap[start + a]?.[0] ?? -1, inputMap[start + b - 1]?.[1] ?? -1]);
        return { type: "element", tagName: "span", properties: { "data-exact-map": JSON.stringify(mapped) }, children: [child] };
      });
    };
    visit(tree);
  };
}

type SourceRange = [number, number];
interface TextRun {
  node: Text;
  start: number;
  end: number;
  order: number;
}
interface IndexedSpan {
  element: HTMLElement;
  map: SourceRange[];
  /** Map indexes for source-backed characters, monotonically source ordered. */
  valid: number[];
  runs: TextRun[];
  min: number;
  max: number;
}
interface TextRecord extends TextRun {
  span: IndexedSpan;
}
interface PreviewIndex {
  spans: IndexedSpan[];
  sourceSpans: IndexedSpan[];
  prefixMax: number[];
  records: TextRecord[];
  byNode: WeakMap<Text, TextRecord>;
  byElement: WeakMap<HTMLElement, IndexedSpan>;
}

export interface PreviewTextSegment {
  node: Text;
  start: number;
  end: number;
  /** Stable DOM-order key, used to wrap a batch without invalidating offsets. */
  order: number;
}
export interface PreviewTextPosition {
  node: Text;
  offset: number;
}

// A rendered note's source maps are immutable between content/decoration DOM
// changes. Cache parsed maps and text-node runs per preview root; repeated
// range lookups are logarithmic instead of rescanning the whole DOM/JSON map.
const previewIndexes = new WeakMap<HTMLElement, PreviewIndex>();
const previewObservers = new WeakMap<HTMLElement, MutationObserver>();

function installRootObserver(root: HTMLElement): void {
  if (previewObservers.has(root) || typeof MutationObserver === "undefined") return;
  const observer = new MutationObserver(() => previewIndexes.delete(root));
  observer.observe(root, {
    subtree: true,
    childList: true,
    characterData: true,
    attributes: true,
    attributeFilter: ["data-exact-map"],
  });
  previewObservers.set(root, observer);
}

/** Explicit invalidation hook for DOM decorators that mutate a preview. */
export function invalidatePreviewIndex(root: HTMLElement): void {
  previewIndexes.delete(root);
}

function parseMap(span: HTMLElement): SourceRange[] | null {
  try {
    const parsed: unknown = JSON.parse(span.dataset.exactMap ?? "");
    if (!Array.isArray(parsed)) return null;
    return parsed.map((entry): SourceRange => {
      if (!Array.isArray(entry) || entry.length < 2) return [-1, -1];
      const start = Number(entry[0]);
      const end = Number(entry[1]);
      return Number.isFinite(start) && Number.isFinite(end) ? [start, end] : [-1, -1];
    });
  } catch {
    return null;
  }
}

function buildPreviewIndex(root: HTMLElement): PreviewIndex {
  const spans: IndexedSpan[] = [];
  const records: TextRecord[] = [];
  const byNode = new WeakMap<Text, TextRecord>();
  const byElement = new WeakMap<HTMLElement, IndexedSpan>();

  for (const element of root.querySelectorAll<HTMLElement>("[data-exact-map]")) {
    const map = parseMap(element);
    if (!map?.length) continue;
    const valid: number[] = [];
    let min = Number.POSITIVE_INFINITY;
    let max = Number.NEGATIVE_INFINITY;
    let previous = Number.NEGATIVE_INFINITY;
    let ordered = true;
    for (let i = 0; i < map.length; i++) {
      const [start, end] = map[i];
      if (start < 0 || end <= start) continue;
      if (start < previous) ordered = false;
      previous = start;
      valid.push(i);
      min = Math.min(min, start);
      max = Math.max(max, end);
    }
    if (!valid.length || !ordered) continue;

    const span: IndexedSpan = { element, map, valid, runs: [], min, max };
    let mapOffset = 0;
    const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      const text = node as Text;
      if (!text.length) continue;
      const run: TextRun = { node: text, start: mapOffset, end: mapOffset + text.length, order: records.length };
      const record: TextRecord = { ...run, span };
      span.runs.push(run);
      records.push(record);
      byNode.set(text, record);
      mapOffset += text.length;
    }
    // Corrupt/stale maps should fail closed, never map text to another source
    // location. A map may span several nodes (e.g. after search marks), but its
    // aggregate text length must still match the encoded UTF-16 map length.
    if (mapOffset !== map.length) continue;
    spans.push(span);
    byElement.set(element, span);
  }

  const sourceSpans = [...spans].sort((a, b) => a.min - b.min || a.max - b.max);
  const prefixMax: number[] = [];
  let greatest = Number.NEGATIVE_INFINITY;
  for (const span of sourceSpans) {
    greatest = Math.max(greatest, span.max);
    prefixMax.push(greatest);
  }
  return { spans, sourceSpans, prefixMax, records, byNode, byElement };
}

function getPreviewIndex(root: HTMLElement): PreviewIndex {
  installRootObserver(root);
  const cached = previewIndexes.get(root);
  if (cached) return cached;
  const index = buildPreviewIndex(root);
  previewIndexes.set(root, index);
  return index;
}

function firstCandidateSpan(index: PreviewIndex, sourceOffset: number): number {
  let low = 0;
  let high = index.prefixMax.length;
  while (low < high) {
    const mid = (low + high) >>> 1;
    if (index.prefixMax[mid] < sourceOffset) low = mid + 1;
    else high = mid;
  }
  return low;
}

function runAt(span: IndexedSpan, mapIndex: number): TextRun | null {
  let low = 0;
  let high = span.runs.length;
  while (low < high) {
    const mid = (low + high) >>> 1;
    if (span.runs[mid].end <= mapIndex) low = mid + 1;
    else high = mid;
  }
  const run = span.runs[low];
  return run && mapIndex >= run.start && mapIndex < run.end ? run : null;
}

function validIndexAtOrAfter(span: IndexedSpan, sourceOffset: number): number {
  let low = 0;
  let high = span.valid.length;
  while (low < high) {
    const mid = (low + high) >>> 1;
    if (span.map[span.valid[mid]][1] <= sourceOffset) low = mid + 1;
    else high = mid;
  }
  return low;
}

/** Map one source range to its exact rendered text fragments using the cached index. */
export function previewTextSegments(root: HTMLElement, start: number, end: number): PreviewTextSegment[] {
  if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) return [];
  const index = getPreviewIndex(root);
  const out: PreviewTextSegment[] = [];
  const firstSpan = firstCandidateSpan(index, start);

  for (let spanIndex = firstSpan; spanIndex < index.sourceSpans.length; spanIndex++) {
    const span = index.sourceSpans[spanIndex];
    if (span.min >= end) break;
    if (span.max < start) continue;
    let validAt = validIndexAtOrAfter(span, start);
    let last: PreviewTextSegment | null = null;
    while (validAt < span.valid.length) {
      const mapIndex = span.valid[validAt++];
      const [sourceStart, sourceEnd] = span.map[mapIndex];
      if (sourceStart >= end) break;
      if (sourceStart < start || sourceEnd > end) continue;
      const run = runAt(span, mapIndex);
      if (!run) continue;
      const offset = mapIndex - run.start;
      if (last && last.node === run.node && last.end === offset) {
        last.end++;
      } else {
        last = { node: run.node, start: offset, end: offset + 1, order: run.order };
        out.push(last);
      }
    }
  }
  out.sort((a, b) => a.order - b.order || a.start - b.start);
  return out;
}

export function previewRange(root: HTMLElement, start: number, end: number): Range | null {
  const segments = previewTextSegments(root, start, end);
  if (!segments.length) return null;
  const first = segments[0];
  const last = segments[segments.length - 1];
  try {
    const range = document.createRange();
    range.setStart(first.node, first.start);
    range.setEnd(last.node, last.end);
    return range;
  } catch {
    return null;
  }
}

/** Resolve a mapped DOM text position directly, without serializing/parsing a map. */
export function sourceOffsetAt(root: HTMLElement, node: Text, offset: number): number | null {
  const index = getPreviewIndex(root);
  const record = index.byNode.get(node);
  if (!record) return null;
  const local = Math.max(0, Math.min(offset, node.length));
  const mapIndex = record.start + Math.min(local, Math.max(0, node.length - 1));
  const entry = record.span.map[mapIndex];
  if (entry && entry[0] >= 0) return entry[0];

  // A renderer-added character may not have a source identity; pick the
  // closest source-backed neighbor within this same rendered text leaf.
  const validAt = validIndexAtOrAfter(record.span, mapIndex);
  const after = record.span.valid[validAt];
  const before = record.span.valid[validAt - 1];
  const afterEntry = after == null ? null : record.span.map[after];
  const beforeEntry = before == null ? null : record.span.map[before];
  if (afterEntry && afterEntry[0] >= 0 && after - mapIndex <= 8) return afterEntry[0];
  if (beforeEntry && beforeEntry[0] >= 0 && mapIndex - before <= 8) return beforeEntry[0];
  return null;
}

/** Read forward from an indexed text position without walking the root from its beginning. */
export function previewTextAfter(root: HTMLElement, node: Text, offset: number, within?: HTMLElement | null, limit = 160): string {
  const index = getPreviewIndex(root);
  const record = index.byNode.get(node);
  if (!record) return "";
  let out = node.data.slice(Math.max(0, Math.min(offset, node.length)));
  for (let i = record.order + 1; i < index.records.length && out.length < limit; i++) {
    const next = index.records[i].node;
    if (within && !within.contains(next)) break;
    out += ` ${next.data}`;
  }
  return out.slice(0, limit);
}

function distanceToRect(rect: DOMRect, x: number, y: number): number {
  const dx = x < rect.left ? rect.left - x : x > rect.right ? x - rect.right : 0;
  const dy = y < rect.top ? rect.top - y : y > rect.bottom ? y - rect.bottom : 0;
  return dx * dx + dy * dy;
}

function nextCodePoint(text: string, offset: number): number {
  if (offset >= text.length) return text.length;
  const point = text.codePointAt(offset) ?? 0;
  return offset + (point > 0xffff ? 2 : 1);
}
function previousCodePoint(text: string, offset: number): number {
  if (offset <= 0) return 0;
  const at = offset - 1;
  return at > 0 && text.charCodeAt(at) >= 0xdc00 && text.charCodeAt(at) <= 0xdfff ? at - 1 : at;
}

interface GlyphHit { offset: number; next: number; rect: DOMRect }
function glyphAt(node: Text, requested: number): GlyphHit | null {
  const value = node.data;
  let offset = Math.max(0, Math.min(requested, value.length));
  if (offset >= value.length) offset = previousCodePoint(value, value.length);
  if (offset > 0 && value.charCodeAt(offset) >= 0xdc00 && value.charCodeAt(offset) <= 0xdfff) offset--;
  // Newline and carriage-return positions do not paint a glyph consistently
  // across engines. Resolve them to the next painted character, or the prior
  // one at the end of a text node.
  while (offset < value.length && (value[offset] === "\n" || value[offset] === "\r")) offset++;
  if (offset >= value.length) {
    offset = previousCodePoint(value, value.length);
    while (offset > 0 && (value[offset] === "\n" || value[offset] === "\r")) offset = previousCodePoint(value, offset);
  }
  if (offset < 0 || offset >= value.length) return null;
  const next = nextCodePoint(value, offset);
  const range = document.createRange();
  try {
    range.setStart(node, offset);
    range.setEnd(node, next);
    const rects = range.getClientRects();
    const rect = Array.from(rects).find((candidate) => candidate.width > 0 && candidate.height > 0);
    return rect ? { offset, next, rect: rect as DOMRect } : null;
  } catch {
    return null;
  }
}

function pointOffsetInText(node: Text, x: number, y: number): number | null {
  const value = node.data;
  if (!value.length) return null;
  let best: GlyphHit | null = null;
  let bestDistance = Number.POSITIVE_INFINITY;
  const direction = getComputedStyle(node.parentElement ?? document.body).direction;
  const chooseSide = (hit: GlyphHit): number => {
    const center = hit.rect.left + hit.rect.width / 2;
    const onLeadingSide = direction === "rtl" ? x > center : x < center;
    return onLeadingSide ? hit.offset : hit.next;
  };

  // Text leaves are normally short. The direct geometry scan is especially
  // accurate for punctuation, graphemes and browser-specific line wrapping.
  if (value.length <= 1400) {
    for (let offset = 0; offset < value.length;) {
      const hit = glyphAt(node, offset);
      const next = nextCodePoint(value, offset);
      offset = Math.max(next, offset + 1);
      if (!hit) continue;
      const distance = distanceToRect(hit.rect, x, y);
      if (distance < bestDistance) {
        best = hit;
        bestDistance = distance;
        if (distance === 0) break;
      }
    }
    return best ? chooseSide(best) : null;
  }

  // Large fenced-code leaves are common in long notes. Locate the visual row
  // and then the nearest glyph with logarithmic Range measurements instead
  // of making thousands of per-character layout calls.
  let low = 0;
  let high = value.length;
  while (low < high) {
    const mid = previousCodePoint(value, (low + high) >>> 1);
    const hit = glyphAt(node, mid);
    if (!hit) { high = mid; continue; }
    if (hit.rect.bottom < y) low = Math.max(hit.next, mid + 1);
    else high = mid;
  }
  const first = glyphAt(node, low) ?? glyphAt(node, previousCodePoint(value, low));
  if (!first) return null;
  const rowTop = first.rect.top;

  let rowLow = low;
  let rowHigh = value.length;
  while (rowLow < rowHigh) {
    const mid = previousCodePoint(value, (rowLow + rowHigh) >>> 1);
    const hit = glyphAt(node, mid);
    if (!hit) { rowHigh = mid; continue; }
    if (hit.rect.top <= rowTop + 0.5) rowLow = Math.max(hit.next, mid + 1);
    else rowHigh = mid;
  }
  const rtl = direction === "rtl";
  let xLow = low;
  let xHigh = rowLow;
  while (xLow < xHigh) {
    const mid = previousCodePoint(value, (xLow + xHigh) >>> 1);
    const hit = glyphAt(node, mid);
    if (!hit || hit.rect.top > rowTop + 0.5) { xHigh = mid; continue; }
    const center = hit.rect.left + hit.rect.width / 2;
    if (rtl ? center > x : center < x) xLow = Math.max(hit.next, mid + 1);
    else xHigh = mid;
  }

  const candidates = [glyphAt(node, xLow), glyphAt(node, previousCodePoint(value, xLow)), first, glyphAt(node, previousCodePoint(value, rowLow))]
    .filter((hit): hit is GlyphHit => !!hit);
  for (const hit of candidates) {
    const distance = distanceToRect(hit.rect, x, y);
    if (distance < bestDistance) { best = hit; bestDistance = distance; }
  }
  return best ? chooseSide(best) : null;
}

function targetElement(target: EventTarget | null | undefined): Element | null {
  if (!target) return null;
  if (target instanceof Element) return target;
  return target instanceof Text ? target.parentElement : null;
}

/**
 * Resolve a pointer point to a text node by Range geometry. This deliberately
 * avoids caretRangeFromPoint/caretPositionFromPoint: code, inline spans and
 * whitespace gutters use the same deterministic hit-test on all WebViews.
 */
export function previewPositionAtPoint(root: HTMLElement, x: number, y: number, target?: EventTarget | null): PreviewTextPosition | null {
  const index = getPreviewIndex(root);
  const element = targetElement(target);
  const targetSpanElement = element?.closest<HTMLElement>("[data-exact-map]") ?? null;
  const targetBlock = element?.closest<HTMLElement>("[data-src-line]") ?? null;
  const preferredSpan = targetSpanElement ? index.byElement.get(targetSpanElement) : undefined;
  const spans = preferredSpan
    ? [preferredSpan]
    : targetBlock
      ? index.spans.filter((span) => targetBlock.contains(span.element))
      : index.spans;

  let bestNode: Text | null = null;
  let bestDistance = Number.POSITIVE_INFINITY;
  for (const span of spans) {
    for (const run of span.runs) {
      const range = document.createRange();
      try { range.selectNodeContents(run.node); } catch { continue; }
      for (const rect of Array.from(range.getClientRects())) {
        if (rect.width <= 0 || rect.height <= 0) continue;
        const distance = distanceToRect(rect as DOMRect, x, y);
        if (distance < bestDistance) {
          bestDistance = distance;
          bestNode = run.node;
          if (distance === 0) break;
        }
      }
      if (bestDistance === 0) break;
    }
    if (bestDistance === 0) break;
  }
  if (!bestNode) return null;
  const offset = pointOffsetInText(bestNode, x, y);
  return offset == null ? null : { node: bestNode, offset };
}

export function sourceAtPoint(root: HTMLElement, x: number, y: number, target?: EventTarget | null): number | null {
  const position = previewPositionAtPoint(root, x, y, target);
  return position ? sourceOffsetAt(root, position.node, position.offset) : null;
}

/** Map a source offset in Markdown syntax (e.g. a table pipe/fence) to the
 * nearest rendered character. Lookups use the cached source index. */
export function previewNearestRange(root: HTMLElement, sourceIndex: number, maxDistance = 192): Range | null {
  if (!Number.isFinite(sourceIndex)) return null;
  const index = getPreviewIndex(root);
  let best: { run: TextRun; offset: number; distance: number } | null = null;
  const first = firstCandidateSpan(index, Math.max(0, sourceIndex - maxDistance - 1));

  for (let spanIndex = first; spanIndex < index.sourceSpans.length; spanIndex++) {
    const span = index.sourceSpans[spanIndex];
    if (span.min > sourceIndex + maxDistance + 1) break;
    if (span.max < sourceIndex - maxDistance - 1) continue;
    const at = validIndexAtOrAfter(span, sourceIndex);
    for (const validAt of [at - 1, at, at + 1]) {
      if (validAt < 0 || validAt >= span.valid.length) continue;
      const mapIndex = span.valid[validAt];
      const [start, end] = span.map[mapIndex];
      if (start < 0 || end <= start) continue;
      const distance = sourceIndex < start ? start - sourceIndex : sourceIndex >= end ? sourceIndex - end + 1 : 0;
      if (distance > maxDistance || (best && distance >= best.distance)) continue;
      const run = runAt(span, mapIndex);
      if (run) best = { run, offset: mapIndex - run.start, distance };
    }
  }
  if (!best) return null;
  try {
    const range = document.createRange();
    range.setStart(best.run.node, best.offset);
    range.setEnd(best.run.node, Math.min(best.offset + 1, best.run.node.length));
    return range;
  } catch {
    return null;
  }
}
