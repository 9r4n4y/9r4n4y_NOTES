"use client";

import * as React from "react";
import { rehypeExactSelection, invalidatePreviewIndex, previewRange, previewNearestRange, previewPositionAtPoint, previewTextAfter, previewTextSegments, sourceAtPoint, sourceOffsetAt } from "./exact-selection";
import ReactMarkdown, { defaultUrlTransform } from "react-markdown";
import remarkGfm from "remark-gfm";
import remarkMath from "remark-math";
import rehypeRaw from "rehype-raw";
import rehypeSanitize, { defaultSchema } from "rehype-sanitize";
const safeMarkdownSchema = { ...defaultSchema, attributes: { ...defaultSchema.attributes, "*": [...(defaultSchema.attributes?.["*"] ?? []), "className", "data-exact-map"], div: [...(defaultSchema.attributes?.div ?? []), "dataType", "dataSize"], span: [...(defaultSchema.attributes?.span ?? []), "className"] } };
import rehypeKatex from "rehype-katex";
import {
  Bold,
  Braces,
  Code,
  Eye,
  Heading1,
  Heading2,
  Heading3,
  ImagePlus,
  Images,
  Italic,
  Link2,
  Link2Off,
  ListPlus,
  List,
  ListChecks,
  ListOrdered,
  Minus,
  PenLine,
  Quote,
  Redo2,
  RemoveFormatting,
  Strikethrough,
  Table2,
  Underline as UnderlineIcon,
  Undo2,
  Maximize2,
} from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { decodeAttachmentPath, encodeAttachmentPath, stripMarkdownFormat, toggleTaskLine, findMarkdownMatchRanges, normalizeSearchText } from "@/core/markdown";
import { preprocessMathMarkdown } from "@/lib/math-pre";
import { useSettings } from "../settings-store";
import {
  KeyTracker,
  matchShortcut,
} from "@/lib/shortcuts";

/** Result payload of the in-note find bar (count + active match). */
export interface SearchResults {
  /** total matches in the note (0 when the query is empty) */
  count: number;
  /** currently active match index (0-based) */
  active: number;
}

/**
 * Notenoid Markdown editor surface.
 *
 * The persisted document remains plain Markdown. Edit mode is intentionally a
 * transparent textarea so existing files, folders, labels, task lists and
 * front-matter stay untouched. Preview mode uses GitHub-Flavored Markdown,
 * including tables, task lists and strikethrough. Attachments continue to be
 * owned by NoteEditorView and are only inserted when the user explicitly asks.
 *
 * edit ↔ preview toggles restore the viewport by TEXT ANCHOR (the block /
 * line that sits at the same relative viewport position before the toggle is
 * re-pinned to the same position after the swap) instead of a raw scrollTop —
 * the two modes have completely different heights, so a raw pixel offset used
 * to land in an entirely different place.
 */

export interface MarkdownEditorHandle {
  focus: () => void;
  insertImage: (url: string, alt?: string) => void;
  /** insert one image, or several arranged in a responsive grid, at the caret. */
  insertImages: (items: { url: string; alt?: string }[]) => void;
  /** remove every markdown reference to a display URL (image + empty grid wrapper). */
  removeImageReference: (url: string) => void;
  /** push a pending throttled store update right now (app hide / close). */
  flushPendingPush: () => void;
  getMarkdown: () => string;
  getScrollElement: () => HTMLElement | null;
  registerUrl: (url: string, file: string) => void;
  setSearchQuery: (query: string) => void;
  goToMatch: (index: number) => void;
}

interface ToolbarProps {
  editor: HTMLTextAreaElement | null;
  preview: boolean;
  onTogglePreview: () => void;
  onPickImages: () => void;
  onInsertAtCursor: () => void;
  onAction: (action: string, value?: string, label?: string) => void;
  /** register a way to open the link popover programmatically (shortcut). */
  onRegisterLinkOpener?: (open: () => void) => void;
}

function ToolButton({
  onClick,
  active,
  disabled,
  label,
  children,
}: {
  onClick?: () => void;
  active?: boolean;
  disabled?: boolean;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      disabled={disabled}
      onMouseDown={(e) => e.preventDefault()}
      onClick={onClick}
      className={cn(
        "inline-flex h-8 min-w-8 shrink-0 items-center justify-center rounded-md px-1.5 text-foreground/75 transition-colors duration-150 hover:bg-black/10 hover:text-foreground disabled:opacity-30 dark:hover:bg-white/10",
        active && "bg-foreground/10 text-foreground dark:bg-white/15"
      )}
    >
      {children}
    </button>
  );
}

function Toolbar({ editor, preview, onTogglePreview, onPickImages, onInsertAtCursor, onAction, onRegisterLinkOpener }: ToolbarProps) {
  const [linkOpen, setLinkOpen] = React.useState(false);
  const [linkUrl, setLinkUrl] = React.useState("");
  const [linkLabel, setLinkLabel] = React.useState("");
  const [multiOpen, setMultiOpen] = React.useState(false);
  const [multiSelection, setMultiSelection] = React.useState<string[]>([]);
  const linkInputRef = React.useRef<HTMLInputElement | null>(null);

  // expose the link popover to the keyboard-shortcut engine
  React.useEffect(() => {
    onRegisterLinkOpener?.(() => setLinkOpen(true));
  }, [onRegisterLinkOpener]);

  const applyLink = () => {
    const url = linkUrl.trim();
    if (!url) return;
    onAction("link", url, linkLabel.trim());
    setLinkOpen(false);
  };

  const multiOptions = [
    ["bold", "Bold"], ["italic", "Italic"], ["underline", "Underline"],
    ["strike", "Strikethrough"], ["code", "Inline code"],
    ["h1", "Heading 1"], ["h2", "Heading 2"], ["h3", "Heading 3"],
  ] as const;
  const applyMulti = () => {
    onAction("multi", multiSelection.join(","));
    setMultiOpen(false);
    setMultiSelection([]);
  };

  return (
    <div className="relative border-b border-black/5 bg-background/60 backdrop-blur dark:border-white/10">
      <div className="flex items-center gap-0.5 overflow-x-auto px-2 py-1.5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        <ToolButton label={preview ? "Edit Markdown" : "Preview rendered note"} active={preview} onClick={onTogglePreview}>
          {preview ? <PenLine className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
        </ToolButton>
        <ToolButton label="Bold" onClick={() => onAction("bold")}><Bold className="h-4 w-4" /></ToolButton>
        <ToolButton label="Italic" onClick={() => onAction("italic")}><Italic className="h-4 w-4" /></ToolButton>
        <ToolButton label="Underline" onClick={() => onAction("underline")}><UnderlineIcon className="h-4 w-4" /></ToolButton>
        <ToolButton label="Strikethrough" onClick={() => onAction("strike")}><Strikethrough className="h-4 w-4" /></ToolButton>
        <ToolButton label="Inline code" onClick={() => onAction("code")}><Code className="h-4 w-4" /></ToolButton>
        <span className="mx-1 h-5 w-px shrink-0 bg-black/10 dark:bg-white/15" />
        <ToolButton label="Heading 1" onClick={() => onAction("h1")}><Heading1 className="h-4 w-4" /></ToolButton>
        <ToolButton label="Heading 2" onClick={() => onAction("h2")}><Heading2 className="h-4 w-4" /></ToolButton>
        <ToolButton label="Heading 3" onClick={() => onAction("h3")}><Heading3 className="h-4 w-4" /></ToolButton>
        <ToolButton label="Body text" onClick={() => onAction("paragraph")}><Braces className="h-4 w-4 rotate-90" /></ToolButton>
        <span className="mx-1 h-5 w-px shrink-0 bg-black/10 dark:bg-white/15" />
        <ToolButton label="Bullet list" onClick={() => onAction("ul")}><List className="h-4 w-4" /></ToolButton>
        <ToolButton label="Numbered list" onClick={() => onAction("ol")}><ListOrdered className="h-4 w-4" /></ToolButton>
        <ToolButton label="Checklist" onClick={() => onAction("todo")}><ListChecks className="h-4 w-4" /></ToolButton>
        <ToolButton label="Quote" onClick={() => onAction("quote")}><Quote className="h-4 w-4" /></ToolButton>
        <ToolButton label="Code block" onClick={() => onAction("codeblock")}><Braces className="h-4 w-4" /></ToolButton>
        <span className="mx-1 h-5 w-px shrink-0 bg-black/10 dark:bg-white/15" />
        <Popover modal open={linkOpen} onOpenChange={(open) => {
          if (open) setLinkUrl("");
          setLinkOpen(open);
        }}>
          <PopoverTrigger asChild>
            <span className="inline-flex shrink-0"><ToolButton label="Add link"><Link2 className="h-4 w-4" /></ToolButton></span>
          </PopoverTrigger>
          <PopoverContent align="start" side="bottom" sideOffset={6} collisionPadding={8} className="z-[70] w-[min(92vw,26rem)] rounded-xl p-2 shadow-xl" onOpenAutoFocus={(e) => {
            e.preventDefault();
            requestAnimationFrame(() => { linkInputRef.current?.focus(); linkInputRef.current?.select(); });
          }}>
            <div className="space-y-2">
              <input ref={linkInputRef} value={linkLabel} onChange={(e) => setLinkLabel(e.target.value)} placeholder="Link text (optional)" aria-label="Link text" className="w-full rounded-md bg-transparent px-2 py-1.5 text-sm outline-none ring-1 ring-black/10 focus:ring-foreground/30 dark:ring-white/15" />
              <div className="flex items-center gap-2">
                <input value={linkUrl} onChange={(e) => setLinkUrl(e.target.value)} onKeyDown={(e) => {
                  if (e.key === "Enter") { e.preventDefault(); applyLink(); }
                  if (e.key === "Escape") setLinkOpen(false);
                }} inputMode="url" placeholder="https://…" aria-label="Link URL" className="min-w-0 flex-1 rounded-md bg-transparent px-2 py-1.5 text-sm outline-none ring-1 ring-black/10 focus:ring-foreground/30 dark:ring-white/15" />
                <button type="button" onClick={applyLink} className="shrink-0 rounded-md bg-foreground px-3 py-1.5 text-sm font-medium text-background">Apply</button>
                <button type="button" onClick={() => setLinkOpen(false)} className="shrink-0 rounded-md px-2 py-1.5 text-sm text-muted-foreground">Cancel</button>
              </div>
            </div>
          </PopoverContent>
        </Popover>
        <ToolButton label="Remove link" onClick={() => onAction("remove-link")}><Link2Off className="h-4 w-4" /></ToolButton>
        <ToolButton label="Add image (saved to attachments)" onClick={onPickImages}><ImagePlus className="h-4 w-4" /></ToolButton>
        <ToolButton label="Insert image at cursor — several become a tidy grid" onClick={onInsertAtCursor}><Images className="h-4 w-4" /></ToolButton>
        <ToolButton label="Divider" onClick={() => onAction("hr")}><Minus className="h-4 w-4" /></ToolButton>
        <ToolButton label="Insert table" onClick={() => onAction("table")}><Table2 className="h-4 w-4" /></ToolButton>
        <ToolButton label="Clear formatting" onClick={() => onAction("clear")}><RemoveFormatting className="h-4 w-4" /></ToolButton>
        <Popover modal open={multiOpen} onOpenChange={setMultiOpen}>
          <PopoverTrigger asChild>
            <span className="inline-flex shrink-0"><ToolButton label="Choose multiple formats"><ListPlus className="h-4 w-4" /></ToolButton></span>
          </PopoverTrigger>
          <PopoverContent align="end" side="bottom" sideOffset={6} collisionPadding={8} className="z-[70] w-56 rounded-xl p-3 shadow-xl">
            <p className="mb-2 text-sm font-medium">Apply multiple formats</p>
            <div className="grid grid-cols-2 gap-1.5">
              {multiOptions.map(([value, label]) => <label key={value} className="flex items-center gap-2 rounded-md px-1.5 py-1 text-xs hover:bg-accent"><input type="checkbox" checked={multiSelection.includes(value)} onChange={(e) => setMultiSelection((current) => e.target.checked ? [...current, value] : current.filter((item) => item !== value))} />{label}</label>)}
            </div>
            <button type="button" disabled={multiSelection.length === 0} onClick={applyMulti} className="mt-3 w-full rounded-md bg-foreground px-3 py-1.5 text-sm font-medium text-background disabled:opacity-40">Done</button>
          </PopoverContent>
        </Popover>
        <span className="mx-1 h-5 w-px shrink-0 bg-black/10 dark:bg-white/15" />
        <ToolButton label="Undo" onClick={() => onAction("undo")}><Undo2 className="h-4 w-4" /></ToolButton>
        <ToolButton label="Redo" onClick={() => onAction("redo")}><Redo2 className="h-4 w-4" /></ToolButton>
        <span className="flex-1" />
      </div>
    </div>
  );
}

export interface MarkdownEditorProps {
  value: string;
  onChange: (markdown: string) => void;
  fileToUrl: (file: string) => string;
  urlToFile: Map<string, string>;
  onRequestInsertImages: () => void;
  /** open the "insert image at cursor" picker (grid for multiples). */
  onRequestInsertAtCursor?: () => void;
  onPasteImages?: (files: File[]) => void;
  onSearchResults?: (results: SearchResults) => void;
  handleRef?: React.RefObject<MarkdownEditorHandle | null>;
  beforeContent?: React.ReactNode;
  placeholder?: string;
  autoFocus?: boolean;
  initialPreview?: boolean;
  /** Identity of the open note — keeps scroll position across remounts. */
  stateKey?: string;
  /** Tap on an inline preview image (lightbox with edit + download). */
  onOpenImage?: (url: string, alt: string) => void;
}

/* --------------------------------------------------------------- fixes
 * The editor used to be remounted (React key change) the moment a brand-new
 * note materializes on disk (store switches editorNoteId from __draft__ to
 * the real id). That remount reset the local preview state — typing the first
 * word "auto-switched" edit ↔ preview. These module-level holders survive
 * remounts so mode + scroll are NEVER changed by anything but the user.
 */
let lastPreviewState: boolean | null = null;
const scrollMemory = new Map<string, number>();
let lastEditorScrollTop = 0;
let lastEditorStateKey: string | null = null;

/* ------------------------------------------------------------------ * EXACT character-anchored scroll sync between edit and preview.
 *
 * anchored by SOURCE LINE, which silently drifts whenever the textarea
 * soft-wraps a paragraph (visual rows ≠ source lines) and when the anchor
 * line sat inside a long block. anchors the exact CHARACTER at the
 * viewport probe instead — the same text always stays at the same screen
 * pixel, in both directions, on every platform:
 *
 *   capture (leaving a mode): find the character under the probe…
 *     • edit    → a hidden MIRROR div (identical font/width/wrap) turns the
 *                 probe pixel into an exact source char index via binary
 *                 search + Range.getBoundingClientRect()
 *     • preview → a cached Range-geometry hit test resolves the text
 *                 node + offset, plus the containing [data-src-line] block
 *   …save its logical identity (source char / block + rendered needle text
 *   read at that point) plus `delta` — the pixel distance between the
 *   character's top and the probe.
 *
 *   restore (entering a mode): re-locate the same logical position in the
 *   NEW mode's DOM (needle search over text nodes / mirror measurement),
 *   measure it with getBoundingClientRect(), and scroll so that
 *   anchorTopViewport = probeY − delta — i.e. adjust scrollTop by the exact
 *   difference. NO raw scrollTop is ever saved or restored.
 *
 * A settle-pin keeps re-applying the computed position while images/fonts
 * change the new mode's height (see startScrollPin).
 */
interface ModeAnchor {
  /** viewport probe as a fraction of the scroll container height */
  ratio: number;
  /** px from the anchor character's top to the probe (viewport px, ≥ 0) */
  delta: number;
  /** exact source char index of the anchor (edit-mode capture) */
  charIdx?: number;
  /** 0-based source line of the anchor (derived on both sides) */
  lineIndex: number;
  /** 1-based source line of the containing preview block (preview capture) */
  blockSrcLine?: number;
  /** normalized text read from the anchor onward — the cross-mode needle */
  needle: string;
}
function renderedText(node: React.ReactNode): string {
  return React.Children.toArray(node).map(child => {
    if (typeof child === "string" || typeof child === "number") return String(child);
    return React.isValidElement<{children?: React.ReactNode}>(child) ? renderedText(child.props.children) : "";
  }).join("");
}

interface ModeWordSelection {
  word: string;
  /** Exact UTF-16 range in the editable source. */
  start: number;
  end: number;
}
const WORD_CHAR = /[\p{L}\p{M}\p{N}_-]/u;
function isWordChar(ch: string | undefined): boolean { return !!ch && WORD_CHAR.test(ch); }
function wordBounds(text: string, index: number): { start: number; end: number; word: string } {
  const safe = Math.max(0, Math.min(index, text.length));
  let start = safe;
  let end = safe;
  // A tap/caret immediately after a word belongs to that word.
  if (!isWordChar(text[start]) && isWordChar(text[start - 1])) start--;
  while (start > 0 && isWordChar(text[start - 1])) start--;
  while (end < text.length && isWordChar(text[end])) end++;
  return { start, end, word: text.slice(start, end) };
}
let lastModeAnchor: ModeAnchor | null = null;

const PROBE_RATIO = 0.35;

/** Whitespace-normalized form used for all cross-mode text comparisons. */
function normText(s: string): string {
  return s.replace(/\s+/g, " ").trim().toLocaleLowerCase();
}

/**
 * Strip the common markdown syntax from ONE source line, approximating its
 * rendered text. Used to align source characters with preview text nodes —
 * never persisted, purely for scroll-anchor matching.
 */
function stripMdLine(line: string): string {
  return line
    .replace(/!\[([^\]]*)\]\([^)]*\)/g, "$1") // images → alt
    .replace(/\[([^\]]*)\]\([^)]*\)/g, "$1") // links → text
    .replace(/<[^>]+>/g, "") // raw html tags
    .replace(/^\s{0,3}#{1,6}\s+/, "") // heading
    .replace(/^\s{0,3}>\s?/, "") // blockquote
    .replace(/^(\s*)[-*+]\s+(\[[ xX]\]\s*)?/, "$1") // bullet + task
    .replace(/^(\s*)\d+[.)]\s+/, "$1") // ordered item
    .replace(/\|/g, " ") // table pipes
    .replace(/(\*\*|__)(.*?)\1/g, "$2") // bold
    .replace(/(\*|_)(.*?)\1/g, "$2") // italic
    .replace(/~~(.*?)~~/g, "$1") // strikethrough
    .replace(/`([^`]*)`/g, "$1") // inline code
    .replace(/\$+/g, ""); // math delimiters
}

/** Move a source anchor on a non-rendered code-fence line to visible code. */
function nearestRenderedSourceOffset(source: string, sourceOffset: number): number {
  const lineStart = source.lastIndexOf("\n", Math.max(0, sourceOffset - 1)) + 1;
  const lineEndAt = source.indexOf("\n", sourceOffset);
  const lineEnd = lineEndAt < 0 ? source.length : lineEndAt;
  const line = source.slice(lineStart, lineEnd);
  const fence = /^ {0,3}(`{3,}|~{3,})(.*)$/.exec(line);
  if (!fence) return sourceOffset;

  // Identify whether this fence line closes a preceding block. Notes are
  // usually small enough that this one-off mode-toggle scan is negligible;
  // search and range lookups use the cached DOM index instead.
  let active: { marker: string; length: number } | null = null;
  for (let cursor = 0; cursor < lineStart;) {
    const endAt = source.indexOf("\n", cursor);
    const end = endAt < 0 || endAt > lineStart ? lineStart : endAt;
    const previousLine = source.slice(cursor, end);
    const priorFence = /^ {0,3}(`{3,}|~{3,})(.*)$/.exec(previousLine);
    if (priorFence) {
      if (!active) active = { marker: priorFence[1][0], length: priorFence[1].length };
      else if (priorFence[1][0] === active.marker && priorFence[1].length >= active.length && !priorFence[2].trim()) active = null;
    }
    cursor = endAt < 0 || endAt >= lineStart ? lineStart : endAt + 1;
  }

  const marker = fence[1][0];
  const length = fence[1].length;
  const closesFence = !!active && marker === active.marker && length >= active.length && !fence[2].trim();
  if (closesFence) {
    let cursor = lineStart - 1;
    while (cursor >= 0) {
      const previousStart = source.lastIndexOf("\n", cursor - 1) + 1;
      const previous = source.slice(previousStart, cursor + 1).replace(/\n$/, "");
      if (previous.trim()) {
        if (!/^ {0,3}(`{3,}|~{3,})/.test(previous)) return previousStart + (previous.length - previous.trimStart().length);
        return sourceOffset;
      }
      cursor = previousStart - 1;
    }
    return sourceOffset;
  }

  let cursor = lineEnd < source.length ? lineEnd + 1 : lineEnd;
  while (cursor < source.length) {
    const endAt = source.indexOf("\n", cursor);
    const end = endAt < 0 ? source.length : endAt;
    const nextLine = source.slice(cursor, end);
    const close = /^ {0,3}(`{3,}|~{3,})\s*$/.exec(nextLine);
    if (close && close[1][0] === marker && close[1].length >= length) break;
    if (nextLine.trim()) return cursor + (nextLine.length - nextLine.trimStart().length);
    cursor = endAt < 0 ? source.length : endAt + 1;
  }
  return sourceOffset;
}

/* ---------------------------------------------------------------- * Textarea MIRROR meter — exact pixel geometry of characters inside the
 * plain textarea (which has no DOM to measure directly).
 *
 * A fixed-position div receives every layout-affecting computed style of
 * the textarea (font, width, padding, wrap mode…), so its text layout is
 * pixel-identical. Range.getBoundingClientRect() over the mirror then
 * gives the exact viewport top of any character, and a monotonic binary
 * search inverts it (pixel → char).
 */
const MIRROR_STYLE_PROPS = [
  "boxSizing", "width", "paddingTop", "paddingRight", "paddingBottom", "paddingLeft",
  "fontFamily", "fontSize", "fontWeight", "fontStyle", "letterSpacing", "lineHeight",
  "textTransform", "textIndent", "whiteSpace", "wordBreak", "overflowWrap",
  "wordSpacing", "tabSize", "fontKerning", "fontVariantLigatures",
] as const;

interface TaMeter {
  text: Text;
  el: HTMLDivElement;
  sync: () => void;
  topOfChar: (charIndex: number) => number | null;
  charAtY: (yFromTaTop: number) => number | null;
}

let meterTa: HTMLTextAreaElement | null = null;
let meter: TaMeter | null = null;

function getMeter(ta: HTMLTextAreaElement): TaMeter {
  if (meter && meterTa === ta && ta.isConnected) return meter;
  if (meter && (!ta.isConnected || meterTa !== ta)) {
    meter.el.remove();
    meter = null;
    meterTa = null;
  }
  const el = document.createElement("div");
  el.setAttribute("aria-hidden", "true");
  const cs = getComputedStyle(ta);
  for (const prop of MIRROR_STYLE_PROPS) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (el.style as any)[prop] = (cs as any)[prop];
  }
  el.style.position = "fixed";
  el.style.left = "-99999px";
  el.style.top = "0px";
  el.style.visibility = "hidden";
  el.style.height = "auto";
  el.style.pointerEvents = "none";
  el.style.zIndex = "-1";
  const text = document.createTextNode("");
  el.appendChild(text);
  document.body.appendChild(el);

  const topOfChar = (charIndex: number): number | null => {
    const value = text.data;
    if (value.length === 0) return 0;
    let from = Math.max(0, Math.min(charIndex, value.length - 1));
    // Hard line breaks are separators, not glyphs. Resolve them explicitly
    // to the next painted character (or the previous one at end-of-text) so
    // layout behavior never depends on a browser's newline Range rectangle.
    if (value[from] === "\n" || value[from] === "\r") {
      let next = from + 1;
      while (next < value.length && (value[next] === "\n" || value[next] === "\r")) next++;
      if (next < value.length) from = next;
      else {
        from--;
        while (from >= 0 && (value[from] === "\n" || value[from] === "\r")) from--;
        if (from < 0) return 0;
      }
    }
    const point = value.codePointAt(from) ?? 0;
    const to = Math.min(value.length, from + (point > 0xffff ? 2 : 1));
    const range = document.createRange();
    range.setStart(text, from);
    range.setEnd(text, to);
    const rects = range.getClientRects();
    if (rects.length > 0) return rects[0].top;
    const bounds = range.getBoundingClientRect();
    return bounds.height > 0 ? bounds.top : null;
  };

  const charAtY = (yFromTaTop: number): number | null => {
    const value = text.data;
    if (value.length === 0) return 0;
    let lo = 0;
    let hi = value.length;
    // find the LAST char whose top is ≤ y (monotonic in i)
    while (lo < hi) {
      const mid = (lo + hi) >> 1;
      const top = topOfChar(mid);
      if (top == null) return null;
      if (top <= yFromTaTop) lo = mid + 1;
      else hi = mid;
    }
    let idx = Math.max(0, lo - 1);
    // Anchor the first visible character on the probe row. Hard breaks are
    // excluded from the walk because they do not paint text or have a useful
    // character rectangle.
    while (idx < text.length && (text.data[idx] === "\n" || text.data[idx] === "\r")) idx++;
    if (idx >= text.length) idx = Math.max(0, text.length - 1);
    const rowTop = topOfChar(idx);
    let guard = 0;
    while (idx > 0 && guard++ < 4000) {
      const previous = idx - 1;
      if (text.data[previous] === "\n" || text.data[previous] === "\r") break;
      const previousTop = topOfChar(previous);
      if (previousTop == null || rowTop == null || Math.abs(previousTop - rowTop) > 0.5) break;
      idx = previous;
    }
    return idx;
  };

  meter = {
    el,
    text,
    sync: () => {
      const value = ta.value;
      if (text.data !== value) text.data = value;
      // styles can change live (note text size setting) — refresh width each sync
      const cs2 = getComputedStyle(ta);
      for (const prop of MIRROR_STYLE_PROPS) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (el.style as any)[prop] = (cs2 as any)[prop];
      }
    },
    topOfChar,
    charAtY,
  };
  meterTa = ta;
  return meter;
}

function disposeMeter(): void {
  if (meter) {
    meter.el.remove();
    meter = null;
    meterTa = null;
  }
}

/* ---------------------------------------------------------------- * Preview-side text search: walk the block's text nodes, concatenate their
 * (normalized) content, and locate the needle; the match start is mapped
 * back to a DOM position and measured with a Range. Returns the px offset
 * of the match from the block's top (null → caller falls back).
 */
function findTextTopInBlock(block: HTMLElement, rawNeedle: string): number | null {
  if (!rawNeedle) return null;
  const candidates = new Set<string>();
  const norm = normText(rawNeedle);
  const stripped = normText(stripMdLine(rawNeedle));
  for (const base of [norm, stripped]) {
    if (!base) continue;
    candidates.add(base);
    // progressively shorter prefixes for fuzzy fallbacks — but never below
    // 12 chars: "paragrap" style fragments match EVERY repeated block
    // prefix ("Paragraph N:") and pinned the wrong block (QA fix)
    for (const len of [48, 32, 24, 12]) {
      if (base.length > len) candidates.add(base.slice(0, len));
    }
  }
  if (candidates.size === 0) return null;

  // collect text nodes once
  const walker = document.createTreeWalker(block, NodeFilter.SHOW_TEXT);
  const nodes: Text[] = [];
  let concatenated = "";
  const spans: { node: Text; start: number; end: number }[] = [];
  for (let n = walker.nextNode(); n; n = walker.nextNode()) {
    const t = n as Text;
    const value = t.data;
    if (!value) continue;
    spans.push({ node: t, start: concatenated.length, end: concatenated.length + value.length });
    concatenated += value;
    nodes.push(t);
  }
  if (nodes.length === 0) return null;
  const haystack = normText(concatenated);

  // map normalized-haystack index back to a raw-concatenated index
  const normToRaw = (normIdx: number): number => {
    // walk the raw string, counting normalized (non-collapsed) chars
    let raw = 0;
    let seen = 0;
    let pendingSpace = false;
    while (raw < concatenated.length && seen < normIdx) {
      const ch = concatenated[raw];
      if (/\s/.test(ch)) {
        pendingSpace = true;
        raw++;
        continue;
      }
      if (pendingSpace) {
        seen++; // the single collapsed space counts as one normalized char
        if (seen >= normIdx) return raw;
        pendingSpace = false;
      }
      seen++;
      raw++;
    }
    return raw;
  };

  for (const needle of candidates) {
    if (needle.length < 3) continue;
    const at = haystack.indexOf(needle);
    if (at === -1) continue;
    const rawAt = normToRaw(at);
    const span = spans.find((s) => rawAt >= s.start && rawAt < s.end) ?? spans[0];
    const range = document.createRange();
    try {
      range.setStart(span.node, Math.max(0, rawAt - span.start));
      range.setEnd(span.node, Math.min(span.node.data.length, rawAt - span.start + 1));
    } catch {
      return null;
    }
    const rects = range.getClientRects();
    if (rects.length === 0) continue;
    return rects[0].top - block.getBoundingClientRect().top;
  }
  return null;
}

/** Capture the exact character under the viewport probe (see header). */
function captureModeAnchor(
  mode: "edit" | "preview",
  ctx: {
    scrollEl: HTMLElement;
    textarea: HTMLTextAreaElement | null;
    draft: string;
    previewRoot: HTMLElement | null;
    getLineBlocks: () => HTMLElement[];
    /** Difference between the settle-pin's intended scroll and current DOM scroll. */
    scrollCorrection?: number;
  }
): ModeAnchor | null {
  const el = ctx.scrollEl;
  const elRect = el.getBoundingClientRect();
  // Capture against the pin's virtual scroll position if layout is still
  // settling; this corrects BOTH the visible character and its pixel delta.
  const probeY = elRect.top + elRect.height * PROBE_RATIO + (ctx.scrollCorrection ?? 0);

  if (mode === "preview") {
    const blocks = ctx.getLineBlocks();
    let caretRect: DOMRect | null = null;
    let needle = "";
    let srcLine: number | null = null;

    // A cached, Range-based hit test uses visible glyph geometry instead of
    // caret-position APIs, whose WebView behavior varies around code and gutters.
    const pointX = elRect.left + Math.min(32, elRect.width * 0.08);
    const point = ctx.previewRoot ? previewPositionAtPoint(ctx.previewRoot, pointX, probeY) : null;
    let caretNode: Node | null = point?.node ?? null;
    let caretOffset = point?.offset ?? 0;
    if (caretNode && caretNode.nodeType === Node.TEXT_NODE) {
      const offset = caretOffset;
      // containing [data-src-line] block
      let host: HTMLElement | null = (caretNode as Text).parentElement;
      while (host && host !== ctx.previewRoot && !host.hasAttribute("data-src-line")) {
        host = host.parentElement;
      }
      const block = host && host.hasAttribute("data-src-line") ? host : null;
      const mapRoot = ctx.previewRoot ?? (caretNode.parentElement as HTMLElement);
      needle = previewTextAfter(mapRoot, caretNode as Text, offset, block, 160);
      caretRect = (caretNode.parentElement as HTMLElement | null)?.getBoundingClientRect() ?? null;
      // Measure a painted glyph with a non-collapsed Range; collapsed-caret
      // geometry differs between browser and WebView implementations.
      try {
        const text = caretNode as Text;
        const range = document.createRange();
        range.setStart(text, Math.min(offset, text.length));
        const nextOffset = offset < text.length && (text.data.codePointAt(offset) ?? 0) > 0xffff ? offset + 2 : offset + 1;
        range.setEnd(text, Math.min(nextOffset, text.length));
        const rects = range.getClientRects();
        if (rects.length > 0) caretRect = rects[0] as DOMRect;
      } catch { /* keep fallback */ }
      if (block) srcLine = Number(block.getAttribute("data-src-line")) || null;
    }

    // Resolve the text point through the rehype source map. This avoids the
    // lossy line-window heuristic (which could jump a table/code anchor to a
    // neighboring block when preview spacing differs from textarea spacing).
    const mappedSourceIndex = caretNode?.nodeType === Node.TEXT_NODE && ctx.previewRoot
      ? sourceOffsetAt(ctx.previewRoot, caretNode as Text, caretOffset)
      : null;

    // 2) fallback: block containing the probe (non-text points: images, hr…)
    if (srcLine == null && blocks.length > 0) {
      let block = blocks[0];
      for (const b of blocks) {
        const r = b.getBoundingClientRect();
        if (r.bottom > probeY) { block = b; break; }
      }
      srcLine = Number(block.getAttribute("data-src-line")) || 1;
      const r = block.getBoundingClientRect();
      caretRect = r as DOMRect;
      needle = block.textContent ?? "";
    }

    const anchorRectTop = caretRect ? caretRect.top : probeY;
    const exactChar = mappedSourceIndex;
    const exactLine = exactChar == null ? Math.max(0, (srcLine ?? 1) - 1) : ctx.draft.slice(0, exactChar).split("\n").length - 1;
    return {
      ratio: PROBE_RATIO,
      delta: Math.max(-160, Math.min(240, probeY - anchorRectTop)),
      charIdx: exactChar ?? undefined,
      lineIndex: exactLine,
      blockSrcLine: exactLine + 1,
      needle: exactChar == null ? normText(needle).slice(0, 160) : normText(ctx.draft.slice(exactChar, exactChar + 160)).slice(0, 160),
    };
  }

  // ---------------- edit mode: exact char via the mirror meter
  const ta = ctx.textarea;
  if (!ta) return null;
  const metered = getMeter(ta);
  metered.sync();
  const taRect = ta.getBoundingClientRect();
  const yInTa = probeY - taRect.top;
  let charIdx = metered.charAtY(yInTa) ?? 0;
  charIdx = nearestRenderedSourceOffset(ctx.draft, charIdx);
  // A newline has no stable rendered glyph. Choose the nearest real text
  // around it rather than always jumping forward: after a paragraph/table
  // separator the next block can be many pixels away, which caused the view
  // to drift by a whole wrapped row on preview/edit toggles.
  if (ctx.draft[charIdx] === "\n") {
    let previous = charIdx - 1;
    while (previous >= 0 && ctx.draft[previous] === "\n") previous--;
    let next = charIdx;
    while (next < ctx.draft.length && ctx.draft[next] === "\n") next++;
    const previousTop = previous >= 0 ? metered.topOfChar(previous) : null;
    const nextTop = next < ctx.draft.length ? metered.topOfChar(next) : null;
    if (previousTop != null && nextTop != null)
      charIdx = Math.abs(yInTa - previousTop) <= Math.abs(yInTa - nextTop) ? previous : next;
    else if (next < ctx.draft.length) charIdx = next;
    else if (previous >= 0) charIdx = previous;
  }
  const charTop = metered.topOfChar(charIdx) ?? 0;
  const delta = probeY - (taRect.top + charTop);

  // needle: normalized text from the anchor char onward (spans lines —
  // preview renders one space where source had a line break inside a
  // paragraph, and normText() on both sides keeps that aligned)
  const rawNeedle = ctx.draft.slice(charIdx, charIdx + 160);
  const lineIndex = ctx.draft.slice(0, charIdx).split("\n").length - 1;

  return {
    ratio: PROBE_RATIO,
    delta: Math.max(-64, Math.min(160, delta)),
    charIdx,
    lineIndex,
    blockSrcLine: lineIndex + 1,
    needle: normText(rawNeedle).slice(0, 160),
  };
}

/** Safe URL transform for the preview: keep local attachment/blob/data-image
 * URLs that react-markdown's default sanitizer would strip (they made every
 * inline image render as an "unavailable" chip). Everything else still goes
 * through the stock sanitizer so javascript:/vbscript: links stay blocked. */
function previewUrlTransform(url: string): string {
  if (!url) return url;
  if (/^(blob:|data:image\/|attachment\/)/i.test(url)) return url;
  if (/^\/?[\w.@%-]+(\/[\w.@%-]*)*$/.test(url) && !url.includes(":")) return url; // relative paths
  return defaultUrlTransform(url);
}

const EMPTY_TASK_LIST_HTML = '<ul data-type="taskList"><li data-type="taskItem" data-checked="false"><p></p></li></ul>';

/* ------------------------------------------------------------------ * Source-line plumbing for the preview: react-markdown gives every node its
 * markdown position; we surface it as data-src-line on block elements so the
 * scroll anchor system can map textarea lines ↔ preview blocks exactly.
 */
interface PositionalNode {
  position?: { start?: { line?: number } };
}

function srcLineAttr(node?: PositionalNode): { "data-src-line"?: number } {
  const line = node?.position?.start?.line;
  return line ? { "data-src-line": line } : {};
}

function lineBlock(tag: string) {
  // react-markdown hands each component its own ExtraProps shape; we only
  // need `node` (position) and forward everything else to the DOM element.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return function LineBlock(props: any) {
    const { node, children, ...rest } = props;
    return React.createElement(tag, { ...rest, ...srcLineAttr(node) }, children);
  };
}

/* ------------------------------------------------------------------ * Display-math upgrade: remark-math only marks FENCED $$ blocks (own lines)
 * as display math; the common single-line form `$$…$$` stays inline. Every
 * mainstream renderer (Obsidian, GitHub, Pandoc) shows single-line $$ as a
 * display block, so we upgrade math-inline whose raw source starts with `$$`
 * before KaTeX sees it. Runs BEFORE rehype-raw (positions intact).
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function rehypeUpgradeDisplayMath(): any {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const walk = (node: any, src: string) => {
    if (!node) return;
    if (node.type === "element") {
      const cls = node.properties?.className;
      if (Array.isArray(cls) && cls.includes("math-inline") && node.position?.start?.offset != null) {
        if (src.slice(node.position.start.offset).startsWith("$$")) {
          node.properties.className = cls
            .filter((c: string) => c !== "math-inline")
            .concat("math-display");
        }
      }
      for (const child of node.children ?? []) walk(child, src);
    } else if (node.type === "root") {
      for (const child of node.children ?? []) walk(child, src);
    }
  };
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return (tree: any, file: { value?: string }) => {
    walk(tree, String(file.value ?? ""));
  };
}

export const MarkdownEditor = React.memo(function MarkdownEditor({
  value,
  onChange,
  fileToUrl,
  urlToFile,
  onRequestInsertImages,
  onRequestInsertAtCursor,
  onPasteImages,
  onSearchResults,
  handleRef,
  beforeContent,
  placeholder,
  autoFocus,
  initialPreview = true,
  stateKey,
  onOpenImage,
}: MarkdownEditorProps) {
  const scrollRef = React.useRef<HTMLDivElement | null>(null);
  const textareaRef = React.useRef<HTMLTextAreaElement | null>(null);
  const previewRef = React.useRef<HTMLDivElement | null>(null);
  const urlToFileRef = React.useRef(urlToFile);
  const searchQueryRef = React.useRef("");
  const searchMarksRef = React.useRef<{
    root: HTMLDivElement | null;
    byIndex: Map<number, HTMLElement[]>;
    activeIndex: number | null;
  }>({ root: null, byIndex: new Map(), activeIndex: null });
  const [preview, setPreviewState] = React.useState(() => lastPreviewState ?? initialPreview);
  const [choosingToggleWord, setChoosingToggleWord] = React.useState(false);
  const [pendingToggleSelection, setPendingToggleSelection] = React.useState<ModeWordSelection | null>(null);
  const [modePulseSelection, setModePulseSelection] = React.useState<ModeWordSelection | null>(null);
  const [draft, setDraft] = React.useState(value === EMPTY_TASK_LIST_HTML ? "- [ ] " : value);
  const [searchQuery, setSearchQuery] = React.useState("");
  const [searchIndex, setSearchIndex] = React.useState(0);
  const [copiedCode, setCopiedCode] = React.useState<string | null>(null);
  const appSettings = useSettings();
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const katexPlugins: any[] = appSettings.mathEnabled
    ? [[rehypeKatex, { throwOnError: false, strict: false, errorColor: "#ef4444" }]]
    : [];
  const pendingAnchorRef = React.useRef<ModeAnchor | null>(null);
  const pinRafRef = React.useRef(0);
  const stopPinRef = React.useRef<() => void>(() => {});
  /** The position the ACTIVE settle-pin is holding (null when idle). Captures
   * read this instead of the transient DOM scroll — textarea/preview heights
   * settle over a few frames, and a capture during that window must see the
   * INTENDED position, not the clamped-to-0 intermediate one. */
  const pinTargetRef = React.useRef<number | null>(null);

  /* --- (paste/typing perf): throttle store propagation ---------------
   * Every keystroke used to flow straight into the zustand store, which
   * re-rendered the whole app behind the editor — freezing on large pastes.
   * The textarea now updates instantly (local draft) while store pushes are
   * throttled (leading + trailing 140ms). Programmatic edits push
   * immediately. The value-sync effect below ignores its own echoes. */
  const lastPushedRef = React.useRef<string | null>(null);
  const draftRef = React.useRef(draft);
  draftRef.current = draft;
  const pushTimerRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const pushThrottleRef = React.useRef(0);
  const pushNow = React.useCallback((text: string) => {
    lastPushedRef.current = text;
    pushThrottleRef.current = Date.now();
    onChange(text);
  }, [onChange]);
  const pushThrottled = React.useCallback((text: string) => {
    lastPushedRef.current = text;
    const now = Date.now();
    const since = now - pushThrottleRef.current;
    if (since >= 140) {
      pushThrottleRef.current = now;
      onChange(text);
      return;
    }
    if (pushTimerRef.current) return;
    pushTimerRef.current = setTimeout(() => {
      pushTimerRef.current = null;
      pushThrottleRef.current = Date.now();
      lastPushedRef.current = draftRef.current;
      onChange(draftRef.current);
    }, 140 - since);
  }, [onChange]);
  const flushPendingPush = React.useCallback(() => {
    if (pushTimerRef.current) {
      clearTimeout(pushTimerRef.current);
      pushTimerRef.current = null;
      lastPushedRef.current = draftRef.current;
      onChange(draftRef.current);
    }
  }, [onChange]);

  const setPreview = React.useCallback((updater: (current: boolean) => boolean) => {
    setPreviewState((current) => {
      const next = updater(current);
      lastPreviewState = next;
      return next;
    });
  }, []);

  /** Keep the viewport pinned to the anchor while the freshly rendered mode
   * settles (async images, fonts, code highlight all change the height —
   * they used to clamp the restored scroll and throw the user to the top).
   * Runs ~2s or until the user scrolls by themselves. */
  const startScrollPin = React.useCallback((getTarget: () => number | null) => {
    stopPinRef.current();
    const el = scrollRef.current;
    if (!el) return;
    let frames = 0;
    let stableFrames = 0;
    let lastSet = -1;
    const stop = () => {
      cancelAnimationFrame(pinRafRef.current);
      ro.disconnect();
      el.removeEventListener("scroll", onUserScroll);
      pinTargetRef.current = null;
      stopPinRef.current = () => {};
    };
    const onUserScroll = () => {
      if (lastSet >= 0 && Math.abs(el.scrollTop - lastSet) > 6) stop();
    };
    const tick = () => {
      const target = getTarget();
      if (target == null) { frames++; if (frames < 120) pinRafRef.current = requestAnimationFrame(tick); else stop(); return; }
      // the user (or a programmatic scroll) moved the viewport away from
      // the pinned position → hand control back IMMEDIATELY. This prevents
      // the settle-pin from ever fighting/clobbering an external scroll that
      // races a frame ahead of the scroll event.
      if (lastSet >= 0 && Math.abs(el.scrollTop - lastSet) > 6) { stop(); return; }
      const max = Math.max(0, el.scrollHeight - el.clientHeight);
      const clamped = Math.max(0, Math.min(target, max));
      if (Math.abs(el.scrollTop - clamped) > 1) {
        el.scrollTop = clamped;
        lastSet = clamped;
        stableFrames = 0;
      } else {
        // position already correct — approve it so the user-scroll guard is
        // armed even when the pin never had to move the viewport
        lastSet = el.scrollTop;
        stableFrames++;
      }
      frames++;
      // stop once the position has held steady for a while (heights settled)
      if (stableFrames > 45 || frames >= 120) stop();
      else pinRafRef.current = requestAnimationFrame(tick);
    };
    const ro = new ResizeObserver(() => { stableFrames = 0; });
    stopPinRef.current = stop;
    el.addEventListener("scroll", onUserScroll, { passive: true });
    ro.observe(el);
    if (el.firstElementChild) ro.observe(el.firstElementChild);
    pinRafRef.current = requestAnimationFrame(tick);
  }, []);

  /** Top-level preview blocks that carry a source-line anchor, in DOM order. */
  const getLineBlocks = React.useCallback((): HTMLElement[] => {
    const root = previewRef.current;
    if (!root) return [];
    const out: HTMLElement[] = [];
    for (const child of Array.from(root.children) as HTMLElement[]) {
      if (child.hasAttribute("data-src-line")) out.push(child);
      else {
        // wrappers rendered by plugins (e.g. KaTeX spans) — look one level down
        const nested = child.querySelector<HTMLElement>("[data-src-line]");
        if (nested) out.push(nested);
      }
    }
    return out;
  }, []);

  /* ---------------- anchor capture + restore ---------------- */

  /** Capture the exact character/block under the probe in the CURRENT mode. */
  const captureAnchor = React.useCallback((): ModeAnchor | null => {
    const el = scrollRef.current;
    if (!el) return null;
    // when a settle-pin is holding an intended position the DOM scroll may
    // lag a frame — correct the edit-side probe by the lag (preview capture
    // is self-consistent: it re-pins the same mode it measured)
    const effectiveScroll = pinTargetRef.current ?? el.scrollTop;
    const scrollCorrection = effectiveScroll - el.scrollTop;
    return captureModeAnchor(preview ? "preview" : "edit", {
      scrollEl: el,
      textarea: textareaRef.current,
      draft: draftRef.current,
      previewRoot: previewRef.current,
      getLineBlocks,
      scrollCorrection,
    });
  }, [preview, getLineBlocks]);

  /**
   * Build the restore getter for the pending anchor in the NEW mode.
   * Runs every settle-pin frame: re-measures the anchor's DOM position so
   * late layout (images, fonts) cannot drift the viewport away from it.
   */
  const makeAnchorGetter = React.useCallback((): (() => number | null) => {
    const anchor = pendingAnchorRef.current;
    if (!anchor) return () => null;

    if (preview) {
      // ---- restore into PREVIEW: locate the needle inside the block that
      // contains the anchor source line, measure with a Range, adjust.
      let exactPreviewRange: Range | null | undefined;
      return () => {
        const el = scrollRef.current;
        if (!el) return null;
        const blocks = getLineBlocks();
        if (blocks.length === 0) return 0;
        // Prefer the exact source-to-rendered character map. This is crucial
        // for tables/code where raw Markdown syntax adds visual rows in edit
        // mode; fuzzy line matching can otherwise land on a neighboring cell.
        if (anchor.charIdx != null && previewRef.current) {
          const root = previewRef.current;
          if (exactPreviewRange === undefined || (exactPreviewRange && !root.contains(exactPreviewRange.startContainer))) {
            exactPreviewRange = previewRange(root, anchor.charIdx, anchor.charIdx + 1)
              ?? previewNearestRange(root, anchor.charIdx);
          }
          const rect = exactPreviewRange?.getBoundingClientRect();
          if (rect && rect.height > 0) {
            const elRect = el.getBoundingClientRect();
            return el.scrollTop + rect.top - elRect.top + anchor.delta - elRect.height * anchor.ratio;
          }
        }
        const want = anchor.blockSrcLine ?? anchor.lineIndex + 1;
        let startIdx = 0;
        for (let i = 0; i < blocks.length; i++) {
          if (Number(blocks[i].getAttribute("data-src-line")) <= want) startIdx = i;
          else break;
        }
        const elRect = el.getBoundingClientRect();
        // try the containing block first, then the next two (needle tails
        // that cross a block boundary); only when NO nearby block matches do
        // we fall back to the containing block's top (QA fix: the old
        // loop returned the start block immediately when its own text didn't
        // contain the needle — e.g. anchors captured on the blank line
        // before a paragraph — and landed a block too high)
        for (let i = startIdx; i < Math.min(blocks.length, startIdx + 3); i++) {
          const found = anchor.needle ? findTextTopInBlock(blocks[i], anchor.needle) : null;
          if (found != null) {
            const blockTopRel = blocks[i].getBoundingClientRect().top - elRect.top;
            return el.scrollTop + blockTopRel + found + anchor.delta - elRect.height * anchor.ratio;
          }
        }
        const blockTopRel = blocks[startIdx].getBoundingClientRect().top - elRect.top;
        return el.scrollTop + blockTopRel + anchor.delta - elRect.height * anchor.ratio;
      };
    }

    // ---- restore into EDIT: resolve the anchor to a source char index once,
    // then measure its exact pixel top in the textarea via the mirror.
    let resolved: number | null | undefined; // undefined = not attempted yet
    const resolveChar = (): number | null => {
      if (resolved !== undefined) return resolved;
      const value = draftRef.current;
      if (anchor.charIdx != null) {
        resolved = Math.max(0, Math.min(anchor.charIdx, value.length));
        return resolved;
      }
      resolved = null;
      const lines = value.split("\n");
      const needle = anchor.needle;
      let lineK = Math.max(0, Math.min(lines.length - 1, (anchor.blockSrcLine ?? anchor.lineIndex + 1) - 1));
      let withinRatio = 0;
      if (needle && needle.length >= 3) {
        // per-line stripped text + 4-line windows for context matching
        const stripped = lines.map((l) => normText(stripMdLine(l)));
        const wins = lines.map((_, i) => stripped.slice(i, i + 4).join(" "));
        // The needle is the text read FROM the anchor character onward, so in
        // the TRUE anchor line's window it matches at the smallest offset —
        // earlier lines can only contain it further into their window (their
        // following lines were appended after their own text). QA fix:
        // the old score tie-break handed repeated-content windows to the
        // WRONG (earlier) line, anchoring several rows above the target.
        const probe = needle.slice(0, Math.min(needle.length, 48));
        let bestLine = -1;
        let bestAt = Number.POSITIVE_INFINITY;
        let bestLen = 0;
        for (let i = 0; i < lines.length; i++) {
          const win = wins[i];
          if (!win) continue;
          const at = win.indexOf(probe);
          if (at === -1) continue;
          let m = probe.length;
          while (m < needle.length && at + m < win.length && win[at + m] === needle[m]) m++;
          if (at < bestAt || (at === bestAt && m > bestLen)) {
            bestAt = at;
            bestLen = m;
            bestLine = i;
          }
        }
        if (bestLine >= 0 && bestLen >= 8 && bestAt < stripped[bestLine].length + 1) {
          lineK = bestLine;
          // the match start inside the line's own stripped text → exact
          // within-line position (± a few syntax chars, same visual row)
          withinRatio =
            stripped[lineK].length > 0
              ? Math.min(1, Math.max(0, bestAt) / stripped[lineK].length)
              : 0;
        }
      }
      // source char = line start + proportional position within the line
      let charIdx = 0;
      for (let i = 0; i < lineK; i++) charIdx += lines[i].length + 1;
      charIdx += Math.round(withinRatio * lines[lineK].length);
      resolved = Math.max(0, Math.min(charIdx, value.length));
      return resolved;
    };

    return () => {
      const el = scrollRef.current;
      const ta = textareaRef.current;
      if (!el || !ta) return null;
      const metered = getMeter(ta);
      metered.sync();
      const charIdx = resolveChar();
      if (charIdx == null) return null;
      const top = metered.topOfChar(charIdx);
      if (top == null) return null;
      const elRect = el.getBoundingClientRect();
      const taRect = ta.getBoundingClientRect();
      const contentY = el.scrollTop + (taRect.top - elRect.top) + top;
      return contentY + anchor.delta - elRect.height * anchor.ratio;
    };
  }, [preview, getLineBlocks]);

  const performTogglePreview = React.useCallback((selection: ModeWordSelection | null = null) => {
    // Capture the viewport only once, when the user confirms. Never toggle on
    // the first tap: that was the source of the Android jump/repeated-word bug.
    const anchor = captureAnchor();
    if (anchor) {
      lastModeAnchor = anchor;
      pendingAnchorRef.current = anchor;
      scrollMemory.set(stateKey ?? "editor", scrollRef.current?.scrollTop ?? 0);
    }
    (window as unknown as { __lastAnchor?: unknown }).__lastAnchor = anchor;
    const chosen = selection ?? pendingToggleSelection;
    // An exact confirmed word has a stronger positioning contract than the
    // generic viewport probe: its own centering effect must be the only
    // restore operation, otherwise the old probe can pull it off-center.
    if (chosen) {
      pendingAnchorRef.current = null;
      stopPinRef.current();
    }
    setModePulseSelection(chosen ?? null);
    textareaRef.current?.blur();
    window.getSelection()?.removeAllRanges();
    setPendingToggleSelection(null);
    setChoosingToggleWord(false);
    setPreview((current) => !current);
  }, [setPreview, captureAnchor, stateKey, pendingToggleSelection]);
  const beginToggleSelection = React.useCallback(() => {
    setModePulseSelection(null);
    setPendingToggleSelection(null);
    setChoosingToggleWord(true);
    window.getSelection()?.removeAllRanges();
  }, []);
  const confirmToggleSelection = React.useCallback(() => {
    if (!pendingToggleSelection) return;
    performTogglePreview(pendingToggleSelection);
  }, [pendingToggleSelection, performTogglePreview]);
  const togglePreview = React.useCallback(() => {
    if (appSettings.confirmModeToggle && draftRef.current.trim()) {
      if (!choosingToggleWord) beginToggleSelection();
      // Only Done confirms; a double-tap must not accidentally switch modes.
      return;
    }
    performTogglePreview(null);
  }, [appSettings.confirmModeToggle, choosingToggleWord, pendingToggleSelection, beginToggleSelection, confirmToggleSelection, performTogglePreview]);

  /* -------------------------------------------------- v18 shortcuts -----
   * Every Markdown toolbar action has a configurable keyboard shortcut
   * (Settings → Shortcuts, 2–4 keys per combination). The engine tracks the
   * exact set of physically held keys and fires the action whose combination
   * matches — including the Preview/Edit toggle (default Shift+X).
   */
  const openLinkPopoverRef = React.useRef<() => void>(() => {});
  const onRegisterLinkOpener = React.useCallback((open: () => void) => {
    openLinkPopoverRef.current = open;
  }, []);
  const shortcutsRef = React.useRef(appSettings.shortcuts);
  shortcutsRef.current = appSettings.shortcuts;
  const runShortcutRef = React.useRef<(actionId: string) => void>(() => {});
  React.useEffect(() => {
    const tracker = new KeyTracker();
    const onKeyDown = (event: KeyboardEvent) => {
      const held = tracker.keydown(event);
      const actionId = matchShortcut(held, shortcutsRef.current);
      if (!actionId) return;
      // A shortcut always wins over typing (earlier release Shift+X behaviour). Use
      // Caps Lock if a shortcut's letter is needed as a capital while typing.
      event.preventDefault();
      runShortcutRef.current(actionId);
    };
    const onKeyUp = (event: KeyboardEvent) => tracker.keyup(event);
    const clear = () => tracker.clear();
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", clear);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", clear);
      tracker.clear();
    };
  }, []);


  /** Re-pin the viewport to the pending anchor (mode switch, image resize…). */
  const runAnchorRestore = React.useCallback(() => {
    if (pendingAnchorRef.current == null) return;
    startScrollPin(makeAnchorGetter());
    pendingAnchorRef.current = null;
  }, [makeAnchorGetter, startScrollPin]);

  React.useEffect(() => { urlToFileRef.current = urlToFile; }, [urlToFile]);

  // per-note scroll memory: survives remounts (draft → real note) and lets a
  // reopened note start where the user last was — never at the top
  React.useEffect(() => {
    const el = scrollRef.current;
    let target: number | null = null;
    if (stateKey && scrollMemory.has(stateKey)) {
      target = scrollMemory.get(stateKey) ?? null;
    } else if (lastEditorStateKey === stateKey || lastEditorStateKey === "__draft__") {
      target = lastEditorScrollTop; // same note (or materialized draft) — keep position
    }
    if (el && target != null && target > 2) {
      const getTarget = () => {
        const cur = scrollRef.current;
        if (!cur) return null;
        // raw intent — the settle-pin clamps for the actual scroll and keeps
        // re-applying as the content grows (field-sizing textarea, images)
        return target!;
      };
      // apply the remembered position SYNCHRONOUSLY — an async-only pin
      // left a window where a fast mode toggle captured a stale position and
      // then clobbered the restore (the "switch back jumps to top" bug).
      const max = Math.max(0, el.scrollHeight - el.clientHeight);
      el.scrollTop = Math.max(0, Math.min(target, max));
      startScrollPin(getTarget);
    }
    return () => {
      const current = scrollRef.current;
      if (current) {
        lastEditorScrollTop = current.scrollTop;
        if (stateKey) scrollMemory.set(stateKey, current.scrollTop);
      }
      lastEditorStateKey = stateKey ?? null;
      stopPinRef.current();
      disposeMeter(); // the mirror only makes sense while a textarea exists
    };
  }, [stateKey, startScrollPin]);

  const toDisplay = React.useCallback((md: string) => md.replace(/(!?\[([^\]]*)\])\(\s*(attachment\/[^)\s]+)((?:\s+"[^"]*")?)\s*\)/g, (full, label: string, alt: string, file: string, title: string) => {
    const decoded = decodeAttachmentPath(file);
    const url = fileToUrl(decoded) || fileToUrl(file);
    // Attachment links are rendered as images even when older notes stored
    // them as `[filename](attachment/...)` instead of `![alt](...)`.
    // Keep the relative attachment path in Markdown until after rehype-sanitize:
    // its default schema rejects blob: URLs, so swapping to the object URL here
    // made regular Markdown images lose src and render only their alt/name.
    // The custom img renderer resolves this same safe relative path to the
    // cached local object URL after sanitization (as it already does for grids).
    return url ? `![${alt || decoded.split("/").pop() || "Attached image"}](${file}${title})` : full;
  }), [fileToUrl]);

  const fromDisplay = React.useCallback((md: string) => {
    let out = md.replace(/\]\(\s*(blob:[^)\s]+|data:[^)\s]+)((?:\s+"[^"]*")?)\s*\)/g, (full, url: string, title: string) => {
      const file = urlToFileRef.current.get(url);
      return file ? `](${encodeAttachmentPath(file)}${title})` : full;
    });
    // HTML grid images — persist blob/data URLs back to attachment paths
    out = out.replace(/(<img\b[^>]*?\bsrc=")(blob:[^"]+|data:[^"]+)(")/gi, (full, head: string, url: string, tail: string) => {
      const file = urlToFileRef.current.get(url);
      return file ? `${head}${encodeAttachmentPath(file)}${tail}` : full;
    });
    return out;
  }, []);

  /* ------------------------------------------------- undo/redo history ()
   * The native textarea undo stack never sees programmatic changes (toolbar
   * buttons, task ticks, image inserts) and React's controlled value breaks
   * it anyway. A snapshot history records EVERY change — typing is coalesced
   * into word-ish chunks, every button action is its own step.
   */
  interface HistoryEntry { text: string; selStart: number; selEnd: number }
  const histRef = React.useRef<{
    entries: HistoryEntry[];
    index: number;
    lastCommitAt: number;
    lastKind: string;
  }>({ entries: [], index: -1, lastCommitAt: 0, lastKind: "" });

  const resetHistory = React.useCallback((text: string) => {
    histRef.current = { entries: [{ text, selStart: 0, selEnd: 0 }], index: 0, lastCommitAt: 0, lastKind: "" };
  }, []);
  React.useEffect(() => { resetHistory(value === EMPTY_TASK_LIST_HTML ? "- [ ] " : value); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const commitHistory = React.useCallback((text: string, kind: "type" | "action") => {
    const h = histRef.current;
    const el = textareaRef.current;
    const entry: HistoryEntry = {
      text,
      selStart: el?.selectionStart ?? 0,
      selEnd: el?.selectionEnd ?? 0,
    };
    const now = Date.now();
    if (kind === "type" && h.lastKind === "type" && now - h.lastCommitAt < 650) {
      h.entries[h.index] = entry; // coalesce a continuous typing burst
    } else {
      h.entries = h.entries.slice(0, h.index + 1);
      h.entries.push(entry);
      if (h.entries.length > 300) h.entries.shift();
      h.index = h.entries.length - 1;
    }
    h.lastCommitAt = now;
    h.lastKind = kind;
  }, []);

  React.useEffect(() => {
    const normalized = value === EMPTY_TASK_LIST_HTML ? "- [ ] " : value;
    // our own throttled echo → do not reset the local draft
    if (normalized === lastPushedRef.current) return;
    if (normalized !== draft) {
      setDraft(normalized);
      resetHistory(normalized); // external change (note switch) — fresh baseline
    }
  }, [value]); // eslint-disable-line react-hooks/exhaustive-deps

  // opening a note or switching modes never focuses the textarea. Android
  // keyboards open only after an explicit user tap in the editor.
  React.useEffect(() => { void autoFocus; }, [autoFocus]);

  const searchCacheRef = React.useRef<{ draft: string; query: string; matches: ReturnType<typeof findMarkdownMatchRanges> } | null>(null);
  const getSearchMatches = React.useCallback((query: string) => {
    const normalizedQuery = normalizeSearchText(query.trim());
    const cached = searchCacheRef.current;
    if (cached && cached.draft === draft && cached.query === normalizedQuery) return cached.matches;
    const matches = findMarkdownMatchRanges(draft, query);
    searchCacheRef.current = { draft, query: normalizedQuery, matches };
    return matches;
  }, [draft]);

  const emitSearch = React.useCallback((query: string, preferred = 0) => {
    const matches = getSearchMatches(query);
    const index = matches.length ? ((preferred % matches.length) + matches.length) % matches.length : 0;
    setSearchIndex(index);
    onSearchResults?.({ count: matches.length, active: index });
    const match = matches[index];
    const el = textareaRef.current;
    const container = scrollRef.current;
    if (!match || !el || !container || preview) return;

    // Keep the find field focused (so search does not open the Android
    // keyboard in the editor), but scroll to exact rendered character geometry.
    try { el.setSelectionRange(match.start, match.end); } catch { /* detached */ }
    const meter = getMeter(el);
    meter.sync();
    const range = document.createRange();
    try {
      range.setStart(meter.text, Math.min(match.start, meter.text.length));
      range.setEnd(meter.text, Math.min(match.end, meter.text.length));
      let rect = Array.from(range.getClientRects())[0] as DOMRect | undefined;
      if (!rect && meter.text.length) {
        const at = Math.min(match.start, meter.text.length - 1);
        range.setStart(meter.text, at);
        range.setEnd(meter.text, at + 1);
        rect = Array.from(range.getClientRects())[0] as DOMRect | undefined;
      }
      if (!rect) return;
      const textareaRect = el.getBoundingClientRect();
      const mirrorRect = meter.el.getBoundingClientRect();
      const containerRect = container.getBoundingClientRect();
      const matchTop = textareaRect.top + rect.top - mirrorRect.top - el.scrollTop;
      const top = container.scrollTop + matchTop - containerRect.top - container.clientHeight * 0.35;
      container.scrollTo({ top: Math.max(0, top), behavior: "smooth" });
    } catch { /* detached between query and layout */ }
  }, [draft, getSearchMatches, onSearchResults, preview]);

  const applyHistoryEntry = React.useCallback((entry: HistoryEntry) => {
    setDraft(entry.text);
    pushNow(entry.text);
    if (searchQueryRef.current) emitSearch(searchQueryRef.current, searchIndex);
    const el = textareaRef.current;
    if (el) {
      requestAnimationFrame(() => {
        el.focus();
        const start = Math.max(0, Math.min(entry.selStart, entry.text.length));
        const end = Math.max(start, Math.min(entry.selEnd, entry.text.length));
        try { el.setSelectionRange(start, end); } catch { /* detached */ }
      });
    }
  }, [emitSearch, onChange, searchIndex]);

  const doUndoRef = React.useRef(() => {});
  const doRedoRef = React.useRef(() => {});
  const doUndo = React.useCallback(() => {
    const h = histRef.current;
    if (h.index <= 0) return;
    h.index--;
    h.lastKind = "";
    applyHistoryEntry(h.entries[h.index]);
  }, [applyHistoryEntry]);
  const doRedo = React.useCallback(() => {
    const h = histRef.current;
    if (h.index >= h.entries.length - 1) return;
    h.index++;
    h.lastKind = "";
    applyHistoryEntry(h.entries[h.index]);
  }, [applyHistoryEntry]);
  React.useEffect(() => { doUndoRef.current = doUndo; doRedoRef.current = doRedo; }, [doUndo, doRedo]);

  React.useImperativeHandle(handleRef, () => ({
    focus: () => textareaRef.current?.focus(),
    registerUrl: (url, file) => { urlToFileRef.current = new Map(urlToFileRef.current).set(url, file); },
    flushPendingPush,
    setSearchQuery: (query) => {
      searchQueryRef.current = query;
      setSearchQuery(query);
      emitSearch(query, 0);
    },
    goToMatch: (index) => {
      setSearchIndex(index);
      emitSearch(searchQueryRef.current, index);
    },
    insertImage: (url, alt = "") => {
      const el = textareaRef.current;
      const snippet = `![${alt}](${url})`;
      // in preview mode the textarea is not mounted — previously the
      // "Insert into note" button silently did nothing. Fall back to
      // appending the image at the end of the note body.
      if (!el) {
        const base = draft.replace(/\n*$/, "");
        const next = `${base}\n\n${snippet}\n`;
        const clean = fromDisplay(next);
        setDraft(clean); pushNow(clean); commitHistory(clean, "action");
        return;
      }
      const s = el.selectionStart;
      const next = `${draft.slice(0, s)}\n${snippet}\n${draft.slice(el.selectionEnd)}`;
      const clean = fromDisplay(next);
      setDraft(clean); pushNow(clean); commitHistory(clean, "action");
      requestAnimationFrame(() => {
        const scrollTop = scrollRef.current?.scrollTop ?? 0;
        el.setSelectionRange(s + clean.slice(s).indexOf("\n", 1) + 1, s + clean.slice(s).indexOf("\n", 1) + 1);
        if (scrollRef.current) scrollRef.current.scrollTop = scrollTop;
      });
    },
    insertImages: (items) => {
      if (!items || items.length === 0) return;
      const el = textareaRef.current;
      let snippet: string;
      if (items.length === 1) {
        snippet = `![${items[0].alt || items[0].url}](${items[0].url})`;
      } else {
        // several images at the cursor become a compact grid. The grid is
        // plain HTML whose <img src> round-trips to attachment/ paths on disk,
        // so node.md stays portable to Obsidian & friends.
        const cols = items.length <= 4 ? 2 : 3;
        const imgs = items
          .map((it) => `<img src="${it.url}" alt="${(it.alt || "image").replace(/"/g, "&quot;")}">`)
          .join("\n");
        snippet = `<div class="img-grid" data-cols="${cols}">\n${imgs}\n</div>`;
      }
      if (!el) {
        const base = draft.replace(/\n*$/, "");
        const next = `${base}\n\n${snippet}\n`;
        const clean = fromDisplay(next);
        setDraft(clean); pushNow(clean); commitHistory(clean, "action");
        return;
      }
      const s = el.selectionStart;
      const e = el.selectionEnd;
      const before = draft.slice(0, s);
      const after = draft.slice(e);
      const padBefore = before && !before.endsWith("\n") ? "\n\n" : before ? "\n" : "";
      const padAfter = after && !after.startsWith("\n") ? "\n\n" : after ? "\n" : "";
      const next = `${before}${padBefore}${snippet}${padAfter}${after}`;
      const clean = fromDisplay(next);
      setDraft(clean); pushNow(clean); commitHistory(clean, "action");
      const caret = before.length + padBefore.length + snippet.length;
      requestAnimationFrame(() => {
        const scrollTop = scrollRef.current?.scrollTop ?? 0;
        try { el.setSelectionRange(caret, caret); } catch { /* detached */ }
        if (scrollRef.current) scrollRef.current.scrollTop = scrollTop;
      });
    },
    removeImageReference: (url) => {
      if (!url) return;
      // the draft may hold either display URLs or persisted attachment paths
      const cands = new Set<string>([url]);
      const file = urlToFileRef.current.get(url);
      if (file) {
        cands.add(file);
        try { cands.add(encodeAttachmentPath(file)); } catch { /* ignore */ }
      }
      let next = draft;
      for (const cand of cands) {
        const esc = cand.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        next = next.replace(new RegExp(`!\\[[^\\]]*\\]\\(\\s*${esc}[^)]*\\)\\s*`, "g"), "");
        next = next.replace(new RegExp(`\\s*<img\\b[^>]*\\bsrc="${esc}"[^>]*>\\s*`, "gi"), "");
      }
      // collapse now-empty grid wrappers
      next = next.replace(/<div class="img-grid"[^>]*>\s*<\/div>\s*/gi, "");
      // tidy leftover blank runs
      next = next.replace(/\n{3,}/g, "\n\n");
      if (next !== draft) {
        const clean = fromDisplay(next);
        setDraft(clean); pushNow(clean); commitHistory(clean, "action");
      }
    },
    getMarkdown: () => draft,
    getScrollElement: () => scrollRef.current,
  }), [draft, emitSearch, fromDisplay, handleRef, onChange, searchQuery, commitHistory, pushNow, flushPendingPush]);

  function updateDraft(next: string, kind: "type" | "action" = "action") {
    const clean = fromDisplay(next);
    setDraft(clean);
    if (kind === "type") pushThrottled(clean);
    else pushNow(clean);
    commitHistory(clean, kind);
    if (searchQueryRef.current) emitSearch(searchQueryRef.current, searchIndex);
  }

  function replaceSelection(replacement: string, cursorOffset = replacement.length) {
    const el = textareaRef.current;
    if (!el) return;
    const s = el.selectionStart, e = el.selectionEnd;
    // Toolbar popovers temporarily take focus. Restoring focus without
    // preventScroll makes Android/WebView jump to the textarea's end (most
    // visible with Markdown link Apply). Keep both the exact caret and the
    // scroll viewport that existed before the replacement.
    const scrollEl = scrollRef.current;
    const savedScrollTop = scrollEl?.scrollTop ?? 0;
    const savedScrollLeft = scrollEl?.scrollLeft ?? 0;
    updateDraft(`${draft.slice(0, s)}${replacement}${draft.slice(e)}`);
    requestAnimationFrame(() => {
      el.focus({ preventScroll: true });
      const p = s + cursorOffset;
      el.setSelectionRange(p, p);
      if (scrollEl) {
        scrollEl.scrollTop = savedScrollTop; scrollEl.scrollLeft = savedScrollLeft;
        requestAnimationFrame(() => {
          if (scrollRef.current) {
            scrollRef.current.scrollTop = savedScrollTop;
            scrollRef.current.scrollLeft = savedScrollLeft;
          }
        });
      }
    });
  }

  function wrap(before: string, after = before, placeholder = "text") {
    const el = textareaRef.current; if (!el) return;
    const s = el.selectionStart, e = el.selectionEnd;
    const selected = draft.slice(s, e) || placeholder;
    const replacement = `${before}${selected}${after}`;
    updateDraft(`${draft.slice(0, s)}${replacement}${draft.slice(e)}`);
    // Never leave the textarea selection highlighted after a toolbar action.
    // With no selection, put the caret between the opening and closing marks;
    // with selected text, put it after the complete formatted text.
    const cursor = s === e ? s + before.length : s + replacement.length;
    requestAnimationFrame(() => { el.focus(); el.setSelectionRange(cursor, cursor); });
  }

  function prefix(prefix: string) {
    const el = textareaRef.current; if (!el) return;
    const s = el.selectionStart, e = el.selectionEnd;
    const start = draft.lastIndexOf("\n", s - 1) + 1;
    // Prefixes are line syntax. If there is no selection, insert at the
    // current line and leave the caret immediately after the prefix.
    if (s === e) {
      const line = draft.slice(start, draft.indexOf("\n", s) === -1 ? draft.length : draft.indexOf("\n", s));
      const marker = /^(#{1,6}\s+|[-*+]\s+|\d+[.)]\s+|>\s+)/.exec(line)?.[0] ?? "";
      const nextPrefix = prefix === "" ? "" : prefix;
      const insert = marker && (prefix.startsWith("#") || /^\d/.test(prefix) || prefix === "> ") ? nextPrefix : prefix;
      const next = `${draft.slice(0, start)}${insert}${draft.slice(start)}`;
      updateDraft(next);
      requestAnimationFrame(() => { el.focus(); const p = s + insert.length; el.setSelectionRange(p, p); });
      return;
    }
    const segment = draft.slice(start, e);
    const patched = segment.split("\n").map((line) => line.startsWith(prefix) ? line : `${prefix}${line}`).join("\n");
    updateDraft(`${draft.slice(0, start)}${patched}${draft.slice(e)}`);
    requestAnimationFrame(() => { el.focus(); const p = start + patched.length; el.setSelectionRange(p, p); });
  }

  function paragraph() {
    const el = textareaRef.current; if (!el) return;
    const s = el.selectionStart, e = el.selectionEnd;
    const start = draft.lastIndexOf("\n", s - 1) + 1;
    const end = draft.indexOf("\n", Math.max(s, e));
    const lineEnd = end === -1 ? draft.length : end;
    const line = draft.slice(start, lineEnd);
    const cleaned = line.replace(/^(#{1,6}\s+|[-*+]\s+|\d+[.)]\s+|>\s+)/, "");
    updateDraft(`${draft.slice(0, start)}${cleaned}${draft.slice(lineEnd)}`);
    requestAnimationFrame(() => { el.focus(); const p = start + Math.min(Math.max(s - start, 0), cleaned.length); el.setSelectionRange(p, p); });
  }

  function handleEditorKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    // Undo/redo (Ctrl+Z / Ctrl+Y and friends) run through the v18 configurable
    // shortcut engine on window level — handling them here as well would fire
    // the action twice per press.
    if (e.key !== "Enter" || e.shiftKey || e.altKey || e.ctrlKey || e.metaKey) return;
    const el = e.currentTarget;
    const s = el.selectionStart, end = el.selectionEnd;
    if (s !== end) return;
    const lineStart = draft.lastIndexOf("\n", s - 1) + 1;
    const line = draft.slice(lineStart, s);
    const bullet = /^(\s*)([-*+])\s+(.*)$/.exec(line);
    const numbered = /^(\s*)(\d+)([.)])\s+(.*)$/.exec(line);
    const task = /^(\s*)([-*+])\s+\[[ xX]\]\s*(.*)$/.exec(line);
    if (!bullet && !numbered) return;
    e.preventDefault();
    // Enter on an empty list item exits the list instead of creating noise.
    const isEmpty = task ? !task[3].trim() : bullet ? !bullet[3].trim() : !numbered![4].trim();
    const continuation = isEmpty
      ? ""
      : task
        ? `${task[1]}${task[2]} [ ] `
        : bullet
          ? `${bullet[1]}${bullet[2]} `
          : `${numbered![1]}${Number(numbered![2]) + 1}${numbered![3]} `;
    const next = `${draft.slice(0, s)}\n${isEmpty ? "" : continuation}${draft.slice(end)}`;
    updateDraft(next);
    requestAnimationFrame(() => { el.focus(); const p = s + 1 + continuation.length; el.setSelectionRange(p, p); });
  }

  function table() {
    const value = "| Column 1 | Column 2 | Column 3 |\n| --- | --- | --- |\n| Row 1 | Value | Value |\n| Row 2 | Value | Value |";
    const el = textareaRef.current;
    if (!el) return;
    const s = el.selectionStart, e = el.selectionEnd;
    const separator = s > 0 && draft[s - 1] !== "\n" ? "\n\n" : "";
    replaceSelection(`${separator}${value}\n`);
  }

  function action(actionName: string, replacement?: string, label?: string) {
    switch (actionName) {
      case "bold": return wrap("**", "**", "");
      case "italic": return wrap("*", "*", "");
      case "underline": return wrap("<u>", "</u>", "");
      case "strike": return wrap("~~", "~~", "");
      case "code": return wrap("`", "`", "");
      case "h1": return prefix("# ");
      case "h2": return prefix("## ");
      case "h3": return prefix("### ");
      case "paragraph": return paragraph();
      case "ul": return prefix("- ");
      case "ol": return prefix("1. ");
      case "todo": return prefix("- [ ] ");
      case "quote": return prefix("> ");
      case "codeblock": return wrap("```\n", "\n```", "");
      case "multi": {
        const el = textareaRef.current; if (!el) return;
        const s = el.selectionStart, e = el.selectionEnd;
        const selected = draft.slice(s, e);
        const formats = (replacement ?? "").split(",").filter(Boolean);
        let content = selected;
        let before = "";
        let after = "";
        for (const format of formats) {
          if (format === "bold") { before += "**"; after = "**" + after; }
          else if (format === "italic") { before += "*"; after = "*" + after; }
          else if (format === "underline") { before += "<u>"; after = "</u>" + after; }
          else if (format === "strike") { before += "~~"; after = "~~" + after; }
          else if (format === "code") { before += "`"; after = "`" + after; }
          else if (format === "h1") before = "# " + before;
          else if (format === "h2") before = "## " + before;
          else if (format === "h3") before = "### " + before;
        }
        const replacementText = `${before}${content}${after}`;
        updateDraft(`${draft.slice(0, s)}${replacementText}${draft.slice(e)}`);
        const cursor = s === e ? s + before.length : s + replacementText.length;
        requestAnimationFrame(() => { el.focus(); el.setSelectionRange(cursor, cursor); });
        return;
      }
      case "hr": return replaceSelection("\n\n---\n");
      case "table": return table();
      case "replace-selection": return replaceSelection(replacement ?? "");
      case "link": {
        const el = textareaRef.current; if (!el) return;
        const s = el.selectionStart, e = el.selectionEnd;
        const selected = label || draft.slice(s, e) || "";
        return replaceSelection(replacement ? `[${selected}](${replacement})` : selected);
      }
      case "remove-link": return updateDraft(draft.replace(/\[([^\]]+)\]\(([^)]+)\)/g, "$1"));
      case "clear": {
        // strip EVERY markdown special character. With a selection, only
        // the selected span is rewritten; without one, the whole note.
        const el = textareaRef.current;
        if (el && el.selectionStart !== el.selectionEnd) {
          const s = el.selectionStart, e = el.selectionEnd;
          const segment = draft.slice(s, e);
          const atLineStart = s === 0 || draft[s - 1] === "\n";
          const lines = segment.split("\n");
          const stripped = lines
            .map((line, i) => (i === 0 && !atLineStart ? stripLineLevel(line, false) : stripLineLevel(line, true)))
            .join("\n");
          const cleaned = stripMarkdownFormat(stripped);
          updateDraft(`${draft.slice(0, s)}${cleaned}${draft.slice(e)}`);
          requestAnimationFrame(() => { el.focus(); const p = s + cleaned.length; el.setSelectionRange(p, p); });
          return;
        }
        return updateDraft(stripMarkdownFormat(draft));
      }
      case "undo": return doUndo();
      case "redo": return doRedo();
    }
  }

  /** Line-start syntax stripping for the selection-aware clear action.
   * Prefix markers are only removed from lines that actually START inside the
   * selection (a mid-line selection must not lose its leading list marker). */
  function stripLineLevel(line: string, allowPrefix: boolean) {
    if (!allowPrefix) return line;
    return line
      .replace(/^\s{0,3}>\s?/, "")
      .replace(/^\s{0,3}#{1,6}\s+/, "")
      .replace(/^(\s*)[-*+]\s+\[[ xX]\]\s*/, "$1")
      .replace(/^(\s*)[-*+]\s+/, "$1")
      .replace(/^(\s*)\d+[.)]\s+/, "$1");
  }

  const copyCode = React.useCallback(async (code: string) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopiedCode(code);
      window.setTimeout(() => setCopiedCode((current) => current === code ? null : current), 1400);
    } catch {
      /* Clipboard may be unavailable in restricted WebViews. */
    }
  }, []);
  const previewContent = React.useMemo(() => toDisplay(draft), [draft, toDisplay]);
  // normalise math delimiters (\[ \], \( \), bare equations) before the
  // markdown pipeline — same line count, so scroll anchors stay valid.
  const mathReadyContent = React.useMemo(
    () => (appSettings.mathEnabled ? preprocessMathMarkdown(previewContent) : previewContent),
    [previewContent, appSettings.mathEnabled]
  );
  const searchMatches = React.useMemo(
    () => getSearchMatches(searchQuery),
    [draft, getSearchMatches, searchQuery]
  );

  // ---- progressive preview for big notes ------------------------------
  // The first screen of a large note is rendered immediately from a
  // prefix of the document (cut on a block boundary, never inside a code
  // fence); the rest streams in after paint in growing steps. A prefix
  // keeps every source offset valid, so exact selection, search counts,
  // task ticking and scroll anchors keep working. Searching for a hit that
  // is not rendered yet extends the prefix to it first, so no result is
  // ever "lost". Small notes (< BIG_NOTE_CHARS) render in one go, as before.
  const BIG_NOTE_CHARS = 30000;
  const FIRST_SLICE = 9000;
  const isBigNote = mathReadyContent.length > BIG_NOTE_CHARS;
  const [renderLimit, setRenderLimit] = React.useState<number>(FIRST_SLICE);
  const renderLimitRef = React.useRef(renderLimit);
  renderLimitRef.current = renderLimit;
  const growLimit = React.useCallback((min: number) => {
    setRenderLimit((cur) => (min > cur ? min : cur));
  }, []);
  // restart small whenever a note is opened or preview is (re)entered
  React.useLayoutEffect(() => {
    if (!preview) return;
    let want = FIRST_SLICE;
    const anchor = pendingAnchorRef.current;
    if (anchor?.charIdx != null) want = Math.max(want, anchor.charIdx + FIRST_SLICE);
    const mem = stateKey ? scrollMemory.get(stateKey) : undefined;
    if (mem && mem > 2) want = Math.max(want, mem * 4 + FIRST_SLICE);
    setRenderLimit(want);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [preview, stateKey]);
  // stream the remainder after paint
  React.useEffect(() => {
    if (!preview || !isBigNote || renderLimit >= mathReadyContent.length) return;
    const ric = (window as unknown as { requestIdleCallback?: (cb: () => void, o?: { timeout: number }) => number }).requestIdleCallback;
    let handle = 0;
    let timer = 0;
    const step = () => setRenderLimit((cur) => cur * 3);
    if (ric) handle = ric(step, { timeout: 400 });
    else timer = window.setTimeout(step, 80);
    return () => {
      if (handle && (window as unknown as { cancelIdleCallback?: (h: number) => void }).cancelIdleCallback) {
        (window as unknown as { cancelIdleCallback: (h: number) => void }).cancelIdleCallback(handle);
      }
      if (timer) clearTimeout(timer);
    };
  }, [preview, isBigNote, renderLimit, mathReadyContent.length]);
  // a search hit beyond the rendered prefix pulls the prefix forward
  React.useEffect(() => {
    if (!preview || !isBigNote || !searchQuery.trim()) return;
    const match = searchMatches[searchIndex];
    if (match && match.end + 2000 > renderLimitRef.current) growLimit(match.end + FIRST_SLICE);
  }, [preview, isBigNote, searchQuery, searchMatches, searchIndex, growLimit]);

  /** Prefix of the preview text, cut at a block boundary outside code fences,
   *  plus the identical line-prefix of the raw draft (for the offset map). */
  const renderSlice = React.useMemo(() => {
    const full = mathReadyContent;
    if (!isBigNote || renderLimit >= full.length) {
      return { text: full, source: draft, partial: false };
    }
    let cut = renderLimit;
    // never split inside an open code fence
    const fenceRe = /^ {0,3}(```|~~~)/gm;
    const head = full.slice(0, cut);
    let fences = 0;
    while (fenceRe.exec(head)) fences++;
    if (fences % 2 === 1) {
      const rest = /\n {0,3}(```|~~~)[^\n]*(\n|$)/.exec(full.slice(cut));
      cut = rest ? cut + rest.index + rest[0].length : full.length;
    } else {
      const blank = full.indexOf("\n\n", cut);
      cut = blank < 0 || blank - cut > 4000 ? full.indexOf("\n", cut) : blank;
      if (cut < 0) cut = full.length;
    }
    if (cut >= full.length) return { text: full, source: draft, partial: false };
    const text = full.slice(0, cut);
    const lines = text.split("\n").length;
    // same line count in the raw draft → matching source prefix
    let idx = 0;
    for (let i = 1; i < lines; i++) {
      const n = draft.indexOf("\n", idx);
      if (n < 0) { idx = draft.length; break; }
      idx = n + 1;
    }
    const nextNl = draft.indexOf("\n", idx);
    const source = draft.slice(0, nextNl < 0 ? draft.length : nextNl);
    return { text, source, partial: true };
  }, [mathReadyContent, draft, isBigNote, renderLimit]);
  const renderedLen = renderSlice.text.length;

  const navDoneRef = React.useRef<string | null>(null);
  React.useEffect(() => { if (!preview || !searchQuery.trim()) navDoneRef.current = null; }, [preview, searchQuery]);

  // keep the "n/total" counter truthful while the note text changes mid-search
  React.useEffect(() => {
    if (preview || !searchQuery.trim()) return;
    const total = searchMatches.length;
    const active = total ? Math.min(searchIndex, total - 1) : 0;
    onSearchResults?.({ count: total, active });
  }, [preview, searchQuery, searchMatches, searchIndex, onSearchResults]);

  // ---- edit-mode search highlights -----------------------------------
  // Highlight rectangles are measured from the same hidden mirror the editor
  // already uses for exact character geometry, then painted ABOVE the
  // textarea as click-through, semi-transparent boxes. Nothing depends on
  // textarea background, stacking or font settings, so they always show.
  const editWrapRef = React.useRef<HTMLDivElement | null>(null);
  // Older Android WebViews (Chrome < 123) do not know `field-sizing: content`;
  // the textarea would then scroll internally and every measured box would be
  // misplaced. Grow it by hand there so layout is identical everywhere.
  React.useLayoutEffect(() => {
    const el = textareaRef.current;
    if (preview || !el) return;
    if (typeof CSS !== "undefined" && CSS.supports?.("field-sizing", "content")) return;
    const fit = () => {
      if (!el.isConnected) return;
      el.style.height = "auto";
      el.style.height = `${el.scrollHeight}px`;
    };
    fit();
    const ro = new ResizeObserver(() => fit());
    ro.observe(el);
    return () => { ro.disconnect(); };
  }, [preview, draft]);
  const [editSearchRects, setEditSearchRects] = React.useState<
    { left: number; top: number; width: number; height: number; active: boolean }[]
  >([]);
  React.useLayoutEffect(() => {
    const wrap = editWrapRef.current;
    const el = textareaRef.current;
    if (preview || !wrap || !el || !searchQuery.trim() || searchMatches.length === 0) {
      setEditSearchRects((old) => (old.length ? [] : old));
      return;
    }
    let raf = 0;
    const measure = () => {
      raf = 0;
      if (!el.isConnected || !wrap.isConnected) return;
      const m = getMeter(el);
      m.sync();
      const wr = wrap.getBoundingClientRect();
      const tr = el.getBoundingClientRect();
      const mr = m.el.getBoundingClientRect();
      // account for any internal textarea scroll (fallback for engines that
      // cannot auto-size), so boxes always sit on the glyphs they cover
      const baseLeft = tr.left - wr.left - mr.left - el.scrollLeft;
      const baseTop = tr.top - wr.top - mr.top - el.scrollTop;
      const total = searchMatches.length;
      const active = Math.min(searchIndex, total - 1);
      // never draw more than ~500 boxes: the window around the active hit
      const from = Math.max(0, Math.min(active - 250, total - 500));
      const to = Math.min(total, from + 500);
      const len = m.text.length;
      const range = document.createRange();
      const out: { left: number; top: number; width: number; height: number; active: boolean }[] = [];
      for (let i = from; i < to; i++) {
        const match = searchMatches[i];
        try {
          range.setStart(m.text, Math.min(match.start, len));
          range.setEnd(m.text, Math.min(match.end, len));
        } catch { continue; }
        for (const r of Array.from(range.getClientRects())) {
          if (r.width <= 0 || r.height <= 0) continue;
          out.push({ left: r.left + baseLeft, top: r.top + baseTop, width: r.width, height: r.height, active: i === active });
        }
      }
      setEditSearchRects(out);
    };
    measure();
    // text size / width / font changes and late font loads re-measure
    const ro = new ResizeObserver(() => { if (!raf) raf = requestAnimationFrame(measure); });
    ro.observe(el);
    ro.observe(wrap);
    const again = () => { if (!raf) raf = requestAnimationFrame(measure); };
    // web fonts (note font setting) can finish loading after the first
    // measurement and reflow text without changing the box size
    let alive = true;
    const fonts = (document as Document & { fonts?: FontFaceSet }).fonts;
    fonts?.ready.then(() => { if (alive) again(); }).catch(() => {});
    fonts?.addEventListener?.("loadingdone", again);
    el.addEventListener("scroll", again, { passive: true });
    window.addEventListener("resize", again);
    // one settle re-measure after layout (keyboard / toolbar / scroll restore)
    const settle = window.setTimeout(again, 250);
    return () => {
      alive = false;
      ro.disconnect();
      if (raf) cancelAnimationFrame(raf);
      window.clearTimeout(settle);
      fonts?.removeEventListener?.("loadingdone", again);
      el.removeEventListener("scroll", again);
      window.removeEventListener("resize", again);
    };
  }, [preview, searchQuery, searchMatches, searchIndex, draft]);

  // Marks are placed from the same source-offset result list used by the
  // counter and edit-mode selection. Hidden fence labels therefore cannot
  // shift the active DOM hit index. Keep the rendered mark nodes indexed so
  // result-arrow clicks never query or walk the preview tree.
  React.useEffect(() => {
    const root = previewRef.current;
    if (!root || !preview || !searchQuery.trim() || searchMatches.length === 0) return;
    const decorations = searchMatches.flatMap((match, searchIndex) =>
      previewTextSegments(root, match.start, match.end).map((segment) => ({ ...segment, searchIndex }))
    );
    // Wrap from the end so splitting a Text node preserves earlier offsets.
    decorations.sort((a, b) => b.order - a.order || b.start - a.start);
    const marksByIndex = new Map<number, HTMLElement[]>();
    const createdMarks: HTMLElement[] = [];
    for (const decoration of decorations) {
      const { node, start, end, searchIndex } = decoration;
      if (!node.isConnected || start < 0 || end > node.length || end <= start) continue;
      const parent = node.parentNode;
      if (!parent) continue;
      let selected: Text = node;
      if (end < selected.length) selected.splitText(end);
      if (start > 0) selected = node.splitText(start);
      const mark = document.createElement("mark");
      mark.className = "search-hit";
      mark.dataset.searchIndex = String(searchIndex);
      parent.insertBefore(mark, selected);
      mark.appendChild(selected);
      createdMarks.push(mark);
      const matchMarks = marksByIndex.get(searchIndex) ?? [];
      matchMarks.push(mark);
      marksByIndex.set(searchIndex, matchMarks);
    }
    searchMarksRef.current = { root, byIndex: marksByIndex, activeIndex: null };
    if (createdMarks.length > 0) invalidatePreviewIndex(root);
    return () => {
      for (const mark of createdMarks) {
        if (mark.isConnected) mark.replaceWith(document.createTextNode(mark.textContent ?? ""));
      }
      if (searchMarksRef.current.root === root) {
        searchMarksRef.current = { root: null, byIndex: new Map(), activeIndex: null };
      }
    };
  }, [preview, renderedLen, mathReadyContent, searchMatches, searchQuery]);

  // Arrow navigation touches only the previous and next match's cached mark
  // nodes, and uses the indexed source map only when the result has no mark.
  React.useEffect(() => {
    if (!preview || !searchQuery.trim()) return;
    const root = previewRef.current;
    const container = scrollRef.current;
    const markIndex = searchMarksRef.current;
    if (!root || !container || markIndex.root !== root) return;
    if (markIndex.activeIndex !== searchIndex) {
      if (markIndex.activeIndex !== null) {
        for (const mark of markIndex.byIndex.get(markIndex.activeIndex) ?? []) {
          mark.classList.remove("search-hit-active");
        }
      }
      for (const mark of markIndex.byIndex.get(searchIndex) ?? []) {
        mark.classList.add("search-hit-active");
      }
      markIndex.activeIndex = searchIndex;
    }
    const active = (markIndex.byIndex.get(searchIndex) ?? []).find((mark) => mark.isConnected);
    let rect: DOMRect | null = active?.getBoundingClientRect() ?? null;
    if (!rect && searchMatches[searchIndex]) {
      const match = searchMatches[searchIndex];
      const range = previewRange(root, match.start, match.end)
        ?? previewNearestRange(root, match.start, 192);
      rect = range?.getBoundingClientRect() ?? null;
    }
    const navKey = `${searchQuery}:${searchIndex}`;
    const hasMark = !!active;
    if (hasMark && navDoneRef.current === navKey) return; // already scrolled here
    if (rect && !modePulseSelection && !choosingToggleWord) {
      if (hasMark) navDoneRef.current = navKey;
      const bounds = container.getBoundingClientRect();
      container.scrollTo({
        top: Math.max(0, container.scrollTop + rect.top - bounds.top - container.clientHeight * 0.35),
        behavior: "smooth",
      });
    }
  }, [preview, renderedLen, searchMatches, searchIndex, searchQuery]);

  const activeWord = pendingToggleSelection ?? modePulseSelection;
  const [selectionRects, setSelectionRects] = React.useState<{left:number;top:number;width:number;height:number}[]>([]);
  const [centerSpace, setCenterSpace] = React.useState(0);
  const [allowCenterSpace, setAllowCenterSpace] = React.useState(false);
  React.useLayoutEffect(() => {
    const container = scrollRef.current;
    if (!container || !allowCenterSpace) return;
    const update = () => setCenterSpace(container.clientHeight / 2);
    update();
    const observer = new ResizeObserver(update); observer.observe(container);
    return () => observer.disconnect();
  }, [allowCenterSpace]);

  // One geometry pipeline for both modes. No DOM mutation and no word search.
  React.useLayoutEffect(() => {
    const container = scrollRef.current;
    if (!container || activeWord?.start == null || activeWord.end == null) {
      setSelectionRects([]); return;
    }
    if (modePulseSelection) setAllowCenterSpace(true);
    let raf = 0;
    let cancelled = false;
    const began = performance.now();
    let previousSize = "";
    const draw = () => {
      if (cancelled) return;
      let rects: DOMRect[] = [];
      if (preview && previewRef.current) {
        rects = Array.from(previewRange(previewRef.current, activeWord.start!, activeWord.end!)?.getClientRects() ?? []);
      } else if (textareaRef.current) {
        const el = textareaRef.current;
        const meter = getMeter(el); meter.sync();
        const range = document.createRange();
        range.setStart(meter.text, Math.min(activeWord.start!, meter.text.length));
        range.setEnd(meter.text, Math.min(activeWord.end!, meter.text.length));
        const mr = meter.el.getBoundingClientRect(), tr = el.getBoundingClientRect();
        rects = Array.from(range.getClientRects()).map(r => new DOMRect(tr.left + r.left - mr.left - el.scrollLeft, tr.top + r.top - mr.top - el.scrollTop, r.width, r.height));
      }
      const c = container.getBoundingClientRect();
      const visibleTop = Math.max(c.top, window.visualViewport?.offsetTop ?? 0);
      const visibleBottom = Math.min(c.bottom, (window.visualViewport?.offsetTop ?? 0) + (window.visualViewport?.height ?? innerHeight));
      const size = `${visibleTop}:${visibleBottom}:${container.scrollHeight}`;
      const target = rects[0];
      let shift = 0;
      if (target && modePulseSelection && (performance.now() - began < 800 || size !== previousSize)) {
        stopPinRef.current();
        const old = container.scrollTop;
        container.scrollTop += target.top + target.height / 2 - (visibleTop + visibleBottom) / 2;
        shift = container.scrollTop - old;
      }
      previousSize = size;
      const next = rects.filter(r => r.width > 0).map(r => ({ left: r.left - c.left + container.scrollLeft, top: r.top - shift - c.top + container.scrollTop, width: r.width, height: r.height }));
      setSelectionRects(old => JSON.stringify(old) === JSON.stringify(next) ? old : next);
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    const timer = modePulseSelection ? window.setTimeout(() => setModePulseSelection(null), 3000) : undefined;
    return () => { cancelled = true; cancelAnimationFrame(raf); clearTimeout(timer); };
  }, [preview, activeWord, modePulseSelection, draft, mathReadyContent]);

  const actionHandler = React.useCallback(
    (actionName: string, replacement?: string, label?: string) => action(actionName, replacement, label),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [draft, doUndo, doRedo]
  );

  /** Shortcut → action bridge. Toolbar-only actions get dedicated handling. */
  const runShortcut = React.useCallback((actionId: string) => {
    switch (actionId) {
      case "preview": return void togglePreview();
      case "link": return openLinkPopoverRef.current();
      case "image": return onRequestInsertImages();
      case "insert-image": return onRequestInsertAtCursor?.();
      default: return actionHandler(actionId);
    }
  }, [togglePreview, onRequestInsertImages, onRequestInsertAtCursor, actionHandler]);
  runShortcutRef.current = runShortcut;

  /* ------------------------------------------------------------ image sizing
   * Size metadata is scoped to the selected Markdown object:
   *   - a normal Markdown image stores size=NN on that image only;
   *   - an HTML img-grid stores data-size=NN on that grid only.
   * The old always-visible overlay was removed. A long press (or context menu)
   * opens the control so reading and scrolling never show a large logo/button.
   */
  const [sizingFor, setSizingFor] = React.useState<string | null>(null);
  const [menuPosition, setMenuPosition] = React.useState<{ left: number; top: number } | null>(null);
  const longPressTimerRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const suppressClickRef = React.useRef(false);

  const parseImageSize = (title?: string): number | null => {
    if (!title) return null;
    const m = /(?:^|\s)size=(\d{1,3})\b/.exec(title);
    if (!m) return null;
    const n = Number(m[1]);
    return n >= 10 && n <= 100 ? n : null;
  };
  const parseGridSize = (props: Record<string, unknown>): number | null => {
    const raw = props["data-size"] ?? props.dataSize;
    const n = typeof raw === "number" ? raw : Number(raw);
    return Number.isFinite(n) && n >= 10 && n <= 100 ? n : null;
  };
  const sourceLineOf = (node: PositionalNode | undefined): number | undefined => node?.position?.start?.line;
  const lineAt = (text: string, index: number) => text.slice(0, index).split("\n").length;

  const setImageSize = React.useCallback(
    (target: { kind: "image" | "grid"; displayUrl?: string; sourceLine?: number }, size: number | null) => {
      let next = draft;
      if (target.kind === "grid") {
        const gridRe = /<div\b([^>]*\bclass\s*=\s*(?:"[^"]*\bimg-grid\b[^"]*"|'[^']*\bimg-grid\b[^']*')[^>]*)>/gi;
        let changed = false;
        next = next.replace(gridRe, (full, attrs: string, offset: number) => {
          if (changed || (target.sourceLine && lineAt(draft, offset) !== target.sourceLine)) return full;
          changed = true;
          let updated = attrs.replace(/\sdata-size=(?:"[^" ]*"|'[^' ]*')/i, "");
          if (size != null) updated += ` data-size="${size}"`;
          return `<div${updated}>`;
        });
      } else {
        // Update the exact Markdown image occurrence by its source line. Do
        // not depend on a blob URL lookup: the persisted draft may contain an
        // attachment path while the preview contains a resolved blob URL.
        let changed = false;
        const imageRe = /(!\[[^\]]*\]\(\s*)([^)\s]+)((?:\s+"[^"]*")?)(\s*\))/g;
        next = next.replace(imageRe, (full, head: string, url: string, oldTitle: string, tail: string, offset: number) => {
          if (changed || (target.sourceLine && lineAt(draft, offset) !== target.sourceLine)) return full;
          const displayUrl = target.displayUrl ?? "";
          const file = urlToFileRef.current.get(displayUrl);
          const decodedUrl = url;
          const matchesTarget = decodedUrl === displayUrl || decodedUrl === file || decodedUrl === (file ? encodeAttachmentPath(file) : "");
          if (!matchesTarget) return full;
          changed = true;
          return size == null ? `${head}${url}${tail}` : `${head}${url} "size=${size}"${tail}`;
        });
        // v18 also accepts a standalone raw-HTML image in Markdown. The
        // Markdown-only mutation above leaves that form unchanged, making its
        // size slider appear frozen. Persist the same size metadata as an
        // HTML title so the existing img renderer applies it on the next pass.
        if (!changed) {
          const htmlImageRe = /<img\b([^>]*\bsrc\s*=\s*(?:"([^"]*)"|'([^']*)')[^>]*)>/gi;
          next = next.replace(htmlImageRe, (full, attrs: string, doubleSrc: string, singleSrc: string, offset: number) => {
            if (changed || (target.sourceLine && lineAt(draft, offset) !== target.sourceLine)) return full;
            const rawSrc = doubleSrc || singleSrc || "";
            const displayUrl = target.displayUrl ?? "";
            const file = urlToFileRef.current.get(displayUrl);
            const matchesTarget = rawSrc === displayUrl || rawSrc === file || rawSrc === (file ? encodeAttachmentPath(file) : "");
            if (!matchesTarget) return full;
            changed = true;
            let updated = attrs;
            const titleMatch = /\stitle=("([^"]*)"|'([^']*)')/i.exec(updated);
            if (size == null) {
              if (titleMatch && /(?:^|\s)size=\d{1,3}\b/.test(titleMatch[2] ?? titleMatch[3] ?? "")) {
                updated = updated.replace(titleMatch[0], "");
              }
            } else if (titleMatch) {
              updated = updated.replace(titleMatch[0], ` title="size=${size}"`);
            } else {
              updated += ` title="size=${size}"`;
            }
            return `<img${updated}>`;
          });
        }
      }
      if (next === draft) return;
      // Preserve the actual editor viewport for image-size actions. The
      // rendered image height changes after this state update; restoring the
      // numeric scrollTop over two frames prevents the browser/WebView from
      // clamping the editor to 0 while the image reflows.
      const scrollElement = scrollRef.current;
      const preservedScrollTop = scrollElement?.scrollTop ?? 0;
      stopPinRef.current();
      pendingAnchorRef.current = null;
      const clean = fromDisplay(next);
      setDraft(clean);
      pushNow(clean);
      commitHistory(clean, "action");
      if (scrollElement) {
        const restore = () => {
          const max = Math.max(0, scrollElement.scrollHeight - scrollElement.clientHeight);
          scrollElement.scrollTop = Math.min(preservedScrollTop, max);
        };
        requestAnimationFrame(() => {
          restore();
          requestAnimationFrame(restore);
        });
      }
    },
    [draft, captureAnchor, commitHistory, fromDisplay, pushNow]
  );

  /** Run a state change without letting the editor viewport move. Opening or
   * closing the size menu must never scroll the note; this captures scrollTop
   * first and re-applies it for a few frames while layout settles (images
   * reflow, fonts load), stopping the moment the user scrolls on their own. */
  const withScrollPreserved = React.useCallback((change: () => void) => {
    const el = scrollRef.current;
    const top = el?.scrollTop ?? 0;
    stopPinRef.current();
    pendingAnchorRef.current = null;
    change();
    if (!el) return;
    let frames = 0;
    let last = top;
    const restore = () => {
      // user scrolled by themselves → leave them alone
      if (frames > 0 && el.scrollTop !== 0 && Math.abs(el.scrollTop - last) > 6) return;
      const max = Math.max(0, el.scrollHeight - el.clientHeight);
      const next = Math.min(top, max);
      if (Math.abs(el.scrollTop - next) > 1) el.scrollTop = next;
      last = el.scrollTop;
      if (++frames < 12) requestAnimationFrame(restore);
    };
    requestAnimationFrame(restore);
  }, []);
  const closeSizing = React.useCallback(() => {
    withScrollPreserved(() => { setSizingFor(null); setMenuPosition(null); });
  }, [withScrollPreserved]);

  const openSizingAt = React.useCallback((key: string, clientX: number, clientY: number) => {
    // Fixed positioning prevents the menu from being re-laid out with the
    // image when its width changes. Clamp against the viewport so it never
    // opens partly off-screen on a phone or desktop edge.
    const menuWidth = 198;
    const menuHeight = 132;
    const gap = 10;
    const maxLeft = Math.max(gap, window.innerWidth - menuWidth - gap);
    const maxTop = Math.max(gap, window.innerHeight - menuHeight - gap);
    const left = Math.max(gap, Math.min(clientX - menuWidth / 2, maxLeft));
    const top = Math.max(gap, Math.min(clientY - menuHeight - 12, maxTop));
    withScrollPreserved(() => { setMenuPosition({ left, top }); setSizingFor(key); });
  }, [withScrollPreserved]);
  const beginLongPress = React.useCallback((key: string, event: React.PointerEvent) => {
    if (event.pointerType === "mouse" && event.button !== 0) return;
    if (longPressTimerRef.current) clearTimeout(longPressTimerRef.current);
    const { clientX, clientY } = event;
    longPressTimerRef.current = setTimeout(() => {
      suppressClickRef.current = true;
      openSizingAt(key, clientX, clientY);
    }, 520);
  }, [openSizingAt]);
  const endLongPress = React.useCallback(() => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  }, []);
  const openSizingFromContext = React.useCallback((key: string, event: React.MouseEvent) => {
    event.preventDefault();
    openSizingAt(key, event.clientX, event.clientY);
  }, [openSizingAt]);
  const closeAfterClickGuard = React.useCallback(() => {
    if (!suppressClickRef.current) return false;
    suppressClickRef.current = false;
    return true;
  }, []);

  const renderImageSizeMenu = (
    key: string,
    target: { kind: "image" | "grid"; displayUrl?: string; sourceLine?: number },
    size: number | null
  ) => sizingFor === key ? (
    <span
      className="md-image-menu"
      style={menuPosition ? { left: `${menuPosition.left}px`, top: `${menuPosition.top}px` } : undefined}
      onPointerDown={(e) => e.stopPropagation()}
      onClick={(e) => e.stopPropagation()}
    >
      <span className="md-image-menu-title">Image width</span>
      <span className="md-image-menu-row">
        {[['S', 35], ['M', 55], ['L', 75], ['Full', 100]].map(([label, value]) => (
          <button key={label as string} type="button" className={cn("md-image-menu-preset", size === value && "md-image-menu-preset-active")} onClick={() => setImageSize(target, value as number)}>{label}</button>
        ))}
        <button type="button" className={cn("md-image-menu-preset", size == null && "md-image-menu-preset-active")} onClick={() => setImageSize(target, null)}>Auto</button>
      </span>
      <input type="range" min={20} max={100} step={5} value={size ?? 60} aria-label="Image width percent" onChange={(e) => setImageSize(target, Number(e.target.value))} />
      <span className="md-image-menu-value">{size == null ? "Auto" : `${size}%`}</span>
      <button type="button" className="md-image-menu-done" onClick={closeSizing}>Done</button>
    </span>
  ) : null;

  const chooseWordFromPreview = React.useCallback((event: React.MouseEvent) => {
    if (!previewRef.current) return;
    const at = sourceAtPoint(previewRef.current, event.clientX, event.clientY, event.target);
    if (at == null) return;
    const bounds = wordBounds(draftRef.current, at);
    if (!bounds.word.trim()) return;
    // v18: with "Require Done" off, the tapped word switches the mode instantly.
    if (!appSettings.confirmWordSelection) {
      performTogglePreview(bounds);
      window.getSelection()?.removeAllRanges();
      return;
    }
    setPendingToggleSelection(bounds);
    window.getSelection()?.removeAllRanges();
  }, [appSettings.confirmWordSelection, performTogglePreview]);
  const chooseWordFromEdit = React.useCallback(() => {
    const el = textareaRef.current;
    if (!el) return;
    const bounds = wordBounds(draftRef.current, el.selectionStart);
    if (!bounds.word) return;
    if (!appSettings.confirmWordSelection) {
      performTogglePreview(bounds);
      return;
    }
    setPendingToggleSelection(bounds);
    el.setSelectionRange(bounds.start, bounds.end);
  }, [appSettings.confirmWordSelection, performTogglePreview]);

  // apply any pending anchor after EVERY render (mode switches, image
  // resizes, task ticks — anything that must not move the viewport)
  React.useEffect(() => {
    runAnchorRestore();
  });

  // ---------------------------------------------------------------------
  // Preview components.
  // react-markdown treats every NEW component function as a NEW element
  // type and remounts the whole subtree. These used to be rebuilt inline on
  // every render (lineBlock("p") creates a fresh function each call), so ANY
  // state change — opening/closing the image-size menu, pressing Done —
  // tore down and re-created every paragraph and image. The preview
  // collapsed for a frame, the browser clamped scrollTop to 0, and the user
  // was thrown to the top of the note.
  // Fix: the renderers below are re-created each render (so they always see
  // fresh state), but react-markdown is handed STABLE wrapper components that
  // forward to the latest renderers. Nothing remounts; the DOM is patched in
  // place and the scroll position is untouched.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const previewRenderers: Record<string, (props: any) => React.ReactNode> = {
                // block-level elements carry their markdown source line so
                // edit ↔ preview switches (and image resizes) can pin the
                // viewport to the EXACT same content — no more jumps.
                p: lineBlock("p"),
                h1: lineBlock("h1"),
                h2: lineBlock("h2"),
                h3: lineBlock("h3"),
                h4: lineBlock("h4"),
                h5: lineBlock("h5"),
                h6: lineBlock("h6"),
                ul: lineBlock("ul"),
                ol: lineBlock("ol"),
                blockquote: lineBlock("blockquote"),
                hr: lineBlock("hr"),
                div: ({ node, children, className, ...props }) => {
                  const isGrid = typeof className === "string" && className.split(/\s+/).includes("img-grid");
                  if (!isGrid) return <div {...props} className={className} {...srcLineAttr(node)}>{children}</div>;
                  const sourceLine = sourceLineOf(node);
                  const key = `grid:${sourceLine ?? "unknown"}`;
                  const size = parseGridSize(props as Record<string, unknown>);
                  const style = { ...(props.style as React.CSSProperties | undefined), ...(size ? { width: `${size}%` } : {}) };
                  return (
                    <>
                      <div {...props} className={className} style={style} {...srcLineAttr(node)} onPointerDown={(e) => beginLongPress(key, e)} onPointerUp={endLongPress} onPointerCancel={endLongPress} onContextMenu={(e) => openSizingFromContext(key, e)}>{children}</div>
                      {renderImageSizeMenu(key, { kind: "grid", sourceLine }, size)}
                    </>
                  );
                },
                table: ({ node, children, ...props }) => (
                  <div
                    {...props}
                    className="md-table-wrap"
                    {...srcLineAttr(node)}
                  >
                    <table>{children}</table>
                  </div>
                ),
                pre: ({ node, children }) => {
                  const codeElement = React.Children.toArray(children).find((child) => React.isValidElement(child));
                  const text = codeElement && React.isValidElement(codeElement)
                    ? renderedText((codeElement.props as { children?: React.ReactNode }).children).replace(/\n$/, "")
                    : "";
                  return (
                    <div className="md-code-wrap" {...srcLineAttr(node)}>
                      <pre>{children}</pre>
                      <button type="button" className="md-code-copy" onClick={() => void copyCode(text)} aria-label="Copy code">
                        {copiedCode === text ? "Copied" : "Copy"}
                      </button>
                    </div>
                  );
                },
                code: ({ children, className, ...props }) => <code {...props} className={cn(className, "md-code-content")}>{children}</code>,
                input: ({ checked, disabled, ...props }) => (
                  // `disabled` is destructured OUT — react-markdown marks
                  // GFM task checkboxes disabled, which made ticking impossible
                  // in the preview. Toggles now write straight back to the note.
                  <input
                    {...props}
                    type="checkbox"
                    checked={!!checked}
                    aria-label={checked ? "Completed task" : "Incomplete task"}
                    onChange={(event) => {
                      const inputs = Array.from(
                        event.currentTarget.closest(".md-preview")?.querySelectorAll('input[type="checkbox"]') ?? []
                      );
                      const index = inputs.indexOf(event.currentTarget);
                      if (index >= 0) {
                        const anchor = captureAnchor();
                        if (anchor) pendingAnchorRef.current = anchor;
                        updateDraft(toggleTaskLine(draft, index, event.currentTarget.checked));
                      }
                    }}
                  />
                ),
                img: ({ src, alt, title, node, ...props }) => {
                  const raw = typeof src === "string" ? src : "";
                  const resolved = raw.startsWith("attachment/")
                    ? fileToUrl(decodeAttachmentPath(raw)) || fileToUrl(raw)
                    : raw;
                  if (!resolved) return <span className="md-image-missing">{alt || "Image unavailable"}</span>;
                  const imgProps = props as unknown as React.ImgHTMLAttributes<HTMLImageElement>;
                  const sourceLine = sourceLineOf(node as PositionalNode | undefined);
                  const size = parseImageSize(typeof title === "string" ? title : undefined);
                  const key = `image:${sourceLine ?? "unknown"}:${resolved}`;
                  const target = { kind: "image" as const, displayUrl: resolved, sourceLine };
                  return (
                    <span className="md-image-wrap" data-sizable={resolved} onPointerDown={(e) => beginLongPress(key, e)} onPointerUp={endLongPress} onPointerCancel={endLongPress} onContextMenu={(e) => openSizingFromContext(key, e)}>
                      <img {...imgProps} src={resolved} alt={alt ?? ""} loading="lazy" decoding="async" data-size={size ?? undefined} style={size ? { width: `${size}%`, maxWidth: "100%" } : undefined} className="md-inline-image" onClick={(event) => { if (closeAfterClickGuard()) { event.preventDefault(); event.stopPropagation(); return; } event.preventDefault(); event.stopPropagation(); onOpenImage?.(resolved, alt ?? ""); }} />
                      {renderImageSizeMenu(key, target, size)}
                    </span>
                  );
                },
                a: ({ href, children, ...props }) => {
                  const rawHref = typeof href === "string" ? href : "";
                  const attachmentUrl = rawHref.startsWith("attachment/")
                    ? fileToUrl(decodeAttachmentPath(rawHref)) || fileToUrl(rawHref)
                    : rawHref.startsWith("blob:") || rawHref.startsWith("data:")
                      ? rawHref
                      : "";
                  if (attachmentUrl) {
                    const alt = renderedText(children);
                    const imgProps = props as unknown as React.ImgHTMLAttributes<HTMLImageElement>;
                    return (
                      <img
                        {...imgProps}
                        src={attachmentUrl}
                        alt={alt || "Attached image"}
                        className="md-inline-image"
                        onClick={(event) => {
                          event.preventDefault();
                          event.stopPropagation();
                          onOpenImage?.(attachmentUrl, alt || "Attached image");
                        }}
                      />
                    );
                  }
                  const normalizedHref = /^(https?:\/\/|mailto:|tel:|sms:|geo:)/i.test(rawHref)
                    ? rawHref
                    : /^(www\.)|^[^\s/?#]+\.[^\s/?#]+$/i.test(rawHref)
                      ? `https://${rawHref}`
                      : rawHref;
                  return <a {...props} href={normalizedHref} target="_blank" rel="noopener noreferrer">{children}</a>;
                },
  };
  const previewRenderersRef = React.useRef(previewRenderers);
  previewRenderersRef.current = previewRenderers;
  const stablePreviewComponents = React.useMemo(() => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const out: Record<string, (props: any) => React.ReactNode> = {};
    for (const tag of Object.keys(previewRenderersRef.current)) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      out[tag] = (props: any) => previewRenderersRef.current[tag]?.(props) ?? null;
    }
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []) as unknown as import("react-markdown").Options["components"];

  return (
    <div className="md-editor flex min-h-0 flex-1 flex-col">
      {choosingToggleWord ? (
        <div className="sticky top-0 z-30 flex min-h-12 shrink-0 items-center gap-2 border-b border-primary/30 bg-primary/10 px-3 py-2 text-sm text-primary">
          <span className="min-w-0 flex-1">
            {appSettings.confirmWordSelection
              ? pendingToggleSelection
                ? `Selected “${pendingToggleSelection.word}”`
                : "Tap one word to select the exact occurrence"
              : pendingToggleSelection
                ? `Selected “${pendingToggleSelection.word}”`
                : "Tap one word — the mode switches instantly"}
          </span>
          <button type="button" className="shrink-0 rounded-md px-3 py-1.5 text-xs font-medium text-muted-foreground hover:bg-black/10 dark:hover:bg-white/10" onClick={() => { setChoosingToggleWord(false); setPendingToggleSelection(null); window.getSelection()?.removeAllRanges(); }}>Cancel</button>
          {appSettings.confirmWordSelection ? (
            <button type="button" className="shrink-0 rounded-md bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground shadow-sm disabled:cursor-not-allowed disabled:opacity-40" disabled={!pendingToggleSelection} onClick={confirmToggleSelection}>Done</button>
          ) : null}
        </div>
      ) : null}
      <div className="sticky top-0 z-20 shrink-0">
        <Toolbar editor={textareaRef.current} preview={preview} onTogglePreview={togglePreview} onPickImages={onRequestInsertImages} onInsertAtCursor={() => onRequestInsertAtCursor?.()} onAction={actionHandler} onRegisterLinkOpener={onRegisterLinkOpener} />
      </div>
      <div
        ref={scrollRef}
        className="relative min-h-0 flex-1 overflow-y-auto px-4 pb-8 pt-2"
        style={{ overflowAnchor: "none" }}
      >
        {beforeContent}
        {allowCenterSpace && <div aria-hidden="true" style={{ height: centerSpace, pointerEvents: "none" }} />}
        {selectionRects.map((rect, index) => <span key={index} aria-hidden="true" data-selection-overlay="true" data-source-start={activeWord?.start} data-source-end={activeWord?.end} className={modePulseSelection ? "exact-word-overlay exact-word-pulse" : "exact-word-overlay"} style={rect} />)}
        {preview ? (
          <div ref={previewRef} className="md-preview md-prose min-h-[40vh]" aria-label="Rendered Markdown preview" onClickCapture={(event) => { if (choosingToggleWord) { event.preventDefault(); event.stopPropagation(); chooseWordFromPreview(event); } }}>
            <ReactMarkdown
              remarkPlugins={[remarkGfm, ...(appSettings.mathEnabled ? [remarkMath] : [])]}
              rehypePlugins={[
                rehypeUpgradeDisplayMath,
                rehypeRaw,
                [rehypeExactSelection, { source: renderSlice.source }],
                [rehypeSanitize, safeMarkdownSchema],
                ...katexPlugins,
              ]}
              urlTransform={previewUrlTransform}
              components={stablePreviewComponents}
            >{renderSlice.text || "*Nothing to preview yet.*"}</ReactMarkdown>
          </div>
        ) : (
          <div ref={editWrapRef} className="md-edit-wrap relative">
          <textarea
            ref={textareaRef}
            value={draft}
            onChange={(e) => updateDraft(e.target.value, "type")}
            onKeyDown={handleEditorKeyDown}
            onClick={() => { if (choosingToggleWord) chooseWordFromEdit(); }}
            onPaste={(e) => {
              const files = e.clipboardData.files;
              if (files.length > 0 && [...files].every((f) => f.type.startsWith("image/"))) {
                e.preventDefault();
                onPasteImages?.(Array.from(files));
              }
            }}
            placeholder={placeholder ?? "Start writing…"}
            readOnly={choosingToggleWord}
            spellCheck
            className="md-textarea block min-h-[40vh] w-full resize-none bg-transparent text-[0.925rem] leading-[1.65] outline-none"
          />
          {editSearchRects.map((r, i) => (
            <span
              key={i}
              aria-hidden="true"
              data-edit-search-hit={r.active ? "active" : "hit"}
              className={r.active ? "md-edit-search-hit md-edit-search-hit-active" : "md-edit-search-hit"}
              style={{ left: r.left, top: r.top, width: r.width, height: r.height }}
            />
          ))}
          </div>
        )}
        {allowCenterSpace && <div aria-hidden="true" style={{ height: centerSpace, pointerEvents: "none" }} />}
      </div>
    </div>
  );
});

export function buildUrlToFileMap(attachments: { file: string; url: string }[]): Map<string, string> {
  const map = new Map<string, string>();
  for (const a of attachments) if (a.url) map.set(a.url, a.file);
  return map;
}
