"use client";

import { useEffect, useState } from "react";
import type { AttachmentDTO } from "@/core/types";
import { getRepo } from "./store";

let repoCache: ReturnType<typeof getRepo> | null = null;
function repo() {
  return getRepo();
}

/**
 * Resolves an attachment's display URL (object URL backed by the local file).
 * AttachmentDTOs loaded during a disk scan carry url === "" — this hook loads
 * the bytes lazily and keeps them cached in the repository.
 */
export function useAttachmentUrl(
  dir: string,
  att: AttachmentDTO | null | undefined
): string {
  const fileKey = att ? `${dir}/${att.file}` : "";
  const [loaded, setLoaded] = useState<{ key: string; url: string } | null>(null);
  const url = att ? att.url || (loaded?.key === fileKey ? loaded.url : "") : "";

  useEffect(() => {
    if (!att || att.url) return;
    let alive = true;
    repo()
      .ensureAttachmentUrl(dir, att.file)
      .then((u) => {
        if (alive && u) setLoaded({ key: fileKey, url: u });
      })
      .catch(() => undefined);
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fileKey, att?.url]);

  return url;
}

/** Resolve all of a note's attachments (used before opening the editor). */
export async function resolveAttachmentUrls(
  dir: string,
  attachments: AttachmentDTO[]
): Promise<Map<string, string>> {
  const map = new Map<string, string>();
  await Promise.all(
    attachments.map(async (att) => {
      const url = att.url || (await repo().ensureAttachmentUrl(dir, att.file));
      if (url) map.set(att.file, url);
    })
  );
  return map;
}

/**
 * Progressive variant: reports each attachment the moment it is ready
 * (batched to one callback per frame) instead of waiting for every file.
 * A small worker pool keeps the disk busy without flooding it. Nothing is
 * downscaled or skipped — every attachment still resolves to its full file.
 */
export function resolveAttachmentUrlsProgressive(
  dir: string,
  attachments: AttachmentDTO[],
  onUpdate: (map: Map<string, string>) => void,
  isAlive: () => boolean,
  concurrency = 4
): void {
  const map = new Map<string, string>();
  let queue = [...attachments];
  let scheduled = false;
  const flush = () => {
    scheduled = false;
    if (isAlive()) onUpdate(new Map(map));
  };
  const schedule = () => {
    if (scheduled) return;
    scheduled = true;
    if (typeof requestAnimationFrame === "function") requestAnimationFrame(flush);
    else setTimeout(flush, 16);
  };
  // attachments that already carry a URL are available immediately
  for (const att of attachments) if (att.url) map.set(att.file, att.url);
  queue = queue.filter((a) => !a.url);
  if (map.size) schedule();
  const worker = async () => {
    while (isAlive()) {
      const att = queue.shift();
      if (!att) return;
      const url = await repo().ensureAttachmentUrl(dir, att.file);
      if (url) {
        map.set(att.file, url);
        schedule();
      }
    }
  };
  for (let i = 0; i < Math.min(concurrency, queue.length); i++) void worker();
}
