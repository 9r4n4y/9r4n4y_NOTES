# Notenoid v15.0

Android version code: **150** · Package: `com.notes.app`

## Selection workflow

The word-selection handoff has been rewritten around exact source character ranges and a shared highlight-overlay renderer. Preview taps identify their source occurrence through the parsed Markdown text map. Edit taps retain their original character offsets. Neither direction searches the entire note for another matching word.

Both modes show a pending yellow highlight before Done. Done changes the mode, brings the chosen occurrence to the center of the visible Markdown area, and blinks its highlight for three seconds. Half-viewport scroll space allows the first and last words to center rather than stopping at an edge. Reduced-motion settings replace blinking with a steady highlight.

Double-tapping the mode control cannot accidentally confirm a pending selection. Done is the confirmation action; Cancel keeps the current mode. Empty notes still switch directly. New installations enable the confirmation workflow by default; existing saved preferences are respected.

## Other changes

- Source-position support for multiline text, Markdown emphasis/link labels, inline/fenced code, tasks, and table cells.
- Word boundaries include Unicode combining marks for Hindi and similar scripts.
- Preview selection intercepts navigation/task actions while a word is being chosen.
- Code-copy and attachment text-label extraction support mapped text spans.
- About badge, package version, and Android release metadata updated to v15.
- Current-only release documentation and automated selection/smoke tests included.
- TypeScript build errors are no longer ignored.
- Memory-conscious webpack static build and SDK setup pipeline correction.

See `VALIDATION-V15.md` for verified behavior and testing limits. Visible text is the selection target; generated equation glyphs, images, and source-only Markdown syntax do not have a guaranteed rendered word counterpart.
