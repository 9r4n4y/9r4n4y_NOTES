"use client";

// ---------------------------------------------------------------------------
// Vault protection
//
// There is exactly one vault password. Setup also records exactly two security
// questions. The UI exposes three separate owner actions:
//   1. Change password: current password -> new password.
//   2. Forgot password: answer the recorded questions; at least one correct
//      answer is enough to choose a new password.
//   3. Change security questions: current password AND at least one correct
//      existing answer are required before replacing both questions.
//
// Passwords and answers are stored only as PBKDF2-SHA256 hashes. The legacy
// hash is still accepted once so existing users are not locked out; a
// successful unlock upgrades it to the single-password record format.
// ---------------------------------------------------------------------------

export const VAULT_RECORD_KEY = "notes-vault-record-v2";
export const VAULT_LEGACY_CODE_KEY = "notes-vault-code-hash";
export const VAULT_SESSION_KEY = "notes-vault-open";

export const SECURITY_QUESTIONS: { id: string; text: string }[] = [
  { id: "first_school", text: "What was the name of your first school?" },
  { id: "maiden_name", text: "What is your mother's maiden name?" },
  { id: "first_pet", text: "What was the name of your first pet?" },
  { id: "birth_city", text: "In which city were you born?" },
  { id: "favourite_book", text: "What is your favourite book?" },
  { id: "childhood_friend", text: "Who was your best childhood friend?" },
  { id: "first_vehicle", text: "What was the model of your first car or bike?" },
  { id: "favourite_food", text: "What is your favourite food?" },
  { id: "nickname", text: "What was your childhood nickname?" },
  { id: "grew_up_street", text: "What street did you grow up on?" },
  { id: "favourite_movie", text: "What is your favourite movie?" },
  { id: "first_job", text: "Where did you work for the first time?" },
  { id: "oldest_cousin", text: "What is your oldest cousin's name?" },
  { id: "first_teacher", text: "What was the name of your first teacher?" },
  { id: "dream_place", text: "What is your dream travel destination?" },
];

export function questionText(id: string): string {
  return SECURITY_QUESTIONS.find((q) => q.id === id)?.text ?? "Security question";
}

export interface VaultQuestionRecord {
  id: string;
  salt: string;
  answerHash: string;
}

export interface VaultRecord {
  v: 2;
  salt: string;
  passwordHash: string;
  iterations: number;
  questions: VaultQuestionRecord[];
}

export interface SetupQuestionInput {
  id: string;
  answer: string;
}

type AnswerInput = { id: string; answer: string };

const PBKDF2_ITERATIONS = 150_000;

function toHex(buf: ArrayBuffer | Uint8Array): string {
  const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
}

function randomHex(bytes = 16): string {
  const arr = new Uint8Array(bytes);
  crypto.getRandomValues(arr);
  return toHex(arr);
}

async function sha256Hex(text: string): Promise<string> {
  return toHex(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text)));
}

async function pbkdf2Hex(text: string, saltHex: string, iterations: number): Promise<string> {
  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(text),
    "PBKDF2",
    false,
    ["deriveBits"]
  );
  const salt = new Uint8Array((saltHex.match(/.{2}/g) ?? []).map((b) => parseInt(b, 16)));
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", salt, iterations },
    keyMaterial,
    256
  );
  return toHex(bits);
}

function normaliseAnswer(answer: string): string {
  return answer.trim().replace(/\s+/g, " ").toLocaleLowerCase();
}

function readRecord(): VaultRecord | null {
  try {
    const raw = localStorage.getItem(VAULT_RECORD_KEY);
    if (!raw) return null;
    const rec = JSON.parse(raw) as VaultRecord;
    if (!rec || rec.v !== 2 || !rec.passwordHash || !rec.salt) return null;
    return {
      ...rec,
      iterations: rec.iterations || PBKDF2_ITERATIONS,
      questions: Array.isArray(rec.questions) ? rec.questions : [],
    };
  } catch {
    return null;
  }
}

function writeRecord(rec: VaultRecord | null): void {
  try {
    if (rec) localStorage.setItem(VAULT_RECORD_KEY, JSON.stringify(rec));
    else localStorage.removeItem(VAULT_RECORD_KEY);
  } catch {
    // Storage errors are surfaced by the caller's normal failure path.
  }
}

function validateQuestions(questions: [SetupQuestionInput, SetupQuestionInput]): void {
  if (questions[0].id === questions[1].id) throw new Error("Choose two different security questions");
  if (questions.some((q) => !q.id || !q.answer.trim())) throw new Error("Both security answers are required");
}

export function vaultPasswordExists(): boolean {
  if (readRecord()) return true;
  try {
    return Boolean(localStorage.getItem(VAULT_LEGACY_CODE_KEY));
  } catch {
    return false;
  }
}

export function hasSecurityQuestions(): boolean {
  return readRecord()?.questions.length === 2;
}

export function getSecurityQuestionIds(): string[] {
  return readRecord()?.questions.map((q) => q.id) ?? [];
}

export function readVaultRecord(): VaultRecord | null {
  return readRecord();
}

export function writeVaultRecord(rec: VaultRecord): void {
  if (rec && rec.v === 2 && typeof rec.passwordHash === "string" && typeof rec.salt === "string") {
    writeRecord({
      ...rec,
      iterations: rec.iterations || PBKDF2_ITERATIONS,
      questions: Array.isArray(rec.questions) ? rec.questions : [],
    });
  }
}

export async function setupVaultPassword(
  password: string,
  questions: [SetupQuestionInput, SetupQuestionInput]
): Promise<void> {
  validateQuestions(questions);
  const salt = randomHex();
  const qRecords: VaultQuestionRecord[] = [];
  for (const question of questions) {
    const qSalt = randomHex();
    qRecords.push({
      id: question.id,
      salt: qSalt,
      answerHash: await pbkdf2Hex(normaliseAnswer(question.answer), qSalt, PBKDF2_ITERATIONS),
    });
  }
  writeRecord({
    v: 2,
    salt,
    passwordHash: await pbkdf2Hex(password, salt, PBKDF2_ITERATIONS),
    iterations: PBKDF2_ITERATIONS,
    questions: qRecords,
  });
  try {
    localStorage.removeItem(VAULT_LEGACY_CODE_KEY);
  } catch {
    // ignore legacy cleanup failures
  }
}

export async function verifyVaultPassword(password: string): Promise<boolean> {
  const rec = readRecord();
  if (rec) {
    return (await pbkdf2Hex(password, rec.salt, rec.iterations || PBKDF2_ITERATIONS)) === rec.passwordHash;
  }

  // One-time compatibility migration for old installations. No legacy UI or
  // second credential is exposed after this succeeds.
  let legacy: string | null = null;
  try {
    legacy = localStorage.getItem(VAULT_LEGACY_CODE_KEY);
  } catch {
    legacy = null;
  }
  if (!legacy || (await sha256Hex(password)) !== legacy) return false;
  const salt = randomHex();
  writeRecord({
    v: 2,
    salt,
    passwordHash: await pbkdf2Hex(password, salt, PBKDF2_ITERATIONS),
    iterations: PBKDF2_ITERATIONS,
    questions: [],
  });
  try {
    localStorage.removeItem(VAULT_LEGACY_CODE_KEY);
  } catch {
    // ignore
  }
  return true;
}

/** Flow 1: change the password using only the current password. */
export async function changeVaultPassword(current: string, next: string): Promise<boolean> {
  if (!(await verifyVaultPassword(current))) return false;
  const rec = readRecord();
  if (!rec) return false;
  const salt = randomHex();
  rec.salt = salt;
  rec.passwordHash = await pbkdf2Hex(next, salt, PBKDF2_ITERATIONS);
  rec.iterations = PBKDF2_ITERATIONS;
  writeRecord(rec);
  return true;
}

/** Return how many recorded answers match. Unknown question IDs never match. */
export async function countCorrectSecurityAnswers(answers: AnswerInput[]): Promise<number> {
  const rec = readRecord();
  if (!rec || rec.questions.length !== 2) return 0;
  const byId = new Map(rec.questions.map((q) => [q.id, q]));
  let correct = 0;
  for (const answer of answers) {
    if (!answer.answer.trim()) continue;
    const question = byId.get(answer.id);
    if (!question) continue;
    const hash = await pbkdf2Hex(normaliseAnswer(answer.answer), question.salt, rec.iterations || PBKDF2_ITERATIONS);
    if (hash === question.answerHash) correct += 1;
  }
  return correct;
}

/** At least one correct answer is sufficient; the other answer may be wrong. */
export async function verifySecurityAnswers(answers: AnswerInput[]): Promise<boolean> {
  return (await countCorrectSecurityAnswers(answers)) >= 1;
}

/** Flow 2: forgot-password recovery using at least one correct answer. */
export async function resetVaultPassword(answers: AnswerInput[], newPassword: string): Promise<boolean> {
  if (!(await verifySecurityAnswers(answers))) return false;
  const rec = readRecord();
  if (!rec) return false;
  const salt = randomHex();
  rec.salt = salt;
  rec.passwordHash = await pbkdf2Hex(newPassword, salt, PBKDF2_ITERATIONS);
  rec.iterations = PBKDF2_ITERATIONS;
  writeRecord(rec);
  return true;
}

/**
 * Flow 3: replace the two security questions. The current password AND at
 * least one correct existing answer are required. A legacy upgraded record
 * with no questions can establish its first pair using the current password.
 */
export async function setSecurityQuestions(
  currentPassword: string,
  currentAnswers: AnswerInput[],
  questions: [SetupQuestionInput, SetupQuestionInput]
): Promise<boolean> {
  if (!(await verifyVaultPassword(currentPassword))) return false;
  const rec = readRecord();
  if (!rec) return false;
  if (rec.questions.length === 2 && !(await verifySecurityAnswers(currentAnswers))) return false;
  validateQuestions(questions);
  const qRecords: VaultQuestionRecord[] = [];
  for (const question of questions) {
    const salt = randomHex();
    qRecords.push({
      id: question.id,
      salt,
      answerHash: await pbkdf2Hex(normaliseAnswer(question.answer), salt, PBKDF2_ITERATIONS),
    });
  }
  rec.questions = qRecords;
  writeRecord(rec);
  return true;
}

export function readVaultSession(): boolean {
  try {
    return sessionStorage.getItem(VAULT_SESSION_KEY) === "1";
  } catch {
    return false;
  }
}

export function writeVaultSession(open: boolean): void {
  try {
    if (open) sessionStorage.setItem(VAULT_SESSION_KEY, "1");
    else sessionStorage.removeItem(VAULT_SESSION_KEY);
  } catch {
    // ignore
  }
}
