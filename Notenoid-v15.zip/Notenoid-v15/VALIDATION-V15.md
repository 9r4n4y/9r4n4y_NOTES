# Notenoid v15 validation

## Passed

- `npx tsc --noEmit` — no TypeScript errors.
- Production static build with webpack — completed successfully, with TypeScript checking enabled.
- Native APK compilation, resource packaging, dexing, alignment, and signing — completed.
- APK signature verification — valid signature schemes 2 and 3, one signer.
- APK metadata — `com.notes.app`, version name `15.0`, code `150`, minimum API 24, target API 34.
- All 190 files packaged under APK `assets/` are byte-for-byte identical to the production web assets used in browser testing.
- 30 storage naming/repository assertions — passed, including folder renames, collision handling, attachment preservation, and note duplication.
- Production Chromium browser regression suite — 20 source-selection scenarios, each in both directions, for **40 mode transfers**. Desktop viewport 1280×900; Android-sized touch viewport 393×851.
- Each transfer checks pending highlight, exact source occurrence, viewport-center error below 8 pixels, pulse presence and removal after three seconds, and unchanged note Markdown.
- Cases cover first/last word, duplicates within a paragraph, multiline paragraphs, bold text, link labels, inline code, fenced code whose language label repeats the word, tasks, table cells, and Hindi combining marks.
- Double-clicking the mode control does not skip the selection step.
- Smoke tests passed for bold rendering, tables, KaTeX rendering, exact code copying, task source updates, and saving/reloading a note. No browser runtime errors were recorded.

Raw concise test outputs are included under `test/results/`.

## Signing identity

The APK uses the keystore provided in the source archive, retaining update compatibility when the installed app uses that same certificate.

Certificate SHA-256:

`adebabf1676d88d4b8ed1caea8a068e86612a058dc498299558a2455393a6c63`

This signing key is publicly distributed material. Do not treat it as a private production key.

## Limits and device checklist

No physical Android handset or Android emulator was available for install/runtime testing. Touch emulation validates Chromium browser behavior, not every Android WebView version, keyboard, display cutout, accessibility configuration, filesystem permission, or device lifecycle event. Compilation/signature verification does not prove runtime correctness on every device.

Before trusting an update with important data:

1. Back up notes and attachments.
2. Install over the existing app only if package/signature compatibility allows it; do not uninstall merely to bypass a signature mismatch.
3. Enable **Ask before Preview/Edit toggle** if an existing preference has it disabled.
4. Repeat top/bottom and duplicate-word selections in both modes, then rotate the device and try with the keyboard open before entering selection.
5. Check file access, attachments, vault access, imports/exports, and background/resume on your device.

The implementation targets visible source-backed text. Images, synthesized equation glyphs, and hidden Markdown syntax do not always have a rendered text range. There is no global repeated-word fallback. No claim is made that every unrelated app feature or device combination has been exhaustively tested.
