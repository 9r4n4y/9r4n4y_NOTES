# Notenoid v15

Local-first Markdown notes for Android and desktop browsers. Notes, attachments, folders, labels, archive, vault, search, formatting, and import/export remain part of the app.

## What's included in v15

- Rewritten **select a word → Done → switch mode** workflow.
- Selection tracks the exact source character range, not a global search or duplicate-word count.
- Custom yellow overlays highlight the selected occurrence before Done in edit and preview, independently of Android native selection colors.
- Done changes mode, centers the word in the visible Markdown area, and pulses its highlight for three seconds.
- Extra scroll space allows the first and last words to reach the center. The scroll space remains after the pulse to avoid an end-of-animation jump.
- Centering accounts for viewport resizing, keyboard dismissal, and layout changes during the pulse.
- Repeated words, multiline paragraphs, emphasis, links, inline/fenced code, task lists, table cells, and Hindi combining marks have automated browser coverage.
- Double-tapping the mode button cannot accidentally confirm a pending selection. Only Done confirms it; Cancel leaves the mode unchanged.
- Android version name **15.0**, version code **150**; About badge **v15.0**.

## Use

1. Enable **Ask before Preview/Edit toggle** in Settings if your saved preference has it disabled. It is enabled by default for new installations.
2. Tap (or double-tap) the eye/pencil mode button.
3. Tap the specific word you want. Its yellow highlight appears without changing mode.
4. Press **Done in the selection bar**. The selected occurrence appears centered in the destination mode and pulses for three seconds.

Empty notes switch immediately so that you can begin typing. Reduced-motion users receive a steady three-second highlight instead of blinking. The feature targets visible Markdown text: images and synthesized equation glyphs are not selectable source words, and hidden Markdown syntax such as a link's destination has no rendered word to highlight.

## Build and test

See [docs/BUILD.md](docs/BUILD.md), [docs/SELECTION.md](docs/SELECTION.md), and [VALIDATION-V15.md](VALIDATION-V15.md).

```sh
npm ci
npm run typecheck
npx tsx scripts/test-storage-naming.ts
npm run dev
# In another terminal, after installing Chromium:
npx playwright install --with-deps chromium
npm run test:selection
node test/smoke.mjs
```

This archive contains only the current release's documentation and source. Persistent storage schema identifiers and Android signing/package identity are intentionally retained for data and update compatibility; they are not app release numbers.

## Install safety

Back up your notes before installing an update. The APK is signed with the key supplied in the source archive and retains package ID `com.notes.app`. An in-place update requires your installed copy to use the same signing certificate. Do not uninstall your current app just to bypass a signature mismatch: app-private notes could be lost. The supplied signing key is public and unsuitable as a secret production distribution key.
