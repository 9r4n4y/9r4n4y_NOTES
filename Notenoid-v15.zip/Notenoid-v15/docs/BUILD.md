# Build Notenoid v15

## Requirements

- Node.js 20.20+ and npm (Node.js 22 LTS recommended)
- JDK 21, with `JAVA_HOME` set and its `bin` directory on `PATH`
- Android build-tools 35.0.0 and platform android-34
- Linux build host for the included APK scripts

## Web and APK

```sh
npm ci
npm run typecheck
bash scripts/setup-sdk.sh
bash scripts/build_web_export.sh
bash scripts/build_apk.sh
```

The web script uses webpack and limits Next.js build workers to one to keep memory use manageable. It copies the static export to `android/assets`. The APK script packages those assets and the Java WebView shell with aapt2, javac, d8, zipalign, and apksigner. It does not use Gradle.

Outputs: `.next-static/` (static web export) and `out/Notenoid.apk` (signed APK, version name 15.0 / code 150).

An external SDK/JDK can be used:

```sh
export ANDROID_SDK=/path/to/android-sdk
export JAVA_HOME=/path/to/jdk21
export PATH="$JAVA_HOME/bin:$PATH"
bash scripts/build_web_export.sh
bash scripts/build_apk.sh
```

The SDK setup script automatically accepts Android SDK licenses. Review those licenses before running it.

The supplied signing keystore is retained for update compatibility. It is publicly distributed source material, not a protected production secret. The app package ID remains `com.notes.app`. Back up data before installing, and check certificate compatibility before replacing an installed app.

## Tests

```sh
npm run typecheck
npx tsx scripts/test-storage-naming.ts
npx playwright install --with-deps chromium
npm run dev
# Separate terminal:
npm run test:selection
```

The browser suite uses `http://localhost:3000` by default; set `TEST_URL` to test a served static export instead. Desktop and touch viewport coverage does not substitute for physical Android WebView testing.
