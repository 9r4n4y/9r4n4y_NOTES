# Notenoid architecture

- `src/core/`: Markdown/frontmatter handling, repository operations, note types, and filesystem adapters.
- `src/core/fs/`: Android filesystem bridge and browser storage backends.
- `src/components/keep/`: note UI, settings, themes, vault, folders, attachments, and application state.
- `src/components/keep/editor/MarkdownEditor.tsx`: editor/preview UI, formatting, search, and mode handoff.
- `src/components/keep/editor/exact-selection.ts`: rendered character-to-source mapping and DOM range resolution.
- `android/src/`: native Android WebView shell and filesystem integration.
- `scripts/`: web export, SDK setup, APK packaging, icons, and storage regression tests.
- `test/selection-e2e.mjs`: desktop/touch browser selection regression suite.

Notes are local-first Markdown documents with attachments managed by the repository. Folder names can include archive/folder/label metadata; repository rename operations preserve attachment data. UI preferences and vault storage schema identifiers remain stable for compatibility. The native package and signing identity are retained, while the application release is 15.0 / Android code 150.
