# Notenoid V5 — Release Notes

Version: 5.0 (versionCode 50) · Web + Android from the same codebase.

## 1. Edit ↔ Preview keeps your exact place

Switching between **Edit** and **Preview** used to restore a raw pixel
`scrollTop`, which lands in a totally different spot because the two modes
have different heights. V5 records a *text anchor* — the block/line sitting at
a fixed viewport probe — and re-pins that same content to the same viewport
position after the swap. Scroll to Topic 13 mid-screen, flip modes as often as
you like: Topic 13 stays exactly where it was. A short re-pin loop keeps the
anchor stable while images/fonts settle heights.

## 2. UI polish

- **Sidebar** finally has a proper header: app identity card (name, note
  count, Settings shortcut) instead of dead space at the top; nicer section
  dividers, count chips, active/hover states, smoother drawer fade/slide.
- Collapsed rail gets a compact brand mark; tooltips kept.
- Consistent icon-button sizing and feedback across top bar, cards and editor.

## 3. Masonry notes grid (Pinterest-style)

- Replaced CSS-columns with a **JavaScript masonry**: every card is measured
  (ResizeObserver) and placed under the currently **shortest column** —
  minimal empty gaps, natural heights, never equalized, never overlapping.
- **2 columns on phones** (previously 1), 3–4 on larger screens
  (width-driven, capped at 4).
- Cards are positioned with `translate3d` + a single GPU transition
  (`cubic-bezier(0.22,1,0.36,1)`, 320ms) so reflows and reorders glide.

## 4. Buttery 2-D drag & drop

- Long-press (300ms) anywhere on a card that isn't a control → the card lifts
  (scale + shadow) and follows the pointer in **X and Y**.
- Other cards reflow live; drop the card anywhere and it glides into its slot.
- **Edge auto-scroll** drags long lists without lifting your finger.
- Escape cancels and the card glides back. Haptic tick on activation.
- No more Y-axis-only ordering bugs from the old CSS-columns layout.

## 5. Large-paste / typing performance

- Store propagation is throttled (leading + trailing 140ms) while the textarea
  stays instant; programmatic edits and close/hide flush immediately.
- `NoteCard` is memoized and its plain-text preview is cached per content;
  typing no longer re-renders the whole grid.
- Measured: 113KB paste ≈ 0.15s (was a multi-second freeze); typing latency on
  a 97KB note dropped from ~61ms to ~21ms per keystroke.

## 6. Image features

- **New gallery icon** right of the upload-image button in the editor toolbar:
  opens an *insert at cursor* picker — upload new images or pick from the
  note's existing attachments.
- **Multi-image grid**: selecting several inserts a compact responsive grid
  (2 columns, 3 for 5+). Stored as plain HTML with `attachment/…` paths, so
  `node.md` stays portable (Obsidian etc. read it fine).
- Every image — grid tile or single — opens the lightbox on tap with
  **Edit · Download · Remove from note · Delete image** (remove = strip from
  body, delete = also remove the file).
- **Settings → Appearance → Images in notes**: sliders for single-image width
  (25–100%) and grid width (40–100%). Grids are `fr`-based square tiles, so
  resizing can never cause overlap or clipping.

## 7. Fixed APK icon

The launcher icon had a baked-in off-white/blue card that looked like a
"second icon inside the icon". All mipmaps are regenerated from the source
artwork: **pure white** legacy/round icons, transparent adaptive foreground
with the glyph centred inside the 66dp safe zone. No more blue cast.

## 8. Bug hunt fixes

- Lightbox opened from note cards could show a **broken image / fail to
  download** (disk-scanned attachments carry `url:""` until resolved) — URLs
  are now resolved before opening.
- Card text previews no longer leak raw grid HTML.
- `markdownToPlain` strips HTML tags (better previews and search).
- Removing an image from a note now matches both display URLs and the
  persisted `attachment/…` paths (empty grid wrappers collapse cleanly).
- First-run hook-order crash fixed; hydration-safe settings defaults extended
  with the new media-size settings.

## Build artifacts

| Artifact | Path |
|---|---|
| Android APK (signed) | `out/Notenoid.apk` |
| Static web export | `.next-static/` |
| Web (standalone server) | `npm run build && npm start` |
