# Notenoid V5.1 — Release Notes

**Focus: the drag & drop system was rebuilt from the ground up, and the note
grid got a symmetry pass so cards with tall photos or long text no longer
stretch the layout into big uneven gaps.**

---

## Drag & drop — rebuilt (the headline fix)

The V5 long-press reordering worked most of the time, but it fought the
layout engine in several places. Every fight was visible as a jump, snap or
stuck card. V5.1 removes the entire class of bugs:

- **The dragged card no longer teleports mid-drag.** Previously, every live
  reorder re-asserted `position: absolute` on the floating card, instantly
  yanking it to the grid origin. The layout engine now skips the dragged
  card completely while a drag is active — the hook owns every one of its
  styles until release.
- **List view can no longer corrupt the dragged card.** In the old list
  layout the floating card's `position: fixed` inline styles were never
  restored, permanently breaking that card's layout after one drag. List
  layout is now a 1-column masonry — grid and list share ONE drag pipeline,
  one style-restore path, one set of bugs (zero).
- **Cards glide instead of snapping.** On release the card's exact visual
  position is converted to grid space, committed with the transition
  disabled, re-flushed once, and handed to the CSS transition — so the card
  glides into its slot (and glides home on cancel) instead of teleporting.
- **Pixel-exact lift.** The card lifts with a scale-compensated transform:
  its top-left tracks your finger/pointer exactly, with no 3–4 px "pop" at
  the moment of lift and no double-scale from the card element.
- **Zero-oscillation drop targeting.** Drop position is computed from the
  masonry layout MODEL of "all cards except the dragged one" — the same pure
  placement function the grid renders with. The result depends only on where
  your finger is, never on where cards currently are, which makes flip-flop
  oscillation mathematically impossible. A 6 px dead-zone around card
  midpoints adds extra stability, and the first 8 px of travel never
  reshuffles anything.
- **One rAF loop for everything.** Card follow, edge auto-scroll,
  scroll-position tracking and target detection run in a single
  requestAnimationFrame at display refresh rate; pointer events only record
  coordinates. The gesture stays smooth on 60–144 Hz screens.
- **Safer gestures.** A second finger can no longer hijack an active drag;
  pointercancel, tab-hide and window blur always glide the card home; the
  post-release click swallow window is capped at 450 ms so the next legit
  tap is never eaten.
- **No more flicker while cards shift.** The entrance stagger is captured
  once per card — reordering no longer rewrites `animation-delay` (which
  re-fired the entrance animation on every live preview).

## Grid symmetry — no more huge uneven gaps

- **Uniform media cards.** The first photo/GIF on a card now uses a
  fixed-height cover crop (grid: 176 px, list: 128 px) instead of its full
  natural height. Tall screenshots no longer stretch one card — and drag its
  whole column down with it.
- **Tighter text previews.** Grid cards clamp body text to 8 lines (was 12)
  and titles to 3 lines, so one verbose note stops towering over its
  neighbours. "Read full note" still expands everything.
- **Long words behave.** Titles, body text and checklist items now break
  with `overflow-wrap: anywhere` (checklist items previously overflowed on
  unbreakable strings), and nothing can overflow the card.

## General UI polish

- Cards keep their rounded shadow language during drag (depth comes from a
  shadow + ring on the card, scale on the wrapper — no more compounding).
- Native image dragging, long-press text selection and touch callouts are
  suppressed on cards so the drag gesture always wins on touch devices.
- `backface-visibility: hidden` on masonry wrappers stops Android WebView
  flicker while cards animate.

## Housekeeping

- App version is now **5.1** (shown in Settings → About app; Android
  `versionCode 51` / `versionName 5.1`).
