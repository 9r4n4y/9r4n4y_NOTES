# Release Notes — v5.2

## The Muuri Update — drag & drop rebuilt from zero

V5.2 throws away the entire hand-rolled drag-and-shift engine and rebuilds
reordering on top of **[Muuri](https://muuri.dev)** — a battle-tested grid
library whose animation engine (rAF + Web Animations API) is what finally
makes card dragging feel buttery, stable and completely bug-free.

### Drag & drop (ground-up replacement)

- **Old engine fully removed.** The V5.1 long-press hook
  (`use-drag-reorder.ts`) and the custom JS masonry positioner
  (`MasonryGrid.tsx`) are deleted — no old drag code can interfere.
  The unused `@dnd-kit/*` dependencies are gone from the package manifest too.
- **Muuri owns the grid.** Live reflow, drop targeting, the ghost
  placeholder slot, and edge auto-scroll are all handled by Muuri's
  internally-verified algorithms. The dragged card can never teleport,
  oscillate, or get "stolen" back by a re-render.
- **Buttery motion.** One shared ease curve (`cubic-bezier(0.22, 1, 0.36, 1)`)
  drives card reflow (280 ms) and drop release (300 ms), so shuffling a
  deck of notes feels like one continuous gesture.
- **Ghost drop slot.** While you hold a card, a translucent dashed slot
  shows exactly where it will land — in both light and dark themes.
- **Smart gestures.**
  - Touch: 240 ms long-press lifts the card (haptic tick included);
    swiping a card before that scrolls the page like normal.
  - Mouse: drag starts after a 4 px nudge, instantly familiar.
  - Presses on a card's own buttons, checklists, inputs and links are
    never hijacked.
  - The click that ends a drag is swallowed, so a drop never opens the
    editor by accident — while a normal tap still does.
- **Drop anywhere.** Dragging to the viewport edge auto-scrolls the page
  with smooth speed ramping; the sort keeps working while it scrolls.
- **Crash-proof by design.** Losing the pointer (incoming call, app
  switch, tab hide, rotation) or pressing Escape aborts the gesture and
  the card *glides* home through Muuri's normal release path — no stuck
  floating cards, no leftover ghost slots, no phantom reorders.

### Layout & UI polish

- **Symmetrical masonry.** A deterministic shortest-column layout feeds
  Muuri exact slots, so columns stay tight and the bottom edge stays even —
  no more towering cards next to stubs and lopsided gaps.
- **Uniform cards.** Notes with very long text are preview-clamped
  (6 lines in grid / 4 in list) with a "Read full note" expander, long
  unbroken words and URLs wrap safely (`overflow-wrap: anywhere`), and
  photos share one fixed cover-crop height (160 px grid / 128 px list) —
  long pictures can no longer stretch a card and break the rhythm.
- **Depth cues.** The lifted card scales to 1.04 with a deep shadow;
  neighbours glide around it. The card's entrance animation no longer
  freezes its transform, so nothing fights the drag engine.
- **Adaptive columns.** 2 columns on phones, up to 4 on wide screens,
  1 column in list layout — all sharing the same drag pipeline.
- Respects Settings → Animations (all motion durations go to 0) and the
  OS reduced-motion preference.

### Under the hood

- `MuuriGrid.tsx` — a thin, fully-synced React ↔ Muuri bridge: React owns
  the set of cards, Muuri owns their positions; the two never fight.
- Store commits happen once per completed drag (order persisted to disk
  and verified across reloads).
- Per-card ResizeObservers keep the layout correct as images load and
  previews expand.

### Versioning

- App version: **5.2** (version code 52)
- Web export + Android APK rebuilt from the same source.
