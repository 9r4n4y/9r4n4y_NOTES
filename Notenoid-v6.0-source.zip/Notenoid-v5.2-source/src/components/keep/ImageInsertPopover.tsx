"use client";

import * as React from "react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Images, Loader2, Upload, Check } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import type { AttachmentDTO } from "@/lib/types";
import { prepareMedia } from "./media";

/**
 * V5 — "Insert image at cursor" picker.
 *
 * Opened from the new gallery icon in the editor toolbar (right of the
 * upload-image button). Two sources:
 *   1. Upload new image files (multiple allowed)
 *   2. Existing attachments of the current note
 *
 * The selection is handed to `onConfirm` as resolved display URLs; the editor
 * inserts one markdown image — or several as a compact responsive grid — at
 * the caret.
 */
export function ImageInsertPopover({
  attachments,
  resolveUrl,
  onConfirm,
  onUploadFiles,
  open: openProp,
  onOpenChange,
  children,
}: {
  /** Current note's attachments (may be empty). */
  attachments: AttachmentDTO[];
  /** Resolve an attachment into a display URL (async, cached by caller). */
  resolveUrl: (att: AttachmentDTO) => Promise<string>;
  onConfirm: (items: { url: string; alt: string }[]) => void;
  /** Store newly picked files as attachments; resolves their display URLs. */
  onUploadFiles: (items: { blob: Blob; alt: string }[]) => Promise<{ url: string; alt: string }[]>;
  /** Controlled open state (used when the toolbar button opens the picker). */
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  children: React.ReactNode;
}) {
  const [uncontrolledOpen, setUncontrolledOpen] = React.useState(false);
  const open = openProp ?? uncontrolledOpen;
  const setOpen = React.useCallback(
    (v: boolean) => {
      setUncontrolledOpen(v);
      onOpenChange?.(v);
    },
    [onOpenChange]
  );
  const [busy, setBusy] = React.useState(false);
  const [selected, setSelected] = React.useState<Set<string>>(new Set());
  const [urls, setUrls] = React.useState<Map<string, string>>(new Map());
  const fileRef = React.useRef<HTMLInputElement | null>(null);

  React.useEffect(() => {
    if (!open) {
      setSelected(new Set());
      return;
    }
    let alive = true;
    (async () => {
      const map = new Map<string, string>();
      await Promise.all(
        attachments.map(async (att) => {
          const u = att.url || (await resolveUrl(att));
          if (u) map.set(att.file, u);
        })
      );
      if (alive) setUrls(map);
    })();
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const toggle = (file: string) => {
    setSelected((cur) => {
      const next = new Set(cur);
      if (next.has(file)) next.delete(file);
      else next.add(file);
      return next;
    });
  };

  const handleFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setBusy(true);
    try {
      const media = await prepareMedia(Array.from(files));
      const resolved = await onUploadFiles(media.map((m) => ({ blob: m.blob, alt: m.name })));
      if (resolved.length === 0) return;
      onConfirm(resolved);
      setOpen(false);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not add the images");
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const confirmSelection = async () => {
    if (selected.size === 0) return;
    setBusy(true);
    try {
      const items: { url: string; alt: string }[] = [];
      for (const att of attachments) {
        if (!selected.has(att.file)) continue;
        const url = urls.get(att.file) || att.url || (await resolveUrl(att));
        if (url) items.push({ url, alt: att.name });
      }
      if (items.length === 0) {
        toast.error("Could not load the selected images");
        return;
      }
      onConfirm(items);
      setOpen(false);
    } finally {
      setBusy(false);
    }
  };

  const count = selected.size;

  return (
    <Popover
      open={open}
      onOpenChange={(o) => {
        setOpen(o);
        if (o) setSelected(new Set());
      }}
    >
      <PopoverTrigger asChild>
        <span className="inline-flex shrink-0">{children}</span>
      </PopoverTrigger>
      <PopoverContent
        align="start"
        side="bottom"
        sideOffset={6}
        collisionPadding={8}
        className="z-[70] w-[min(92vw,22rem)] rounded-xl p-3 shadow-xl"
      >
        <div className="mb-2 flex items-center gap-2">
          <Images className="h-4 w-4 text-muted-foreground" />
          <p className="text-sm font-medium">Insert images at cursor</p>
        </div>
        <p className="mb-3 text-xs text-muted-foreground">
          Pick one image for a single picture — or several, and they arrange
          themselves into a tidy grid.
        </p>

        <input
          ref={fileRef}
          type="file"
          accept="image/*,.gif"
          multiple
          className="hidden"
          onChange={(e) => void handleFiles(e.target.files)}
        />
        <button
          type="button"
          disabled={busy}
          onClick={() => fileRef.current?.click()}
          className="mb-3 flex w-full items-center justify-center gap-2 rounded-lg border-2 border-dashed border-border px-3 py-3 text-sm font-medium transition-colors hover:bg-accent disabled:opacity-60"
        >
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
          {busy ? "Preparing…" : "Choose new images"}
        </button>

        {attachments.length > 0 ? (
          <>
            <p className="mb-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              From this note
            </p>
            <div className="max-h-44 overflow-y-auto pr-1">
              <div className="grid grid-cols-4 gap-1.5">
                {attachments.map((att) => {
                  const url = urls.get(att.file) || att.url || "";
                  const isSel = selected.has(att.file);
                  return (
                    <button
                      key={att.file}
                      type="button"
                      aria-label={`Select ${att.name}`}
                      aria-pressed={isSel}
                      onClick={() => toggle(att.file)}
                      className={cn(
                        "relative aspect-square overflow-hidden rounded-md border-2 transition-colors duration-150",
                        isSel ? "border-primary" : "border-transparent hover:border-black/20 dark:hover:border-white/25"
                      )}
                    >
                      {url ? (
                        <img src={url} alt={att.name} className="h-full w-full object-cover" />
                      ) : (
                        <div className="h-full w-full animate-pulse bg-black/10" />
                      )}
                      {isSel ? (
                        <span className="absolute right-0.5 top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-primary-foreground shadow">
                          <Check className="h-2.5 w-2.5" />
                        </span>
                      ) : null}
                    </button>
                  );
                })}
              </div>
            </div>
          </>
        ) : null}

        <div className="mt-3 flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={() => setOpen(false)}
            className="rounded-md px-2.5 py-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={count === 0 || busy}
            onClick={() => void confirmSelection()}
            className="rounded-md bg-foreground px-3 py-1.5 text-sm font-medium text-background transition-opacity disabled:opacity-40"
          >
            Insert{count > 0 ? ` ${count}` : ""}
          </button>
        </div>
      </PopoverContent>
    </Popover>
  );
}
