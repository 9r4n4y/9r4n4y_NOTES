"use client";

/* eslint-disable react-hooks/refs -- latest-ref sync: refs are written during
 * render and read only inside callbacks/effects/layout passes (never to
 * derive render output), the established pattern for imperative layout. */

import * as React from "react";
import Muuri, { type Item } from "muuri";

/**
 * V5.2 — Muuri-powered drag & drop masonry grid.
 *
 * The V5.1 hand-rolled drag hook + JS masonry pair (MasonryGrid.tsx +
 * use-drag-reorder.ts) is GONE — layout, reflow animation, long-press
 * detection, drop targeting, ghost placeholder and edge auto-scroll are all
 * delegated to Muuri (https://muuri.dev), whose animation engine runs on
 * requestAnimationFrame + the Web Animations API and never fights React.
 *
 * How this component stays stable (and bug-free) with React:
 *
 * 1. React owns the SET of cards. Every card is rendered as a keyed wrapper
 *    div (`.muuri-item`) in store order. Muuri owns the POSITION of cards —
 *    it writes transforms directly and animates them itself. During a drag
 *    Muuri only reorders its internal item array (it never touches the DOM
 *    order), so React re-renders can never teleport a floating card.
 *
 * 2. The order is committed to the store ONCE, after the release animation
 *    finishes (`dragReleaseEnd`). React then re-renders children in the new
 *    order; since Muuri positioned everything with transforms, re-parenting
 *    the wrapper nodes is visually a no-op. A sync pass afterwards keeps the
 *    Muuri item array and the rendered order identical for the next gesture.
 *
 * 3. Touch scrolling coexists with dragging: Muuri is configured with
 *    `touchAction: 'auto'` (its own default 'none' would make cards dead
 *    zones for scrolling) and this component preventDefaults `touchmove`
 *    ONLY while a drag is actually active — the same trick the V5.1 hook
 *    used, so swipe-to-scroll works until the long-press lifts the card.
 *
 * 4. Layout: a custom shortest-column masonry layout function (same packing
 *    as Google Keep) feeds Muuri exact slots, so the grid stays symmetric
 *    with minimal bottom gaps while Muuri animates every reflow.
 *
 * Gesture: touch/pen → 240 ms long-press (moving >8 px cancels, that's a
 * scroll); mouse → immediate drag after 4 px. Haptic tick on lift. Clicks
 * right after a drag are swallowed so they never open the editor.
 */

const TOUCH_LONG_PRESS_MS = 220;
const TOUCH_CANCEL_PX = 10;
const MOUSE_CANCEL_PX = 4;

/** Shared easing — one glide curve for layout moves and drop release. */
const EASE = "cubic-bezier(0.22, 1, 0.36, 1)";

type MuuriLayoutData = {
  id: number;
  items: Item[];
  slots: number[];
  styles?: Record<string, string> | null;
};

/** the runtime Grid instance carries a private destroyed flag */
function isAlive(grid: Muuri | null): grid is Muuri {
  return !!grid && !(grid as unknown as { _isDestroyed?: boolean })._isDestroyed;
}

export interface MuuriGridProps {
  /** Ordered note ids — render order follows this exactly. */
  itemIds: string[];
  /** Render the card for an id. */
  renderItem: (id: string, index: number) => React.ReactNode;
  /** Horizontal + vertical gap in px. */
  gap: number;
  /** Minimum column width before another column is added. */
  minColWidth?: number;
  /** Column cap on very wide screens. */
  maxCols?: number;
  /** Force an exact column count (list view uses 1). */
  colsOverride?: number;
  /** Enable long-press drag & drop reordering. */
  dragEnabled?: boolean;
  /** Called once after a drag settles, with the final order. */
  onReorder?: (ids: string[]) => void;
  /** Whether in-app animations are enabled (Settings → Animations). */
  animations?: boolean;
  className?: string;
}

/* ------------------------------------------------------------------ */
/* column math (shared by the React width pass and the Muuri layout fn) */
/* ------------------------------------------------------------------ */

function computeCols(
  width: number,
  gap: number,
  minColWidth: number,
  maxCols: number,
  colsOverride?: number
): number {
  return Math.max(
    1,
    colsOverride ??
      Math.max(2, Math.min(maxCols, Math.floor((width + gap) / (minColWidth + gap)) || 2))
  );
}

function computeColWidth(width: number, cols: number, gap: number): number {
  return cols > 0 ? Math.max(0, Math.floor((width - gap * (cols - 1)) / cols)) : 0;
}

/* ------------------------------------------------------------------ */
/* component                                                           */
/* ------------------------------------------------------------------ */

export function MuuriGrid({
  itemIds,
  renderItem,
  gap,
  minColWidth = 220,
  maxCols = 4,
  colsOverride,
  dragEnabled = false,
  onReorder,
  animations = true,
  className,
}: MuuriGridProps) {
  const containerRef = React.useRef<HTMLDivElement | null>(null);
  const gridRef = React.useRef<Muuri | null>(null);
  const rafRef = React.useRef(0);
  const swallowClickRef = React.useRef(false);
  /** column width the wrappers are currently sized to */
  const [colWidth, setColWidth] = React.useState<number | null>(null);
  const colWidthRef = React.useRef<number | null>(null);

  // latest-value refs (read inside Muuri callbacks & effects, never render)
  const itemIdsRef = React.useRef(itemIds);
  itemIdsRef.current = itemIds;
  const reorderRef = React.useRef(onReorder);
  reorderRef.current = onReorder;
  const layoutCfgRef = React.useRef({ gap, minColWidth, maxCols, colsOverride, animations });
  layoutCfgRef.current = { gap, minColWidth, maxCols, colsOverride, animations };
  const dragEnabledRef = React.useRef(dragEnabled);
  dragEnabledRef.current = dragEnabled;

  const haptic = React.useCallback(() => {
    try {
      if (typeof navigator !== "undefined" && "vibrate" in navigator) navigator.vibrate(15);
    } catch {
      /* ignore */
    }
  }, []);

  /* ---------------------------------------------------------------- */
  /* custom layout — shortest-column masonry (deterministic, gap-aware) */
  /* ---------------------------------------------------------------- */
  const layoutFn = React.useCallback(
    (
      _grid: Muuri,
      layoutId: number,
      items: Item[],
      width: number,
      _height: number,
      callback: (layout: MuuriLayoutData) => void
    ) => {
      const cfg = layoutCfgRef.current;
      const cols = computeCols(width, cfg.gap, cfg.minColWidth, cfg.maxCols, cfg.colsOverride);
      const w = computeColWidth(width, cols, cfg.gap);
      const colHeights = new Array<number>(cols).fill(0);
      const slots: number[] = [];

      for (let i = 0; i < items.length; i++) {
        const item = items[i];
        let col = 0;
        for (let c = 1; c < cols; c++) {
          if (colHeights[c] < colHeights[col] - 0.5) col = c;
        }
        const h =
          item.getHeight() + item.getMargin().top + item.getMargin().bottom || w;
        slots.push(Math.round(col * (w + cfg.gap)), Math.round(colHeights[col]));
        colHeights[col] += h + cfg.gap;
      }

      const height = items.length > 0 ? Math.max(...colHeights) - cfg.gap : 0;
      callback({
        id: layoutId,
        items,
        slots,
        styles: { height: `${Math.max(0, Math.round(height))}px` },
      });
    },
    []
  );

  /* ---------------------------------------------------------------- */
  /* sync the Muuri item array with the rendered order                 */
  /* ---------------------------------------------------------------- */
  const syncGrid = React.useCallback((instant: boolean) => {
    const grid = gridRef.current;
    const container = containerRef.current;
    if (!isAlive(grid) || !container) return;

    // never touch the grid while a gesture owns it
    const items = grid.getItems();
    for (let i = 0; i < items.length; i++) {
      if (items[i].isDragging() || items[i].isReleasing()) return;
    }

    const els = Array.from(
      container.querySelectorAll<HTMLElement>(":scope > .muuri-item")
    );
    const idOf = (el: HTMLElement) => el.getAttribute("data-note-id") ?? "";

    // 1) add items React mounted since the last sync
    const known = new Set<string>();
    for (const item of grid.getItems()) {
      const el = item.getElement();
      if (el) known.add(idOf(el));
    }
    const missing = els.filter((el) => !known.has(idOf(el)));
    if (missing.length > 0) grid.add(missing, { index: -1, layout: false });

    // 2) remove items React unmounted since the last sync
    const present = new Set<string>(els.map(idOf));
    const gone = grid.getItems().filter((item) => {
      const el = item.getElement();
      return !el || !present.has(idOf(el));
    });
    if (gone.length > 0) grid.remove(gone, { removeElements: false, layout: false });

    // 3) match Muuri's internal order to the rendered order (no animation)
    //    (only when the sets match 1:1 — sort() blindly trusts the array)
    const byId = new Map<string, Item>();
    for (const item of grid.getItems()) {
      const el = item.getElement();
      if (el) byId.set(idOf(el), item);
    }
    const ordered = itemIdsRef.current
      .map((id) => byId.get(id))
      .filter(Boolean) as Item[];
    if (ordered.length > 0 && ordered.length === grid.getItems().length) {
      grid.sort(ordered, { layout: false });
    }

    // 4) re-measure + reflow (animates — this is the smooth glide)
    grid.refreshItems();
    grid.layout(instant);
  }, []);

  /** debounced reflow for item size changes (images loading, text expand) */
  const scheduleRelayout = React.useCallback(() => {
    cancelAnimationFrame(rafRef.current);
    rafRef.current = requestAnimationFrame(() => {
      const grid = gridRef.current;
      if (!isAlive(grid)) return;
      const items = grid.getItems();
      for (let i = 0; i < items.length; i++) {
        if (items[i].isDragging() || items[i].isReleasing()) return;
      }
      grid.refreshItems();
      grid.layout();
    });
  }, []);

  /* ---------------------------------------------------------------- */
  /* container width tracking (column count + wrapper width)           */
  /* ---------------------------------------------------------------- */
  React.useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const apply = () => {
      const width = el.clientWidth;
      if (width <= 0) return;
      const cfg = layoutCfgRef.current;
      const cols = computeCols(width, cfg.gap, cfg.minColWidth, cfg.maxCols, cfg.colsOverride);
      const w = computeColWidth(width, cols, cfg.gap);
      if (w > 0 && w !== colWidthRef.current) {
        colWidthRef.current = w;
        setColWidth(w);
      }
    };
    apply();
    const ro = new ResizeObserver(apply);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  /* ---------------------------------------------------------------- */
  /* create / destroy the Muuri instance                               */
  /* ---------------------------------------------------------------- */
  React.useLayoutEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // measure NOW so the first layout is correct (wrappers may still carry
    // the pre-JS 100% width — fix them up before Muuri reads their sizes)
    const width = container.clientWidth;
    if (width > 0) {
      const cfg = layoutCfgRef.current;
      const cols = computeCols(width, cfg.gap, cfg.minColWidth, cfg.maxCols, cfg.colsOverride);
      const w = computeColWidth(width, cols, cfg.gap);
      if (w > 0) {
        colWidthRef.current = w;
        setColWidth((prev) => (prev === w ? prev : w));
        container.querySelectorAll<HTMLElement>(":scope > .muuri-item").forEach((el) => {
          el.style.width = `${w}px`;
        });
      }
    }

    const cfg = layoutCfgRef.current;
    const anim = cfg.animations;
    const grid = new Muuri(container, {
      items: ":scope > .muuri-item",
      layoutOnInit: false,
      layout: layoutFn,
      layoutOnResize: 100,
      // V6: 200ms with the shared glide curve — long enough to look smooth,
      // short enough that successive drag-sorts never stack animations (the
      // old 280ms @ 50ms sort-interval churn read as "laggy/choppy" on
      // mid-range Android WebViews).
      layoutDuration: anim ? 200 : 0,
      layoutEasing: EASE,
      // NOTE: always create the grid drag-capable; whether a gesture may
      // actually START is decided live by dragStartPredicate below (Muuri
      // cannot toggle dragEnabled after construction, so gating here keeps
      // the grid reactive to prop changes without a teardown).
      dragEnabled: true,
      dragStartPredicate: (item, event) => {
        // reordering disabled → every gesture is a plain click/scroll
        if (!dragEnabledRef.current) return false;
        if (event.isFirst) {
          // never hijack presses on the card's own controls
          const target = event.srcEvent.target as HTMLElement | null;
          if (target && target.closest("button, input, textarea, select, a, [data-no-drag]")) {
            return false;
          }
        }
        const isMouse = event.pointerType === "mouse";
        return Muuri.ItemDrag.defaultStartPredicate(
          item,
          event,
          isMouse
            ? { distance: MOUSE_CANCEL_PX, delay: 0 }
            : { distance: TOUCH_CANCEL_PX, delay: TOUCH_LONG_PRESS_MS }
        );
      },
      dragAxis: "xy",
      dragSort: true,
      // V6: slower, more deliberate sort decisions — the old settings made
      // neighbours swap every 50ms with a tiny threshold, which showed up as
      // cards jittering left/right and bouncing between columns.
      dragSortHeuristics: {
        sortInterval: 110,
        minDragDistance: 10,
        minBounceBackAngle: 1.4,
      },
      dragSortPredicate: {
        threshold: 55,
        action: "move",
        migrateAction: "move",
      },
      dragRelease: { duration: anim ? 260 : 0, easing: EASE, useDragContainer: true },
      // NOTE: touch-action 'auto' (NOT Muuri's default 'none') so swiping a
      // card still scrolls the page — the touchmove guard below takes over
      // only once a drag is genuinely active.
      dragCssProps: {
        touchAction: "auto",
        userSelect: "none",
        userDrag: "none",
        tapHighlightColor: "rgba(0, 0, 0, 0)",
        touchCallout: "none",
        contentZooming: "none",
      },
      dragPlaceholder: {
        enabled: true,
        createElement: () => {
          const el = document.createElement("div");
          el.className = "muuri-drop-placeholder";
          return el;
        },
      },
      // V6: the old safeZone (0.82) made ~82% of the viewport an aggressive
      // autoscroll zone — the screen raced up/down "instead of following the
      // note". Now autoscroll only engages near the real edges, ramps
      // smoothly, and items are sorted only AFTER an autoscroll settles
      // (sortDuringScroll: false) so positions never fight the scroll.
      dragAutoScroll: {
        targets: [window as unknown as Window],
        threshold: 44,
        safeZone: 0.3,
        speed: Muuri.AutoScroller.smoothSpeed(600, 780, 250),
        sortDuringScroll: false,
        smoothStop: true,
      },
    });
    gridRef.current = grid;

    // ---- drag lifecycle wiring ----

    grid.on("dragStart", () => {
      haptic();
      swallowClickRef.current = true;
      document.body.classList.add("drag-reorder-active");
      container.classList.add("drag-active");
    });

    grid.on("dragEnd", () => {
      container.classList.remove("drag-active");
      // swallow the click that follows pointerup so it never opens the editor;
      // the flag self-clears shortly after in case no click fires
      window.setTimeout(() => {
        swallowClickRef.current = false;
      }, 380);
    });

    grid.on("dragReleaseEnd", () => {
      container.classList.remove("drag-active");
      document.body.classList.remove("drag-reorder-active");
      const g = gridRef.current;
      if (!isAlive(g)) return;
      const nextIds = g
        .getItems()
        .map((item) => item.getElement()?.getAttribute("data-note-id"))
        .filter((id): id is string => !!id);
      const current = itemIdsRef.current;
      const changed =
        nextIds.length === current.length && nextIds.some((id, i) => id !== current[i]);
      if (changed) reorderRef.current?.(nextIds);
    });

    return () => {
      cancelAnimationFrame(rafRef.current);
      document.body.classList.remove("drag-reorder-active");
      container.classList.remove("drag-active");
      try {
        grid.destroy();
      } catch {
        /* already destroyed */
      }
      gridRef.current = null;
    };
  }, [layoutFn, haptic]);

  /* ---------------------------------------------------------------- */
  /* global listeners: touchmove guard, click swallow, safety nets     */
  /* ---------------------------------------------------------------- */
  React.useEffect(() => {
    const isDragActive = () => {
      const grid = gridRef.current;
      if (!isAlive(grid)) return false;
      const items = grid.getItems();
      for (let i = 0; i < items.length; i++) {
        if (items[i].isDragging()) return true;
      }
      return false;
    };

    // While a drag is active the page must not scroll — preventDefault the
    // touchmove (registered non-passive on purpose) so the browser never
    // takes the gesture over and never fires a pointercancel mid-drag.
    //
    // V6: ALSO protect the long-press window itself. On Android, the moment a
    // finger moves during Muuri's 220 ms hold the browser claims the gesture
    // for scrolling (touch-action: auto) and fires pointercancel — the drag
    // never starts and long-press reordering feels broken/random. When a
    // finger has been resting on a card (tiny movement, hold > 120 ms) we
    // preventDefault so the browser cannot interrupt the pending drag. A
    // genuine swipe (fast movement) still scrolls normally.
    let holdGuard: { x: number; y: number; t: number } | null = null;
    const onTouchStart = (e: TouchEvent) => {
      holdGuard = null;
      if (!dragEnabledRef.current) return;
      const target = e.target as HTMLElement | null;
      if (!target) return;
      if (!target.closest(".muuri-item")) return;
      if (target.closest("button, input, textarea, select, a, [data-no-drag]")) return;
      const t = e.touches[0];
      holdGuard = { x: t.clientX, y: t.clientY, t: Date.now() };
    };
    const onTouchMove = (e: TouchEvent) => {
      if (isDragActive()) {
        e.preventDefault();
        return;
      }
      if (!holdGuard) return;
      const t = e.touches[0];
      if (!t) return;
      const moved = Math.hypot(t.clientX - holdGuard.x, t.clientY - holdGuard.y);
      const held = Date.now() - holdGuard.t;
      if (held > 180) {
        // committed hold: the long-press drag is about to start — the browser
        // must not claim the gesture for scrolling (pointercancel killer)
        e.preventDefault();
        return;
      }
      if (moved >= 12) holdGuard = null; // fast swipe → let it scroll
    };
    const clearHold = () => {
      holdGuard = null;
    };
    document.addEventListener("touchstart", onTouchStart, { capture: true, passive: true });
    document.addEventListener("touchend", clearHold, { capture: true, passive: true });
    document.addEventListener("touchcancel", clearHold, { capture: true, passive: true });
    document.addEventListener("touchmove", onTouchMove, { passive: false });

    // swallow clicks right after a drag (mouse drags end with a click event)
    const onClickCapture = (e: MouseEvent) => {
      if (!swallowClickRef.current) return;
      const target = e.target as HTMLElement | null;
      if (target && containerRef.current?.contains(target)) {
        e.stopPropagation();
        e.preventDefault();
        swallowClickRef.current = false;
      }
    };
    document.addEventListener("click", onClickCapture, true);

    // safety nets: losing the pointer (app backgrounded, incoming call,
    // rotation, tab switch, Escape) aborts the gesture and the card GLIDES
    // home. ItemDrag.stop() alone would freeze the card mid-air (it bypasses
    // the release machinery, so later layouts consider it "in place"), so we
    // immediately kick off the normal release animation — which also resets
    // the drag placeholder and fires dragReleaseEnd for us.
    const abortDrag = () => {
      const grid = gridRef.current;
      if (!isAlive(grid)) return;
      const items = grid.getItems();
      let aborted = false;
      for (const item of items) {
        if (item.isDragging()) {
          try {
            const internals = item as unknown as {
              _drag?: { stop: () => void };
              _dragRelease?: { start: () => void };
              _dragPlaceholder?: { reset: () => void };
            };
            internals._drag?.stop();
            internals._dragRelease?.start();
            internals._dragPlaceholder?.reset();
            aborted = true;
          } catch {
            /* noop */
          }
        }
      }
      if (aborted) {
        document.body.classList.remove("drag-reorder-active");
        swallowClickRef.current = false;
        grid.refreshItems();
        grid.layout();
      }
    };
    const onVisibility = () => {
      if (document.visibilityState === "hidden") abortDrag();
    };
    window.addEventListener("blur", abortDrag);
    document.addEventListener("visibilitychange", onVisibility);
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isDragActive()) abortDrag();
    };
    window.addEventListener("keydown", onKeyDown);

    return () => {
      document.removeEventListener("touchstart", onTouchStart, { capture: true } as EventListenerOptions);
      document.removeEventListener("touchend", clearHold, { capture: true } as EventListenerOptions);
      document.removeEventListener("touchcancel", clearHold, { capture: true } as EventListenerOptions);
      document.removeEventListener("touchmove", onTouchMove);
      document.removeEventListener("click", onClickCapture, true);
      window.removeEventListener("blur", abortDrag);
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("keydown", onKeyDown);
    };
  }, []);

  /* ---------------------------------------------------------------- */
  /* keep the grid in sync with React-rendered order & sizes           */
  /* ---------------------------------------------------------------- */
  const firstSyncRef = React.useRef(true);
  React.useLayoutEffect(() => {
    // first run positions everything INSTANTLY (pre-paint), later runs glide
    syncGrid(firstSyncRef.current);
    firstSyncRef.current = false;
  }, [itemIds, colWidth, dragEnabled, syncGrid]);

  /** per-item ResizeObserver: content growth (images, expanders) reflows */
  const roRef = React.useRef<ResizeObserver | null>(null);
  React.useEffect(() => {
    const ro = new ResizeObserver(scheduleRelayout);
    roRef.current = ro;
    const container = containerRef.current;
    if (container) {
      container.querySelectorAll<HTMLElement>(":scope > .muuri-item").forEach((el) => ro.observe(el));
    }
    return () => {
      ro.disconnect();
      roRef.current = null;
    };
  }, [scheduleRelayout, itemIds]);

  /** stable per-id wrapper refs; observed for size changes */
  const refCache = React.useRef<Map<string, (el: HTMLDivElement | null) => void>>(new Map());
  const itemRef = React.useCallback((id: string) => {
    const cache = refCache.current;
    let cb = cache.get(id);
    if (!cb) {
      cb = (el: HTMLDivElement | null) => {
        if (!el) return;
        // (width itself is owned by React via the style prop — this only
        // wires the size watcher so content growth reflows the grid)
        roRef.current?.observe(el);
      };
      cache.set(id, cb);
    }
    return cb;
  }, []);

  return (
    <div ref={containerRef} className={`muuri-grid ${className ?? ""}`}>
      {itemIds.map((id, index) => (
        <div
          key={id}
          ref={itemRef(id)}
          data-note-id={id}
          className="muuri-item"
          style={{ width: colWidth != null ? `${colWidth}px` : "100%" }}
        >
          {renderItem(id, index)}
        </div>
      ))}
    </div>
  );
}
