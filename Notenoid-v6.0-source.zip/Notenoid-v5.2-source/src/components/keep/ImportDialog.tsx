"use client";

// ---------------------------------------------------------------------------
// V6 Import — drop a backup ZIP, everything lands back in its place.
//
// Accepts BOTH layouts:
//   • V6 exports  (manifest.json + settings.json + notes/… + _vault/…)
//   • legacy V5 exports (note folders at the ZIP root + README.txt + _vault/)
//
// What gets restored automatically:
//   • every note folder (title, body, colour, pin, archive, vault flags,
//     labels, folder assignment, timestamps, attachments)
//   • folder definitions (emoji/tint) + label list (merged, no duplicates)
//   • app settings (theme, fonts, scales, wallpaper…) from settings.json
//   • the vault record when the backup carries one AND this device has no
//     vault yet (never silently overwrites an existing vault)
// ---------------------------------------------------------------------------

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useKeepStore, getRepo } from "./store";
import { updateSettings, useSettings, type AppSettings } from "./settings-store";
import { DEFAULT_SETTINGS } from "./settings-store";
import { isKnownTheme } from "@/lib/themes";
import { FONT_CHOICES } from "@/lib/fonts";
import { writeVaultRecord, vaultPasswordExists } from "@/lib/vault";
import { noteToMarkdown, markdownToNote, NOTE_FILE, ATTACHMENT_DIR } from "@/core/markdown";
import { joinPath } from "@/core/fs/adapter";
import { CheckCircle2, FileArchive, Loader2, Upload, AlertCircle } from "lucide-react";
import { useRef, useState } from "react";
import { toast } from "sonner";
import JSZip from "jszip";
import { useBackLayer } from "@/lib/back-nav";

interface ImportSummary {
  notes: number;
  vault: number;
  folders: number;
  labels: number;
  settingsApplied: boolean;
  vaultRecordRestored: boolean;
  skipped: string[];
}

export function ImportDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const settings = useSettings();
  const [busy, setBusy] = useState(false);
  const [phase, setPhase] = useState("");
  const [summary, setSummary] = useState<ImportSummary | null>(null);
  const [error, setError] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const busyRef = useRef(false);

  // BACK dismisses the dialog while idle (never mid-import)
  useBackLayer(open && !busy, () => onOpenChange(false));

  async function handleFile(file: File) {
    setError("");
    setSummary(null);
    if (!/\.zip$/i.test(file.name) && !/zip/.test(file.type || "")) {
      setError("Please choose a .zip backup exported from the app.");
      return;
    }
    setBusy(true);
    busyRef.current = true;
    try {
      setPhase("Reading ZIP…");
      const zip = await JSZip.loadAsync(file);
      const entries = Object.values(zip.files).filter((f) => !f.dir);

      const findNodeFiles = (prefix: string) =>
        entries.filter((f) => f.name.startsWith(prefix) && f.name.endsWith(NOTE_FILE));

      // locate the note root (V6 "notes/" prefix or legacy ZIP root).
      // Vault notes live outside notes/ (_vault/ at any depth) — find them
      // across the whole ZIP separately.
      let nodeFiles = findNodeFiles("notes/");
      if (nodeFiles.length === 0) nodeFiles = findNodeFiles("");
      const vaultFiles = entries.filter(
        (f) => f.name.includes("_vault/") && f.name.endsWith(NOTE_FILE)
      );
      const regular = nodeFiles.filter((f) => !f.name.includes("_vault/"));

      if (regular.length + vaultFiles.length === 0) {
        setError("No notes found in this ZIP — is it a backup exported from the app?");
        return;
      }

      const skipped: string[] = [];

      // ---- settings --------------------------------------------------------
      setPhase("Restoring settings…");
      let settingsApplied = false;
      let vaultRecordRestored = false;
      const settingsFile = zip.file("settings.json");
      if (settingsFile) {
        try {
          const parsed = JSON.parse(await settingsFile.async("string")) as Partial<AppSettings> & {
            vaultRecord?: unknown;
          };
          const patch: Partial<AppSettings> = {};
          for (const key of Object.keys(DEFAULT_SETTINGS) as (keyof AppSettings)[]) {
            if (parsed[key] !== undefined) {
              // dynamic copy of a same-shaped settings object
              (patch as Record<string, unknown>)[key] = parsed[key];
            }
          }
          if (patch.appName === "Notes") patch.appName = "Notenoid";
          if (patch.themeId && !isKnownTheme(patch.themeId)) patch.themeId = "system";
          if (patch.appFont && !FONT_CHOICES.some((f) => f.id === patch.appFont)) patch.appFont = "default";
          if (patch.noteFont && !FONT_CHOICES.some((f) => f.id === patch.noteFont)) patch.noteFont = "default";
          if (Object.keys(patch).length > 0) {
            updateSettings(patch);
            settingsApplied = true;
          }
          // vault record: restore ONLY when this device has no vault yet
          if (parsed.vaultRecord && typeof parsed.vaultRecord === "object" && !vaultPasswordExists()) {
            writeVaultRecord(parsed.vaultRecord as Parameters<typeof writeVaultRecord>[0]);
            vaultRecordRestored = true;
          }
        } catch {
          skipped.push("settings.json (unreadable)");
        }
      }

      // ---- folders + labels config ----------------------------------------
      setPhase("Restoring folders & labels…");
      let folderCount = 0;
      let labelsAdded = 0;
      const configFile = zip.file("config.json") ?? zip.file(".notes/config.json");
      if (configFile) {
        try {
          const cfg = JSON.parse(await configFile.async("string")) as {
            folders?: { name: string; emoji?: string; color?: string }[];
            labels?: string[];
          };
          const existingFolders = new Set(
            useKeepStore.getState().folders.map((f) => f.name.toLowerCase())
          );
          for (const def of Array.isArray(cfg.folders) ? cfg.folders : []) {
            if (!def?.name || existingFolders.has(def.name.toLowerCase())) continue;
            const created = await useKeepStore.getState().createFolder(
              def.name,
              def.emoji || "📁",
              def.color || "default"
            );
            if (created) {
              folderCount++;
              existingFolders.add(def.name.toLowerCase());
            }
          }
          const existingLabels = new Set(useKeepStore.getState().labels.map((l) => l.name.toLowerCase()));
          for (const name of Array.isArray(cfg.labels) ? cfg.labels : []) {
            if (!name || existingLabels.has(name.toLowerCase())) continue;
            const res = await useKeepStore.getState().createLabel(name);
            if (res.ok) {
              labelsAdded++;
              existingLabels.add(name.toLowerCase());
            }
          }
        } catch {
          skipped.push("config.json (unreadable)");
        }
      }

      // ---- notes -----------------------------------------------------------
      const fs = getRepo().fs;
      const usedDirs = new Set<string>();
      const listRoot = async () => {
        const dirs = new Set<string>();
        for (const entry of await fs.listDir("")) {
          if (entry.kind === "dir") dirs.add(entry.name);
        }
        return dirs;
      };

      async function importNote(file: JSZip.JSZipObject, isVault: boolean) {
        // path: <root>[Folder/]<Note>/node.md → note dir = segment before node.md
        const withoutRoot = file.name.startsWith("notes/") ? file.name.slice("notes/".length) : file.name;
        const parts = withoutRoot.split("/");
        parts.pop(); // node.md
        const dirName = parts.pop() || "Untitled";
        try {
          const raw = await file.async("string");
          const parsed = markdownToNote(raw, dirName);
          if (isVault) parsed.model.vaulted = true;

          // unique target dir at the storage root
          const existing = await listRoot();
          const taken = new Set<string>(
            [...usedDirs, ...existing].map((n) => n.toLowerCase())
          );
          let target = dirName || "Untitled";
          for (let i = 2; i < 1000; i++) {
            if (!taken.has(target.toLowerCase())) break;
            target = `${dirName || "Untitled"} (${i})`;
          }
          usedDirs.add(target.toLowerCase());

          await fs.makeDir(target);
          await fs.writeText(
            joinPath(target, NOTE_FILE),
            noteToMarkdown({ ...parsed.model, title: parsed.model.title || dirName })
          );

          // attachments: <same dir>/attachment/*
          const dirPrefix = file.name.slice(0, file.name.length - NOTE_FILE.length);
          for (const entry of entries) {
            if (!entry.name.startsWith(dirPrefix)) continue;
            const tail = entry.name.slice(dirPrefix.length);
            if (!tail.startsWith(`${ATTACHMENT_DIR}/`) || entry.dir) continue;
            const fileName = tail.slice(ATTACHMENT_DIR.length + 1);
            if (!fileName || fileName.includes("/")) continue;
            const blob = await entry.async("arraybuffer");
            await fs.writeBinary(joinPath(target, ATTACHMENT_DIR, fileName), new Uint8Array(blob));
          }
          return true;
        } catch {
          skipped.push(dirName || "note");
          return false;
        }
      }

      setPhase("Restoring notes…");
      let noteCount = 0;
      let vaultCount = 0;
      for (const f of regular) {
        if (await importNote(f, false)) noteCount++;
      }
      for (const f of vaultFiles) {
        if (await importNote(f, true)) vaultCount++;
      }

      // ---- rescan + report -------------------------------------------------
      setPhase("Finishing…");
      await useKeepStore.getState().rescan();
      const result: ImportSummary = {
        notes: noteCount,
        vault: vaultCount,
        folders: folderCount,
        labels: labelsAdded,
        settingsApplied,
        vaultRecordRestored,
        skipped,
      };
      setSummary(result);
      toast.success("Import complete", {
        description: `${noteCount + vaultCount} note(s) restored${vaultRecordRestored ? " — vault protection restored" : ""}`,
      });
    } catch (e) {
      console.error(e);
      setError(e instanceof Error ? e.message : "Could not read that ZIP file.");
    } finally {
      setBusy(false);
      busyRef.current = false;
      setPhase("");
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!busy) onOpenChange(o); }}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileArchive className="h-5 w-5" /> Import backup
          </DialogTitle>
          <DialogDescription>
            Choose a ZIP exported from the app. Notes, folders, labels, archive, vault and
            settings are placed back automatically.
          </DialogDescription>
        </DialogHeader>

        {summary ? (
          <div className="space-y-3">
            <div className="space-y-1.5 rounded-lg border border-emerald-500/30 bg-emerald-500/5 px-3 py-2.5 text-sm">
              <p className="flex items-center gap-2 font-medium text-emerald-700 dark:text-emerald-400">
                <CheckCircle2 className="h-4 w-4" /> Import complete
              </p>
              <ul className="ml-6 list-disc text-xs leading-relaxed text-muted-foreground">
                <li>{summary.notes} note(s) restored</li>
                {summary.vault > 0 ? <li>{summary.vault} vault note(s) restored (stays protected)</li> : null}
                <li>{summary.folders} folder definition(s) merged</li>
                <li>{summary.labels} label(s) added</li>
                {summary.settingsApplied ? <li>App settings applied</li> : null}
                {summary.vaultRecordRestored ? <li>Vault password &amp; security questions restored</li> : null}
                {summary.skipped.length > 0 ? <li>Skipped: {summary.skipped.join(", ")}</li> : null}
              </ul>
            </div>
            <div className="flex justify-end">
              <Button onClick={() => onOpenChange(false)}>Done</Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <button
              type="button"
              disabled={busy}
              onClick={() => inputRef.current?.click()}
              className="flex h-32 w-full flex-col items-center justify-center gap-2 rounded-lg border border-dashed text-sm text-muted-foreground transition-colors hover:bg-accent/50 disabled:opacity-50"
            >
              {busy ? (
                <>
                  <Loader2 className="h-6 w-6 animate-spin" />
                  {phase || "Working…"}
                </>
              ) : (
                <>
                  <Upload className="h-6 w-6" />
                  Tap to choose a backup ZIP
                </>
              )}
            </button>
            <input
              ref={inputRef}
              type="file"
              accept=".zip,application/zip,application/x-zip-compressed"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) void handleFile(f);
                e.target.value = "";
              }}
            />
            {error ? (
              <p className="flex items-start gap-1.5 text-xs text-destructive">
                <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                {error}
              </p>
            ) : null}
            <p className="text-xs leading-relaxed text-muted-foreground">
              Nothing is deleted — imported notes are added alongside your existing ones
              (same-titled notes get a numbered suffix). Your current vault password is never
              overwritten by an import. Legacy V5 exports are supported too.
            </p>
            <p className="text-[11px] text-muted-foreground">
              Current theme: {settings.themeId}
            </p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
