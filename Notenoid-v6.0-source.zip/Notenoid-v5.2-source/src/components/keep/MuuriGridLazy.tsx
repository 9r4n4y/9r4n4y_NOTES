"use client";

import dynamic from "next/dynamic";

/**
 * V5.2 — client-only loader for the Muuri grid.
 *
 * Muuri's module scope performs pointer/touch feature detection
 * (`'PointerEvent' in window`, navigator.msPointerEnabled, …), which throws
 * when Next.js evaluates this component graph on the server during static
 * prerendering. The grid is a purely client-side concern (notes only exist
 * after hydration anyway — they live in IndexedDB), so it is loaded with
 * `ssr: false`. Everything else in the tree keeps prerendering normally.
 */
const MuuriGrid = dynamic(() => import("./MuuriGrid").then((m) => m.MuuriGrid), {
  ssr: false,
});

export { MuuriGrid };
