"use client";

// ---------------------------------------------------------------------------
// V6 Vault dialogs.
//
// • VaultPasswordDialog — asks for the password to unlock the vault. Includes
//   a "Forgot password?" path that verifies BOTH security questions and then
//   lets the owner set a new password (and opens the vault).
// • VaultSetupDialog — one-time setup: create the password and pick exactly
//   TWO security questions from the bank, answered by the owner. Both answers
//   are required later for password recovery.
// ---------------------------------------------------------------------------

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useKeepStore } from "./store";
import {
  KeyRound,
  Loader2,
  LockKeyhole,
  ShieldQuestion,
  ArrowLeft,
} from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { useBackLayer } from "@/lib/back-nav";
import {
  SECURITY_QUESTIONS,
  questionText,
  getSecurityQuestionIds,
  resetVaultPassword,
} from "@/lib/vault";

/* ------------------------------------------------------------------ */
/* Password dialog                                                     */
/* ------------------------------------------------------------------ */

export function VaultPasswordDialog() {
  const open = useKeepStore((s) => s.vaultCodePrompt);
  const setOpen = useKeepStore((s) => s.setVaultCodePrompt);
  const resolveVaultCode = useKeepStore((s) => s.resolveVaultCode);
  useBackLayer(open, () => setOpen(false));

  const [mode, setMode] = useState<"password" | "recovery">("password");
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(false);

  // recovery state
  const [qIds, setQIds] = useState<string[]>(() => getSecurityQuestionIds());
  const [answers, setAnswers] = useState(["", ""]);
  const [newPass, setNewPass] = useState("");
  const [recoveryError, setRecoveryError] = useState("");

  const hasQuestions = qIds.length === 2;

  function close() {
    setCode("");
    setError(false);
    setMode("password");
    setAnswers(["", ""]);
    setNewPass("");
    setRecoveryError("");
    setOpen(false);
  }

  async function submit() {
    if (!code) return;
    setBusy(true);
    const ok = await resolveVaultCode(code);
    setBusy(false);
    if (ok) {
      setCode("");
      setError(false);
      toast.success("Vault unlocked", { description: "It stays open until you close the app." });
    } else {
      setError(true);
      toast.error("Wrong password");
    }
  }

  async function submitRecovery() {
    setRecoveryError("");
    if (answers.some((a) => !a.trim())) {
      setRecoveryError("Please answer both security questions.");
      return;
    }
    if (newPass.length < 3) {
      setRecoveryError("The new password must be at least 3 characters.");
      return;
    }
    setBusy(true);
    const ok = await resetVaultPassword(
      qIds.map((id, i) => ({ id, answer: answers[i] })),
      newPass
    );
    setBusy(false);
    if (!ok) {
      setRecoveryError("One or both answers are incorrect. Check them and try again.");
      return;
    }
    // success — unlock for this session
    const state = useKeepStore.getState();
    await state.resolveVaultCode(newPass);
    close();
    toast.success("Password reset", { description: "The vault is unlocked for this session." });
  }

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) close(); }}>
      <DialogContent className="max-w-sm">
        {mode === "password" ? (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <KeyRound className="h-5 w-5" /> Vault is protected
              </DialogTitle>
              <DialogDescription>
                Type your vault password to open it. You will not be asked again until the app
                closes.
              </DialogDescription>
            </DialogHeader>
            <Input
              type="password"
              autoFocus
              value={code}
              onChange={(e) => {
                setCode(e.target.value);
                setError(false);
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter") void submit();
              }}
              placeholder="Vault password"
              aria-invalid={error}
              className={error ? "border-destructive" : undefined}
            />
            {error ? <p className="text-xs text-destructive">Incorrect password. Try again.</p> : null}
            <div className="flex items-center justify-between gap-2">
              {hasQuestions ? (
                <Button
                  variant="ghost"
                  size="sm"
                  className="gap-1.5 text-muted-foreground"
                  onClick={() => {
                    setMode("recovery");
                    setError(false);
                  }}
                >
                  <ShieldQuestion className="h-4 w-4" /> Forgot password?
                </Button>
              ) : null}
              <div className="ml-auto flex gap-2">
                <Button variant="ghost" onClick={close}>
                  Cancel
                </Button>
                <Button onClick={() => void submit()} disabled={busy || !code}>
                  {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  Unlock
                </Button>
              </div>
            </div>
          </>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <ShieldQuestion className="h-5 w-5" /> Reset with security questions
              </DialogTitle>
              <DialogDescription>
                Answer both of your security questions to set a new password.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-3">
              {qIds.map((id, i) => (
                <div key={id} className="space-y-1.5">
                  <Label>{questionText(id)}</Label>
                  <Input
                    value={answers[i] ?? ""}
                    onChange={(e) =>
                      setAnswers((cur) => cur.map((v, j) => (j === i ? e.target.value : v)))
                    }
                    autoComplete="off"
                    placeholder="Your answer"
                  />
                </div>
              ))}
              <div className="space-y-1.5">
                <Label>New vault password</Label>
                <Input
                  type="password"
                  value={newPass}
                  onChange={(e) => setNewPass(e.target.value)}
                  placeholder="At least 3 characters"
                />
              </div>
              {recoveryError ? <p className="text-xs text-destructive">{recoveryError}</p> : null}
            </div>
            <div className="flex justify-between gap-2">
              <Button
                variant="ghost"
                className="gap-1.5"
                onClick={() => setMode("password")}
                disabled={busy}
              >
                <ArrowLeft className="h-4 w-4" /> Back
              </Button>
              <Button onClick={() => void submitRecovery()} disabled={busy}>
                {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                Reset password
              </Button>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

/* ------------------------------------------------------------------ */
/* Setup dialog (first time)                                           */
/* ------------------------------------------------------------------ */

export function VaultSetupDialog() {
  const open = useKeepStore((s) => s.vaultSetupOpen);
  const setOpen = useKeepStore((s) => s.setVaultSetupOpen);
  const completeVaultSetup = useKeepStore((s) => s.completeVaultSetup);
  useBackLayer(open, () => setOpen(false));

  const [pass, setPass] = useState("");
  const [confirm, setConfirm] = useState("");
  const [qIds, setQIds] = useState<[string, string]>([SECURITY_QUESTIONS[0].id, SECURITY_QUESTIONS[1].id]);
  const [answers, setAnswers] = useState(["", ""]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const usedElsewhere = useMemo(() => new Set(qIds), [qIds]);

  function close() {
    setPass("");
    setConfirm("");
    setAnswers(["", ""]);
    setError("");
    setOpen(false);
  }

  async function submit() {
    setError("");
    if (pass.length < 3) {
      setError("The password must be at least 3 characters.");
      return;
    }
    if (pass !== confirm) {
      setError("The two passwords do not match.");
      return;
    }
    if (qIds[0] === qIds[1]) {
      setError("Pick two different security questions.");
      return;
    }
    if (answers.some((a) => !a.trim())) {
      setError("Please answer both security questions.");
      return;
    }
    setBusy(true);
    const ok = await completeVaultSetup(pass, [
      { id: qIds[0], answer: answers[0] },
      { id: qIds[1], answer: answers[1] },
    ]);
    setBusy(false);
    if (ok) {
      close();
      toast.success("Vault ready", {
        description: "Protected with your password — use it to protect your private notes.",
      });
    } else {
      setError("Could not save the vault. Try again.");
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) close(); }}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <LockKeyhole className="h-5 w-5" /> Protect your notes
          </DialogTitle>
          <DialogDescription>
            Set a vault password and two security questions. The vault keeps private notes behind
            this password; after unlocking once, it stays open until the app closes.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="vault-new-pass">Password</Label>
              <Input
                id="vault-new-pass"
                type="password"
                value={pass}
                onChange={(e) => setPass(e.target.value)}
                placeholder="At least 3 characters"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="vault-confirm-pass">Confirm password</Label>
              <Input
                id="vault-confirm-pass"
                type="password"
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") void submit();
                }}
                placeholder="Repeat it"
              />
            </div>
          </div>

          <div className="rounded-lg border bg-accent/30 p-3">
            <p className="mb-2.5 flex items-center gap-1.5 text-sm font-medium">
              <ShieldQuestion className="h-4 w-4" /> Security questions (2 required)
            </p>
            <p className="mb-3 text-xs text-muted-foreground">
              You will answer both of these to recover access if you ever forget the password.
              Answers are not case-sensitive.
            </p>
            <div className="space-y-3">
              {[0, 1].map((slot) => (
                <div key={slot} className="grid gap-2 sm:grid-cols-[1.4fr_1fr]">
                  <Select
                    value={qIds[slot]}
                    onValueChange={(v) =>
                      setQIds((cur) => (slot === 0 ? [v, cur[1]] : [cur[0], v]))
                    }
                  >
                    <SelectTrigger aria-label={`Security question ${slot + 1}`}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {SECURITY_QUESTIONS.map((q) => (
                        <SelectItem
                          key={q.id}
                          value={q.id}
                          disabled={usedElsewhere.has(q.id) && qIds[slot] !== q.id}
                        >
                          {q.text}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Input
                    value={answers[slot] ?? ""}
                    onChange={(e) =>
                      setAnswers((cur) => cur.map((v, j) => (j === slot ? e.target.value : v)))
                    }
                    autoComplete="off"
                    placeholder="Your answer"
                    aria-label={`Answer for question ${slot + 1}`}
                  />
                </div>
              ))}
            </div>
          </div>

          {error ? <p className="text-xs text-destructive">{error}</p> : null}
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={close} disabled={busy}>
            Cancel
          </Button>
          <Button onClick={() => void submit()} disabled={busy}>
            {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Protect my notes
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
