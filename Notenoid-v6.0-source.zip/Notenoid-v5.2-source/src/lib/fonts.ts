// ---------------------------------------------------------------------------
// V6 font choices — 14 fonts covering sans, serif, monospace, geometric and
// handwriting styles for BOTH the app UI and note text.
//
// The actual font files are self-hosted at build time via next/font/google
// (see app/layout.tsx) which exposes each family under a CSS variable
// (--nf-<id>) — they work fully OFFLINE (no Google request at runtime), so
// the Android APK gets all fonts bundled. Every choice carries a system
// fallback stack so text renders even while the font chunk is loading.
// ---------------------------------------------------------------------------

export interface FontChoice {
  id: string;
  name: string;
  /** what the style is good for (used as subtitle in the picker) */
  kind: "system" | "sans" | "serif" | "mono" | "geometric" | "handwriting";
  /** full CSS font-family stack; usually starts with the next/font var */
  stack: string;
}

const SANS_FALLBACK = `"Segoe UI", -apple-system, BlinkMacSystemFont, Roboto, sans-serif`;
const SERIF_FALLBACK = `Georgia, "Times New Roman", serif`;
const MONO_FALLBACK = `ui-monospace, Menlo, Consolas, monospace`;

export const FONT_CHOICES: FontChoice[] = [
  {
    id: "default",
    name: "System default",
    kind: "system",
    stack: `"Google Sans", Roboto, system-ui, ${SANS_FALLBACK}`,
  },
  { id: "inter", name: "Inter", kind: "sans", stack: `var(--nf-inter), ${SANS_FALLBACK}` },
  { id: "roboto", name: "Roboto", kind: "sans", stack: `var(--nf-roboto), Roboto, ${SANS_FALLBACK}` },
  { id: "open-sans", name: "Open Sans", kind: "sans", stack: `var(--nf-open-sans), ${SANS_FALLBACK}` },
  { id: "nunito", name: "Nunito", kind: "sans", stack: `var(--nf-nunito), ${SANS_FALLBACK}` },
  { id: "poppins", name: "Poppins", kind: "geometric", stack: `var(--nf-poppins), ${SANS_FALLBACK}` },
  { id: "lora", name: "Lora", kind: "serif", stack: `var(--nf-lora), ${SERIF_FALLBACK}` },
  {
    id: "merriweather",
    name: "Merriweather",
    kind: "serif",
    stack: `var(--nf-merriweather), ${SERIF_FALLBACK}`,
  },
  {
    id: "playfair",
    name: "Playfair Display",
    kind: "serif",
    stack: `var(--nf-playfair), ${SERIF_FALLBACK}`,
  },
  {
    id: "jetbrains-mono",
    name: "JetBrains Mono",
    kind: "mono",
    stack: `var(--nf-jetbrains-mono), ${MONO_FALLBACK}`,
  },
  { id: "fira-code", name: "Fira Code", kind: "mono", stack: `var(--nf-fira-code), ${MONO_FALLBACK}` },
  {
    id: "ibm-plex-mono",
    name: "IBM Plex Mono",
    kind: "mono",
    stack: `var(--nf-ibm-plex-mono), ${MONO_FALLBACK}`,
  },
  {
    id: "comic-neue",
    name: "Comic Neue",
    kind: "handwriting",
    stack: `var(--nf-comic-neue), "Comic Sans MS", cursive, ${SANS_FALLBACK}`,
  },
  { id: "caveat", name: "Caveat", kind: "handwriting", stack: `var(--nf-caveat), "Segoe Script", cursive` },
];

export function getFont(id: string): FontChoice {
  return FONT_CHOICES.find((f) => f.id === id) ?? FONT_CHOICES[0];
}
