// ---------------------------------------------------------------------------
// V6 theme system — 24 complete app themes.
//
// Each theme defines the full shadcn/ui CSS variable set, so EVERY surface
// (top bar, sidebar, dialogs, popovers, inputs, menus, scrollbars, editor
// chrome…) follows the theme — nothing is left half-styled. Themes are
// applied as inline CSS custom properties on <html> by ThemeController
// (components/keep/ThemeController.tsx); the settings store is the source.
//
// Note colours are intentionally independent (lib/keep-constants.ts), so a
// themed app never fights the user's per-note colours.
//
// Groups: classic (the V5 light/dark pair), light (colour-tinted), dark
// (comfy dark UI), contrast (accessibility), comfy (well-known palettes),
// special (Frutiger Aero, Vaporwave — with extra CSS in globals.css).
// ---------------------------------------------------------------------------

export type ThemeMode = "light" | "dark";
export type ThemeGroup = "classic" | "light" | "dark" | "contrast" | "comfy" | "special";

export interface ThemeDef {
  id: string;
  name: string;
  mode: ThemeMode;
  group: ThemeGroup;
  /** short swatch description for the gallery preview */
  swatch: [string, string, string]; // [background, primary, accent]
  /** CSS custom properties WITHOUT the leading "--" */
  vars: Record<string, string>;
}

const baseLight: Record<string, string> = {
  "card-foreground": "#1b1d21",
  "popover-foreground": "#1b1d21",
  "secondary-foreground": "#1b1d21",
  "accent-foreground": "#1b1d21",
  destructive: "#dc2626",
  radius: "0.625rem",
};

const baseDark: Record<string, string> = {
  "card-foreground": "#f0f1f3",
  "popover-foreground": "#f0f1f3",
  "secondary-foreground": "#f0f1f3",
  "accent-foreground": "#f0f1f3",
  destructive: "#ef4444",
  radius: "0.625rem",
};

function theme(
  id: string,
  name: string,
  mode: ThemeMode,
  group: ThemeGroup,
  swatch: [string, string, string],
  vars: Record<string, string>
): ThemeDef {
  return { id, name, mode, group, swatch, vars: { ...(mode === "dark" ? baseDark : baseLight), ...vars } };
}

export const THEMES: ThemeDef[] = [
  // ---------------------------------------------------------------- classic
  theme("classic-light", "Keep Light", "light", "classic", ["#f1f3f4", "#232629", "#f1f3f4"], {
    background: "#f1f3f4",
    foreground: "#232629",
    card: "#ffffff",
    popover: "#ffffff",
    primary: "#232629",
    "primary-foreground": "#fdfdfd",
    secondary: "#e7e9eb",
    muted: "#e9ebed",
    "muted-foreground": "#697077",
    accent: "#e4e7ea",
    border: "#dde0e4",
    input: "#d5d9dd",
    ring: "#8f979e",
  }),
  theme("classic-dark", "Keep Dark", "dark", "classic", ["#1f2023", "#e3e3e3", "#2a2b2e"], {
    background: "#1f2023",
    foreground: "#e7e8ea",
    card: "#28292d",
    popover: "#2c2d31",
    primary: "#e3e3e3",
    "primary-foreground": "#1e1f22",
    secondary: "#323336",
    muted: "#2e2f33",
    "muted-foreground": "#9ba0a6",
    accent: "#333438",
    border: "#37383c",
    input: "#3c3d41",
    ring: "#8f979e",
  }),

  // ------------------------------------------------------------- light UI
  theme("sky", "Sky Blue", "light", "light", ["#eef4fb", "#2563eb", "#e3edfa"], {
    background: "#eef4fb",
    foreground: "#1c2b3a",
    card: "#ffffff",
    popover: "#ffffff",
    primary: "#2563eb",
    "primary-foreground": "#ffffff",
    secondary: "#e3edfa",
    muted: "#e8f0f9",
    "muted-foreground": "#5c6f82",
    accent: "#dde9f8",
    border: "#d5e2f1",
    input: "#c9daf0",
    ring: "#60a5fa",
  }),
  theme("mint", "Fresh Mint", "light", "light", ["#effaf3", "#059669", "#dcf3e6"], {
    background: "#effaf3",
    foreground: "#14332a",
    card: "#ffffff",
    popover: "#ffffff",
    primary: "#059669",
    "primary-foreground": "#ffffff",
    secondary: "#dcf3e6",
    muted: "#e3f5eb",
    "muted-foreground": "#55786a",
    accent: "#d5efdf",
    border: "#cce8d8",
    input: "#bcdcc9",
    ring: "#34d399",
  }),
  theme("lavender", "Lavender", "light", "light", ["#f4f1fb", "#7c3aed", "#ebe5f9"], {
    background: "#f4f1fb",
    foreground: "#2a2140",
    card: "#ffffff",
    popover: "#ffffff",
    primary: "#7c3aed",
    "primary-foreground": "#ffffff",
    secondary: "#ebe5f9",
    muted: "#eee9f9",
    "muted-foreground": "#6d6486",
    accent: "#e4dcf6",
    border: "#ddd4ef",
    input: "#d1c5e9",
    ring: "#a78bfa",
  }),
  theme("rose", "Rose Quartz", "light", "light", ["#fbf1f4", "#e11d48", "#f8e2e9"], {
    background: "#fbf1f4",
    foreground: "#40222c",
    card: "#ffffff",
    popover: "#ffffff",
    primary: "#e11d48",
    "primary-foreground": "#ffffff",
    secondary: "#f8e2e9",
    muted: "#f9e7ed",
    "muted-foreground": "#86606e",
    accent: "#f4d9e2",
    border: "#efd3dd",
    input: "#e9c4d1",
    ring: "#fb7185",
  }),
  theme("peach", "Warm Peach", "light", "light", ["#fdf3ec", "#ea580c", "#f9e6d8"], {
    background: "#fdf3ec",
    foreground: "#3e2718",
    card: "#ffffff",
    popover: "#ffffff",
    primary: "#ea580c",
    "primary-foreground": "#ffffff",
    secondary: "#f9e6d8",
    muted: "#faebdf",
    "muted-foreground": "#84604a",
    accent: "#f5dfcc",
    border: "#f0d7c1",
    input: "#eacbaf",
    ring: "#fb923c",
  }),
  theme("sand", "Sandy Beige", "light", "light", ["#f7f3ea", "#a16207", "#efe8d8"], {
    background: "#f7f3ea",
    foreground: "#33301f",
    card: "#fffdf8",
    popover: "#fffdf8",
    primary: "#a16207",
    "primary-foreground": "#ffffff",
    secondary: "#efe8d8",
    muted: "#f0ead9",
    "muted-foreground": "#79725c",
    accent: "#eae1cb",
    border: "#e3d9c2",
    input: "#dbcfb2",
    ring: "#ca8a04",
  }),
  theme("slate-light", "Cool Slate", "light", "light", ["#f4f5f6", "#334155", "#e8eaed"], {
    background: "#f4f5f6",
    foreground: "#242a31",
    card: "#ffffff",
    popover: "#ffffff",
    primary: "#334155",
    "primary-foreground": "#ffffff",
    secondary: "#e8eaed",
    muted: "#ebedef",
    "muted-foreground": "#616a73",
    accent: "#e2e5e9",
    border: "#dbdfe4",
    input: "#d2d7dd",
    ring: "#94a3b8",
  }),

  // -------------------------------------------------------------- dark UI
  theme("midnight", "Midnight Blue", "dark", "dark", ["#0f172a", "#93c5fd", "#27354d"], {
    background: "#0f172a",
    foreground: "#e2e8f0",
    card: "#1e293b",
    popover: "#22304a",
    primary: "#93c5fd",
    "primary-foreground": "#0f172a",
    secondary: "#27354d",
    muted: "#233248",
    "muted-foreground": "#94a7c2",
    accent: "#2c3d5a",
    border: "#2d3d58",
    input: "#334564",
    ring: "#60a5fa",
  }),
  theme("espresso", "Espresso", "dark", "dark", ["#201a17", "#e7c9a9", "#382d27"], {
    background: "#201a17",
    foreground: "#f0e6e0",
    card: "#2b2320",
    popover: "#312823",
    primary: "#e7c9a9",
    "primary-foreground": "#2b2015",
    secondary: "#382d27",
    muted: "#342a24",
    "muted-foreground": "#b8a394",
    accent: "#3e322b",
    border: "#42352c",
    input: "#493b31",
    ring: "#d4a373",
  }),
  theme("forest-night", "Forest Night", "dark", "dark", ["#101a14", "#86efac", "#22352a"], {
    background: "#101a14",
    foreground: "#e0efe4",
    card: "#18251c",
    popover: "#1c2b21",
    primary: "#86efac",
    "primary-foreground": "#0c1a10",
    secondary: "#22352a",
    muted: "#203026",
    "muted-foreground": "#9db8a7",
    accent: "#273d2f",
    border: "#2a4233",
    input: "#2f4a39",
    ring: "#4ade80",
  }),
  theme("plum-dark", "Deep Plum", "dark", "dark", ["#1c1420", "#d8b4fe", "#34253d"], {
    background: "#1c1420",
    foreground: "#f3e8f7",
    card: "#281d2e",
    popover: "#2e2136",
    primary: "#d8b4fe",
    "primary-foreground": "#241531",
    secondary: "#34253d",
    muted: "#2f2237",
    "muted-foreground": "#b39cba",
    accent: "#3a2a45",
    border: "#402e4c",
    input: "#483457",
    ring: "#c084fc",
  }),
  theme("charcoal", "Charcoal", "dark", "dark", ["#171717", "#fafafa", "#2a2a2a"], {
    background: "#171717",
    foreground: "#ededed",
    card: "#212121",
    popover: "#262626",
    primary: "#fafafa",
    "primary-foreground": "#171717",
    secondary: "#2a2a2a",
    muted: "#272727",
    "muted-foreground": "#9c9c9c",
    accent: "#2f2f2f",
    border: "#333333",
    input: "#3a3a3a",
    ring: "#a3a3a3",
  }),

  // -------------------------------------------------------- high contrast
  theme("contrast-light", "High Contrast Light", "light", "contrast", ["#ffffff", "#000000", "#f0f0f0"], {
    background: "#ffffff",
    foreground: "#000000",
    card: "#ffffff",
    popover: "#ffffff",
    primary: "#000000",
    "primary-foreground": "#ffffff",
    secondary: "#f0f0f0",
    muted: "#f2f2f2",
    "muted-foreground": "#333333",
    accent: "#e8e8e8",
    border: "#000000",
    input: "#000000",
    ring: "#000000",
    destructive: "#b91c1c",
    radius: "0.375rem",
  }),
  theme("contrast-dark", "High Contrast Dark", "dark", "contrast", ["#000000", "#ffe600", "#1c1c1c"], {
    background: "#000000",
    foreground: "#ffffff",
    card: "#0a0a0a",
    popover: "#111111",
    primary: "#ffe600",
    "primary-foreground": "#000000",
    secondary: "#1c1c1c",
    muted: "#161616",
    "muted-foreground": "#e0e0e0",
    accent: "#222222",
    border: "#ffffff",
    input: "#ffffff",
    ring: "#ffe600",
    destructive: "#ff5252",
    radius: "0.375rem",
  }),
  theme("contrast-blue", "High Contrast Navy", "dark", "contrast", ["#001f3f", "#ffd700", "#0a335e"], {
    background: "#001f3f",
    foreground: "#ffffff",
    card: "#00274d",
    popover: "#002c56",
    primary: "#ffd700",
    "primary-foreground": "#001f3f",
    secondary: "#0a335e",
    muted: "#062d52",
    "muted-foreground": "#cfe0f5",
    accent: "#0d3a67",
    border: "#7ea6d8",
    input: "#7ea6d8",
    ring: "#ffd700",
    destructive: "#ff6b6b",
    radius: "0.375rem",
  }),

  // ---------------------------------------------------------------- comfy
  theme("solarized-light", "Solarized Light", "light", "comfy", ["#fdf6e3", "#268bd2", "#eee8d5"], {
    background: "#fdf6e3",
    foreground: "#073642",
    card: "#fffbee",
    popover: "#fffaf0",
    primary: "#268bd2",
    "primary-foreground": "#fdf6e3",
    secondary: "#eee8d5",
    muted: "#f2ecd9",
    "muted-foreground": "#657b83",
    accent: "#e9e2cc",
    border: "#e2d9bd",
    input: "#d9cfaf",
    ring: "#93a1a1",
  }),
  theme("solarized-dark", "Solarized Dark", "dark", "comfy", ["#002b36", "#2aa198", "#0a4a56"], {
    background: "#002b36",
    foreground: "#cfd8dc",
    card: "#073642",
    popover: "#093d4a",
    primary: "#2aa198",
    "primary-foreground": "#002b36",
    secondary: "#0a4a56",
    muted: "#09414d",
    "muted-foreground": "#93a1a1",
    accent: "#0d4c58",
    border: "#11515d",
    input: "#155a66",
    ring: "#268bd2",
  }),
  theme("nord", "Nord", "dark", "comfy", ["#2e3440", "#88c0d0", "#434c5e"], {
    background: "#2e3440",
    foreground: "#eceff4",
    card: "#3b4252",
    popover: "#3f475a",
    primary: "#88c0d0",
    "primary-foreground": "#2e3440",
    secondary: "#434c5e",
    muted: "#3f475a",
    "muted-foreground": "#c3cbd8",
    accent: "#434c5e",
    border: "#4c566a",
    input: "#4c566a",
    ring: "#88c0d0",
  }),
  theme("dracula", "Dracula", "dark", "comfy", ["#282a36", "#bd93f9", "#44475a"], {
    background: "#282a36",
    foreground: "#f8f8f2",
    card: "#2f3141",
    popover: "#343650",
    primary: "#bd93f9",
    "primary-foreground": "#1a1b24",
    secondary: "#44475a",
    muted: "#3d3f52",
    "muted-foreground": "#c6c8d8",
    accent: "#44475a",
    border: "#4a4d66",
    input: "#4a4d66",
    ring: "#ff79c6",
    destructive: "#ff5555",
  }),
  theme("gruvbox", "Gruvbox", "dark", "comfy", ["#282828", "#fabd2f", "#504945"], {
    background: "#282828",
    foreground: "#ebdbb2",
    card: "#32302f",
    popover: "#37332f",
    primary: "#fabd2f",
    "primary-foreground": "#282828",
    secondary: "#3c3836",
    muted: "#393434",
    "muted-foreground": "#bdae93",
    accent: "#504945",
    border: "#544a42",
    input: "#5c5148",
    ring: "#fabd2f",
  }),

  // -------------------------------------------------------------- special
  theme("frutiger-aero", "Frutiger Aero", "light", "special", ["#dff1fb", "#0284c7", "#e8f6fd"], {
    background: "#dff1fb",
    foreground: "#0c3c52",
    card: "#ffffff",
    popover: "#ffffff",
    primary: "#0284c7",
    "primary-foreground": "#ffffff",
    secondary: "#e8f6fd",
    muted: "#e2f1f9",
    "muted-foreground": "#4a7c95",
    accent: "#d9eefa",
    border: "#bfe3f2",
    input: "#aadcf0",
    ring: "#38bdf8",
    radius: "1rem",
  }),
  theme("vaporwave", "Vaporwave", "dark", "special", ["#241b3a", "#ff71ce", "#3a2d66"], {
    background: "#241b3a",
    foreground: "#f5e9ff",
    card: "#2d2250",
    popover: "#322659",
    primary: "#ff71ce",
    "primary-foreground": "#2d0f22",
    secondary: "#352a5e",
    muted: "#31265a",
    "muted-foreground": "#b8a8d9",
    accent: "#3a2d66",
    border: "#4a3a7a",
    input: "#544191",
    ring: "#01cdfe",
    destructive: "#ff4757",
  }),
];

export const DEFAULT_THEME_ID = "system";

export function getTheme(id: string): ThemeDef | null {
  return THEMES.find((t) => t.id === id) ?? null;
}

/** All theme ids that may appear in settings. */
export function isKnownTheme(id: string): boolean {
  return id === "system" || THEMES.some((t) => t.id === id);
}
