# Notenoid V6.0 — Release Notes

A cross-platform upgrade focused on precision, personalisation and trust.
Everything below is covered by an automated 48-check browser test-suite
(mouse + Android-emulated touch drag, math, images, scroll anchors, themes,
fonts, vault flows, export/import round-trip).

## 1. Per-image sizing (new)

* Every single image in the note preview now has its own **size button**
  (bottom-right of the image): presets S / M / L / Full / Auto plus a fine
  slider (20–100 %).
* The chosen width is stored **in the markdown** (`![img](path "size=75")`),
  so it survives sync, export and other editors.
* Resizing **never jumps you to the top or bottom** — the viewport is pinned
  to the image's block via source-line anchors, so you see the change live.
* The old universal "Single image width" setting is gone; the image **grid**
  width remains a global setting.

## 2. Text sizing — fixed and separated

* **App text size** (70–150 %) now scales the whole interface: it changes the
  root font-size, so every rem-based control, menu, dialog and card grows
  together — no more half-scaled UI.
* **Note text size** (70–170 %) scales only markdown content: editor
  textarea, rendered preview (headings/lists scale proportionally) and the
  note-card previews.

## 3. Fonts (14, incl. monospace)

* 14 self-hosted font families (offline-ready, bundled into the APK):
  System, Inter, Roboto, Open Sans, Nunito, Poppins, Lora, Merriweather,
  Playfair Display, **JetBrains Mono**, **Fira Code**, **IBM Plex Mono**,
  Comic Neue, Caveat.
* Separate pickers for the **app UI font** and the **note font**.

## 4. 24 full-app themes

* Classic (Keep Light/Dark), 7 light & colourful, 5 dark UI, 3 **high
  contrast**, 5 comfy palettes (Solarized, Nord, Dracula, Gruvbox), and 2
  special: **Frutiger Aero** (glassy, glossy sky gradient) and Vaporwave.
* Themes apply to every surface (bars, dialogs, menus, inputs, scrollbars).
* Per-note colours remain fully independent — themes never fight them.
* System option follows the OS (Android-aware) and updates live.

## 5. Full math support (KaTeX)

* `$…$`, `$$…$$` and fenced `$$` blocks render beautifully in the preview
  (inline + display math, single-line `$$…$$` upgraded to display mode like
  Obsidian/GitHub).
* Permanent support — no button needed. Toggle in Settings → Appearance.
* KaTeX fonts are bundled: works offline in the APK.

## 6. Import (full restore) + smarter export

* **Settings → Import**: upload the exported ZIP — notes, folders, labels,
  archive, vault and app settings are restored automatically.
* Accepts both V6 exports and legacy V5 ZIPs (note folders at the root).
* New export layout: `manifest.json`, `settings.json`, `config.json`,
  `notes/<Folder>/<Note>/node.md + attachment/`, `_vault/…`.
* Export options: scope (all/folder), images, archive, app settings and
  **vault notes — gated by the vault password** when the vault is locked.
* The vault's security data rides along in a vault-included export so a new
  device restores the protection seamlessly (never overwrites an existing
  local vault).

## 7. Vault — re-architected (first-class)

* The **Vault section is always visible** in the sidebar. Tapping it asks for
  the password; the first time it runs a setup.
* One-time setup: **password + exactly 2 security questions** chosen from a
  bank of 15 different types. Both answers are required for recovery.
* Password hashing: **PBKDF2-SHA256, 150 000 iterations, per-vault salt**.
  Answers are normalised (case/whitespace-insensitive) and hashed the same
  way. Legacy V5 codes migrate transparently on first unlock.
* **Unlocks once per app session** — after typing the password the vault
  stays open until the app closes (session storage).
* Forgot password? Answer **both** security questions and set a new password
  right from the unlock dialog.
* Settings → Vault (always visible): status, lock now, change password,
  manage security questions, export vault.
* All "hidden vault"/"secret chamber" wording removed — the vault is simply
  described as a way to **protect your notes**. The "Know the secret" button
  and the `open_vault` search phrase are gone.

## 8. Android: appear in "Open with"

* The app now registers for `ACTION_VIEW` on `text/plain`, `text/markdown`,
  `text/*` and `application/json` (content & file schemes).
* Opening a .txt/.md file from any file manager imports it as a note and
  opens the editor — no storage permission needed (ContentResolver).

## 9. Edit ↔ preview position — exact restore

* The rendered preview is annotated with the **markdown source line** of every
  block (`data-src-line` from react-markdown positions).
* Mode switches map the viewport through that anchor — the same text sits at
  the same screen position before and after the switch, in both directions.
* Settle-pins never fight the user: any external scroll immediately hands
  control back, and captures measure the *intended* position, not a
  mid-layout intermediate (fixes the Android jump-to-top/jump-to-bottom).

## 10. Junk removed

* 45 dependencies dropped (all TipTap packages, recharts, embla, vaul,
  react-hook-form, zod, date-fns, uuid, next-intl, sharp, …) and 35 unused
  shadcn/ui components + the dead TipTap search extension.
* Smaller install, smaller APK, faster builds.

## 11. Muuri drag & drop — smooth on Android

* Retuned heuristics: slower sort interval (110 ms), higher swap threshold
  (55), stronger bounce-back — no more left/right jitter or flicker.
* Autoscroll: edge-only (threshold 44 px, safe zone 0.3), smooth ramp, and
  items sort **after** an autoscroll settles — no more screen racing up/down
  while dragging.
* GPU: dragging/releasing items get their own compositor layer
  (`will-change: transform`) — no flicker on mid-range WebViews.
* **New long-press hold guard**: on Android, a resting finger can no longer
  be hijacked by the browser (pointercancel) during the 220 ms hold — the
  drag starts reliably; quick swipes on cards still scroll normally.

## Upgrade notes

* Settings from V5 migrate automatically (`fontSize` → app scale; per-image
  sizes start at Auto).
* Old vault codes keep working; you'll be offered to complete the security
  questions from Settings → Vault.
