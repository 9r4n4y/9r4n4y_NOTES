"use client";

import { Button } from "@/components/ui/button";
import { useKeepStore } from "./store";
import { useSettings } from "./settings-store";
import { cn } from "@/lib/utils";
import {
  Archive,
  Folder as FolderIcon,
  StickyNote,
  Lock,
  Pencil,
  Plus,
  Tags,
  Trash2,
  Settings,
} from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import type { LucideIcon } from "lucide-react";
import { toast } from "sonner";

interface NavItem {
  key: string;
  label: string;
  icon: LucideIcon;
}

const MAIN_NAV: NavItem[] = [
  { key: "notes", label: "Notes", icon: StickyNote },
  { key: "folders", label: "Folders", icon: FolderIcon },
  { key: "archive", label: "Archive", icon: Archive },
  { key: "trash", label: "Trash", icon: Trash2 },
];

const VAULT_NAV: NavItem = { key: "vault", label: "Vault", icon: Lock };

export function Sidebar({
  open,
  mobileOpen,
  onCloseMobile,
  onNewFolder,
  onManageLabels,
}: {
  open: boolean;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  onNewFolder: () => void;
  onManageLabels: () => void;
}) {
  const view = useKeepStore((s) => s.view);
  const activeFolderId = useKeepStore((s) => s.activeFolderId);
  const activeLabelId = useKeepStore((s) => s.activeLabelId);
  const setView = useKeepStore((s) => s.setView);
  const folders = useKeepStore((s) => s.folders);
  const labels = useKeepStore((s) => s.labels);
  const notes = useKeepStore((s) => s.notes);
  const vaultOpen = useKeepStore((s) => s.vaultOpen);
  const closeVault = useKeepStore((s) => s.closeVault);
  const setSettingsOpen = useKeepStore((s) => s.setSettingsOpen);
  const settings = useSettings();

  const expanded = open || mobileOpen;
  const notesCount = notes.filter((n) => !n.trashed && !n.archived && !n.vaulted).length;

  const countFor = (key: string) => {
    switch (key) {
      case "notes":
        return notesCount;
      case "archive":
        return notes.filter((n) => n.archived && !n.trashed && !n.vaulted).length;
      case "trash":
        return notes.filter((n) => n.trashed).length;
      case "vault":
        return notes.filter((n) => n.vaulted && !n.trashed).length;
      default:
        return undefined;
    }
  };

  const isActive = (key: string) => {
    if (key === "folders") return view === "folders";
    return view === key;
  };

  function go(key: string) {
    setView(key as never);
    onCloseMobile();
  }

  function renderButton(
    item: { key: string; label: string; icon: LucideIcon },
    active: boolean,
    onClick: () => void,
    trailing?: React.ReactNode
  ) {
    const content = (
      <button
        type="button"
        onClick={onClick}
        className={cn(
          "group flex h-10 items-center gap-3 rounded-full text-sm transition-[background-color,color] duration-150 active:scale-[0.98]",
          expanded ? "w-full px-3.5" : "mx-auto w-10 justify-center px-0",
          active
            ? "bg-[#fef7e0] font-medium text-foreground dark:bg-[#004a8d]/60 dark:text-white"
            : "text-foreground/75 hover:bg-black/5 hover:text-foreground dark:hover:bg-white/8"
        )}
      >
        <item.icon className={cn("h-5 w-5 shrink-0 transition-transform duration-150 group-active:scale-90", active ? "text-current" : "text-foreground/60")} />
        {expanded ? (
          <>
            <span className="flex-1 truncate text-left">{item.label}</span>
            {trailing}
          </>
        ) : null}
      </button>
    );
    if (!expanded) {
      return (
        <Tooltip key={item.key}>
          <TooltipTrigger asChild>{content}</TooltipTrigger>
          <TooltipContent side="right" className="text-xs">
            {item.label}
          </TooltipContent>
        </Tooltip>
      );
    }
    return <div key={item.key}>{content}</div>;
  }

  return (
    <>
      {/* mobile scrim — always mounted, fades for a buttery transition */}
      <div
        className={cn(
          "fixed inset-0 z-40 bg-black/40 transition-opacity duration-200 md:hidden",
          mobileOpen ? "opacity-100" : "pointer-events-none opacity-0"
        )}
        onClick={onCloseMobile}
        aria-hidden={!mobileOpen}
      />

      <nav
        aria-label="Main navigation"
        className={cn(
          "z-50 flex shrink-0 flex-col gap-0.5 overflow-y-auto overflow-x-hidden pb-6",
          // mobile: fixed drawer under the top bar
          "fixed bottom-0 left-0 top-16 w-64 bg-background shadow-2xl transition-transform duration-300 [transition-timing-function:cubic-bezier(0.22,1,0.36,1)] md:sticky md:top-16 md:h-[calc(100vh-4rem)] md:translate-x-0 md:bg-transparent md:shadow-none",
          mobileOpen ? "translate-x-0" : "-translate-x-full",
          open ? "md:w-64" : "md:w-[4.5rem]"
        )}
      >
        {/* V5: brand header — the drawer no longer starts with dead space */}
        {expanded ? (
          <div className="mb-2 px-3 pt-3">
            <div className="flex items-center gap-3 rounded-2xl border border-black/5 bg-card/70 px-3.5 py-3 shadow-sm dark:border-white/10">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-amber-300 to-amber-500 text-lg shadow-inner" aria-hidden>
                📝
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm font-semibold leading-tight">{settings.appName}</span>
                <span className="block text-[11px] leading-tight text-muted-foreground">
                  {notesCount} note{notesCount === 1 ? "" : "s"} · local-first
                </span>
              </span>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 shrink-0 rounded-full"
                aria-label="Settings"
                title="Settings"
                onClick={() => {
                  setSettingsOpen(true);
                  onCloseMobile();
                }}
              >
                <Settings className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ) : (
          <div className="mb-1 mt-2 flex justify-center" aria-hidden>
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-amber-300 to-amber-500 text-base">
              📝
            </span>
          </div>
        )}

        {MAIN_NAV.map((item) => renderButton(item, isActive(item.key), () => go(item.key), countFor(item.key) ? (
          <span className="rounded-full bg-black/5 px-2 py-0.5 text-[11px] tabular-nums text-muted-foreground dark:bg-white/10">
            {countFor(item.key)}
          </span>
        ) : undefined))}

        {/* Secret vault — only visible while unlocked */}
        {vaultOpen
          ? renderButton(
              VAULT_NAV,
              view === "vault",
              () => go("vault"),
              <span
                role="button"
                tabIndex={0}
                aria-label="Lock vault"
                title="Lock vault"
                className="inline-flex cursor-pointer rounded-full p-1 hover:bg-black/10 dark:hover:bg-white/10"
                onClick={(e) => {
                  e.stopPropagation();
                  closeVault();
                  onCloseMobile();
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.stopPropagation();
                    closeVault();
                    onCloseMobile();
                  }
                }}
              >
                {countFor("vault") || ""}
                <Lock className="h-3.5 w-3.5" />
              </span>
            )
          : null}

        <div className={cn("mt-3 flex items-center", expanded ? "px-4" : "justify-center")}>
          {expanded ? (
            <div className="flex w-full items-center justify-between border-t border-black/5 pt-3 dark:border-white/10">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Folders
              </p>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                aria-label="New folder"
                onClick={() => {
                  onNewFolder();
                  onCloseMobile();
                }}
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              aria-label="New folder"
              onClick={() => {
                onNewFolder();
                onCloseMobile();
              }}
            >
              <Plus className="h-4 w-4" />
            </Button>
          )}
        </div>

        {folders.map((f) =>
          renderButton(
            { key: f.id, label: `${f.name}`, icon: (() => <span>{f.emoji}</span>) as unknown as LucideIcon },
            view === "folder" && activeFolderId === f.id,
            () => {
              setView("folder", f.id);
              onCloseMobile();
            },
            <span className="rounded-full bg-black/5 px-2 py-0.5 text-[11px] tabular-nums text-muted-foreground dark:bg-white/10">
              {notes.filter((n) => !n.trashed && !n.archived && !n.vaulted && n.folderId === f.id).length || ""}
            </span>
          )
        )}

        {expanded ? (
          <div className="mt-3 px-4">
            <div className="flex items-center justify-between border-t border-black/5 pt-3 dark:border-white/10">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Labels
              </p>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                aria-label="Edit labels"
                onClick={() => {
                  onManageLabels();
                  onCloseMobile();
                }}
              >
                <Pencil className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        ) : null}

        {labels.map((l) =>
          renderButton(
            { key: l.id, label: l.name, icon: Tags },
            view === "label" && activeLabelId === l.id,
            () => {
              setView("label", l.id);
              onCloseMobile();
            },
            <span className="rounded-full bg-black/5 px-2 py-0.5 text-[11px] tabular-nums text-muted-foreground dark:bg-white/10">
              {notes.filter((n) => !n.trashed && !n.archived && !n.vaulted && n.labels.some((nl) => nl.id === l.id)).length || ""}
            </span>
          )
        )}

        {labels.length === 0 && expanded ? (
          <button
            type="button"
            onClick={() => {
              onManageLabels();
              onCloseMobile();
              toast("Create your first label here", { description: "Labels let you tag and filter notes." });
            }}
            className="mx-4 mt-1 rounded-md px-2 py-2 text-left text-xs text-muted-foreground hover:bg-accent"
          >
            + Create labels to tag notes
          </button>
        ) : null}
      </nav>
    </>
  );
}
