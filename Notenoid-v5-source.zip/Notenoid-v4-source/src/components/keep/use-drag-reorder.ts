"use client";

import { useCallback, useEffect, useRef, useState } from "react";

/**
 * Long-press drag-and-drop reordering for note cards.
 *
 * V5 — full 2-D rewrite for the masonry grid:
 *  - pointer/touch down on a card starts a 300 ms long-press timer
 *  - moving >12 px before activation cancels (that's a scroll)
 *  - on activation the card lifts (scale + shadow), follows the pointer in X
 *    AND Y, and the other cards glide out of the way (live preview)
 *  - near the top/bottom edge the page auto-scrolls so long lists stay
 *    draggable without lifting the finger
 *  - on release the card glides from the pointer into its final slot (the
 *    MasonryGrid layout effect writes the slot transform while the CSS class
 *    transition animates from the release position — no FLIP juggling here)
 *  - Escape returns the card to where it came from and commits nothing
 *
 * The hook drives the card's MASONRY WRAPPER (`[data-masonry-item]`) when it
 * exists — a position:fixed card inside a transformed wrapper would otherwise
 * be positioned relative to that wrapper, not the viewport.
 *
 * No external dependencies; haptic feedback uses the Vibration API when
 * available (the Android shell grants it through the system WebView).
 */

const LONG_PRESS_MS = 300;
const CANCEL_PX = 12;
const EDGE_ZONE = 88; // px from viewport edge where auto-scroll starts
const MAX_SPEED = 22; // px/frame near the very edge

export interface DragReorderApi {
  containerRef: React.RefObject<HTMLDivElement | null>;
  draggingId: string | null;
  handlePointerDown: (e: React.PointerEvent, id: string) => void;
}

interface CardRect {
  id: string;
  left: number;
  top: number;
  right: number;
  bottom: number;
  cx: number;
  cy: number;
}

interface DragState {
  pointerId: number;
  startX: number;
  startY: number;
  lastX: number;
  lastY: number;
  timer: ReturnType<typeof setTimeout> | null;
  active: boolean;
  cancelled: boolean;
  initialOrder: string[];
  order: string[];
  fromIndex: number;
  rects: CardRect[];
  scrollY0: number;
  scrollSpeed: number;
  raf: number;
  dragEl: HTMLElement | null;
}

interface Options {
  /** Ordered note ids currently rendered (preview order included). */
  itemIds: string[];
  enabled: boolean;
  /** Called during the drag whenever the preview order should change. */
  onPreview: (ids: string[]) => void;
  /** Called once on release with the final order. */
  onCommit: (ids: string[]) => void;
}

function collectRects(container: HTMLElement): CardRect[] {
  const els = Array.from(container.querySelectorAll<HTMLElement>("[data-note-id]"));
  return els.map((el) => {
    const r = el.getBoundingClientRect();
    return {
      id: el.getAttribute("data-note-id")!,
      left: r.left,
      top: r.top,
      right: r.right,
      bottom: r.bottom,
      cx: r.left + r.width / 2,
      cy: r.top + r.height / 2,
    };
  });
}

export function useDragReorder({ itemIds, enabled, onPreview, onCommit }: Options): DragReorderApi {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [draggingId, setDraggingId] = useState<string | null>(null);

  const st = useRef<DragState>({
    pointerId: -1,
    startX: 0,
    startY: 0,
    lastX: 0,
    lastY: 0,
    timer: null,
    active: false,
    cancelled: false,
    initialOrder: [],
    order: [],
    fromIndex: -1,
    rects: [],
    scrollY0: 0,
    scrollSpeed: 0,
    raf: 0,
    dragEl: null,
  });

  const idsRef = useRef(itemIds);
  idsRef.current = itemIds;
  const enabledRef = useRef(enabled);
  enabledRef.current = enabled;
  const previewRef = useRef(onPreview);
  previewRef.current = onPreview;
  const commitRef = useRef(onCommit);
  commitRef.current = onCommit;

  const vibrate = useCallback(() => {
    try {
      if (typeof navigator !== "undefined" && "vibrate" in navigator) navigator.vibrate(18);
    } catch {
      /* ignore */
    }
  }, []);

  const finishDrag = useCallback(
    (commit: boolean) => {
      const s = st.current;
      if (s.timer) clearTimeout(s.timer);
      s.timer = null;
      cancelAnimationFrame(s.raf);
      const wasActive = s.active;
      const el = s.dragEl;
      const finalOrder = [...s.order];
      const initialOrder = [...s.initialOrder];
      const fromRect = el && wasActive ? el.getBoundingClientRect() : null;

      s.active = false;
      s.pointerId = -1;
      s.scrollSpeed = 0;
      setDraggingId(null);
      document.body.classList.remove("drag-reorder-active");

      if (wasActive && el && fromRect) {
        // swallow the click that follows pointerup so it doesn't open the editor
        document.addEventListener(
          "click",
          (e) => {
            e.stopPropagation();
            e.preventDefault();
          },
          { capture: true, once: true }
        );

        // Convert the current VISUAL position into container-space transform,
        // clear the fixed styling, and let MasonryGrid's layout effect write
        // the final slot transform — the CSS class transition then animates
        // the card from the release point into its slot automatically.
        const container = containerRef.current;
        const cRect = container?.getBoundingClientRect();
        const eqX = cRect ? fromRect.left - cRect.left : 0;
        const eqY = cRect ? fromRect.top - cRect.top : 0;

        el.style.transition = "none";
        el.style.transform = `translate3d(${eqX}px, ${eqY}px, 0) scale(1.04)`;
        // structural styles (position/left/top/width/margin) are restored by
        // MasonryGrid's layout effect right after this commit — clearing them
        // here would fight React's style diff and drop the absolute position
        el.style.zIndex = "";
        el.style.pointerEvents = "";
        el.style.boxShadow = "";
        el.style.willChange = "transform";

        if (commit) {
          commitRef.current(finalOrder);
        } else {
          previewRef.current(initialOrder); // glide back to origin
        }

        // hand transition control back to the CSS class
        requestAnimationFrame(() => {
          el.style.transition = "";
          setTimeout(() => {
            el.style.willChange = "";
          }, 340);
        });
      }
      // (no cleanup needed when the drag never activated — no styles were set)

      s.dragEl = null;
      s.fromIndex = -1;
      s.order = [];
      s.initialOrder = [];
      s.rects = [];
    },
    []
  );

  const handlePointerDown = useCallback(
    (e: React.PointerEvent, id: string) => {
      if (!enabledRef.current) return;
      if (e.pointerType === "mouse" && e.button !== 0) return;
      const target = e.target as HTMLElement;
      // don't hijack interactions with the card's own controls
      if (target.closest("button, input, textarea, a, select")) return;
      // make sure the press landed on the card this handler belongs to
      const card = target.closest<HTMLElement>("[data-note-id]");
      if (!card || card.getAttribute("data-note-id") !== id) return;

      const s = st.current;
      s.pointerId = e.pointerId;
      s.startX = e.clientX;
      s.startY = e.clientY;
      s.lastX = e.clientX;
      s.lastY = e.clientY;
      s.cancelled = false;
      s.active = false;
      s.initialOrder = [...idsRef.current];
      s.order = [...idsRef.current];
      s.fromIndex = s.order.indexOf(id);

      if (s.timer) clearTimeout(s.timer);
      s.timer = setTimeout(() => {
        if (s.cancelled || s.pointerId !== e.pointerId || s.fromIndex < 0) return;
        const container = containerRef.current;
        const cardEl = container?.querySelector<HTMLElement>(`[data-note-id="${id}"]`);
        if (!cardEl || !container) return;

        // float the card's MASONRY WRAPPER (fixed inside a transformed
        // ancestor would be positioned relative to that ancestor)
        const dragEl = cardEl.closest<HTMLElement>("[data-masonry-item]") ?? cardEl;

        // measure all card slots at activation (viewport coords)
        s.rects = collectRects(container);
        s.scrollY0 = window.scrollY;
        s.dragEl = dragEl;
        s.active = true;

        const r = dragEl.getBoundingClientRect();
        // float the card: fixed position, glued to the pointer
        dragEl.style.position = "fixed";
        dragEl.style.left = `${r.left}px`;
        dragEl.style.top = `${r.top}px`;
        dragEl.style.width = `${r.width}px`;
        dragEl.style.margin = "0";
        dragEl.style.zIndex = "60";
        dragEl.style.pointerEvents = "none";
        dragEl.style.boxShadow = "0 18px 42px rgba(0,0,0,0.28)";
        dragEl.style.willChange = "transform";
        dragEl.style.transition = "none";
        dragEl.style.transform = "translate3d(0, 0, 0) scale(1.04)";

        vibrate();
        setDraggingId(id);
        document.body.classList.add("drag-reorder-active");

        // auto-scroll loop (edge drag on long lists)
        const autoScroll = () => {
          if (!s.active) return;
          if (s.scrollSpeed !== 0) window.scrollBy(0, s.scrollSpeed);
          s.raf = requestAnimationFrame(autoScroll);
        };
        s.raf = requestAnimationFrame(autoScroll);
      }, LONG_PRESS_MS);
    },
    [vibrate]
  );

  // global move / up listeners (drags continue outside the card bounds)
  useEffect(() => {
    if (!enabled) return;

    /** Where should the dragged card land? Returns an insertion index into
     * the preview order (excluding the dragged id). */
    const findTargetIndex = (px: number, py: number): number => {
      const s = st.current;
      const scrollDelta = window.scrollY - s.scrollY0;
      const others = s.order.filter((_, i) => i !== s.fromIndex);
      let bestIdx = -1;
      let bestDist = Infinity;
      for (let k = 0; k < others.length; k++) {
        const rect = s.rects.find((r) => r.id === others[k]);
        if (!rect) continue;
        const top = rect.top - scrollDelta;
        const bottom = rect.bottom - scrollDelta;
        // inside (with a little forgiveness) → direct hit
        if (px >= rect.left - 6 && px <= rect.right + 6 && py >= top - 6 && py <= bottom + 6) {
          return k;
        }
        const cy = top + (bottom - top) / 2;
        const d = Math.hypot(px - rect.cx, py - cy);
        if (d < bestDist) {
          bestDist = d;
          bestIdx = k;
        }
      }
      if (bestIdx < 0 || bestDist > 260) return -1;
      return bestIdx;
    };

    const onMove = (e: PointerEvent) => {
      const s = st.current;
      if (s.pointerId !== e.pointerId) return;
      s.lastX = e.clientX;
      s.lastY = e.clientY;

      if (!s.active) {
        if (Math.hypot(e.clientX - s.startX, e.clientY - s.startY) > CANCEL_PX) {
          s.cancelled = true;
          if (s.timer) clearTimeout(s.timer);
        }
        return;
      }

      e.preventDefault(); // block scrolling while dragging

      const el = s.dragEl;
      if (!el) return;
      const dx = e.clientX - s.startX;
      const dy = e.clientY - s.startY;
      el.style.transform = `translate3d(${dx}px, ${dy}px, 0) scale(1.04)`;

      // edge auto-scroll speed
      const vh = window.innerHeight;
      if (e.clientY < EDGE_ZONE) {
        s.scrollSpeed = -Math.round(Math.min(MAX_SPEED, ((EDGE_ZONE - e.clientY) / EDGE_ZONE) * MAX_SPEED) + 3);
      } else if (e.clientY > vh - EDGE_ZONE) {
        s.scrollSpeed = Math.round(Math.min(MAX_SPEED, ((e.clientY - (vh - EDGE_ZONE)) / EDGE_ZONE) * MAX_SPEED) + 3);
      } else {
        s.scrollSpeed = 0;
      }

      // live reorder preview
      const target = findTargetIndex(e.clientX, e.clientY);
      if (target >= 0) {
        const others = s.order.filter((_, i) => i !== s.fromIndex);
        const rect = s.rects.find((r) => r.id === others[target]);
        const scrollDelta = window.scrollY - s.scrollY0;
        // past the card's vertical midpoint → insert after it, else before
        const after = rect ? e.clientY > rect.top - scrollDelta + (rect.bottom - rect.top) / 2 : false;
        const insertAt = after ? target + 1 : target;
        if (insertAt !== s.fromIndex) {
          const ids = [...s.order];
          const [moved] = ids.splice(s.fromIndex, 1);
          ids.splice(insertAt, 0, moved);
          s.order = ids;
          s.fromIndex = insertAt;
          previewRef.current(ids);
        }
      }
    };

    const onUp = (e: PointerEvent) => {
      const s = st.current;
      if (s.pointerId !== e.pointerId) return;
      finishDrag(s.active);
    };

    const onTouchMove = (e: TouchEvent) => {
      // pointermove preventDefault alone doesn't stop touch scrolling
      if (st.current.active) e.preventDefault();
    };

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && st.current.active) finishDrag(false);
    };

    window.addEventListener("pointermove", onMove, { passive: false });
    window.addEventListener("pointerup", onUp);
    window.addEventListener("pointercancel", onUp);
    document.addEventListener("touchmove", onTouchMove, { passive: false });
    window.addEventListener("keydown", onKeyDown);
    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onUp);
      document.removeEventListener("touchmove", onTouchMove);
      window.removeEventListener("keydown", onKeyDown);
      const s = st.current;
      if (s.timer) clearTimeout(s.timer);
    };
  }, [enabled, finishDrag]);

  return { containerRef, draggingId, handlePointerDown };
}
