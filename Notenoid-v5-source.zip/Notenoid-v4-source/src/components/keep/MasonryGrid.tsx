"use client";

import * as React from "react";

/**
 * V5 — JavaScript masonry ("Pinterest" layout).
 *
 * Why not CSS columns: the old grid used CSS multi-columns which (a) renders
 * ONE column on phone widths, (b) orders items down each column instead of
 * across the row, and (c) breaks drag & drop reordering.
 *
 * This component measures every card with a ResizeObserver, assigns each new
 * card to the currently SHORTEST column (minimal empty gaps), and positions
 * cards imperatively with translate3d + a GPU transition class, so any
 * reorder or resize glides smoothly at high refresh rates. Columns respond to
 * the container width (2 on phones, more on larger screens) and every card
 * keeps its natural height — never equalized, never overlapping.
 *
 * Positioning is IMPERATIVE (direct style writes, never React style props)
 * so the long-press drag hook can take over the dragged card's transform
 * without React clobbering it mid-gesture.
 */

export interface MasonryLayout {
  cols: number;
  colWidth: number;
  height: number;
  positions: Map<string, { x: number; y: number }>;
}

export interface MasonryGridProps {
  /** Ordered item ids — DOM order follows this exactly. */
  itemIds: string[];
  /** Render the card for an id. */
  renderItem: (id: string, index: number) => React.ReactNode;
  /** Horizontal + vertical gap in px. */
  gap: number;
  /** Minimum column width before another column is added. */
  minColWidth?: number;
  /** Column cap on very wide screens. */
  maxCols?: number;
  /** The currently dragged id — its transform is owned by the drag hook. */
  draggingId?: string | null;
  /** External ref to the container (drag & drop needs it). */
  outerRef?: React.RefObject<HTMLDivElement | null>;
  className?: string;
}

export const MASONRY_EASE = "cubic-bezier(0.22, 1, 0.36, 1)";

export function MasonryGrid({
  itemIds,
  renderItem,
  gap,
  minColWidth = 220,
  maxCols = 4,
  draggingId = null,
  outerRef,
  className,
}: MasonryGridProps) {
  const innerRef = React.useRef<HTMLDivElement | null>(null);
  const containerRef = React.useRef<HTMLDivElement | null>(null);
  const setContainerRef = React.useCallback((el: HTMLDivElement | null) => {
    innerRef.current = el;
    if (outerRef) outerRef.current = el;
  }, [outerRef]);
  const itemsRef = React.useRef<Map<string, { el: HTMLElement; h: number }>>(new Map());
  const roRef = React.useRef<ResizeObserver | null>(null);
  const rafRef = React.useRef(0);
  const measuredRef = React.useRef<Set<string>>(new Set());
  const draggingRef = React.useRef(draggingId);
  draggingRef.current = draggingId;

  const [layout, setLayout] = React.useState<MasonryLayout | null>(null);
  const layoutRef = React.useRef<MasonryLayout | null>(null);
  const itemIdsRef = React.useRef(itemIds);
  itemIdsRef.current = itemIds;

  const computeLayout = React.useCallback(() => {
    const el = innerRef.current;
    if (!el) return;
    const width = el.clientWidth;
    if (width <= 0) return;
    const cols = Math.max(2, Math.min(maxCols, Math.floor((width + gap) / (minColWidth + gap)) || 2));
    const colWidth = Math.floor((width - gap * (cols - 1)) / cols);
    const colHeights = new Array<number>(cols).fill(0);
    const positions = new Map<string, { x: number; y: number }>();
    const ids = itemIdsRef.current;
    for (const id of ids) {
      const item = itemsRef.current.get(id);
      const h = item?.h ?? 0;
      let col = 0;
      for (let c = 1; c < cols; c++) {
        if (colHeights[c] < colHeights[col] - 0.5) col = c;
      }
      positions.set(id, { x: col * (colWidth + gap), y: colHeights[col] });
      colHeights[col] += h + gap;
    }
    const height = ids.length > 0 ? Math.max(...colHeights) - gap : 0;
    setLayout((prev) => {
      if (
        prev &&
        prev.cols === cols &&
        prev.colWidth === colWidth &&
        Math.abs(prev.height - height) < 0.5 &&
        prev.positions.size === positions.size &&
        ids.every((id) => {
          const a = prev.positions.get(id);
          const b = positions.get(id);
          return a && b && Math.abs(a.x - b.x) < 0.5 && Math.abs(a.y - b.y) < 0.5;
        })
      ) {
        return prev; // avoid pointless re-renders (keeps 144Hz feel)
      }
      return { cols, colWidth, height, positions };
    });
  }, [gap, minColWidth, maxCols]);

  const scheduleLayout = React.useCallback(() => {
    cancelAnimationFrame(rafRef.current);
    rafRef.current = requestAnimationFrame(computeLayout);
  }, [computeLayout]);

  // container width changes → recompute columns
  React.useEffect(() => {
    const el = innerRef.current;
    if (!el) return;
    const ro = new ResizeObserver(scheduleLayout);
    ro.observe(el);
    roRef.current = ro;
    scheduleLayout();
    return () => {
      ro.disconnect();
      roRef.current = null;
      cancelAnimationFrame(rafRef.current);
    };
  }, [scheduleLayout]);

  // order / layout changed → apply positions (imperative write)
  React.useLayoutEffect(() => {
    layoutRef.current = layout;
    if (!layout) return;
    for (const [id, pos] of layout.positions) {
      const entry = itemsRef.current.get(id);
      if (!entry) continue;
      const el = entry.el;
      // re-assert structural styles (the drag hook temporarily rewrites them;
      // React's style diff would NOT re-apply unchanged values on its own)
      el.style.position = "absolute";
      el.style.top = "0px";
      el.style.left = "0px";
      el.style.width = `${layout.colWidth}px`;
      el.style.margin = "0px";
      if (id === draggingRef.current) continue; // drag hook owns the transform
      el.style.transition = ""; // restore the CSS class transition
      el.style.transform = `translate3d(${pos.x}px, ${pos.y}px, 0)`;
      el.style.opacity = measuredRef.current.has(id) ? "1" : "0";
    }
  }, [layout]);

  // order changed → relayout (cards FLIP to their new spots)
  React.useEffect(() => {
    scheduleLayout();
  }, [itemIds, scheduleLayout]);

  // when a drag ends the hook hands the transform back — write the slot pos
  React.useLayoutEffect(() => {
    if (draggingId != null) return;
    const lay = layoutRef.current;
    if (!lay) return;
    for (const [id, pos] of lay.positions) {
      const entry = itemsRef.current.get(id);
      if (!entry) continue;
      const el = entry.el;
      // structural styles first (the hook had rewritten them for floating)
      el.style.position = "absolute";
      el.style.top = "0px";
      el.style.left = "0px";
      el.style.width = `${lay.colWidth}px`;
      el.style.margin = "0px";
      if (el.style.position === "fixed") continue; // not released yet
      el.style.transition = "";
      el.style.transform = `translate3d(${pos.x}px, ${pos.y}px, 0)`;
    }
  }, [draggingId]);

  /** stable per-id ref callbacks (a fresh closure per render would make React
   * detach/reattach every card on every render) */
  const refCache = React.useRef<Map<string, (el: HTMLElement | null) => void>>(new Map());
  const itemRef = React.useCallback(
    (id: string) => {
      const cache = refCache.current;
      let cb = cache.get(id);
      if (!cb) {
        cb = (el: HTMLElement | null) => {
          const map = itemsRef.current;
          if (!el) {
            map.delete(id);
            measuredRef.current.delete(id);
            return;
          }
          map.set(id, { el, h: el.getBoundingClientRect().height });
          if (roRef.current) roRef.current.observe(el);
          // measure now + after fonts/images settle
          const measure = () => {
            const entry = itemsRef.current.get(id);
            if (!entry) return;
            const h = entry.el.getBoundingClientRect().height;
            if (Math.abs(h - entry.h) > 0.5) {
              entry.h = h;
              measuredRef.current.add(id);
              scheduleLayout();
            } else if (!measuredRef.current.has(id)) {
              measuredRef.current.add(id);
              scheduleLayout();
            }
          };
          requestAnimationFrame(measure);
          setTimeout(measure, 80);
          setTimeout(measure, 260);
        };
        cache.set(id, cb);
      }
      return cb;
    },
    [scheduleLayout]
  );

  return (
    <div
      ref={setContainerRef}
      className={className}
      style={{
        position: "relative",
        height: layout ? Math.max(0, layout.height) : undefined,
        minHeight: 80,
      }}
    >
      {itemIds.map((id, index) => {
        return (
          <div
            key={id}
            ref={itemRef(id)}
            data-masonry-item={id}
            className="masonry-item"
            style={{
              position: "absolute",
              top: 0,
              left: 0,
              width: layout ? layout.colWidth : "100%",
            }}
          >
            {renderItem(id, index)}
          </div>
        );
      })}
    </div>
  );
}
