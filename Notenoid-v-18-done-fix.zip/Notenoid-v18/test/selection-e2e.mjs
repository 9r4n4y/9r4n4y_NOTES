import { chromium } from '@playwright/test';
import assert from 'node:assert/strict';
const b=await chromium.launch({headless:true});
const errors=[];
for (const mobile of [false,true]) {
 const p=await b.newPage({viewport:mobile?{width:393,height:851}:{width:1280,height:900},isMobile:mobile,hasTouch:mobile});
 p.on('pageerror',e=>errors.push(e.message));
 await p.goto(process.env.TEST_URL || 'http://localhost:3000');
 await p.getByText('Use in-app local storage').click();
 await p.getByLabel('Seed password',{exact:true}).fill('amber lantern meadow orbit copper river');
 await p.getByLabel('Confirm seed password',{exact:true}).fill('amber lantern meadow orbit copper river');
 await p.getByRole('checkbox').check();
 await p.getByRole('button',{name:'Encrypt local storage',exact:true}).click();
 await p.getByText('New note — tap to write').click();
 await p.getByRole('button',{name:'Edit Markdown',exact:true}).click();
 const text='repeat FIRST repeat\n\n'+Array.from({length:65},(_,i)=>`Paragraph ${i}: repeat **repeat** and [repeat](https://repeat.test).\nSecond line repeat with हिन्दी शब्द.`).join('\n\n')+'\n\n`repeat repeat`\n\n```repeat\nrepeat repeat\n```\n\n- [ ] repeat repeat\n\n| Column | Other |\n| --- | --- |\n| repeat | repeat |\n\nrepeat LAST repeat';
 const ta=p.locator('textarea.md-textarea'); await ta.fill(text);
 const chooseEdit=async offset=>{
   await p.getByRole('button',{name:'Preview rendered note',exact:true}).dblclick();
   await ta.evaluate((el,at)=>{el.setSelectionRange(at,at);el.dispatchEvent(new MouseEvent('click',{bubbles:true}));},offset);
   await p.waitForTimeout(150);
   assert(await p.locator('[data-selection-overlay]').count()>0,'edit pending highlight');
   await p.locator('.md-editor').getByRole('button',{name:'Done',exact:true}).click();
 };
 const centered=async()=>{
   await p.waitForTimeout(950);
   const result=await p.locator('[data-selection-overlay]').first().evaluate(el=>{
     const r=el.getBoundingClientRect(), c=el.parentElement.getBoundingClientRect();
     return {error:Math.abs(r.top+r.height/2-(c.top+c.bottom)/2),top:r.top,bottom:r.bottom};
   });
   assert(result.error<8,`center error ${JSON.stringify(result)}`);
   assert(await p.locator('.exact-word-pulse').count()>0,'pulse running');
 };
 for(const offset of [0,text.lastIndexOf('repeat'),text.indexOf('**repeat**')+2,text.indexOf('Second line repeat')+12,text.indexOf('`repeat repeat`')+8,text.indexOf('```repeat\n')+17,text.indexOf('- [ ] repeat repeat')+13,text.indexOf('| repeat | repeat |')+11,text.indexOf('हिन्दी'),text.indexOf('[repeat]')+1]) {
   await chooseEdit(offset); await centered();
   assert.equal(Number(await p.locator('[data-selection-overlay]').first().getAttribute('data-source-start')),offset,'exact preview occurrence');
   const selected=await p.locator('.md-preview').evaluate((root,at)=>{
     for(const s of root.querySelectorAll('[data-exact-map]')){
       const map=JSON.parse(s.dataset.exactMap), index=map.findIndex(([a])=>a===at);
       if(index<0)continue;
       const r=document.createRange(); r.setStart(s.firstChild,index); r.setEnd(s.firstChild,index+1);
       const b=r.getBoundingClientRect(); return {x:b.left+b.width/2,y:b.top+b.height/2};
     }
   },offset);
   assert(selected,'exact source span exists');
   await p.getByRole('button',{name:'Edit Markdown',exact:true}).dblclick();
   // Toolbar/banner changes the geometry, so recompute after entering selection.
   const point=await p.locator('.md-preview').evaluate((root,at)=>{
     for(const s of root.querySelectorAll('[data-exact-map]')){
       const map=JSON.parse(s.dataset.exactMap), i=map.findIndex(([a])=>a===at); if(i<0)continue;
       s.scrollIntoView({block:'center'});
       const r=document.createRange();r.setStart(s.firstChild,i);r.setEnd(s.firstChild,i+1);const b=r.getBoundingClientRect();return{x:b.left+b.width/2,y:b.top+b.height/2};
     }
   },offset);
   if(mobile)await p.touchscreen.tap(point.x,point.y);else await p.mouse.click(point.x,point.y);
   await p.waitForTimeout(150);
   assert(await p.locator('[data-selection-overlay]').count()>0,'preview pending highlight');
   await p.locator('.md-editor').getByRole('button',{name:'Done',exact:true}).click();
   await centered();
   assert.equal(Number(await p.locator('[data-selection-overlay]').first().getAttribute('data-source-start')),offset,'exact edit occurrence');
   await p.waitForTimeout(2250);
   assert.equal(await p.locator('.exact-word-pulse').count(),0,'three-second pulse ends');
   assert.equal(await ta.inputValue(),text,'source not changed');
   console.log(`${mobile?'touch':'desktop'} source offset ${offset}: both directions, highlight, centering, timer, source preservation PASS`);
 }
 await p.close();
}
assert.deepEqual(errors,[],'no runtime errors');
await b.close();
