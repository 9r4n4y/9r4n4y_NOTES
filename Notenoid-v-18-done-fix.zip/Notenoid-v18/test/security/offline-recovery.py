"""Run after npx tsx test/security/run.ts creates the independent fixture."""
import os, subprocess, shutil
from pathlib import Path
root = Path(__file__).resolve().parents[2]
workspace = root/'test/.generated'
env = {**os.environ, 'TEST_SEED': 'amber lantern meadow orbit copper river', 'TEST_VAULT': 'ResetVaultPassword!2026'}
for name in ['offline-regular', 'offline-all', 'offline-wrong']:
    shutil.rmtree(workspace/name, ignore_errors=True)
base = ['python', str(root/'scripts/recover.py'), str(workspace/'recovery-fixture')]
subprocess.run(base+[str(workspace/'offline-regular'), '--seed-env', 'TEST_SEED'], env=env, check=True)
subprocess.run(base+[str(workspace/'offline-all'), '--seed-env', 'TEST_SEED', '--include-vault', '--vault-env', 'TEST_VAULT'], env=env, check=True)
assert 'UNIQUE_PLAINTEXT_SENTINEL_9247' in (workspace/'offline-all/Private title/node.md').read_text()
assert 'VAULT_BODY_SENTINEL' in (workspace/'offline-all/VAULT_TITLE_SENTINEL/node.md').read_text()
assert (workspace/'offline-all/VAULT_TITLE_SENTINEL/attachment/vault.bin').read_bytes() == bytes([27, 0, 99, 255])
assert not (workspace/'offline-regular/VAULT_TITLE_SENTINEL/node.md').exists()
wrong = subprocess.run(base+[str(workspace/'offline-wrong'), '--seed-env', 'TEST_SEED'], env={**env, 'TEST_SEED': 'wrong'}, capture_output=True)
assert wrong.returncode == 1 and not (workspace/'offline-wrong').exists()
print('PASS independent Python recovery: exact ordinary/vault contents and binary attachments; seed alone does not unlock vault; wrong seed writes no output.')
