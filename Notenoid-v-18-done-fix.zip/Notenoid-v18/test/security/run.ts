import "fake-indexeddb/auto";
import assert from "node:assert/strict";
import { mkdir, writeFile, rm } from "node:fs/promises";
import { pbkdf2Sync } from "node:crypto";
import { MemoryFS } from "./memory-fs";
import { EncryptedFS } from "../../src/core/security/encrypted-fs";
import { NoteRepository } from "../../src/core/repo";
import { noteToMarkdown } from "../../src/core/markdown";
import {
  setupVaultPassword,
  verifyVaultPassword,
  changeVaultPassword,
  resetVaultPassword,
  setSecurityQuestions,
  verifySecurityAnswers,
  lockVault,
  getVaultKey,
  readVaultRecord,
  seedRecovery,
  VAULT_RECORD_KEY,
} from "../../src/lib/vault";
import {
  securePreferences,
  flushPreferences,
} from "../../src/core/security/preferences";
import {
  readableBackup,
  encryptedBackup,
  importReadableBackup,
  inspectReadableBackup,
} from "../../src/core/security/backup";
import JSZip from "jszip";
const seed = "amber lantern meadow orbit copper river";
const password = "SeparateVaultPassword!2026";
const questions: [
  { id: string; answer: string },
  { id: string; answer: string },
] = [
  { id: "first_school", answer: "not a real school; twenty random planets" },
  { id: "first_pet", answer: "galactic whales sing midnight sonnets" },
];
let tests = 0;
function pass(s: string) {
  tests++;
  console.log("PASS", s);
}
async function fresh() {
  const raw = new MemoryFS(),
    fs = new EncryptedFS(raw);
  await fs.initialize(seed, {});
  return { raw, fs, repo: new NoteRepository(fs) };
}
async function denied(fn: () => Promise<unknown>, s: string) {
  await assert.rejects(fn);
  pass(s);
}
async function fixture(raw: MemoryFS) {
  await raw.makeDir("Private title/attachment");
  await raw.writeText(
    "Private title/node.md",
    "---\nid: first-note\ntitle: Private title\nvaulted: false\n---\nUNIQUE_PLAINTEXT_SENTINEL_9247",
  );
  await raw.writeBinary(
    "Private title/attachment/private-name.png",
    new Uint8Array([0, 1, 2, 255, 17, 43]),
  );
  await raw.makeDir(".notes");
  await raw.writeText(
    ".notes/config.json",
    JSON.stringify({
      folders: [{ name: "Secret folder", emoji: "📁", color: "default" }],
      labels: ["Private label"],
    }),
  );
}
async function main() {
  const raw = new MemoryFS();
  await fixture(raw);
  const fs = new EncryptedFS(raw);
  assert.equal(await fs.prepare(), false);
  await fs.initialize(seed, {
    "notes-app-settings-v1": JSON.stringify({ appName: "Secret app name" }),
  });
  const repo = new NoteRepository(fs);
  assert.equal(
    (await repo.scan()).notes[0].content.trim(),
    "UNIQUE_PLAINTEXT_SENTINEL_9247",
  );
  assert.deepEqual(
    await fs.readBinary("Private title/attachment/private-name.png"),
    new Uint8Array([0, 1, 2, 255, 17, 43]),
  );
  assert.equal(await raw.exists("Private title"), false);
  assert.equal(await raw.exists(".notes"), false);
  pass("verified plaintext migration and attachment bytes");
  const disk = [...raw.files]
    .map(([p, v]) => p + new TextDecoder().decode(v))
    .join("");
  for (const secret of [
    "UNIQUE_PLAINTEXT_SENTINEL_9247",
    "Private title",
    "private-name.png",
    "Secret folder",
    "Private label",
    "Secret app name",
    seed,
  ])
    assert(!disk.includes(secret));
  pass(
    "raw container reveals no fixture note content, filenames, preferences, or seed",
  );
  securePreferences.setItem("custom", "encrypted setting");
  await flushPreferences();
  await fs.close();
  const auto = new EncryptedFS(raw);
  assert.equal(await auto.prepare(), true);
  assert.equal(securePreferences.getItem("custom"), "encrypted setting");
  pass(
    "remembered non-extractable device key auto-unlocks and preserves preferences",
  );
  await auto.close();
  await new Promise<void>((resolve, reject) => {
    const r = indexedDB.deleteDatabase("notenoid-device-keys");
    r.onsuccess = () => resolve();
    r.onerror = () => reject(r.error);
  });
  const restored = new EncryptedFS(raw);
  assert.equal(await restored.prepare(), false);
  assert.equal(restored.state, "recover");
  await denied(
    () => restored.recover("wrong password"),
    "wrong seed fails without changing files",
  );
  await restored.recover(seed);
  assert.equal((await new NoteRepository(restored).scan()).notes.length, 1);
  pass("app-reset folder recovery with seed only");
  await setupVaultPassword(password, questions);
  const r = new NoteRepository(restored);
  const note = await r.createNote({
    title: "VAULT_TITLE_SENTINEL",
    content: "VAULT_BODY_SENTINEL",
    vaulted: true,
    media: [
      { name: "vault.bin", blob: new Blob([new Uint8Array([27, 0, 99, 255])]) },
    ],
  });
  lockVault();
  await denied(
    () => restored.readText(note.dir + "/node.md"),
    "vault note blocks storage-key-only reads",
  );
  await denied(
    () => restored.readBinary(note.dir + "/attachment/vault.bin"),
    "vault attachment blocks storage-key-only reads",
  );
  assert(
    (await r.scan()).notes.some(
      (n) => n.vaulted && n.title === "Locked vault note",
    ),
  );
  pass("locked vault appears as locked placeholder, not plaintext");
  assert.equal(await verifyVaultPassword("wrong"), false);
  assert.equal(await verifyVaultPassword(password), true);
  assert(
    (await restored.readText(note.dir + "/node.md")).includes(
      "VAULT_BODY_SENTINEL",
    ),
  );
  pass("correct separate vault password decrypts notes");
  assert.equal(
    await changeVaultPassword("wrong", "NewVaultPassword!2026"),
    false,
  );
  assert.equal(
    await changeVaultPassword(password, "NewVaultPassword!2026"),
    true,
  );
  lockVault();
  assert.equal(await verifyVaultPassword(password), false);
  assert.equal(await verifyVaultPassword("NewVaultPassword!2026"), true);
  assert(
    (await restored.readText(note.dir + "/node.md")).includes(
      "VAULT_BODY_SENTINEL",
    ),
  );
  pass("password change rewraps same vault key; old password fails");
  assert.equal(
    await resetVaultPassword(
      [{ id: "first_school", answer: "wrong" }],
      "ResetVaultPassword!2026",
    ),
    false,
  );
  assert.equal(
    await resetVaultPassword([questions[0]], "ResetVaultPassword!2026"),
    true,
  );
  assert.equal(await verifyVaultPassword("ResetVaultPassword!2026"), true);
  pass("either-answer recovery preserves encrypted data; wrong answer denied");
  const newQuestions: [
    { id: string; answer: string },
    { id: string; answer: string },
  ] = [
    { id: "first_school", answer: "replacement random answer one" },
    { id: "first_pet", answer: "replacement random answer two" },
  ];
  assert.equal(
    await setSecurityQuestions(
      "ResetVaultPassword!2026",
      [{ id: "first_school", answer: "wrong" }],
      newQuestions,
    ),
    false,
  );
  assert.equal(
    await setSecurityQuestions(
      "ResetVaultPassword!2026",
      [questions[1]],
      newQuestions,
    ),
    true,
  );
  assert.equal(await verifySecurityAnswers(questions), false);
  assert.equal(await verifySecurityAnswers([newQuestions[1]]), true);
  pass(
    "security-question change requires current credentials and retires old answers",
  );
  await denied(
    () => readableBackup(r, { vaultPassword: "incorrect" }),
    "export fails rather than omitting vault notes",
  );
  const backup = await readableBackup(r, {
    vaultPassword: "ResetVaultPassword!2026",
  });
  const z = await JSZip.loadAsync(backup.bytes);
  assert(Object.keys(z.files).some((p) => p.startsWith("_vault/")));
  assert(
    (
      await z.file("_vault/VAULT_TITLE_SENTINEL/node.md")!.async("string")
    ).includes("VAULT_BODY_SENTINEL"),
  );
  assert.deepEqual(
    await z
      .file("_vault/VAULT_TITLE_SENTINEL/attachment/vault.bin")!
      .async("uint8array"),
    new Uint8Array([27, 0, 99, 255]),
  );
  assert.equal((await inspectReadableBackup(backup.bytes)).vault, true);
  assert.equal(backup.vaultNotes, 1);
  assert(backup.attachments >= 1);
  assert.equal(z.file("vault-record.json"), null);
  const withoutVault = await readableBackup(r, { includeVault: false });
  assert.equal(withoutVault.vaultNotes, 0);
  assert.equal((await inspectReadableBackup(withoutVault.bytes)).vault, false);
  pass("password-free readable ZIP reports counts and never exports vault credentials; vault inclusion is optional");
  const encrypted = await encryptedBackup(r);
  assert(!new TextDecoder().decode(encrypted).includes("VAULT_BODY_SENTINEL"));
  pass("encrypted disaster-recovery backup retains encrypted container");
  // Save a fixture for the independent Python utility (never packaged as user data).
  const fixtureDir = (await import("node:path")).resolve(
    process.cwd(),
    "test/.generated/recovery-fixture",
  );
  await rm(fixtureDir, { recursive: true, force: true });
  for (const [p, v] of raw.files) {
    await mkdir(fixtureDir + "/" + p.slice(0, p.lastIndexOf("/")), {
      recursive: true,
    });
    await writeFile(fixtureDir + "/" + p, v);
  }
  const savedRecord = JSON.stringify(readVaultRecord());
  await restored.close();
  const recovered = new EncryptedFS(raw);
  assert.equal(await recovered.prepare(), true);
  assert.equal(getVaultKey(), null);
  assert.equal(JSON.stringify(readVaultRecord()), savedRecord);
  assert.equal(await verifyVaultPassword("ResetVaultPassword!2026"), true);
  assert.equal(await verifySecurityAnswers([newQuestions[0]]), true);
  pass(
    "folder reopen restores original vault password/questions without setup",
  );
  await recovered.close();
  const target = await fresh();
  await denied(
    () => importReadableBackup(target.repo, backup.bytes, { vaultPassword: "bad" }),
    "wrong destination vault password imports nothing",
  );
  assert.equal((await target.repo.scan()).notes.length, 0);
  await setupVaultPassword("IndependentDestination!2026", questions);
  await importReadableBackup(target.repo, backup.bytes, { vaultPassword: "IndependentDestination!2026" });
  assert.equal((await target.repo.scan()).notes.length, 2);
  assert.equal(await verifySecurityAnswers([questions[1]]), true);
  assert.equal(await verifySecurityAnswers([newQuestions[1]]), false);
  assert.equal(await verifyVaultPassword("IndependentDestination!2026"), true);
  assert.equal(await verifyVaultPassword("ResetVaultPassword!2026"), false);
  assert.deepEqual(
    await target.fs.readBinary("VAULT_TITLE_SENTINEL/attachment/vault.bin"),
    new Uint8Array([27, 0, 99, 255]),
  );
  pass("vault import requires a destination vault and never changes its password or security questions");
  await target.fs.close();
  const target2 = await fresh();
  await setupVaultPassword("DestinationPassword!2026", questions);
  await denied(
    () => importReadableBackup(target2.repo, backup.bytes, { vaultPassword: "ResetVaultPassword!2026" }),
    "source credentials cannot unlock a different destination vault",
  );
  await importReadableBackup(target2.repo, backup.bytes, { vaultPassword: "DestinationPassword!2026" });
  assert.equal(await verifyVaultPassword("DestinationPassword!2026"), true);
  assert.equal(await verifyVaultPassword("ResetVaultPassword!2026"), false);
  pass("import into an existing vault leaves destination credentials unchanged");
  const regular = (await target2.repo.scan()).notes.find((n) => !n.vaulted)!;
  await target2.repo.saveNote({ ...regular, title: "Renamed", archived: true });
  assert((await target2.repo.scan()).notes.some((n) => n.title === "Renamed"));
  const dup = await target2.repo.duplicateNote(
    (await target2.repo.scan()).notes.find((n) => !n.vaulted)!,
  );
  await target2.repo.deleteNoteDir(dup.dir);
  pass("encrypted repository rename/archive/duplicate/delete");
  await target2.fs.writeText("Concurrent/a.txt", "a");
  await Promise.all(
    Array.from({ length: 12 }, (_, i) =>
      target2.fs.writeText(`Concurrent/${i}.txt`, String(i)),
    ),
  );
  assert.equal((await target2.fs.listDir("Concurrent")).length, 13);
  await denied(
    () => target2.fs.writeText("../escape", "bad"),
    "path traversal rejected",
  );
  pass("serialized concurrent saves preserve all files");
  await target2.fs.close();
  // Migrate password/answer verifiers while preserving existing credentials.
  const legacy = new MemoryFS();
  await fixture(legacy);
  await legacy.makeDir("Old vault");
  await legacy.writeText(
    "Old vault/node.md",
    "---\nid: old-vault\ntitle: Old vault\nvaulted: true\n---\nLEGACY_VAULT_SECRET",
  );
  const salt = "11".repeat(16);
  const hash = (s: string) =>
    pbkdf2Sync(s, Buffer.from(salt, "hex"), 150000, 32, "sha256").toString(
      "hex",
    );
  const rec = {
    v: 2,
    salt,
    passwordHash: hash(password),
    iterations: 150000,
    questions: questions.map((q) => ({
      id: q.id,
      salt,
      answerHash: hash(q.answer),
    })),
  };
  const legacyFS = new EncryptedFS(legacy);
  await legacyFS.initialize(seed, { [VAULT_RECORD_KEY]: JSON.stringify(rec) });
  assert.equal(await verifyVaultPassword(password), true);
  assert.equal(await verifySecurityAnswers([questions[0]]), true);
  assert(
    (await legacyFS.readText("Old vault/node.md")).includes(
      "LEGACY_VAULT_SECRET",
    ),
  );
  assert(!JSON.stringify(readVaultRecord()).includes(rec.passwordHash));
  pass(
    "automatic verifier-to-wrapped-key migration preserves existing vault credentials",
  );
  await legacyFS.close();
  const interrupted = new MemoryFS();
  await fixture(interrupted);
  let stop = true;
  interrupted.fail = (op, p) => {
    if (op === "remove" && p === "Private title" && stop) {
      stop = false;
      throw Error("simulated interruption");
    }
  };
  const interruptedFS = new EncryptedFS(interrupted);
  await denied(
    () => interruptedFS.initialize(seed, {}),
    "migration interruption reported",
  );
  interrupted.fail = null;
  const resume = new EncryptedFS(interrupted);
  await resume.prepare();
  await resume.recover(seed);
  assert.equal(await interrupted.exists("Private title"), false);
  assert(
    (await resume.readText("Private title/node.md")).includes(
      "UNIQUE_PLAINTEXT",
    ),
  );
  pass(
    "interrupted plaintext cleanup resumes using authenticated encrypted checkpoint",
  );
  await resume.close();
  const fault = await fresh();
  await fault.fs.writeText("Durable/file", "original");
  fault.raw.fail = (op, p) => {
    if (op === "write" && p.includes("/index-")) throw Error("disk full");
  };
  await denied(
    () => fault.fs.writeText("Durable/file", "unsaved"),
    "failed index commit reported",
  );
  fault.raw.fail = null;
  const reopened = new EncryptedFS(fault.raw);
  assert(await reopened.prepare());
  assert.equal(await reopened.readText("Durable/file"), "original");
  pass("failed commit retains prior committed data");
  await reopened.close();
  const corrupt = await fresh();
  await corrupt.fs.writeText("Secret/file", "secret");
  await corrupt.fs.close();
  const latest = [...corrupt.raw.files.keys()]
    .filter((p) => p.includes("/index-"))
    .sort()
    .at(-1)!;
  corrupt.raw.files.get(latest)![20] ^= 1;
  await denied(
    () => new EncryptedFS(corrupt.raw).prepare(),
    "tampered index fails closed; no silent rollback",
  );
  const headerFault = await fresh();
  await headerFault.fs.writeText("Metadata/file", "kept");
  await headerFault.fs.close();
  const h = JSON.parse(
    await headerFault.raw.readText("notenoid.encrypted/key.json"),
  );
  h.wrappedKey = h.wrappedKey.slice(0, -4) + "AAAA";
  await headerFault.raw.writeText(
    "notenoid.encrypted/key.json",
    JSON.stringify(h),
  );
  await denied(
    () => new EncryptedFS(headerFault.raw).prepare(),
    "remembered-key auto-unlock authenticates recovery header",
  );
  const tampered = await fresh();
  await tampered.fs.writeText("Document/file", "original");
  const backupFiles = await tampered.fs.encryptedBackup();
  const objectName = Object.keys(backupFiles).find((n) =>
    n.startsWith("objects/"),
  )!;
  tampered.raw.files.get("notenoid.encrypted/" + objectName)![15] ^= 1;
  await denied(
    () => tampered.fs.readText("Document/file"),
    "tampered object authentication rejects modified content",
  );
  await tampered.fs.close();
  const move = await fresh();
  await setupVaultPassword(password, questions);
  const moving = await move.repo.createNote({
    title: "Transfer",
    content: "secret move",
    media: [{ name: "image.bin", blob: new Blob([new Uint8Array([1, 2, 3])]) }],
  });
  await move.repo.saveNote({ ...moving, vaulted: true });
  lockVault();
  await denied(
    () => move.fs.readText(moving.dir + "/node.md"),
    "moving ordinary note into vault adds independent encryption",
  );
  await verifyVaultPassword(password);
  await move.repo.saveNote({ ...moving, vaulted: false });
  lockVault();
  assert(
    (await move.fs.readText(moving.dir + "/node.md")).includes("secret move"),
  );
  assert.deepEqual(
    await move.fs.readBinary(moving.dir + "/attachment/image.bin"),
    new Uint8Array([1, 2, 3]),
  );
  pass(
    "moving out of vault preserves note and media under outer storage encryption",
  );
  await move.fs.makeDir("__proto__");
  await move.fs.writeText("__proto__/file", "safe");
  assert.equal(await move.fs.readText("__proto__/file"), "safe");
  pass("reserved-looking titles do not mutate index prototypes");
  await move.fs.close();
  const unrelated = new MemoryFS();
  await unrelated.makeDir("notenoid.encrypted");
  await unrelated.writeText(
    "notenoid.encrypted/important.txt",
    "unrelated user data",
  );
  await denied(
    () => new EncryptedFS(unrelated).initialize(seed, {}),
    "unrecognized same-named folder is not overwritten",
  );
  assert.equal(
    await unrelated.readText("notenoid.encrypted/important.txt"),
    "unrelated user data",
  );
  const fork = await fresh();
  await fork.fs.writeText("File/x", "x");
  await fork.fs.close();
  const last = [...fork.raw.files.keys()]
    .filter((p) => p.includes("/index-"))
    .sort()
    .at(-1)!;
  const other = last.replace(
    /[a-f0-9]{32}\.bin$/,
    "00000000000000000000000000000000.bin",
  );
  await fork.raw.writeBinary(other, await fork.raw.readBinary(last));
  await denied(
    () => new EncryptedFS(fork.raw).prepare(),
    "forked checkpoints fail closed rather than selecting one silently",
  );
  const direct = new MemoryFS();
  for (const [p, v] of raw.files)
    if (p.startsWith("notenoid.encrypted/")) {
      const relative = p.slice("notenoid.encrypted/".length);
      if (relative.includes("/"))
        await direct.makeDir(relative.slice(0, relative.lastIndexOf("/")));
      await direct.writeBinary(relative, v);
    }
  const directFS = new EncryptedFS(direct);
  assert.equal(await directFS.prepare(), true);
  assert(
    (await directFS.readText("Private title/node.md")).includes(
      "UNIQUE_PLAINTEXT",
    ),
  );
  pass(
    "selecting the encrypted container itself is recognized, not treated as a new empty store",
  );
  await directFS.close();
  const archive = await fresh();
  await setupVaultPassword(password, questions);
  const trashedVault = await archive.repo.createNote({
    title: "Vault trash retained",
    content: "trashed vault body",
    vaulted: true,
  });
  await archive.repo.saveNote({ ...trashedVault, trashed: true });
  await archive.repo.createNote({
    title: "Ordinary archive",
    content: "ordinary archive body",
    archived: true,
  });
  const archiveExport = await readableBackup(archive.repo, {
    vaultPassword: password,
    includeVault: true,
    includeArchive: false,
  });
  const archiveZip = await JSZip.loadAsync(archiveExport.bytes);
  assert(archiveZip.file("_vault/Vault trash retained/node.md"));
  assert(!archiveZip.file("notes/Ordinary archive/node.md"));
  pass(
    "all vault notes remain included even with ordinary archive filtering; vault trash retained",
  );
  await archive.fs.close();
  const marker = await fresh();
  await marker.repo.createNote({
    title: "Body text is not metadata",
    content: "Example:\nvaulted: true",
    vaulted: false,
  });
  assert(
    (await marker.fs.readText("Body text is not metadata/node.md")).includes(
      "vaulted: true",
    ),
  );
  pass(
    "literal vaulted marker in note body cannot accidentally vault or block an ordinary note",
  );
  await setupVaultPassword(password, questions);
  await marker.fs.writeText(
    "Quoted/node.md",
    '---\nid: quoted-vault\ntitle: Quoted\nvaulted: "true"\n---\nquoted vault secret',
  );
  lockVault();
  await denied(
    () => marker.fs.readText("Quoted/node.md"),
    "quoted true vault metadata receives the same independent encryption as boolean metadata",
  );
  await verifyVaultPassword(password);
  const metadataZip = new JSZip();
  metadataZip.file(
    "notes/Custom/node.md",
    "---\nid: custom-note\ntitle: Custom\ncustomTag: preserved-value\n---\ncustom content",
  );
  await importReadableBackup(
    marker.repo,
    await metadataZip.generateAsync({ type: "uint8array" }),
  );
  assert(
    (await marker.fs.readText("Custom/node.md")).includes(
      "customTag: preserved-value",
    ),
  );
  pass("readable import retains unknown custom frontmatter metadata");
  await marker.fs.close();
  const missingDevice = new MemoryFS();
  const noDeviceFS = new EncryptedFS(missingDevice);
  const savedFactory = globalThis.indexedDB;
  Object.defineProperty(globalThis, "indexedDB", {
    value: {
      open() {
        throw Error("device-key storage unavailable");
      },
    },
    configurable: true,
  });
  try {
    await noDeviceFS.initialize(seed, {});
    assert(noDeviceFS.warning.includes("Automatic unlock could not be saved"));
    await noDeviceFS.writeText(
      "Note/node.md",
      "---\ntitle: Note\n---\nprotected",
    );
  } finally {
    Object.defineProperty(globalThis, "indexedDB", {
      value: savedFactory,
      configurable: true,
    });
  }
  await noDeviceFS.close();
  const afterMissing = new EncryptedFS(missingDevice);
  assert.equal(await afterMissing.prepare(), false);
  await afterMissing.recover(seed);
  assert((await afterMissing.readText("Note/node.md")).includes("protected"));
  pass(
    "device-key persistence failure warns without losing data or falling back to plaintext; seed recovery works",
  );
  await afterMissing.close();
  const wrongRemembered = await fresh();
  await wrongRemembered.fs.writeText("Protected/file", "kept");
  const storageHeader = JSON.parse(
    await wrongRemembered.raw.readText("notenoid.encrypted/key.json"),
  );
  await wrongRemembered.fs.close();
  await (
    await import("../../src/core/security/remember")
  ).rememberKey(storageHeader.id, crypto.getRandomValues(new Uint8Array(32)));
  const rememberedFailure = new EncryptedFS(wrongRemembered.raw);
  await denied(
    () => rememberedFailure.prepare(),
    "wrong remembered device key is rejected",
  );
  rememberedFailure.requestRecovery();
  await rememberedFailure.recover(seed);
  assert.equal(await rememberedFailure.readText("Protected/file"), "kept");
  pass("explicit seed recovery replaces a corrupted remembered device key");
  await rememberedFailure.close();
  const snapshotTest = await fresh();
  await snapshotTest.fs.writeText("Note/file", "before");
  const [snapshotFiles] = await Promise.all([
    snapshotTest.fs.encryptedBackup(),
    snapshotTest.fs.writeText("Note/file", "after"),
  ]);
  const copy = new MemoryFS();
  for (const [path, bytes] of Object.entries(snapshotFiles)) {
    const full = "notenoid.encrypted/" + path;
    await copy.makeDir(full.slice(0, full.lastIndexOf("/")));
    await copy.writeBinary(full, bytes);
  }
  const snapshotFS = new EncryptedFS(copy);
  assert(await snapshotFS.prepare());
  assert.equal(await snapshotFS.readText("Note/file"), "before");
  assert.equal(await snapshotTest.fs.readText("Note/file"), "after");
  pass(
    "encrypted recovery copy is a consistent snapshot while a save is queued",
  );
  await snapshotFS.close();
  const snapshotObject = Object.keys(snapshotFiles).find((path) =>
    path.startsWith("objects/"),
  )!;
  snapshotTest.raw.files.get("notenoid.encrypted/" + snapshotObject)![0] ^= 1; // prior checkpoint object only; corrupt current object explicitly
  const currentFiles = await snapshotTest.fs.encryptedBackup();
  const currentObject = Object.keys(currentFiles).find((path) =>
    path.startsWith("objects/"),
  )!;
  snapshotTest.raw.files.get("notenoid.encrypted/" + currentObject)![0] ^= 1;
  await denied(
    () => snapshotTest.fs.encryptedBackup(),
    "encrypted backup refuses damaged current objects",
  );
  await snapshotTest.fs.close();

  /* ================= v18: minimum lengths + seed recovery ================= */
  // 3-character credentials are accepted everywhere; 2 characters are not.
  const tiny = new MemoryFS();
  const tinyFS = new EncryptedFS(tiny);
  await denied(
    () => tinyFS.initialize("ab", {}),
    "2-character seed rejected",
  );
  await tinyFS.initialize("abc", {});
  pass("3-character seed password accepted");
  await denied(
    () =>
      setupVaultPassword("ab", [
        { id: "first_school", answer: "abc" },
        { id: "first_pet", answer: "abc" },
      ]),
    "2-character vault password rejected",
  );
  await denied(
    () =>
      setupVaultPassword("abc", [
        { id: "first_school", answer: "ab" },
        { id: "first_pet", answer: "abc" },
      ]),
    "2-character security answer rejected",
  );
  await setupVaultPassword("abc", [
    { id: "first_school", answer: "sun" },
    { id: "first_pet", answer: "moon" },
  ]);
  pass("3-character vault password and answers accepted");
  const tinyRepo = new NoteRepository(tinyFS);
  await tinyRepo.createNote({ title: "Tiny", content: "tiny secret" });
  assert(
    Object.keys(await tinyFS.encryptedBackup()).includes("seed-recovery.json"),
  );
  pass("encrypted backup carries the seed-recovery file");

  // the seed-recovery file exists with both question slots
  assert.equal(
    (await tinyFS.readSeedRecovery())?.questions.sort().join(","),
    "first_pet,first_school",
  );
  pass("vault setup records both security questions for seed recovery");

  // forget the device key → recovery screen state → wrong answer denied,
  // correct answer unlocks the storage without the seed
  await tinyFS.close();
  assert.equal(seedRecovery.persist, null);
  pass("seed-recovery bridge detaches on close");
  await new Promise<void>((resolve, reject) => {
    const r = indexedDB.deleteDatabase("notenoid-device-keys");
    r.onsuccess = () => resolve();
    r.onerror = () => reject(r.error);
  });
  const forgot = new EncryptedFS(tiny);
  await forgot.prepare();
  assert.equal(forgot.state, "recover");
  assert.equal(
    (await forgot.readSeedRecovery())?.questions.length,
    2,
  );
  assert.equal(
    await forgot.recoverByAnswers([
      { id: "first_school", answer: "wrong" },
    ]),
    false,
  );
  pass("wrong security answer cannot unlock the seed");
  assert.equal(
    await forgot.recoverByAnswers([{ id: "first_school", answer: "SUN" }]),
    true,
  );
  assert.equal(
    (await new NoteRepository(forgot).scan()).notes[0].content.trim(),
    "tiny secret",
  );
  pass("correct security answer unlocks storage without the seed");
  await forgot.close();

  // the seed itself keeps working after answer-based recovery
  await new Promise<void>((resolve, reject) => {
    const r = indexedDB.deleteDatabase("notenoid-device-keys");
    r.onsuccess = () => resolve();
    r.onerror = () => reject(r.error);
  });
  const seedAgain = new EncryptedFS(tiny);
  await seedAgain.prepare();
  await seedAgain.recover("abc");
  assert.equal(
    (await new NoteRepository(seedAgain).scan()).notes.length,
    1,
  );
  pass("original 3-character seed still unlocks after answer recovery");
  await seedAgain.close();

  // changing the questions re-writes the slots: old answer dead, new works
  await new Promise<void>((resolve, reject) => {
    const r = indexedDB.deleteDatabase("notenoid-device-keys");
    r.onsuccess = () => resolve();
    r.onerror = () => reject(r.error);
  });
  const rebind = new EncryptedFS(tiny);
  await rebind.prepare();
  await rebind.recover("abc");
  assert.equal(
    await setSecurityQuestions(
      "abc",
      [{ id: "first_school", answer: "sun" }],
      [
        { id: "birth_city", answer: "new answer one" },
        { id: "nickname", answer: "new answer two" },
      ],
    ),
    true,
  );
  await rebind.close();
  await new Promise<void>((resolve, reject) => {
    const r = indexedDB.deleteDatabase("notenoid-device-keys");
    r.onsuccess = () => resolve();
    r.onerror = () => reject(r.error);
  });
  const rebindFS = new EncryptedFS(tiny);
  await rebindFS.prepare();
  assert.equal(
    (await rebindFS.readSeedRecovery())?.questions.sort().join(","),
    "birth_city,nickname",
  );
  assert.equal(
    await rebindFS.recoverByAnswers([{ id: "first_school", answer: "sun" }]),
    false,
  );
  assert.equal(
    await rebindFS.recoverByAnswers([{ id: "nickname", answer: "New Answer Two" }]),
    true,
  );
  pass("question change rebinds seed recovery to the new answers");
  await rebindFS.close();

  // a tampered seed-recovery box is rejected, not silently accepted
  const tamperedSeed = new EncryptedFS(tiny);
  await tamperedSeed.prepare();
  const rawFile = [...tiny.files.entries()].find(([p]) =>
    p.endsWith("seed-recovery.json"),
  )!;
  const parsed = JSON.parse(new TextDecoder().decode(rawFile[1]));
  parsed.slots[0].box = parsed.slots[0].box.slice(0, -2) + "==";
  await tiny.writeText(
    "notenoid.encrypted/seed-recovery.json",
    JSON.stringify(parsed),
  );
  assert.equal(
    await tamperedSeed.recoverByAnswers([{ id: "birth_city", answer: "new answer one" }]),
    false,
  );
  pass("tampered seed-recovery slot fails authentication");
  await tamperedSeed.close();

  // a one-answer vault password reset must keep the OTHER still-valid slot
  await new Promise<void>((resolve, reject) => {
    const r = indexedDB.deleteDatabase("notenoid-device-keys");
    r.onsuccess = () => resolve();
    r.onerror = () => reject(r.error);
  });
  const mergeFS = new EncryptedFS(tiny);
  await mergeFS.prepare();
  await mergeFS.recover("abc");
  assert.equal(
    await resetVaultPassword(
      [{ id: "birth_city", answer: "new answer one" }],
      "NewResetPass!3",
    ),
    true,
  );
  assert.equal(
    (await mergeFS.readSeedRecovery())?.questions.sort().join(","),
    "birth_city,nickname",
    "single-answer reset keeps both slots",
  );
  await mergeFS.close();
  await new Promise<void>((resolve, reject) => {
    const r = indexedDB.deleteDatabase("notenoid-device-keys");
    r.onsuccess = () => resolve();
    r.onerror = () => reject(r.error);
  });
  const mergeCheck = new EncryptedFS(tiny);
  await mergeCheck.prepare();
  assert.equal(
    await mergeCheck.recoverByAnswers([
      { id: "nickname", answer: "new answer two" },
    ]),
    true,
    "the untouched slot still recovers the seed",
  );
  pass("one-answer vault reset preserves the other seed-recovery slot");
  await mergeCheck.close();

  // Android Keystore bridge: raw key re-supplied on demand → slots can be
  // rebuilt even when the seed was never typed on this session
  const bridged = new MemoryFS();
  const keystore = new Map<string, string>();
  const windowHolder = (
    globalThis as unknown as { window?: { AndroidBridge?: unknown } }
  ).window;
  (globalThis as unknown as { window?: { AndroidBridge?: unknown } }).window = {
    AndroidBridge: {
      rememberStorageKey: (id: string, key: string) =>
        JSON.stringify((keystore.set(id, key), { ok: true })),
      recallStorageKey: (id: string) =>
        JSON.stringify(keystore.has(id) ? { ok: true, key: keystore.get(id) } : { ok: false }),
    },
  };
  try {
    const bridgedFS = new EncryptedFS(bridged);
    await bridgedFS.initialize("abc", {});
    await setupVaultPassword("abc", [
      { id: "first_school", answer: "sun" },
      { id: "first_pet", answer: "moon" },
    ]);
    await bridgedFS.close();
    // simulate a lost seed-recovery file (e.g. older container)
    await bridged.remove("notenoid.encrypted/seed-recovery.json");
    const bridgedAgain = new EncryptedFS(bridged);
    assert.equal(await bridgedAgain.prepare(), true); // Keystore auto-unlock
    assert.equal(await bridgedAgain.readSeedRecovery(), null);
    assert.equal(
      await setSecurityQuestions(
        "abc",
        [{ id: "first_school", answer: "sun" }],
        [
          { id: "first_school", answer: "sun" },
          { id: "first_pet", answer: "moon" },
        ],
      ),
      true,
    );
    assert.equal(
      (await bridgedAgain.readSeedRecovery())?.questions.length,
      2,
    );
    pass("Android Keystore bridge rebuilds seed recovery without a typed seed");
    await bridgedAgain.close();
  } finally {
    if (windowHolder === undefined)
      delete (globalThis as unknown as { window?: unknown }).window;
    else
      (globalThis as unknown as { window?: unknown }).window = windowHolder;
  }

  console.log(`\n${tests} security/storage/backup scenario groups passed.`);
}
main().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
