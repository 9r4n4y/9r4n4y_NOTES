import type { FSAdapter, DirEntry } from "../../src/core/fs/adapter";
export class MemoryFS implements FSAdapter {
  readonly kind = "web" as const;
  files = new Map<string, Uint8Array>();
  dirs = new Set([""]);
  fail: ((operation: string, path: string) => void) | null = null;
  rootLabel() {
    return "MemoryFixture";
  }
  hasRoot() {
    return true;
  }
  async needsPermission() {
    return false;
  }
  async pickRoot() {
    return true;
  }
  async restoreRoot() {
    return true;
  }
  async exists(p: string) {
    return this.files.has(p) || this.dirs.has(p);
  }
  async listDir(path: string) {
    if (!this.dirs.has(path)) throw Error("Missing dir " + path);
    const prefix = path ? path + "/" : "";
    const entries: DirEntry[] = [];
    for (const d of this.dirs)
      if (
        d !== path &&
        d.startsWith(prefix) &&
        !d.slice(prefix.length).includes("/")
      )
        entries.push({ name: d.slice(prefix.length), kind: "dir" });
    for (const [f, v] of this.files)
      if (f.startsWith(prefix) && !f.slice(prefix.length).includes("/"))
        entries.push({
          name: f.slice(prefix.length),
          kind: "file",
          size: v.length,
        });
    return entries;
  }
  async readText(p: string) {
    return new TextDecoder().decode(await this.readBinary(p));
  }
  async readBinary(p: string) {
    this.fail?.("read", p);
    const b = this.files.get(p);
    if (!b) throw Error("Missing " + p);
    return new Uint8Array(b);
  }
  async makeDir(p: string) {
    this.fail?.("mkdir", p);
    let path = "";
    for (const part of p.split("/").filter(Boolean)) {
      path = path ? path + "/" + part : part;
      this.dirs.add(path);
    }
  }
  async writeText(p: string, s: string) {
    await this.writeBinary(p, new TextEncoder().encode(s));
  }
  async writeBinary(p: string, b: Uint8Array) {
    this.fail?.("write", p);
    const parent = p.includes("/") ? p.slice(0, p.lastIndexOf("/")) : "";
    if (!this.dirs.has(parent)) throw Error("Missing parent " + parent);
    this.files.set(p, new Uint8Array(b));
  }
  async remove(p: string, recursive = true) {
    this.fail?.("remove", p);
    for (const f of this.files.keys())
      if (f === p || f.startsWith(p + "/")) this.files.delete(f);
    for (const d of this.dirs)
      if (d === p || d.startsWith(p + "/")) this.dirs.delete(d);
  }
  async rename(from: string, to: string) {
    this.fail?.("rename", from);
    for (const [f, v] of [...this.files])
      if (f === from || f.startsWith(from + "/")) {
        this.files.set(to + f.slice(from.length), v);
        this.files.delete(f);
      }
    for (const d of [...this.dirs])
      if (d === from || d.startsWith(from + "/")) {
        this.dirs.add(to + d.slice(from.length));
        this.dirs.delete(d);
      }
  }
}
