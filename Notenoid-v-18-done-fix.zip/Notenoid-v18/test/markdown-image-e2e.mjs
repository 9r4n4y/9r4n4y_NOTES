// Regression e2e: uploads one Markdown image and a multi-image HTML grid, then
// verifies that the actual PNGs (not just their alt/name text) render in the
// preview. Run against `npm run dev` with `TEST_URL=http://localhost:3000`.
import { chromium } from "@playwright/test";
import assert from "node:assert/strict";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const fixture = (name) => path.join(here, "fixtures", name);
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({ viewport: { width: 1440, height: 1050 }, deviceScaleFactor: 1 });
const page = await context.newPage();
const errors = [];
page.on("pageerror", (error) => errors.push(error.message));
await page.addInitScript(() => localStorage.setItem("notes-app-settings-v1", JSON.stringify({ confirmModeToggle: false })));
await page.goto(process.env.TEST_URL || "http://localhost:3000");
await page.getByText("Use in-app local storage").click();
await page.getByLabel("Seed password", { exact: true }).fill("amber lantern meadow orbit copper river");
await page.getByLabel("Confirm seed password", { exact: true }).fill("amber lantern meadow orbit copper river");
await page.getByRole("checkbox").check();
await page.getByRole("button", { name: "Encrypt local storage", exact: true }).click();
await page.getByRole("button", { name: "New note", exact: true }).first().waitFor();
await page.getByRole("button", { name: "New note", exact: true }).first().click();
await page.getByPlaceholder("Title", { exact: true }).fill("Markdown image render test");
await page.getByRole("button", { name: "Edit Markdown", exact: true }).click();
const textarea = page.locator("textarea.md-textarea");
await textarea.fill("Single-upload Markdown image.\n\n");

// Single-image upload: picker inserts a regular Markdown image using the
// attachment saved by the app, not a transient remote URL.
await page.getByRole("button", { name: /Insert image at cursor/ }).click();
await page.getByRole("button", { name: "Choose new images", exact: true }).click();
const pickers = page.locator('input[type="file"][accept="image/*,.gif"]');
await pickers.last().setInputFiles(fixture("single-upload.png"));
await page.waitForFunction(() => document.querySelector("textarea.md-textarea")?.value.includes("attachment/single-upload.png"));
await page.getByRole("button", { name: "Choose new images", exact: true }).waitFor({ state: "hidden" });

// Multi-image upload: the same picker inserts a portable img-grid block.
await textarea.evaluate((el) => { el.focus(); el.setSelectionRange(el.value.length, el.value.length); });
await page.getByRole("button", { name: /Insert image at cursor/ }).click();
await page.getByRole("button", { name: "Choose new images", exact: true }).click();
await pickers.last().setInputFiles([fixture("grid-blue.png"), fixture("grid-green.png")]);
await page.waitForFunction(() => document.querySelector("textarea.md-textarea")?.value.includes('class="img-grid"'));
await page.getByRole("button", { name: "Choose new images", exact: true }).waitFor({ state: "hidden" });
await page.getByRole("button", { name: "Preview rendered note", exact: true }).click();

const rendered = page.locator(".md-preview img.md-inline-image");
await page.waitForFunction(() => {
  const imgs = [...document.querySelectorAll(".md-preview img.md-inline-image")];
  return imgs.length === 3 && imgs.every((img) => img.complete && img.naturalWidth > 0);
});
assert.equal(await rendered.count(), 3, "one uploaded Markdown image plus two grid images must render");
assert.equal(await page.locator(".md-preview .img-grid img").count(), 2, "both grid tiles must render");
assert.equal(await page.locator(".md-preview .md-image-missing").count(), 0, "no image may degrade to its name/alt text");
const imageState = await rendered.evaluateAll((imgs) => imgs.map((img) => ({
  alt: img.alt,
  src: img.getAttribute("src"),
  naturalWidth: img.naturalWidth,
  naturalHeight: img.naturalHeight,
  complete: img.complete,
})));
assert.deepEqual(imageState.map((img) => img.alt), ["single-upload.png", "grid-blue.png", "grid-green.png"]);
assert.deepEqual([imageState[0].naturalWidth, imageState[0].naturalHeight], [420, 260]);
assert.deepEqual(imageState.slice(1).map((img) => [img.naturalWidth, img.naturalHeight]), [[320, 320], [320, 320]]);
assert(imageState.every((img) => img.complete));
const gridLayout = await page.locator(".md-preview .img-grid").evaluate((grid) => ({
  display: getComputedStyle(grid).display,
  columns: getComputedStyle(grid).gridTemplateColumns.split(" ").length,
}));
assert.equal(gridLayout.display, "grid");
assert.equal(gridLayout.columns, 2, "two uploaded pictures must form a two-column grid");
assert.deepEqual(errors, []);

// Both independent sizing controls must persist width in Markdown and reflect
// it in the rendered layout (grid data-size and single-image title metadata).
const grid = page.locator(".md-preview .img-grid");
await grid.click({ button: "right" });
const gridRange = page.getByLabel("Image width percent");
await gridRange.press("End");
await page.waitForFunction(() => document.querySelector(".md-preview .img-grid")?.getAttribute("style")?.includes("100%"));
assert.equal(await gridRange.inputValue(), "100");
assert.equal(await grid.evaluate((el) => el.style.width), "100%");
await page.locator(".md-image-menu-done").click();
await page.getByRole("button", { name: "Edit Markdown", exact: true }).click();
assert.match(await textarea.inputValue(), /class="img-grid"[^>]*data-size="100"/);
await page.getByRole("button", { name: "Preview rendered note", exact: true }).click();
const single = page.locator(".md-preview .md-image-wrap").first();
await single.click({ button: "right" });
await page.getByLabel("Image width percent").press("End");
await page.locator(".md-image-menu-done").click();
await page.getByRole("button", { name: "Edit Markdown", exact: true }).click();
assert.match(await textarea.inputValue(), /!\[single-upload\.png\]\(attachment\/single-upload\.png "size=100"\)/);
await page.getByRole("button", { name: "Preview rendered note", exact: true }).click();
console.log("PASS: image grid resizing persists data-size and single-image sizing persists its Markdown size metadata");

await page.screenshot({ path: path.join(here, "evidence", "markdown-images-v18.png"), fullPage: true });
console.log("PASS: single Markdown image upload renders (420×260); both grid images render (320×320, 2-column layout); no alt/name-only placeholders; screenshot saved to test/evidence/markdown-images-v18.png");
console.log(JSON.stringify(imageState, null, 2));

// Older Notenoid notes may use [filename](attachment/...) instead of Markdown
// image syntax; the compatibility conversion must keep working after the fix.
await page.getByRole("button", { name: "Edit Markdown", exact: true }).click();
await textarea.fill("[single-upload.png](attachment/single-upload.png)");
await page.getByRole("button", { name: "Preview rendered note", exact: true }).click();
await page.waitForFunction(() => {
  const imgs = [...document.querySelectorAll(".md-preview img.md-inline-image")];
  return imgs.length === 1 && imgs[0].complete && imgs[0].naturalWidth === 420;
});
assert.equal(await page.locator(".md-preview .md-image-missing").count(), 0);
console.log("PASS: legacy [filename](attachment/...) link still becomes a rendered local image");
assert.deepEqual(errors, []);
await browser.close();
