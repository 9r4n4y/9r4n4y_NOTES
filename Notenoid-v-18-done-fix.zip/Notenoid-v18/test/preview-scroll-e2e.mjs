import { chromium } from "@playwright/test";
import assert from "node:assert/strict";
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({ viewport: { width: 1280, height: 900 } });
const page = await context.newPage();
const errors = [];
page.on("pageerror", e => errors.push(e.message));
await page.goto(process.env.TEST_URL || "http://localhost:3000");
await page.getByText("Use in-app local storage").click();
await page.getByLabel("Seed password", { exact: true }).fill("amber lantern meadow orbit copper river");
await page.getByLabel("Confirm seed password", { exact: true }).fill("amber lantern meadow orbit copper river");
await page.getByRole("checkbox").check();
await page.getByRole("button", { name: "Encrypt local storage", exact: true }).click();
await page.getByRole("button", { name: "New note", exact: true }).first().waitFor();
await page.getByRole("button", { name: "New note", exact: true }).first().click();
await page.getByPlaceholder("Title", { exact: true }).fill("Long scroll anchor QA");
await page.getByRole("button", { name: "Edit Markdown", exact: true }).click();
const textarea = page.locator("textarea.md-textarea");
const chunks=[];
for(let i=0;i<85;i++) chunks.push(`## Section ${i}\n\nParagraph ${i} — inline code \`const row = ${i};\` and **bold words**. VIEWPORT_ANCHOR_${String(i).padStart(3,"0")} continues with enough prose to wrap over several lines.\n\n| column | value | note |\n| --- | ---: | :--- |\n| alpha | ${i} | TABLE_ANCHOR_${String(i).padStart(3,"0")} |\n| beta | ${i+1} | second row |\n\n\`\`\`ts\n// FENCE_ANCHOR_${String(i).padStart(3,"0")}\nfunction sample${i}() {\n  const value = ${i};\n  return value * 2;\n}\n\`\`\`\n\n> Quote ${i} with another \`inline token\` and a long line to force different rendered heights.\n\n- item ${i}\n  - nested item\n- [ ] checkable task\n`);
await textarea.fill(chunks.join("\n"));
await page.getByRole("button", { name: "Preview rendered note", exact: true }).click();
const editor = page.locator(".md-editor").last();
const scroller = editor.locator("div.overflow-y-auto");
async function rangeTop(markerText) {
  return scroller.evaluate((sc, needle) => {
    const root=sc.parentElement.querySelector(".md-preview");
    const walker=document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    for(let n=walker.nextNode();n;n=walker.nextNode()) {
      const at=n.data.indexOf(needle); if(at<0) continue;
      const r=document.createRange(); r.setStart(n,at); r.setEnd(n,at+needle.length);
      return r.getBoundingClientRect().top;
    }
    throw new Error(`text not found: ${needle}`);
  }, markerText);
}
async function roundTrip(markerText) {
  const block = editor.locator(".md-preview [data-src-line]").filter({ hasText: markerText }).first();
  await block.waitFor();
  const align = async () => scroller.evaluate((sc, needle) => {
    const root=sc.parentElement.querySelector(".md-preview");
    const walker=document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    for(let n=walker.nextNode();n;n=walker.nextNode()) {
      const at=n.data.indexOf(needle); if(at<0) continue;
      const r=document.createRange(); r.setStart(n,at); r.setEnd(n,at+needle.length);
      sc.scrollTop += r.getBoundingClientRect().top-sc.getBoundingClientRect().top-sc.clientHeight*.35;
      return;
    }
    throw new Error(`text not found: ${needle}`);
  }, markerText);
  await align(); await page.waitForTimeout(250); await align(); await page.waitForTimeout(250);
  const before = await rangeTop(markerText);
  const box = await scroller.boundingBox();
  assert(box && before > box.y && before < box.y+box.height, `${markerText} should be visible before toggle`);
  await editor.getByRole("button", { name: "Edit Markdown", exact: true }).click();
  await textarea.waitFor();
  await editor.getByRole("button", { name: "Preview rendered note", exact: true }).click();
  await block.waitFor(); await page.waitForTimeout(250);
  const after = await rangeTop(markerText);
  console.log(`${markerText}: ${before.toFixed(1)}px → ${after.toFixed(1)}px; drift ${Math.abs(after-before).toFixed(1)}px`);
  assert(Math.abs(after-before)<=12, `${markerText}: preserve vertical position within 12px`);
}
for (const marker of ["VIEWPORT_ANCHOR_040", "TABLE_ANCHOR_040", "FENCE_ANCHOR_040"]) await roundTrip(marker);
assert.deepEqual(errors,[]);
console.log("PASS: paragraph, table and fenced-code anchors retain viewport position in long Markdown with inline code, lists and quotes.");
await browser.close();
