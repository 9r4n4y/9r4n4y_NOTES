// v18 shortcut engine e2e — every Markdown action shortcut is exercised in a
// real browser, including re-recording, min/max key rules, conflicts, reset,
// and the Preview/Edit toggle (default Shift+X).
import { chromium } from "@playwright/test";
import assert from "node:assert/strict";

const browser = await chromium.launch({ headless: true });
const errors = [];
const context = await browser.newContext();
const page = await context.newPage();
page.on("pageerror", (e) => errors.push(e.message));

// min-3 seed password — proves the short seed is accepted
const SEED = "abc";

await page.addInitScript(() =>
  localStorage.setItem(
    "notes-app-settings-v1",
    JSON.stringify({ confirmModeToggle: false }),
  ),
);
await page.goto(process.env.TEST_URL || "http://localhost:3000");
await page.getByText("Use in-app local storage").click();
await page.getByLabel("Seed password", { exact: true }).fill(SEED);
await page.getByLabel("Confirm seed password", { exact: true }).fill(SEED);
await page.getByRole("checkbox").check();
await page.getByRole("button", { name: "Encrypt local storage", exact: true }).click();
await page.getByText("New note — tap to write").click();
await page.getByRole("button", { name: "Edit Markdown", exact: true }).click();
const ta = page.locator("textarea.md-textarea");
await ta.waitFor();

const value = () => ta.inputValue();
const kb = page.keyboard;
const select = (from, to = from) => ta.evaluate((el, [a, b]) => el.setSelectionRange(a, b), [from, to]);
const selectAll = () => ta.evaluate((el) => el.select());
const caretEnd = () => ta.evaluate((el) => el.setSelectionRange(el.value.length, el.value.length));

// ---------- preview toggle: Shift+X (the headline shortcut) ----------
await ta.fill("plain words here");
assert.equal(await page.locator(".md-preview").count(), 0, "starts in edit mode");
await kb.press("Shift+X");
await page.locator(".md-preview").waitFor();
assert.equal(await ta.count(), 0, "Shift+X switched to preview");
await kb.press("Shift+X");
await ta.waitFor();
assert.equal(await page.locator(".md-preview").count(), 0, "Shift+X switched back to edit");
console.log("PASS Shift+X toggles Preview/Edit both ways");

// a shortcut wins over typing (legacy parity): Shift+X inside the textarea
// toggles the mode instead of typing a capital X
await ta.click();
await kb.press("Shift+X");
await page.locator(".md-preview").waitFor();
await kb.press("Shift+X");
await ta.waitFor();
console.log("PASS Shift+X works while the textarea is focused");

// ---------- inline formatting ----------
await ta.fill("plain words here");
await select(0, 5); // "plain"
await kb.press("Control+B");
assert.equal(await value(), "**plain** words here");
await kb.press("Control+Z");
assert.equal(await value(), "plain words here", "undo restores pre-bold text");
await kb.press("Control+Y");
assert.equal(await value(), "**plain** words here", "redo re-applies bold");
console.log("PASS Ctrl+B bold + Ctrl+Z undo + Ctrl+Y redo");

await ta.fill("plain words here");
await select(0, 5);
await kb.press("Control+I");
assert.equal(await value(), "*plain* words here");
console.log("PASS Ctrl+I italic");

await ta.fill("plain words here");
await select(0, 5);
await kb.press("Control+Shift+U");
assert.equal(await value(), "<u>plain</u> words here");
console.log("PASS Ctrl+Shift+U underline");

await ta.fill("plain words here");
await select(0, 5);
await kb.press("Control+Shift+S");
assert.equal(await value(), "~~plain~~ words here");
console.log("PASS Ctrl+Shift+S strikethrough");

await ta.fill("plain words here");
await select(0, 5);
await kb.press("Control+Backquote");
assert.equal(await value(), "`plain` words here");
console.log("PASS Ctrl+` inline code");

// ---------- line/block formatting (fresh text per action) ----------
await ta.fill("plain words here");
await kb.press("Control+Shift+1");
assert.equal(await value(), "# plain words here");
await ta.fill("plain words here");
await kb.press("Control+Shift+2");
assert.equal(await value(), "## plain words here");
await ta.fill("plain words here");
await kb.press("Control+Shift+3");
assert.equal(await value(), "### plain words here");
await kb.press("Control+Shift+0");
assert.equal(await value(), "plain words here", "body text strips the heading");
console.log("PASS Ctrl+Shift+1/2/3 headings + Ctrl+Shift+0 body text");

await ta.fill("plain words here");
await kb.press("Control+Shift+8");
assert.equal(await value(), "- plain words here");
await ta.fill("plain words here");
await kb.press("Control+Shift+7");
assert.equal(await value(), "1. plain words here");
await ta.fill("plain words here");
await kb.press("Control+Shift+L");
assert.equal(await value(), "- [ ] plain words here");
await ta.fill("plain words here");
await kb.press("Control+Shift+9");
assert.equal(await value(), "> plain words here");
await kb.press("Control+Shift+0");
assert.equal(await value(), "plain words here", "body text strips the quote");
console.log("PASS bullet / numbered / checklist / quote shortcuts");

await ta.fill("plain words here");
await select(0, 5);
await kb.press("Control+Shift+Backquote");
assert.equal(await value(), "```\nplain\n``` words here");
console.log("PASS Ctrl+Shift+` code block");

// ---------- links ----------
await ta.fill("plain words here");
await select(0, 5);
await kb.press("Control+K");
await page.getByLabel("Link URL").waitFor();
await page.getByLabel("Link URL").fill("https://example.com");
await page.getByLabel("Link text").fill("example");
await page.getByRole("button", { name: "Apply" }).click();
assert.equal(await value(), "[example](https://example.com) words here");
await kb.press("Control+Shift+K");
assert.equal(await value(), "example words here", "remove-link keeps the text");
console.log("PASS Ctrl+K add link + Ctrl+Shift+K remove links");

// ---------- divider + table ----------
await ta.fill("plain words here");
await caretEnd();
await kb.press("Control+Shift+Minus");
assert.ok((await value()).includes("\n\n---\n"), `divider inserted: ${JSON.stringify(await value())}`);
console.log("PASS Ctrl+Shift+- divider");

await ta.fill("plain words here");
await caretEnd();
await kb.press("Control+Shift+M");
assert.ok((await value()).includes("| Column 1 | Column 2 | Column 3 |"), "table inserted");
console.log("PASS Ctrl+Shift+M table");

// ---------- clear formatting ----------
await ta.fill("# **plain** *words* `here`");
await selectAll();
await kb.press("Control+Alt+N");
const cleared = await value();
assert.ok(!cleared.includes("**") && !cleared.includes("*") && !cleared.includes("`") && !cleared.includes("#"), `cleared: ${JSON.stringify(cleared)}`);
console.log("PASS Ctrl+Alt+N clear formatting");

// ---------- images (file picker / insert picker) ----------
await ta.fill("plain words here");
const chooserP = page.waitForEvent("filechooser");
await kb.press("Control+Alt+I");
await chooserP;
console.log("PASS Ctrl+Alt+I opens the image file picker");

await kb.press("Control+Alt+G");
await page.getByText("Insert images at cursor").waitFor();
await kb.press("Escape");
console.log("PASS Ctrl+Alt+G opens the insert-at-cursor picker");

// ---------- settings: record a new combination ----------
await page.getByRole("button", { name: "Back to notes", exact: true }).click();
await page.waitForTimeout(700);
await page.getByRole("button", { name: "Settings", exact: true }).last().click();
await page.getByRole("button", { name: "Shortcuts" }).click();

const boldRow = page.locator("div.divide-y > div", { hasText: "Bold" }).first();
const recordBtn = boldRow.getByRole("button", { name: "Record shortcut for Bold" });
assert.equal(await recordBtn.textContent(), "Ctrl + B");
await recordBtn.click();
await page.waitForTimeout(120);
await kb.down("Alt");
await kb.down("B");
await page.waitForTimeout(80);
await kb.up("B");
await kb.up("Alt");
await page.waitForTimeout(200);
assert.equal(await recordBtn.textContent(), "Alt + B", "recorded Alt+B shows on the button");
console.log("PASS recording a 2-key combination (Alt+B)");

// min 2 keys
await recordBtn.click();
await page.waitForTimeout(120);
await kb.press("A");
await page.waitForTimeout(150);
assert.ok((await recordBtn.textContent()).includes("Alt + B"), "single key rejected, old combo kept");
const rowError = boldRow.locator("p.text-destructive");
assert.equal(await rowError.textContent(), "Hold at least 2 keys together");
console.log("PASS 1-key combination rejected (minimum is 2)");

// max 4 keys
await recordBtn.click();
await page.waitForTimeout(120);
for (const k of ["Shift", "Control", "Alt", "Meta", "K"]) await kb.down(k);
await page.waitForTimeout(80);
for (const k of ["Shift", "Control", "Alt", "Meta", "K"]) await kb.up(k);
await page.waitForTimeout(150);
assert.equal(await rowError.textContent(), "At most 4 keys per shortcut");
console.log("PASS 5-key combination rejected (maximum is 4)");

// 4-key combination is allowed
await recordBtn.click();
await page.waitForTimeout(120);
for (const k of ["Control", "Alt", "Shift", "K"]) await kb.down(k);
await page.waitForTimeout(80);
for (const k of ["Control", "Alt", "Shift", "K"]) await kb.up(k);
await page.waitForTimeout(200);
assert.equal(await recordBtn.textContent(), "Ctrl + Alt + Shift + K");
console.log("PASS 4-key combination accepted");

// conflict rejected
await recordBtn.click();
await page.waitForTimeout(120);
await kb.down("Shift");
await kb.down("X");
await page.waitForTimeout(80);
await kb.up("X");
await kb.up("Shift");
await page.waitForTimeout(200);
await page.getByText("Already used by “Preview / Edit toggle”").waitFor();
assert.equal(await recordBtn.textContent(), "Ctrl + Alt + Shift + K", "conflict not saved");
console.log("PASS duplicate combination rejected with the conflicting action named");

// escape cancels recording
await recordBtn.click();
await page.waitForTimeout(120);
await kb.press("Escape");
await page.waitForTimeout(150);
assert.equal(await recordBtn.textContent(), "Ctrl + Alt + Shift + K", "escape keeps the old binding");
console.log("PASS Escape cancels recording");

// reset all restores the defaults, then bind Bold to Alt+B again
await page.getByRole("button", { name: "Reset all" }).click();
await page.waitForTimeout(200);
assert.equal(await recordBtn.textContent(), "Ctrl + B");
console.log("PASS Reset all restores defaults");

await recordBtn.click();
await page.waitForTimeout(120);
await kb.down("Alt");
await kb.down("B");
await page.waitForTimeout(80);
await kb.up("B");
await kb.up("Alt");
await page.waitForTimeout(200);
assert.equal(await recordBtn.textContent(), "Alt + B");
await page.keyboard.press("Escape");
await page.waitForTimeout(300);
console.log("PASS re-recorded Bold as Alt+B and closed settings");

// the app follows the new binding; the old one is released
const ensureEdit = async () => {
  await page.getByText("New note — tap to write").click();
  if (await page.locator(".md-preview").count())
    await page.getByRole("button", { name: "Edit Markdown", exact: true }).click();
  await ta.waitFor();
};
await ensureEdit();
await ta.fill("plain words here");
await select(0, 5);
await kb.press("Alt+B");
assert.equal(await value(), "**plain** words here", "rebound Alt+B bolds");
await select(0, 7);
await kb.press("Control+B");
assert.equal(await value(), "**plain** words here", "old Ctrl+B no longer bound (no-op)");
console.log("PASS re-recorded shortcut works and the old one is released");

// persistence across reload
await page.getByRole("button", { name: "Back to notes", exact: true }).click();
await page.waitForTimeout(700);
await page.reload();
await page.waitForTimeout(1000);
await ensureEdit();
await ta.fill("plain words here");
await select(0, 5);
await kb.press("Alt+B");
assert.equal(await value(), "**plain** words here", "custom binding survives reload");
await kb.press("Shift+X");
await page.locator(".md-preview").waitFor();
console.log("PASS custom shortcuts persist across reload; Shift+X still toggles preview");

assert.deepEqual(errors, []);
console.log("\nSHORTCUT SUITE PASSED — every action shortcut, recording rules, conflicts, reset and persistence verified.");
await browser.close();
