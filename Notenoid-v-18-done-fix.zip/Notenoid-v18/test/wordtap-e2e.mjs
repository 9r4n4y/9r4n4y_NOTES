// v18 optional word-tap toggle e2e — the "Require Done after word tap" setting.
// Off: tapping the word switches the mode immediately (no Done press).
// On:  the optional word-select flow — tap the word, then press Done.
import { chromium } from "@playwright/test";
import assert from "node:assert/strict";

const browser = await chromium.launch({ headless: true });
const errors = [];
const page = await browser.newPage();
page.on("pageerror", (e) => errors.push(e.message));

await page.addInitScript(() =>
  localStorage.setItem(
    "notes-app-settings-v1",
    JSON.stringify({ confirmModeToggle: true, confirmWordSelection: false }),
  ),
);
await page.goto(process.env.TEST_URL || "http://localhost:3000");
await page.getByText("Use in-app local storage").click();
await page.getByLabel("Seed password", { exact: true }).fill("abc");
await page.getByLabel("Confirm seed password", { exact: true }).fill("abc");
await page.getByRole("checkbox").check();
await page.getByRole("button", { name: "Encrypt local storage", exact: true }).click();
await page.getByText("New note — tap to write").click();

const text =
  "alpha beta gamma\n\n" +
  Array.from({ length: 40 }, (_, i) => `Paragraph ${i} with alpha words.`).join("\n\n");
const ta = page.locator("textarea.md-textarea");

// empty note → the first toggle switches directly (no text to anchor yet)
await page.getByRole("button", { name: "Edit Markdown", exact: true }).click();
await ta.waitFor();
await ta.fill(text);

// ---- A) instant mode: edit → preview (word tap in the textarea) ----
const last = text.lastIndexOf("alpha");
await page.getByRole("button", { name: "Preview rendered note", exact: true }).click();
await page.getByText("Tap one word — the mode switches instantly").waitFor();
assert.equal(
  await page.locator(".md-editor").getByRole("button", { name: "Done", exact: true }).count(),
  0,
  "no Done button in instant mode",
);
await ta.evaluate((el, at) => {
  el.setSelectionRange(at, at);
  el.dispatchEvent(new MouseEvent("click", { bubbles: true }));
}, last);
await page.waitForTimeout(350);
await page.locator(".md-preview").waitFor();
assert.equal(await ta.count(), 0, "mode switched instantly to preview");
const start = Number(
  await page.locator("[data-selection-overlay]").first().getAttribute("data-source-start"),
);
assert.equal(start, last, "exact occurrence anchored in the preview");
console.log("PASS instant mode: edit word tap switches to preview with no Done");

// ---- B) instant mode: preview → edit (word tap in the rendered preview) ----
await page.getByRole("button", { name: "Edit Markdown", exact: true }).click();
await page.getByText("Tap one word — the mode switches instantly").waitFor();
const point = await page.locator(".md-preview").evaluate((root) => {
  for (const s of root.querySelectorAll("[data-exact-map]")) {
    const map = JSON.parse(s.dataset.exactMap);
    const index = map.findIndex(([a]) => a === 0); // source offset 0 → "alpha"
    if (index < 0) continue;
    s.scrollIntoView({ block: "center" });
    const r = document.createRange();
    r.setStart(s.firstChild, index);
    r.setEnd(s.firstChild, index + 1);
    const b = r.getBoundingClientRect();
    return { x: b.left + b.width / 2, y: b.top + b.height / 2 };
  }
  return null;
});
assert(point, "exact source span found for offset 0");
await page.mouse.click(point.x, point.y);
await page.waitForTimeout(350);
await ta.waitFor();
assert.equal(await page.locator(".md-preview").count(), 0, "mode switched instantly to edit");
assert.ok(
  (await page.locator("[data-selection-overlay]").count()) > 0,
  "pulse overlay marks the exact word",
);
console.log("PASS instant mode: preview word tap switches to edit with no Done");

// ---- turn "Require Done" back on through the real Settings UI ----
await page.getByRole("button", { name: "Back to notes", exact: true }).click();
await page.waitForTimeout(700);
await page.getByRole("button", { name: "Settings", exact: true }).last().click();
await page.getByRole("button", { name: "Search & Notes" }).click();
const doneRow = page.locator("div.rounded-lg.border.px-3", { hasText: "Require Done after word tap" });
await doneRow.getByRole("switch").click();
await page.waitForTimeout(200);
assert.equal(await doneRow.getByRole("switch").getAttribute("data-state"), "checked");
await page.keyboard.press("Escape");
await page.waitForTimeout(300);
console.log("PASS 'Require Done after word tap' toggle found and enabled");

// ---- C) Done mode returns (optional word-select flow) on a fresh note ----
await page.getByText("New note — tap to write").click();
if (await page.locator(".md-preview").count())
  await page.getByRole("button", { name: "Edit Markdown", exact: true }).click();
await ta.waitFor();
await ta.fill(text);
await page.getByRole("button", { name: "Preview rendered note", exact: true }).click();
await page.getByText("Tap one word to select the exact occurrence").waitFor();
const doneBtn = page.locator(".md-editor").getByRole("button", { name: "Done", exact: true });
assert.equal(await doneBtn.count(), 1, "Done button visible again");
await ta.evaluate((el) => {
  el.setSelectionRange(0, 0);
  el.dispatchEvent(new MouseEvent("click", { bubbles: true }));
});
await page.waitForTimeout(250);
assert.ok(await ta.count(), "word tap alone does NOT switch in Done mode");
await page.getByText("Selected “alpha”").waitFor();
await doneBtn.click();
await page.locator(".md-preview").waitFor();
assert.equal(await ta.count(), 0, "Done switches the mode");
console.log("PASS Done mode: word tap + Done required again after enabling the setting");

assert.deepEqual(errors, []);
console.log("\nWORD-TAP SUITE PASSED — instant and Done-confirmed toggles both work.");
await browser.close();
