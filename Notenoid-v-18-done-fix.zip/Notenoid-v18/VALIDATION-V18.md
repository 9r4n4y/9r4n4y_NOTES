# Notenoid v18 — validation record

## Automated checks

- `npm run typecheck` — PASS.
- `npm run test:security` — PASS, 61 security/storage/backup scenario groups. Covers readable ZIP export/import, attachment bytes, optional vault export, omission of vault credentials from readable ZIPs, and proof that importing into a destination vault leaves its password/security answers unchanged.
- `TEST_URL=http://localhost:3002 npm run test:images` against the production static payload — PASS. Single Markdown attachment and both grid images render; grid and single-image width controls persist; legacy attachment links render.
- `TEST_URL=http://localhost:3002 npm run test:security-ui` against the production static payload — PASS. UI tests include vault attachment download, wrong export password rejection, default attachment/vault selections, ZIP counts/no credentials, destination-vault import, destination credential preservation, and security-question password recovery.
- `TEST_URL=http://localhost:3000 node test/preview-scroll-e2e.mjs` — PASS. Paragraph, table-cell and fenced-code text anchors all remained within 0px drift in the final recorded run. The fixture has 85 long Markdown sections with inline code, tables, fenced code, quotes, and nested/task lists.
- `bash scripts/build_web_export.sh` — PASS; current static payload copied to `android/assets/`.
- `JAVA_HOME=/tmp/jdk17 PATH=/tmp/jdk17/bin:$PATH APK_STORE_PASSWORD=… npm run build:apk` — PASS. APK signature verifies, `zipalign -c 4` passes, metadata is `com.notes.app`, version name 18.0, version code 180, min API 24, target API 34.

## Lint

Full `npm run lint` is not clean in the supplied baseline: it reports existing issues in unrelated UI hooks/files and generated `android/assets` JavaScript. TypeScript checking and the targeted browser/security tests above pass. No unrelated broad lint cleanup was attempted.
