#!/usr/bin/env python3
"""launcher icons — single clean WHITE icon.

Problem being fixed: the old foreground PNGs baked the artwork's off-white /
light-blue card into the adaptive foreground, so launchers showed a washed-out
"blue tile inside the white tile" — the user saw TWO icons stacked. This script
rebuilds every mipmap from the source artwork with:

  1. the glyph EXTRACTED to pure black-on-transparent (any blue/gray cast in
     the artwork background is dropped — alpha comes from luminance),
  2. the adaptive FOREGROUND = transparent + centered black glyph (0.50 of the
     108dp canvas, well inside the 66dp safe zone) on the WHITE background
     color resource, so every launcher mask shows one clean white icon,
  3. legacy ic_launcher / ic_launcher_round = glyph on PURE white, the round
     variant circular-masked.
"""
from PIL import Image, ImageDraw, ImageFilter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "android" / "res"
SOURCE = ROOT / "icon-source" / "1789483250921.png"

DENSITIES = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}
ADAPTIVE_DENSITIES = {"mdpi": 108, "hdpi": 162, "xhdpi": 216, "xxhdpi": 324, "xxxhdpi": 432}
FOREGROUND_SCALE = 0.50   # glyph box on the 108dp adaptive canvas
LEGACY_SCALE = 0.72       # glyph box on the legacy bitmap


def extract_glyph() -> Image.Image:
    """Pure black glyph on transparency from the source artwork."""
    src = Image.open(SOURCE).convert("L")
    src = src.filter(ImageFilter.MedianFilter(3))  # de-speckle
    # alpha = darkness: white → 0, black → 255; gamma keeps strokes solid
    alpha = src.point(lambda v: max(0, min(255, int((255 - v) ** 1.06))))
    # drop the near-white paper noise
    alpha = alpha.point(lambda v: 0 if v < 26 else v)
    glyph = Image.new("RGBA", src.size, (18, 18, 18, 0))
    glyph.putalpha(alpha)
    return glyph


def compose(size: int, scale: float, circle: bool, transparent: bool) -> Image.Image:
    canvas = Image.new("RGBA", (size, size), (255, 255, 255, 0) if transparent else (255, 255, 255, 255))
    box = int(size * scale)
    g = GLYPH.resize((box, box), Image.Resampling.LANCZOS)
    canvas.alpha_composite(g, ((size - box) // 2, (size - box) // 2))
    if circle:
        mask = Image.new("L", (size, size), 0)
        ImageDraw.Draw(mask).ellipse((0, 0, size - 1, size - 1), fill=255)
        out = Image.new("RGBA", (size, size), (255, 255, 255, 0))
        out.paste(canvas, (0, 0), mask)
        return out
    return canvas


GLYPH = extract_glyph()

for density, size in DENSITIES.items():
    outdir = RES / f"mipmap-{density}"
    outdir.mkdir(parents=True, exist_ok=True)
    compose(size, LEGACY_SCALE, circle=False, transparent=False).save(outdir / "ic_launcher.png", optimize=True)
    compose(size, LEGACY_SCALE, circle=True, transparent=False).save(outdir / "ic_launcher_round.png", optimize=True)
    print(f"ic_launcher(+round) {density}: {size}px")

for density, size in ADAPTIVE_DENSITIES.items():
    outdir = RES / f"mipmap-{density}"
    outdir.mkdir(parents=True, exist_ok=True)
    # foreground: TRANSPARENT + glyph — the adaptive background layer is the
    # white @color/ic_launcher_background, so no baked-in card / blue cast
    compose(size, FOREGROUND_SCALE, circle=False, transparent=True).save(outdir / "ic_launcher_foreground.png", optimize=True)
    print(f"ic_launcher_foreground {density}: {size}px")

print("ICONS GENERATED — clean white, no blue artifact")
