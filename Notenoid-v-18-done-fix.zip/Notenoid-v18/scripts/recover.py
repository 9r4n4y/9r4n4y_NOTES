#!/usr/bin/env python3
"""Independent Notenoid storage format 1 recovery. Does not import application code.
Requires Python 3.10+ and cryptography (python -m pip install cryptography).
Never overwrite an existing output directory. Seed/passwords are prompted, not argv.
"""
import argparse, base64, getpass, hashlib, json, os, re, sys
from pathlib import Path, PurePosixPath
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

def b64(s): return base64.b64decode(s, validate=True)
def derive(password, salt, iterations):
    if not 100000 <= iterations <= 2000000 or len(salt) < 16: raise ValueError('Invalid KDF parameters')
    return hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, iterations, 32)
def decrypt(key, value, context):
    if len(value) < 28: raise ValueError('Truncated encrypted data')
    return AESGCM(key).decrypt(value[:12], value[12:], context.encode('utf-8'))
def safe(path):
    p = PurePosixPath(path)
    if not path or p.is_absolute() or '\\' in path or any(x in ('', '.', '..') for x in path.split('/')) or any(ord(c)<32 for c in path): raise ValueError('Unsafe recovered path')
    return p

def recover(folder, seed, output, vault_password=None, checkpoint=None):
    folder = Path(folder)
    if not (folder/'key.json').is_file(): folder = folder/'notenoid.encrypted'
    header = json.loads((folder/'key.json').read_text())
    if header.get('format') != 'notenoid-storage' or header.get('version') != 1 or header.get('kdf') != 'PBKDF2-SHA256': raise ValueError('Unsupported storage format')
    storage_id = header['id']
    if not re.fullmatch(r'[a-f0-9]{32}', storage_id): raise ValueError('Invalid storage identifier')
    key = decrypt(derive(seed, b64(header['salt']), header['iterations']), b64(header['wrappedKey']), f'notenoid:recovery:{storage_id}')
    names = sorted(p.name for p in folder.glob('index-*.bin') if re.fullmatch(r'index-\d{12}-[a-f0-9]{32}\.bin', p.name))
    selected = checkpoint or (names[-1] if names else None)
    if selected not in names: raise ValueError('Authenticated checkpoint missing')
    revision = int(selected.split('-')[1])
    index = json.loads(decrypt(key, (folder/selected).read_bytes(), f'notenoid:index:{storage_id}:{revision}'))
    if index['version'] != 1 or index['revision'] != revision: raise ValueError('Checkpoint mismatch')
    expected_header = json.dumps([header[k] for k in ['format', 'version', 'id', 'kdf', 'iterations', 'salt', 'wrappedKey']], separators=(',', ':')).encode()
    if index['headerHash'] != base64.b64encode(hashlib.sha256(expected_header).digest()).decode(): raise ValueError('Recovery header authentication failed')
    vault_key = None
    vault_record = json.loads(index['prefs'].get('notes-vault-record-v2', 'null'))
    if vault_password is not None:
        if not vault_record or vault_record.get('v') != 3: raise ValueError('Vault credentials missing')
        slot = vault_record['password']
        wrapping_key = hashlib.sha256(vault_password.encode()).digest() if slot.get('legacy') else derive(vault_password, b64(slot['salt']), slot['iterations'])
        vault_key = decrypt(wrapping_key, b64(slot['box']), f"notenoid:vault:{vault_record['id']}:password")
    recovered = {}; locked = {}
    for name, entry in index['entries'].items():
        safe(name)
        if entry['kind'] == 'dir': continue
        object_id = entry['object']
        if not re.fullmatch(r'[a-f0-9]{32}', object_id): raise ValueError('Unsafe object identifier')
        ciphertext = (folder/'objects'/f'{object_id}.bin').read_bytes()
        if base64.b64encode(hashlib.sha256(ciphertext).digest()).decode() != entry['cipherHash']: raise ValueError('Object checksum mismatch')
        plain = decrypt(key, ciphertext, f'notenoid:object:{storage_id}:{object_id}')
        if entry['vault']:
            if vault_key is None:
                recovered[f'.vault-locked/{object_id}.bin'] = plain
                locked[name] = {'object': object_id, 'size': entry['size']}
                continue
            plain = decrypt(vault_key, plain, f'notenoid:vault-object:{object_id}')
        if len(plain) != entry['size']: raise ValueError('Recovered length mismatch')
        recovered[name] = plain
    recovered['.notenoid-recovered-preferences.json'] = json.dumps(index['prefs'], ensure_ascii=False, indent=2).encode()
    if locked: recovered['.vault-locked/manifest.json'] = json.dumps({'record': vault_record, 'files': locked}, ensure_ascii=False, indent=2).encode()
    # No output is written until every selected object authenticates successfully.
    output = Path(output)
    output.mkdir(mode=0o700, parents=False, exist_ok=False)
    for name, content in recovered.items():
        path = output.joinpath(*safe(name).parts)
        path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        with path.open('xb') as stream:
            os.chmod(path, 0o600); stream.write(content)
    return len(recovered), len(locked)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('folder', help='Container folder or its parent')
    parser.add_argument('output', help='New output directory (must not exist)')
    parser.add_argument('--include-vault', action='store_true', help='Also prompt for the separate vault password')
    parser.add_argument('--checkpoint', help='Explicit older index filename, only for deliberate rollback recovery')
    parser.add_argument('--seed-env', help='Automation only: environment variable containing seed (prefer interactive prompt)')
    parser.add_argument('--vault-env', help='Automation only: environment variable containing vault password')
    args = parser.parse_args()
    try:
        seed = os.environ[args.seed_env] if args.seed_env else getpass.getpass('Seed password: ')
        password = (os.environ[args.vault_env] if args.vault_env else getpass.getpass('Vault password: ')) if args.include_vault else None
        count, locked = recover(args.folder, seed, args.output, password, args.checkpoint)
        print(f'Recovered {count} output files; {locked} vault files remain separately encrypted.')
        print('WARNING: recovered ordinary files/preferences, and explicitly unlocked vault files, are plaintext. Keep them private.')
    except Exception as error:
        print(f'Recovery failed: wrong credential, damaged data, unsafe path, or output error ({type(error).__name__}: {error}). No credential was printed.', file=sys.stderr)
        return 1
    return 0
if __name__ == '__main__': sys.exit(main())
