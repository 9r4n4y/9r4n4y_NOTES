# Notenoid v18.0

Local-first, cross-platform Markdown notes with attachments, encrypted storage, and a separately protected vault.

- **Android app:** version 18.0, version code 180, package `com.notes.app`.
- **Web app:** the same Next.js/React source and local-first storage model.
- **Storage:** encrypted at rest after setup; no account or server is required for notes.

## v18 changes

See [`RELEASE-NOTES-V18.md`](RELEASE-NOTES-V18.md) for the release summary.

- Fixed independent width controls for image grids and single Markdown images. Multi-image insertion still produces a rendered image grid; ordinary Markdown image insertion still renders attachments.
- Reworked readable ZIP exports. Vault inclusion is optional and enabled by default; if selected, the existing vault password is verified but is never written into the ZIP. Attachments are included by default and remain optional. The completion message reports note, attachment, and vault-note counts.
- Readable ZIPs are not encrypted or password-protected. Vault notes included in one are plaintext. Importing a vault-containing archive requires a separately configured destination vault and its password; archive passwords and security answers are never imported or changed.
- The default Preview/Edit toggle switches immediately and restores a text-based viewport anchor. Anchoring uses rendered-to-source maps and nearest rendered characters for Markdown syntax, including tables and code.
- Fixed Preview/Edit scroll drift caused by landing on a newline between blocks.

## Build

See [`docs/BUILD.md`](docs/BUILD.md). The source ZIP includes the build scripts and Android shell. Build a web app with `npm ci && npm run build`; create the Android APK with the documented Android SDK prerequisites and `npm run build:apk`.

## Tests

The v18 validation record is in [`VALIDATION-V18.md`](VALIDATION-V18.md). Relevant commands include:

```sh
npm run typecheck
npm run test:security
npm run test:images
node test/preview-scroll-e2e.mjs
```

The browser tests require a running dev server and Playwright Chromium. They exercise attachment rendering, single/grid resizing, and Preview/Edit position retention in long Markdown containing paragraphs, tables, inline/fenced code, quotes, and lists.

## Security and backups

Readable exports are intentionally portable, plain ZIPs; treat them as sensitive files. A ZIP is not encrypted just because vault notes came from a protected vault. For disaster recovery, the separate encrypted-container recovery workflow is documented in [`docs/RECOVERY.md`](docs/RECOVERY.md). Keep external backups before uninstalling or changing devices.
