// ---------------------------------------------------------------------------
// — math markdown preprocessor.
//
// remark-math only understands $…$ / $$…$$, but people write math in many
// more shapes. This module normalises the four common forms BEFORE the
// markdown pipeline sees them, so KaTeX can render everything:
//
//   1. \[ x = \frac{-b \pm \sqrt{b^2-4ac}}{2a} \]   → $$ … $$  (display)
//   2. \( \sin^2\theta + \cos^2\theta = 1 \)        → $ … $    (inline)
//   3. BARE equation lines — a line that is "just math":
//         x = \frac{-b \pm \sqrt{b^2 - 4ac}}{2a}
//         a^2 - b^2 = (a-b)(a+b)
//         E = mc^2
//         a + b = c
//      → wrapped as $$ … $$ so they render as beautiful display blocks.
//
// Guarantees (important for the editor's edit↔preview scroll anchoring):
//   • the returned text has EXACTLY the same number of lines as the input —
//     transformations happen on the same line they were found on;
//   • fenced code blocks (``` / ~~~), YAML front-matter, inline code spans,
//     headings, list items, quotes, tables and raw HTML are never touched;
//   • prose is never mathified: a line containing ordinary words (3+ letter
//     words other than known function names) is left alone.
// ---------------------------------------------------------------------------

/** LaTeX control sequences that mark a line as math. */
const LATEX_CMD_RE = /\\(frac|dfrac|tfrac|sqrt|sum|int|prod|lim|log|ln|exp|sin|cos|tan|cot|sec|csc|arcsin|arccos|arctan|sinh|cosh|tanh|vec|hat|bar|dot|ddot|pm|mp|times|div|cdot|oplus|otimes|perp|parallel|angle|triangle|quad|qquad|left|right|begin|end|operatorname|mathbb|mathcal|mathbf|mathrm|text|mathfrak|boldsymbol|overline|underline|widehat|widetilde|overrightarrow|binom|choose|to|rightarrow|leftarrow|Rightarrow|infty|partial|nabla|forall|exists|in|notin|subset|supset|cup|cap|forall|approx|neq|leq|geq|equiv|sim|propto|alpha|beta|gamma|delta|epsilon|varepsilon|zeta|eta|theta|vartheta|iota|kappa|lambda|mu|nu|xi|pi|varpi|rho|varrho|sigma|varsigma|tau|upsilon|phi|varphi|chi|psi|omega|Gamma|Delta|Theta|Lambda|Xi|Pi|Sigma|Upsilon|Phi|Psi|Omega|displaystyle|limits|nonumber|tag|not|ldots|cdots|vdots|ddots|langle|rangle|lVert|rVert|mathop|overset|underset|stackrel|substack|cases|aligned|gathered|split|array|bmatrix|pmatrix|vmatrix|Bmatrix|Vmatrix|matrix)\b/;

/** Words that commonly appear inside math but are NOT prose indicators. */
const MATH_WORDS = new Set([
  "sin", "cos", "tan", "cot", "sec", "csc", "log", "ln", "lim", "sup", "inf",
  "max", "min", "det", "gcd", "lcm", "exp", "mod", "deg", "arg", "dim", "var",
  "const", "arc", "sinh", "cosh", "tanh", "coth", "and", "or", "dx", "dy",
  "dz", "dt", "du", "dv", "dw", "pi", "theta", "alpha", "beta", "gamma",
  "delta", "phi", "psi", "omega", "lambda", "mu", "nu", "sigma", "rho", "tau",
  "eta", "xi", "zeta", "kappa", "epsilon", "infty", "vec", "op", "rhs", "lhs",
]);

/**
 * Decide whether a trimmed line is a bare math equation.
 * Deliberately conservative: prose never gets wrapped.
 */
function isBareMathLine(line: string): boolean {
  const s = line.trim();
  if (!s || s.length > 160) return false;

  // markdown / html structure — never math
  if (/^(#{1,6}\s|>|[-*+]\s|\d+[.)]\s|\||!?\[|<|```|~~~|\$\$|~~~)/.test(s)) return false;
  if (/^(https?:|\/\/)/i.test(s)) return false;

  // already user-formatted math — leave for remark-math
  if (s.includes("$")) return false;

  // ordinary prose punctuation that math never uses
  if (/[""''"]/.test(s)) return false;
  // inline code on the line — leave the line untouched
  if (s.includes("`")) return false;
  // sentences (something followed by ". " then more words) are prose
  if (/\.\s+\w{3,}/.test(s)) return false;
  // exclamation / question sentences
  if (/[!?]/.test(s)) return false;

  // prose detection: 3+ letter words that are not math function names.
  // LaTeX commands (\frac, \cdot…) are stripped first — they are math,
  // not prose words.
  const words =
    s
      .replace(/\\[a-zA-Z]+/g, " ")
      .toLowerCase()
      .match(/[a-z]{3,}/g) ?? [];
  const proseWords = words.filter((w) => !MATH_WORDS.has(w));
  if (proseWords.length > 0) return false;

  const hasCmd = LATEX_CMD_RE.test(s);
  const hasSuperSub = /[\^_]/.test(s);
  const hasRelation = /[=<>±≤≥≠≈]|\bto\b/.test(s);
  const hasLetter = /[a-zA-Z]/.test(s);
  const hasDigit = /\d/.test(s);

  // must look like math at all
  if (!hasRelation && !hasSuperSub && !hasCmd) return false;

  // a LaTeX command (\frac, \sqrt, \theta …) is a strong signal
  if (hasCmd && proseWords.length === 0) return true;

  // superscript/subscript style: x^2 + y^2 = z^2  /  a_1 + a_2
  if (hasSuperSub && (hasRelation || hasCmd) && hasLetter) return true;

  // plain equations like "a + b = c", "D = b2 - 4ac", "1 + 1 = 2":
  // only math-ish characters, contains a relation and some variable
  if (hasRelation && hasLetter && !proseWords.length) {
    const stripped = s.replace(/[\s+\-*/=()^_{}[\].,|\\<>±×÷·√∑∫≤≥≠≈0-9a-zA-Z]/g, "");
    if (stripped.length === 0) return true;
  }

  // pure arithmetic "2 + 2 = 4"
  if (hasRelation && hasDigit && !hasLetter && !proseWords.length) {
    if (/^[\s\d+\-*/=().,^]+$/.test(s)) return true;
  }

  return false;
}

/**
 * Replace \( \) / \[ \] delimiters OUTSIDE of inline code spans on one line.
 * Keeps single-line text on a single line (line-count preservation).
 */
function transformDelimiters(line: string): string {
  // inline code spans are protected: split on `…`
  const parts = line.split(/(`[^`]*`)/g);
  return parts
    .map((part) => {
      if (part.startsWith("`") && part.endsWith("`")) return part;
      return (
        part
          // \( … \)  →  $ … $
          .replace(/\\\((.+?)\\\)/g, (_m, inner: string) => `$${inner}$`)
          // \[ … \]  →  $$ … $$   (may sit inline)
          .replace(/\\\[(.+?)\\\]/g, (_m, inner: string) => `$$${inner}$$`)
          // lone \( / \) pair spread as bare "\(" "\)" is untouched
      );
    })
    .join("");
}

export interface MathPreprocessOptions {
  /** also detect bare equation lines (default true) */
  bareLines?: boolean;
}

/**
 * Normalise all math delimiters in a markdown document.
 * Line count is preserved exactly.
 */
export function preprocessMathMarkdown(src: string, options: MathPreprocessOptions = {}): string {
  const { bareLines = true } = options;
  const lines = src.split("\n");
  const out: string[] = [];

  let inFence = false;
  let fenceMarker = "";
  let inFrontmatter = false;
  let inMathBlock = false;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // --- YAML front-matter (only at the very top) -------------------------
    if (i === 0 && line.trim() === "---") {
      inFrontmatter = true;
      out.push(line);
      continue;
    }
    if (inFrontmatter) {
      out.push(line);
      if (line.trim() === "---") {
        inFrontmatter = false;
      }
      continue;
    }

    // --- fenced code blocks ------------------------------------------------
    const fenceMatch = line.match(/^\s{0,3}(`{3,}|~{3,})/);
    if (fenceMatch) {
      const marker = fenceMatch[1][0];
      if (!inFence) {
        inFence = true;
        fenceMarker = marker;
      } else if (marker === fenceMarker && line.trim().match(/^[`~]+$/)) {
        inFence = false;
        fenceMarker = "";
      }
      out.push(line);
      continue;
    }
    if (inFence) {
      out.push(line);
      continue;
    }

    // --- normal content line -----------------------------------------------
    let next = transformDelimiters(line);

    // Multi-line \[ … \] blocks: an opener/closer line becomes $$ in place.
    // (same line count — the delimiters are replaced on their own lines)
    // NOTE: replacements use FUNCTION form — "$$" inside a plain replace
    // string is the escape for a literal "$" and would collapse.
    if (/^\\\[/u.test(next.trim())) next = next.replace(/\\\[/u, () => "$$");
    else if (/\\\]$/u.test(next.trim())) next = next.replace(/\\\]$/u, () => "$$");

    // Track $$ display blocks (openers may carry content: "$$x = 1").
    // Bare-line wrapping must NEVER touch lines inside a math block —
    // otherwise "A =" inside a \[ bmatrix \] block would be re-wrapped.
    const wasInMath = inMathBlock;
    if (!wasInMath && bareLines && isBareMathLine(next)) {
      const indent = next.match(/^\s*/)?.[0] ?? "";
      next = `${indent}$$${next.trim()}$$`;
    }

    const t = next.trim();
    if (!wasInMath) {
      if (t === "$$") inMathBlock = true;
      else if (t.startsWith("$$") && !(t.endsWith("$$") && t.length > 4)) inMathBlock = true;
    } else {
      if (t === "$$") inMathBlock = false;
      else if (t.endsWith("$$")) inMathBlock = false;
    }

    out.push(next);
  }

  return out.join("\n");
}
