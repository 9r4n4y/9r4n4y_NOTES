// ---------------------------------------------------------------------------
// special themes — heavy-decoration palettes that pair with custom CSS in
// globals.css (glass surfaces, gradients, glows). Defined separately from the
// main array for readability; themes.ts merges them at module load.
// ---------------------------------------------------------------------------

import type { ThemeDef } from "./themes";

const baseLight: Record<string, string> = {
  "card-foreground": "#1b1d21",
  "popover-foreground": "#1b1d21",
  "secondary-foreground": "#1b1d21",
  "accent-foreground": "#1b1d21",
  destructive: "#dc2626",
  radius: "0.625rem",
};

const baseDark: Record<string, string> = {
  "card-foreground": "#f0f1f3",
  "popover-foreground": "#f0f1f3",
  "secondary-foreground": "#f0f1f3",
  "accent-foreground": "#f0f1f3",
  destructive: "#ef4444",
  radius: "0.625rem",
};

function theme(
  id: string,
  name: string,
  mode: "light" | "dark",
  swatch: [string, string, string],
  vars: Record<string, string>
): ThemeDef {
  const group = "special" as const;
  return {
    id,
    name,
    mode,
    group,
    swatch,
    vars: { ...(mode === "dark" ? baseDark : baseLight), ...vars },
  };
}

export const SPECIAL_THEMES: ThemeDef[] = [
  // ---- Frutiger Aero: glossy glass over a bright sky-to-leaf gradient ----
  theme("frutiger-aero", "Frutiger Aero", "light", ["#cfe9f7", "#0284c7", "#d9f2d9"], {
    background: "#dff1fb",
    foreground: "#0c3c52",
    card: "#f7fdff",
    popover: "#f9feff",
    primary: "#0284c7",
    "primary-foreground": "#ffffff",
    secondary: "#e8f6fd",
    muted: "#e2f1f9",
    "muted-foreground": "#3f7288",
    accent: "#d9eefa",
    border: "#a9d8ee",
    input: "#9ed2ec",
    ring: "#0ea5e9",
    radius: "1.1rem",
  }),

  // ---- Vaporwave: neon pink/cyan over the classic dusk grid ---------------
  theme("vaporwave", "Vaporwave", "dark", ["#241b3a", "#ff71ce", "#3a2d66"], {
    background: "#241b3a",
    foreground: "#f5e9ff",
    card: "#2d2250",
    popover: "#322659",
    primary: "#ff71ce",
    "primary-foreground": "#2d0f22",
    secondary: "#352a5e",
    muted: "#31265a",
    "muted-foreground": "#b8a8d9",
    accent: "#3a2d66",
    border: "#4a3a7a",
    input: "#544191",
    ring: "#01cdfe",
    destructive: "#ff4757",
  }),

  // ---- Aurora: borealis glass in deep teal/indigo --------------------------
  theme("aurora", "Aurora", "dark", ["#0b1220", "#5eead4", "#14243a"], {
    background: "#0b1220",
    foreground: "#dbeafe",
    card: "#101a2e",
    popover: "#142036",
    primary: "#5eead4",
    "primary-foreground": "#04211c",
    secondary: "#16233c",
    muted: "#12203a",
    "muted-foreground": "#8fa3c4",
    accent: "#1b2b47",
    border: "#24344f",
    input: "#2b3d5c",
    ring: "#38bdf8",
    destructive: "#fb7185",
    radius: "0.875rem",
  }),
];
