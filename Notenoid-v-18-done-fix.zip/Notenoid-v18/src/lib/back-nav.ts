"use client";

import { useEffect, useRef } from "react";

// ---------------------------------------------------------------------------
// back-nav — unified BACK handling for the app's UI layers (, bug #3).
//
// One LIFO stack of "back handlers", consumed by:
//   • Android system back  → MainActivity evaluates window.__handleAndroidBack()
//     which runs the top handler. When nothing consumes the back press the
//     native shell does the app-home action (moveTaskToBack).
//   • Browser back (web)   → guarded history entries. Every UI layer pushes a
//     history entry on open; popstate closes the top layer; closing a layer
//     through its own UI consumes its history entry.
//
// Layers (in typical z-order): lightbox, image editor, note editor, dialogs,
// mobile drawer — plus a bottom "main view history" handler installed by
// KeepApp. The top-most handler wins, so BACK dismisses the surface the user
// actually sees, then the one below, and only exits when nothing is left.
// ---------------------------------------------------------------------------

type BackHandler = () => boolean;

interface StackEntry {
  id: number;
  handler: BackHandler;
}

const stack: StackEntry[] = [];
let seq = 0;

/** Register a handler. Returns an unregister function. */
export function addBackHandler(handler: BackHandler): () => void {
  const id = ++seq;
  stack.push({ id, handler });
  return () => removeBackHandler(id);
}

export function removeBackHandler(id: number): void {
  const idx = stack.findIndex((e) => e.id === id);
  if (idx >= 0) stack.splice(idx, 1);
}

/** Run the top-most handler. True when a layer consumed the back press. */
export function handleBack(): boolean {
  if (stack.length === 0) return false;
  try {
    return stack[stack.length - 1].handler();
  } catch (e) {
    console.error("back handler failed", e);
    return false;
  }
}

// ---------------------------------------------------------------- web history

let historyApiInstalled = false;

/** One browser history guard for the whole app. UI closes never call
 * history.back(): several layers can close together (vault + mobile drawer),
 * and queued back calls could otherwise leave the application entirely. */
export function installBackNavigation(): void {
  if (historyApiInstalled || typeof window === "undefined") return;
  historyApiInstalled = true;
  const w = window as unknown as {
    __handleAndroidBack?: () => boolean;
    __pushBackGuard?: () => void;
    __popBackGuard?: () => void;
    AndroidBridge?: unknown;
  };
  if (w.AndroidBridge) {
    w.__handleAndroidBack = () => handleBack();
    return;
  }
  w.__pushBackGuard = () => {};
  w.__popBackGuard = () => {};
  const push = () =>
    history.pushState({ ...history.state, notenoidBackGuard: true }, "");
  if (!history.state?.notenoidBackGuard) {
    history.replaceState({ ...history.state, notenoidBackBase: true }, "");
    push();
  }
  window.addEventListener("popstate", () => {
    if (handleBack()) {
      push();
      return;
    }
    // Only an explicit browser Back action reaches this path.
    if (history.state?.notenoidBackBase) history.back();
  });
}

/**
 * React hook: binds a UI layer's open state to the back stack. While `open`
 * is true the layer is the top-most back target (if registered last).
 */
export function useBackLayer(open: boolean, close: () => void): void {
  const closeRef = useRef(close);
  closeRef.current = close;

  useEffect(() => {
    if (!open) return;
    const remove = addBackHandler(() => {
      closeRef.current();
      return true;
    });
    // web history guard (no-op on Android)
    (window as unknown as { __pushBackGuard?: () => void }).__pushBackGuard?.();
    return () => {
      remove();
      (window as unknown as { __popBackGuard?: () => void }).__popBackGuard?.();
    };
  }, [open]);
}
