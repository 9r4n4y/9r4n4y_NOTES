"use client";
import {
  aes,
  b64,
  unb64,
  random,
  id,
  derive,
  seal,
  open,
  utf8,
  hexBytes,
  ITERATIONS,
} from "@/core/security/crypto";
import {
  securePreferences,
  flushPreferences,
} from "@/core/security/preferences";
export const VAULT_RECORD_KEY = "notes-vault-record-v2";
export const VAULT_LEGACY_CODE_KEY = "notes-vault-code-hash";
export const VAULT_SESSION_KEY = "notes-vault-open";
/** Minimum length for every password and security answer (v18). */
export const MIN_CREDENTIAL_LENGTH = 3;

/* --------------------------------------------------------------- v18 seed
 * recovery bridge ---------------------------------------------------------
 * The seed password wraps the whole encrypted storage. v18 lets the user
 * recover a forgotten seed with a vault security ANSWER: whenever answers are
 * known (vault setup, question change, answer-based vault reset), the storage
 * layer re-writes "seed-recovery.json" inside the container with slots that
 * wrap the raw storage key under each answer. The EncryptedFS instance sets
 * these hooks while storage is unlocked.
 */
export type SeedRecoveryPersist = (
  questions: { id: string; answer: string }[],
  /** current authoritative question ids — existing slots outside this list are dropped */
  validIds?: string[],
) => Promise<void>;
export const seedRecovery: {
  /** persist answer-wrapped storage-key slots (set by the unlocked EncryptedFS) */
  persist: SeedRecoveryPersist | null;
  /** current on-disk seed-recovery state, or null when unavailable */
  status: (() => Promise<{ slots: { id: string }[] } | null>) | null;
} = {
  persist: null,
  status: null,
};
export const SECURITY_QUESTIONS: { id: string; text: string }[] = [
  { id: "first_school", text: "What was the name of your first school?" },
  { id: "maiden_name", text: "What is your mother's maiden name?" },
  { id: "first_pet", text: "What was the name of your first pet?" },
  { id: "birth_city", text: "In which city were you born?" },
  { id: "favourite_book", text: "What is your favourite book?" },
  { id: "childhood_friend", text: "Who was your best childhood friend?" },
  {
    id: "first_vehicle",
    text: "What was the model of your first car or bike?",
  },
  { id: "favourite_food", text: "What is your favourite food?" },
  { id: "nickname", text: "What was your childhood nickname?" },
  { id: "grew_up_street", text: "What street did you grow up on?" },
  { id: "favourite_movie", text: "What is your favourite movie?" },
  { id: "first_job", text: "Where did you work for the first time?" },
  { id: "oldest_cousin", text: "What is your oldest cousin's name?" },
  { id: "first_teacher", text: "What was the name of your first teacher?" },
  { id: "dream_place", text: "What is your dream travel destination?" },
];

export function questionText(id: string): string {
  return (
    SECURITY_QUESTIONS.find((q) => q.id === id)?.text ?? "Security question"
  );
}

export interface SetupQuestionInput {
  id: string;
  answer: string;
}
type AnswerInput = SetupQuestionInput;
export interface KeySlot {
  salt: string;
  iterations: number;
  box: string;
  legacy?: boolean;
}
export interface VaultRecord {
  v: 3;
  id: string;
  password: KeySlot;
  questions: { id: string; slot: KeySlot }[];
}
let activeRaw: Uint8Array | null = null;
let activeKey: CryptoKey | null = null;
let session = false;
const normalise = (s: string) =>
  s.trim().replace(/\s+/g, " ").toLocaleLowerCase();
/** Shared answer normalisation — the seed-recovery slots must match it. */
export const normaliseAnswer = normalise;
export function readVaultRecord(): VaultRecord | null {
  const raw = securePreferences.getItem(VAULT_RECORD_KEY);
  if (!raw) return null;
  const r = JSON.parse(raw);
  if (r.v !== 3) throw Error("Vault protection needs storage migration");
  return r;
}
async function write(rec: VaultRecord) {
  securePreferences.setItem(VAULT_RECORD_KEY, JSON.stringify(rec));
  await flushPreferences();
}
export async function writeVaultRecord(rec: VaultRecord) {
  if (rec.v !== 3 || !rec.id || rec.questions.length > 2)
    throw Error("Invalid vault record");
  await write(rec);
}
export function vaultPasswordExists() {
  return !!securePreferences.getItem(VAULT_RECORD_KEY);
}
export function hasSecurityQuestions() {
  return readVaultRecord()?.questions.length === 2;
}
export function getSecurityQuestionIds() {
  return readVaultRecord()?.questions.map((q) => q.id) ?? [];
}
export function getVaultKey() {
  return activeKey;
}
export function requireVaultKey() {
  if (!activeKey) throw Error("Vault is locked. Enter its password.");
  return activeKey;
}
export function lockVault() {
  activeRaw?.fill(0);
  activeRaw = null;
  activeKey = null;
  session = false;
}
export function readVaultSession() {
  return session && !!activeKey;
}
export function writeVaultSession(open: boolean) {
  if (!open) lockVault();
  else session = !!activeKey;
}
async function activate(raw: Uint8Array) {
  activeRaw?.fill(0);
  activeRaw = new Uint8Array(raw);
  activeKey = await aes(raw);
}
function context(rec: Pick<VaultRecord, "id">, name: string) {
  return `notenoid:vault:${rec.id}:${name}`;
}
async function slotKey(password: string, slot: KeySlot) {
  if (slot.legacy)
    return aes(
      new Uint8Array(await crypto.subtle.digest("SHA-256", utf8(password))),
    );
  return derive(password, unb64(slot.salt), slot.iterations);
}
async function makeSlot(
  password: string,
  raw: Uint8Array,
  ctx: string,
): Promise<KeySlot> {
  const salt = random(16);
  const key = await derive(password, salt);
  return {
    salt: b64(salt),
    iterations: ITERATIONS,
    box: b64(await seal(key, raw, ctx)),
  };
}
async function unwrap(password: string, slot: KeySlot, ctx: string) {
  return open(await slotKey(password, slot), unb64(slot.box), ctx);
}
function validate(questions: [SetupQuestionInput, SetupQuestionInput]) {
  if (
    questions[0].id === questions[1].id ||
    questions.some(
      (q) =>
        !SECURITY_QUESTIONS.some((s) => s.id === q.id) ||
        q.answer.trim().length < MIN_CREDENTIAL_LENGTH,
    )
  )
    throw Error(
      "Choose two different questions and supply both answers (at least 3 characters each)",
    );
}
/** Best-effort sync of the seed-recovery slots whenever answers are known.
 * The vault record itself is already saved at this point — a seed-recovery
 * failure must not fail the credential change. Settings → Vault shows a
 * banner whenever the slots end up missing or out of date. */
async function syncSeedRecovery(
  questions: { id: string; answer: string }[],
  validIds?: string[],
) {
  if (!seedRecovery.persist) return;
  try {
    await seedRecovery.persist(questions, validIds);
  } catch {
    /* reported by the Settings → Vault seed-recovery banner */
  }
}
export async function setupVaultPassword(
  password: string,
  questions: [SetupQuestionInput, SetupQuestionInput],
) {
  if (vaultPasswordExists())
    throw Error("Vault already exists; use Change password");
  if (password.length < MIN_CREDENTIAL_LENGTH)
    throw Error("Use at least 3 characters for the vault password");
  validate(questions);
  const raw = random();
  const rec: VaultRecord = {
    v: 3,
    id: id(),
    password: null as unknown as KeySlot,
    questions: [],
  };
  try {
    rec.password = await makeSlot(password, raw, context(rec, "password"));
    for (const q of questions)
      rec.questions.push({
        id: q.id,
        slot: await makeSlot(
          normalise(q.answer),
          raw,
          context(rec, `answer:${q.id}`),
        ),
      });
    await write(rec);
    await activate(raw);
    await syncSeedRecovery(
      questions,
      questions.map((q) => q.id),
    );
  } finally {
    raw.fill(0);
  }
}
export async function verifyVaultPassword(password: string) {
  const rec = readVaultRecord();
  if (!rec) return false;
  let raw: Uint8Array;
  try {
    raw = await unwrap(password, rec.password, context(rec, "password"));
  } catch {
    return false;
  }
  await activate(raw);
  raw.fill(0);
  return true;
}
export async function changeVaultPassword(current: string, next: string) {
  if (next.length < MIN_CREDENTIAL_LENGTH) throw Error("Use at least 3 characters");
  if (!(await verifyVaultPassword(current))) return false;
  const rec = readVaultRecord()!;
  rec.password = await makeSlot(next, activeRaw!, context(rec, "password"));
  await write(rec);
  return true;
}
async function recoverKey(answers: AnswerInput[]): Promise<Uint8Array | null> {
  const rec = readVaultRecord();
  if (!rec) return null;
  for (const q of rec.questions) {
    const answer = answers.find((a) => a.id === q.id)?.answer;
    if (!answer?.trim()) continue;
    try {
      return await unwrap(
        normalise(answer),
        q.slot,
        context(rec, `answer:${q.id}`),
      );
    } catch {
      /* incorrect answer */
    }
  }
  return null;
}
export async function countCorrectSecurityAnswers(answers: AnswerInput[]) {
  const rec = readVaultRecord();
  if (!rec) return 0;
  let count = 0;
  for (const q of rec.questions) {
    const answer = answers.find((a) => a.id === q.id)?.answer;
    if (!answer?.trim()) continue;
    try {
      const raw = await unwrap(
        normalise(answer),
        q.slot,
        context(rec, `answer:${q.id}`),
      );
      raw.fill(0);
      count++;
    } catch {
      /* incorrect */
    }
  }
  return count;
}
export async function verifySecurityAnswers(answers: AnswerInput[]) {
  return (await countCorrectSecurityAnswers(answers)) > 0;
}
export async function resetVaultPassword(
  answers: AnswerInput[],
  newPassword: string,
) {
  if (newPassword.length < MIN_CREDENTIAL_LENGTH)
    throw Error("Use at least 3 characters");
  const raw = await recoverKey(answers);
  if (!raw) return false;
  try {
    const rec = readVaultRecord()!;
    rec.password = await makeSlot(newPassword, raw, context(rec, "password"));
    await write(rec);
    await activate(raw);
    // answers were proven correct here — refresh the seed-recovery slots too,
    // keeping untouched slots for questions that still exist in the record
    const proven = answers.filter((a) => a.answer.trim().length > 0);
    if (proven.length)
      await syncSeedRecovery(
        proven,
        rec.questions.map((q) => q.id),
      ).catch(() => {});
    return true;
  } finally {
    raw.fill(0);
  }
}
export async function setSecurityQuestions(
  password: string,
  currentAnswers: AnswerInput[],
  questions: [SetupQuestionInput, SetupQuestionInput],
) {
  validate(questions);
  if (!(await verifyVaultPassword(password))) return false;
  const rec = readVaultRecord()!;
  if (
    rec.questions.length === 2 &&
    !(await verifySecurityAnswers(currentAnswers))
  )
    return false;
  rec.questions = [];
  for (const q of questions)
    rec.questions.push({
      id: q.id,
      slot: await makeSlot(
        normalise(q.answer),
        activeRaw!,
        context(rec, `answer:${q.id}`),
      ),
    });
  await write(rec);
  await syncSeedRecovery(
    questions,
    questions.map((q) => q.id),
  );
  return true;
}
/** Existing password verifiers are derived keys; wrap a random vault key with
 * each one, then remove the verifiers. No password or answer change required. */
export async function migrateVaultPreferences(
  prefs: Record<string, string>,
): Promise<CryptoKey | null> {
  const old = prefs[VAULT_RECORD_KEY]
    ? JSON.parse(prefs[VAULT_RECORD_KEY])
    : null;
  if (old?.v === 3) return null;
  const legacy = prefs[VAULT_LEGACY_CODE_KEY];
  if (!old && !legacy) return null;
  const raw = random();
  const rec: VaultRecord = {
    v: 3,
    id: id(),
    password: null as unknown as KeySlot,
    questions: [],
  };
  const convert = async (
    hash: string,
    salt: string,
    ctx: string,
    legacy = false,
  ): Promise<KeySlot> => ({
    salt: legacy ? "" : b64(hexBytes(salt)),
    iterations: old?.iterations ?? 150_000,
    legacy,
    box: b64(await seal(await aes(hexBytes(hash)), raw, ctx)),
  });
  rec.password = await convert(
    old?.passwordHash ?? legacy,
    old?.salt ?? "",
    context(rec, "password"),
    !old,
  );
  for (const q of old?.questions ?? [])
    rec.questions.push({
      id: q.id,
      slot: await convert(q.answerHash, q.salt, context(rec, `answer:${q.id}`)),
    });
  prefs[VAULT_RECORD_KEY] = JSON.stringify(rec);
  delete prefs[VAULT_LEGACY_CODE_KEY];
  const key = await aes(raw);
  raw.fill(0);
  return key;
}
