"use client";

import { useEffect } from "react";
import { isAndroidShell } from "@/lib/android-theme";

/**
 * Keep the Android system bars in sync with the ACTIVE THEME.
 *
 * the theme system (24 themes + system-follow) owns the `dark` class and
 * the --background/--card variables, so the native status/navigation bars now
 * follow those directly (MutationObserver on <html>). On web this is a no-op
 * (the themeColor <meta> covers mobile browsers).
 */
export function SystemBarsSync() {
  useEffect(() => {
    if (!isAndroidShell()) return;

    const push = () => {
      const root = document.documentElement;
      const dark = root.classList.contains("dark");
      const style = getComputedStyle(root);
      const read = (name: string, fallback: string) => {
        const v = style.getPropertyValue(name).trim();
        return /^#[0-9a-fA-F]{6}([0-9a-fA-F]{2})?$/.test(v) ? v : fallback;
      };
      const statusHex = read("--background", dark ? "#111113" : "#f1f3f4");
      const navHex = read("--card", dark ? "#202124" : "#f1f3f4");
      const bridge = (
        window as unknown as {
          AndroidBridge?: {
            setSystemBars?: (s: string, n: string, darkStatus: boolean, darkNav: boolean) => void;
            setWebViewBackground?: (hex: string) => void;
          };
        }
      ).AndroidBridge;
      try {
        bridge?.setSystemBars?.(statusHex, navHex, !dark, !dark);
        bridge?.setWebViewBackground?.(statusHex);
      } catch {
        /* bridge missing — ignore */
      }
    };

    push();
    const observer = new MutationObserver(push);
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["class", "style"],
    });
    return () => observer.disconnect();
  }, []);

  return null;
}
