"use client";
import { useBackLayer } from "@/lib/back-nav";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useKeepStore, getRepo } from "./store";
import { readableBackup } from "@/core/security/backup";
import { saveBlob } from "@/lib/save-blob";
import { lockVault } from "@/lib/vault";
import { toast } from "sonner";

export function ExportDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const notes = useKeepStore((s) => s.notes), folders = useKeepStore((s) => s.folders);
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [includeVault, setIncludeVault] = useState(true);
  const [images, setImages] = useState(true);
  const [archive, setArchive] = useState(true);
  const [scope, setScope] = useState("");
  const [summary, setSummary] = useState("");
  useBackLayer(open, () => { if (!busy) { setPassword(""); onOpenChange(false); } });
  const hasVault = notes.some((n) => n.vaulted);

  async function run() {
    setBusy(true); setError(""); setSummary("");
    const wasOpen = useKeepStore.getState().vaultOpen;
    try {
      await useKeepStore.getState().flushAll();
      const result = await readableBackup(getRepo(), {
        vaultPassword: includeVault ? password : undefined,
        includeVault, includeArchive: archive, includeImages: images, folder: scope || null,
      });
      await saveBlob("notenoid-notes-v18.zip", new Blob([new Uint8Array(result.bytes)], { type: "application/zip" }));
      const report = `${result.count} notes exported · ${result.attachments} attachments exported · ${result.vaultNotes} vault notes exported`;
      setSummary(report);
      toast.success("Export complete", { description: report });
      setPassword("");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Export failed");
    } finally {
      if (!wasOpen) lockVault();
      setBusy(false);
    }
  }

  return <Dialog open={open} onOpenChange={(o) => { if (!busy) { if (!o) { setPassword(""); setError(""); setSummary(""); } onOpenChange(o); } }}>
    <DialogContent className="max-w-md">
      <DialogHeader><DialogTitle>Export notes</DialogTitle><DialogDescription>The ZIP itself is not password-protected. Any included notes and attachments can be read by anyone who has the file.</DialogDescription></DialogHeader>
      <div className="space-y-4">
        <label className="block text-sm">Ordinary notes to export<select aria-label="Export scope" className="mt-1 w-full rounded border bg-background p-2" value={scope} onChange={(e) => setScope(e.target.value)}><option value="">All notes</option>{folders.map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}</select></label>
        <label className="flex gap-2 text-sm"><input type="checkbox" checked={images} onChange={(e) => setImages(e.target.checked)} />Include attachments (recommended)</label>
        <label className="flex gap-2 text-sm"><input type="checkbox" checked={archive} onChange={(e) => setArchive(e.target.checked)} />Include archived ordinary notes</label>
        {hasVault && <div className="space-y-2 rounded border p-3">
          <label className="flex gap-2 text-sm font-medium"><input type="checkbox" checked={includeVault} onChange={(e) => { setIncludeVault(e.target.checked); setPassword(""); }} />Include vault notes</label>
          {includeVault && <><p className="text-xs text-muted-foreground">Enter your existing vault password to authorize the export. It is only verified; no password, vault credentials, or security answers are written into the ZIP.</p><Input aria-label="Export vault password" placeholder="Vault password" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} /></>}
        </div>}
        <p className="text-xs text-muted-foreground">Attachments are on by default and remain optional. Exported vault notes are plaintext in this ZIP; the ZIP does not carry vault access settings.</p>
        {summary && <p role="status" className="rounded bg-accent p-2 text-sm font-medium">{summary}</p>}
        {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
        <Button className="w-full" disabled={busy || (includeVault && hasVault && !password)} onClick={() => void run()}>{busy ? "Exporting…" : "Export password-free ZIP"}</Button>
      </div>
    </DialogContent>
  </Dialog>;
}
