"use client";

import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { useKeepStore, type LightboxAttachment } from "./store";
import { Download, PenLine, ImageOff, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { saveBlob } from "@/lib/save-blob";
import { useBackLayer } from "@/lib/back-nav";
import { encodeAttachmentPath } from "@/core/markdown";

export function Lightbox({
  attachment,
  onClose,
}: {
  attachment: LightboxAttachment | null;
  onClose: () => void;
}) {
  // (bug #3): BACK closes the lightbox first
  useBackLayer(!!attachment, onClose);
  return (
    <Dialog open={!!attachment} onOpenChange={(o) => !o && onClose()}>
      <DialogContent
        className="max-w-3xl border-none bg-transparent p-0 shadow-none [&>button]:rounded-full [&>button]:bg-primary/80 [&>button]:p-1"
        onClick={(e) => e.stopPropagation()}
      >
        <DialogTitle className="sr-only">Media preview</DialogTitle>
        {attachment ? (
          <div className="flex flex-col items-center gap-3">
            <img
              src={attachment.url}
              alt={attachment.name}
              className="mx-auto max-h-[78vh] w-auto max-w-full rounded-lg object-contain"
            />
            <LightboxToolbar att={attachment} onClose={onClose} />
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}

function LightboxToolbar({
  att,
  onClose,
}: {
  att: LightboxAttachment;
  onClose: () => void;
}) {
  const notes = useKeepStore((s) => s.notes);
  const openImageEditor = useKeepStore((s) => s.openImageEditor);
  const removeNoteAttachment = useKeepStore((s) => s.removeNoteAttachment);

  function edit() {
    const noteId = att.noteId ?? notes.find((n) => n.attachments.some((a) => a.id === att.id))?.id;
    if (noteId) {
      openImageEditor(noteId, att);
    } else {
      toast.error("Could not find the note this image belongs to");
    }
  }

  /** every string that could reference this image inside the saved
   * markdown: the display URL(s), the raw attachment path and its encoded
   * (percent-escaped) variant. */
  function referenceCandidates(): string[] {
    const cands = new Set<string>();
    for (const u of [att.markdownUrl, att.url, att.file]) if (u) cands.add(u);
    try {
      const enc = encodeAttachmentPath(att.file || "");
      if (enc) cands.add(enc);
    } catch { /* ignore */ }
    return [...cands].filter(Boolean);
  }

  /** strip the image from markdown body text (md image/link + <img> tags) */
  function stripReferences(body: string): string {
    let next = body;
    for (const cand of referenceCandidates()) {
      const esc = cand.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      next = next.replace(new RegExp(`!\\[[^\\]]*\\]\\(\\s*${esc}[^)]*\\)\\s*`, "g"), "");
      next = next.replace(new RegExp(`\\[([^\\]]*)\\]\\(\\s*${esc}[^)]*\\)`, "g"), "$1");
      next = next.replace(new RegExp(`\\s*<img\\b[^>]*\\bsrc="${esc}"[^>]*>\\s*`, "gi"), "");
    }
    // collapse now-empty grid wrappers + leftover blank runs
    next = next.replace(/<div class="img-grid"[^>]*>\s*(<br\s*\/?>)?\s*<\/div>\s*/gi, "");
    next = next.replace(/<div class="img-grid"[^>]*>\s*<\/div>\s*/gi, "");
    next = next.replace(/\n{3,}/g, "\n\n");
    return next;
  }

  /** strip the image from the note BODY markdown (grid wrappers collapse). */
  function removeFromNote() {
    if (!att.noteId) return;
    const note = notes.find((n) => n.id === att.noteId);
    if (!note) {
      toast.error("Could not find the note this image belongs to");
      return;
    }
    const next = stripReferences(note.content);
    if (next !== note.content) {
      useKeepStore.getState().updateNote(note.id, { content: next }, true);
    }
    onClose();
    toast.success("Image removed from note");
  }

  /** remove from the body AND delete the attachment file itself. */
  function deleteEverywhere() {
    if (!att.noteId) return;
    const note = notes.find((n) => n.id === att.noteId);
    if (note) {
      const next = stripReferences(note.content);
      if (next !== note.content) {
        useKeepStore.getState().updateNote(note.id, { content: next }, true);
      }
    }
    void removeNoteAttachment(att.noteId, att);
    onClose();
    toast.success("Image deleted");
  }

  const canManage = !!att.noteId;

  return (
    <div className="flex flex-wrap items-center justify-center gap-2 pb-1">
      <button
        type="button"
        onClick={edit}
        className="inline-flex items-center gap-1.5 rounded-full bg-neutral-900/85 px-3.5 py-1.5 text-xs font-medium text-white shadow transition-colors hover:bg-neutral-900"
      >
        <PenLine className="h-3.5 w-3.5" /> Edit image
      </button>
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          try {
            fetch(att.url)
              .then((r) => r.blob())
              .then((b) => saveBlob(att.name || "image", b))
              .catch(() => toast.error("Download failed"));
          } catch {
            toast.error("Download failed");
          }
        }}
        className="inline-flex items-center gap-1.5 rounded-full bg-neutral-900/85 px-3.5 py-1.5 text-xs font-medium text-white shadow transition-colors hover:bg-neutral-900"
      >
        <Download className="h-3.5 w-3.5" /> Download
      </button>
      {canManage ? (
        <>
          <button
            type="button"
            onClick={removeFromNote}
            className="inline-flex items-center gap-1.5 rounded-full bg-neutral-900/85 px-3.5 py-1.5 text-xs font-medium text-white shadow transition-colors hover:bg-neutral-900"
          >
            <ImageOff className="h-3.5 w-3.5" /> Remove from note
          </button>
          <button
            type="button"
            onClick={deleteEverywhere}
            className="inline-flex items-center gap-1.5 rounded-full bg-red-600/90 px-3.5 py-1.5 text-xs font-medium text-white shadow transition-colors hover:bg-red-600"
          >
            <Trash2 className="h-3.5 w-3.5" /> Delete image
          </button>
        </>
      ) : null}
      {att.kind === "gif" ? (
        <span className="rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-medium text-white backdrop-blur-sm">
          GIF
        </span>
      ) : null}
    </div>
  );
}
