"use client";

import { useEffect } from "react";
import { NoteCard } from "./NoteCard";
import { EmptyState } from "./EmptyState";
import { MuuriGrid } from "./MuuriGridLazy";
import { useKeepStore, filterBySearch, scopeNotes, sortNotes } from "./store";
import { useSettings, DENSITY_CLASS } from "./settings-store";
import { StickyNote } from "lucide-react";
import type { NoteDTO } from "@/lib/types";

function Section({
  title,
  notes,
  layout,
  small,
  dragEnabled,
  onReorderCommit,
}: {
  title?: string;
  notes: NoteDTO[];
  layout: "grid" | "list";
  small?: boolean;
  dragEnabled?: boolean;
  onReorderCommit?: (ids: string[]) => void;
}) {
  const { density, animations } = useSettings();
  const d = DENSITY_CLASS[density];
  const selectionMode = useKeepStore((s) => s.selectionMode);
  const selectedIds = useKeepStore((s) => s.selectedIds);

  if (notes.length === 0) return null;

  const noteById = new Map(notes.map((n) => [n.id, n]));
  const selectedSet = new Set(selectedIds);

  // grid AND list share one Muuri pipeline — the list layout is simply
  // a 1-column grid, so long-press reordering is identical (and stable) in
  // both layouts. Muuri owns all reflow animation; the store is updated once
  // per completed drag.
  return (
    <section aria-label={title}>
      {title ? (
        <h2 className={`mb-4 font-medium text-foreground/70 ${small ? "text-xs uppercase tracking-wider" : "text-sm"}`}>
          {title}
        </h2>
      ) : null}
      <MuuriGrid
        itemIds={notes.map((n) => n.id)}
        gap={d.gridGap}
        colsOverride={layout === "list" ? 1 : undefined}
        className={layout === "list" ? "mx-auto max-w-4xl" : undefined}
        dragEnabled={!!dragEnabled && !selectionMode && notes.length > 1}
        animations={animations}
        onReorder={onReorderCommit}
        renderItem={(id, index) => {
          const note = noteById.get(id);
          if (!note) return null;
          return (
            <NoteCard
              note={note}
              layout={layout}
              index={index}
              selectMode={selectionMode}
              selected={selectedSet.has(id)}
            />
          );
        }}
      />
    </section>
  );
}

export function NotesView({ heading }: { heading?: string }) {
  const notes = useKeepStore((s) => s.notes);
  const view = useKeepStore((s) => s.view);
  const activeFolderId = useKeepStore((s) => s.activeFolderId);
  const activeLabelId = useKeepStore((s) => s.activeLabelId);
  const search = useKeepStore((s) => s.search);
  const layout = useKeepStore((s) => s.layout);
  const reorderNotes = useKeepStore((s) => s.reorderNotes);
  const settings = useSettings();

  let scoped = scopeNotes(notes, view, activeFolderId, activeLabelId);

  // Optional: when searching from the main view, also surface archived notes
  // (setting-controlled; archived notes show an "Archived" badge + unarchive).
  if (search && settings.searchIncludeArchive && view === "notes") {
    const archived = notes.filter((n) => !n.trashed && n.archived && !n.vaulted);
    const seen = new Set(scoped.map((n) => n.id));
    scoped = [...scoped, ...archived.filter((n) => !seen.has(n.id))];
  }

  const results = sortNotes(filterBySearch(scoped, search));

  // publish the visible ids so the bulk bar's "select all" acts on
  // exactly what the user sees (view + search aware)
  const visibleKey = results.map((n) => n.id).join(",");
  const setVisibleIds = useKeepStore((s) => s.setVisibleIds);
  useEffect(() => {
    setVisibleIds(visibleKey.length > 0 ? visibleKey.split(",") : []);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visibleKey, setVisibleIds]);

  // drag-and-drop ordering: main list views without an active search filter
  const canReorder = !search && (view === "notes" || view === "folder" || view === "label");

  if (results.length === 0) {
    if (search) {
      return <EmptyState icon={StickyNote} title="No matching notes" subtitle={`Nothing matches "${search}" in this view`} />;
    }
    switch (view) {
      case "vault":
        return <EmptyState icon={StickyNote} title="Your vault is empty" subtitle="Move notes here from a note's menu while the vault is open" />;
      case "archive":
        return <EmptyState icon={StickyNote} title="No archived notes" subtitle="Archive notes to tuck them away without deleting" />;
      case "trash":
        return <EmptyState icon={StickyNote} title="Nothing in trash" subtitle="Deleted notes rest here until you remove them forever" />;
      case "folder":
        return <EmptyState icon={StickyNote} title="This folder is empty" subtitle="Move notes here from a note's menu" />;
      case "label":
        return <EmptyState icon={StickyNote} title="No notes with this label" subtitle="Tag notes from a note's toolbar" />;
      default:
        return <EmptyState icon={StickyNote} title="Notes you add appear here" />;
    }
  }

  const showSections = view === "notes" || view === "folder" || view === "label";
  const pinned = results.filter((n) => n.pinned);
  const others = results.filter((n) => !n.pinned);

  const commit = (ids: string[]) => {
    if (ids.length > 0) reorderNotes(ids);
  };

  if (!showSections || pinned.length === 0) {
    return (
      <div className="space-y-8">
        {heading ? <h1 className="text-sm font-medium uppercase tracking-wider text-foreground/60">{heading}</h1> : null}
        <Section
          notes={results}
          layout={layout}
          dragEnabled={canReorder}
          onReorderCommit={commit}
        />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {heading ? <h1 className="text-sm font-medium uppercase tracking-wider text-foreground/60">{heading}</h1> : null}
      <Section
        title="PINNED"
        notes={pinned}
        layout={layout}
        small
        dragEnabled={canReorder}
        onReorderCommit={commit}
      />
      <Section
        title="OTHERS"
        notes={others}
        layout={layout}
        small
        dragEnabled={canReorder}
        onReorderCommit={commit}
      />
    </div>
  );
}
