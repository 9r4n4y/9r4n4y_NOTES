"use client";
import { useBackLayer } from "@/lib/back-nav";
import { useState, useRef } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useKeepStore, getRepo } from "./store";
import {
  inspectReadableBackup,
  importReadableBackup,
} from "@/core/security/backup";
import { vaultPasswordExists, lockVault } from "@/lib/vault";
import { toast } from "sonner";
export function ImportDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [bytes, setBytes] = useState<Uint8Array | null>(null),
    [info, setInfo] = useState<{
      vault: boolean;
      notes: number;
    } | null>(null),
    [password, setPassword] = useState(""),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [summary, setSummary] = useState("");
  const input = useRef<HTMLInputElement>(null);
  // Subscribe so completing setup behind this dialog refreshes vault readiness.
  const vaultSetupOpen = useKeepStore((s) => s.vaultSetupOpen);
  useBackLayer(open, () => {
    if (!busy) {
      setPassword("");
      setBytes(null);
      setInfo(null);
      onOpenChange(false);
    }
  });
  async function choose(file: File) {
    setError("");
    setSummary("");
    setInfo(null);
    setBytes(null);
    setBusy(true);
    try {
      if (file.size > 256 * 1024 * 1024)
        throw Error("ZIP exceeds the 256 MiB input limit");
      const data = new Uint8Array(await file.arrayBuffer());
      setInfo(await inspectReadableBackup(data));
      setBytes(data);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Unreadable ZIP");
    } finally {
      setBusy(false);
    }
  }
  async function run() {
    if (!bytes) return;
    setBusy(true);
    setError("");
    const wasOpen = useKeepStore.getState().vaultOpen;
    try {
      await useKeepStore.getState().flushAll();
      const result = await importReadableBackup(getRepo(), bytes, {
        vaultPassword: password,
      });
      setSummary(`${result.notes} notes imported · ${result.vault} vault notes imported. Your existing vault password and security questions were not changed.`);
      setPassword("");
      setBytes(null);
      setInfo(null);
      toast.success("Import complete");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Import failed");
    } finally {
      if (!wasOpen) lockVault();
      await useKeepStore.getState().rescan();
      setBusy(false);
    }
  }
  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!busy) {
          setPassword("");
              setBytes(null);
          setInfo(null);
          setError("");
          setSummary("");
          onOpenChange(o);
        }
      }}
    >
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Import backup</DialogTitle>
          <DialogDescription>
            Readable ZIPs do not carry vault passwords or security answers. Vault notes can only be imported into a vault you set up yourself; importing never replaces its password or recovery questions.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <input
            ref={input}
            type="file"
            accept=".zip,application/zip"
            aria-label="Backup ZIP"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void choose(f);
              e.target.value = "";
            }}
            disabled={busy}
          />
          {info && (
            <p className="text-sm">
              {info.notes} notes found{info.vault ? ", including vault notes" : ""}.
            </p>
          )}
          {info?.vault && (
            <>
              {!vaultPasswordExists() ? (
                <div className="space-y-2 rounded border border-amber-500/40 bg-amber-500/5 p-3 text-sm">
                  <p>This backup contains vault notes. Create your own vault first; the backup cannot supply or change its password or security questions. Then return here and import again.</p>
                  <Button variant="outline" disabled={vaultSetupOpen} onClick={() => useKeepStore.getState().setVaultSetupOpen(true)}>{vaultSetupOpen ? "Finish vault setup to continue" : "Set up my vault"}</Button>
                </div>
              ) : (
                <>
                  <p className="text-sm">Enter your existing destination vault password to authorize adding these notes to your vault. The ZIP contains no password, and its security questions will never be imported.</p>
                  <Input type="password" aria-label="Destination vault password" placeholder="Your vault password" value={password} onChange={(e) => setPassword(e.target.value)} />
                </>
              )}
            </>
          )}
          {summary && (
            <p role="status" className="text-sm">
              {summary}
            </p>
          )}
          {error && (
            <p role="alert" className="text-sm text-destructive">
              {error}
            </p>
          )}
          <Button
            disabled={busy || !bytes || (!!info?.vault && (!vaultPasswordExists() || !password))}
            onClick={() => void run()}
          >
            {busy ? "Verifying / importing…" : "Import notes"}
          </Button>
          <p className="text-xs text-muted-foreground">
            Encrypted folder recovery is separate from readable ZIP import and requires its original storage seed. Readable ZIP import never overwrites destination vault credentials or security questions.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
