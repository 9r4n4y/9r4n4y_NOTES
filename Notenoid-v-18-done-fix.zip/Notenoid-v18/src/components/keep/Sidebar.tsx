"use client";

import { Button } from "@/components/ui/button";
import { useKeepStore } from "./store";
import { useSettings } from "./settings-store";
import { cn } from "@/lib/utils";
import {
  Archive,
  Folder as FolderIcon,
  StickyNote,
  Lock,
  Pencil,
  Plus,
  Tags,
  Trash2,
  Settings,
  X,
} from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import type { LucideIcon } from "lucide-react";
import { toast } from "sonner";

interface NavItem {
  key: string;
  label: string;
  icon: LucideIcon;
}

const MAIN_NAV: NavItem[] = [
  { key: "notes", label: "Notes", icon: StickyNote },
  { key: "folders", label: "Folders", icon: FolderIcon },
  { key: "archive", label: "Archive", icon: Archive },
  { key: "vault", label: "Vault", icon: Lock },
  { key: "trash", label: "Trash", icon: Trash2 },
];

export function Sidebar({
  open,
  mobileOpen,
  onCloseMobile,
  onNewFolder,
  onManageLabels,
}: {
  open: boolean;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  onNewFolder: () => void;
  onManageLabels: () => void;
}) {
  const view = useKeepStore((s) => s.view);
  const activeFolderId = useKeepStore((s) => s.activeFolderId);
  const activeLabelId = useKeepStore((s) => s.activeLabelId);
  const setView = useKeepStore((s) => s.setView);
  const folders = useKeepStore((s) => s.folders);
  const labels = useKeepStore((s) => s.labels);
  const notes = useKeepStore((s) => s.notes);
  const vaultOpen = useKeepStore((s) => s.vaultOpen);
  const requestVaultAccess = useKeepStore((s) => s.requestVaultAccess);
  const closeVault = useKeepStore((s) => s.closeVault);
  const setSettingsOpen = useKeepStore((s) => s.setSettingsOpen);
  const settings = useSettings();

  const expanded = open || mobileOpen;
  const notesCount = notes.filter((n) => !n.trashed && !n.archived && !n.vaulted).length;

  const countFor = (key: string) => {
    switch (key) {
      case "notes":
        return notesCount;
      case "archive":
        return notes.filter((n) => n.archived && !n.trashed && !n.vaulted).length;
      case "trash":
        return notes.filter((n) => n.trashed).length;
      case "vault":
        // count is only revealed while the vault is open (no metadata leak)
        return vaultOpen ? notes.filter((n) => n.vaulted && !n.trashed).length : undefined;
      default:
        return undefined;
    }
  };

  const isActive = (key: string) => {
    if (key === "folders") return view === "folders";
    if (key === "vault") return view === "vault" && vaultOpen;
    return view === key;
  };

  function go(key: string) {
    if (key === "vault") {
      // always visible — tapping asks for the password (or runs the
      // one-time setup) when the vault is not open in this session.
      requestVaultAccess();
      onCloseMobile();
      return;
    }
    setView(key as never);
    onCloseMobile();
  }

  function renderButton(
    item: { key: string; label: string; icon: LucideIcon },
    active: boolean,
    onClick: () => void,
    trailing?: React.ReactNode
  ) {
    const content = (
      <button
        type="button"
        onClick={onClick}
        className={cn(
          "group relative flex h-10 items-center gap-3 rounded-full text-sm transition-[background-color,color] duration-150 active:scale-[0.98]",
          expanded ? "w-full px-3.5" : "mx-auto w-10 justify-center px-0",
          active
            ? "bg-primary/12 font-medium text-foreground"
            : "text-foreground/75 hover:bg-black/5 hover:text-foreground dark:hover:bg-white/10"
        )}
      >
        {active ? (
          <span
            aria-hidden
            className="absolute -left-2 top-1/2 h-5 w-1 -translate-y-1/2 rounded-full bg-primary"
          />
        ) : null}
        <item.icon className={cn("h-5 w-5 shrink-0 transition-transform duration-150 group-active:scale-90", active ? "text-current" : "text-foreground/60")} />
        {expanded ? (
          <>
            <span className="min-w-0 flex-1 truncate text-left">{item.label}</span>
            {trailing}
          </>
        ) : null}
      </button>
    );
    if (!expanded) {
      return (
        <Tooltip key={item.key}>
          <TooltipTrigger asChild>{content}</TooltipTrigger>
          <TooltipContent side="right" className="text-xs">
            {item.label}
          </TooltipContent>
        </Tooltip>
      );
    }
    return <div key={item.key}>{content}</div>;
  }

  return (
    <>
      {/* mobile scrim — always mounted, fades for a buttery transition */}
      <div
        className={cn(
          "fixed inset-0 z-40 bg-black/40 backdrop-blur-[2px] transition-opacity duration-200 md:hidden",
          mobileOpen ? "opacity-100" : "pointer-events-none opacity-0"
        )}
        onClick={onCloseMobile}
        aria-hidden={!mobileOpen}
      />

      {/*
        — full-height navigation panel.
        The panel now spans the ENTIRE screen height on both form factors:
        • mobile: a fixed drawer from the very top of the screen (over the
          top bar) down to the bottom — no more dead blurred strip above it;
        • desktop: an edge-to-edge sticky rail (h-screen) that sits LEFT of
          the top bar in the new app-shell layout.
      */}
      <nav
        aria-label="Main navigation"
        className={cn(
          "app-sidebar z-50 flex shrink-0 flex-col gap-0.5 overflow-y-auto overflow-x-hidden pb-6",
          // fix: horizontal padding so the active-row indicator dot
          // (absolutely positioned at -left-2) is never clipped by the
          // overflow-x-hidden scrollbar guard — it used to render half-cut
          "px-2",
          // mobile: full-height drawer (covers the whole left side, top to bottom)
          "fixed inset-y-0 left-0 w-64 bg-background shadow-2xl transition-transform duration-300 [transition-timing-function:cubic-bezier(0.22,1,0.36,1)]",
          // desktop: sticky full-height rail beside the content column
          "md:sticky md:top-0 md:h-screen md:translate-x-0 md:shadow-none md:border-r md:border-border/50",
          // desktop rail surface follows the active theme
          "md:bg-card/40 md:backdrop-blur-2xl",
          mobileOpen ? "translate-x-0" : "-translate-x-full",
          open ? "md:w-64" : "md:w-[5rem]"
        )}
        style={{ paddingTop: "max(env(safe-area-inset-top), 0.5rem)" }}
      >
        {/* brand header — the decorative icon is gone; the panel starts
            with the app name itself, plus a mobile close affordance */}
        {expanded ? (
          <div className="mb-2 px-3 pt-2">
            <div className="flex items-center gap-2 rounded-2xl border border-black/5 bg-card/70 px-3 py-2.5 shadow-sm dark:border-white/10">
              <span className="min-w-0 flex-1">
                <span className="block truncate text-base font-semibold leading-tight tracking-tight">
                  {settings.appName}
                </span>
                <span className="block text-[11px] leading-tight text-muted-foreground">
                  {notesCount} note{notesCount === 1 ? "" : "s"} · local-first
                </span>
              </span>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 shrink-0 rounded-full md:hidden"
                aria-label="Close menu"
                title="Close menu"
                onClick={onCloseMobile}
              >
                <X className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 shrink-0 rounded-full"
                aria-label="Settings"
                title="Settings"
                onClick={() => {
                  setSettingsOpen(true);
                  onCloseMobile();
                }}
              >
                <Settings className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ) : (
          <div className="mb-1 mt-2 flex justify-center" aria-hidden>
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9 rounded-full"
              aria-label="Settings"
              title="Settings"
              onClick={() => {
                setSettingsOpen(true);
                onCloseMobile();
              }}
            >
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        )}

        {MAIN_NAV.map((item) =>
          renderButton(
            item,
            isActive(item.key),
            () => go(item.key),
            item.key === "vault" ? (
              vaultOpen ? (
                // fix: the vault count used to be jammed INSIDE the lock
                // button ({count}<Lock/>) — the digits touched the icon and
                // long counts overlapped the row. Count pill + lock button
                // are now separate, gap-spaced, and never shrink.
                <span className="inline-flex shrink-0 items-center gap-1">
                  <span
                    aria-label={`${countFor("vault") ?? 0} vaulted notes`}
                    className="rounded-full bg-black/5 px-2 py-0.5 text-[11px] font-medium tabular-nums leading-5 text-muted-foreground dark:bg-white/10"
                  >
                    {countFor("vault") ?? 0}
                  </span>
                  <span
                    role="button"
                    tabIndex={0}
                    aria-label="Lock vault"
                    title="Lock vault"
                    className="inline-flex cursor-pointer rounded-full p-1 hover:bg-black/10 dark:hover:bg-white/10"
                    onClick={(e) => {
                      e.stopPropagation();
                      closeVault();
                      onCloseMobile();
                    }}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.stopPropagation();
                        closeVault();
                        onCloseMobile();
                      }
                    }}
                  >
                    <Lock className="h-3.5 w-3.5" />
                  </span>
                </span>
              ) : (
                <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-black/5 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide text-muted-foreground dark:bg-white/10">
                  <Lock className="h-3 w-3" /> locked
                </span>
              )
            ) : countFor(item.key) !== undefined && countFor(item.key) !== null && (countFor(item.key) as number) > 0 ? (
              <span className="shrink-0 rounded-full bg-black/5 px-2 py-0.5 text-[11px] tabular-nums leading-5 text-muted-foreground dark:bg-white/10">
                {countFor(item.key)}
              </span>
            ) : undefined
          )
        )}

        <div className={cn("mt-3 flex items-center", expanded ? "px-4" : "justify-center")}>
          {expanded ? (
            <div className="flex w-full items-center justify-between border-t border-black/5 pt-3 dark:border-white/10">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Folders
              </p>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                aria-label="New folder"
                onClick={() => {
                  onNewFolder();
                  onCloseMobile();
                }}
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              aria-label="New folder"
              onClick={() => {
                onNewFolder();
                onCloseMobile();
              }}
            >
              <Plus className="h-4 w-4" />
            </Button>
          )}
        </div>

        {folders.map((f) =>
          renderButton(
            { key: f.id, label: `${f.name}`, icon: (() => <span>{f.emoji}</span>) as unknown as LucideIcon },
            view === "folder" && activeFolderId === f.id,
            () => {
              setView("folder", f.id);
              onCloseMobile();
            },
            <span className="shrink-0 rounded-full bg-black/5 px-2 py-0.5 text-[11px] tabular-nums leading-5 text-muted-foreground dark:bg-white/10">
              {notes.filter((n) => !n.trashed && !n.archived && !n.vaulted && n.folderId === f.id).length || ""}
            </span>
          )
        )}

        {expanded ? (
          <div className="mt-3 px-4">
            <div className="flex items-center justify-between border-t border-black/5 pt-3 dark:border-white/10">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Labels
              </p>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                aria-label="Edit labels"
                onClick={() => {
                  onManageLabels();
                  onCloseMobile();
                }}
              >
                <Pencil className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        ) : null}

        {labels.map((l) =>
          renderButton(
            { key: l.id, label: l.name, icon: Tags },
            view === "label" && activeLabelId === l.id,
            () => {
              setView("label", l.id);
              onCloseMobile();
            },
            <span className="shrink-0 rounded-full bg-black/5 px-2 py-0.5 text-[11px] tabular-nums leading-5 text-muted-foreground dark:bg-white/10">
              {notes.filter((n) => !n.trashed && !n.archived && !n.vaulted && n.labels.some((nl) => nl.id === l.id)).length || ""}
            </span>
          )
        )}

        {labels.length === 0 && expanded ? (
          <button
            type="button"
            onClick={() => {
              onManageLabels();
              onCloseMobile();
              toast("Create your first label here", { description: "Labels let you tag and filter notes." });
            }}
            className="mx-4 mt-1 rounded-md px-2 py-2 text-left text-xs text-muted-foreground hover:bg-accent"
          >
            + Create labels to tag notes
          </button>
        ) : null}
      </nav>
    </>
  );
}
