"use client";

import { ThemeProvider as NextThemesProvider } from "next-themes";
import type { ComponentProps } from "react";
import {securePreferences,preferencesReady} from "@/core/security/preferences";
import { installAndroidThemeShim } from "@/lib/android-theme";

// (bug #4): inside the Android shell the prefers-color-scheme media query
// is backed by the native uiMode (see src/lib/android-theme.ts). Installing
// at module scope guarantees the shim exists before next-themes reads it.
if (typeof window !== "undefined") {
  installAndroidThemeShim();
  // next-themes must not persist readable user preferences outside storage.
  const prototype=Storage.prototype as Storage & {__notenoidTheme?:boolean};
  if(!prototype.__notenoidTheme){
    const get=prototype.getItem,set=prototype.setItem,remove=prototype.removeItem;
    prototype.getItem=function(key:string){return key==='notenoid-volatile-theme'?securePreferences.getItem('theme'):get.call(this,key);};
    prototype.setItem=function(key:string,value:string){if(key==='notenoid-volatile-theme'){if(preferencesReady())securePreferences.setItem('theme',value);return;}set.call(this,key,value);};
    prototype.removeItem=function(key:string){if(key==='notenoid-volatile-theme'){if(preferencesReady())securePreferences.removeItem('theme');return;}remove.call(this,key);};
    prototype.__notenoidTheme=true;
  }
}

export function ThemeProvider({ children, ...props }: ComponentProps<typeof NextThemesProvider>) {
  return <NextThemesProvider {...props} storageKey="notenoid-volatile-theme">{children}</NextThemesProvider>;
}
