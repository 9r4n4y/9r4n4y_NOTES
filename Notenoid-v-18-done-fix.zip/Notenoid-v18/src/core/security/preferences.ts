/** Sensitive preferences live only in memory until encrypted by the storage layer. */
let values: Record<string, string> = {};
let save: ((values: Record<string, string>) => Promise<void>) | null = null;
let pending = Promise.resolve();
let error: unknown = null;
export const sensitiveKeys = [
  "notes-app-settings-v1",
  "keep-layout",
  "notes-vault-record-v2",
  "notes-vault-code-hash",
  "theme",
];
export function attachPreferences(
  initial: Record<string, string>,
  persist: (v: Record<string, string>) => Promise<void>,
) {
  values = { ...initial };
  save = persist;
  pending = Promise.resolve();
  error = null;
}
export function detachPreferences() {
  values = {};
  save = null;
}
export function preferencesReady() {
  return !!save;
}
export function snapshotPreferences() {
  return { ...values };
}
export const securePreferences = {
  getItem(key: string) {
    return values[key] ?? null;
  },
  setItem(key: string, value: string) {
    if (!save) throw Error("Encrypted storage is not ready");
    values[key] = value;
    enqueue();
  },
  removeItem(key: string) {
    if (!save) throw Error("Encrypted storage is not ready");
    delete values[key];
    enqueue();
  },
};
function enqueue() {
  const copy = { ...values };
  const persist = save!;
  pending = pending
    .then(() => persist(copy))
    .catch((e) => {
      error = e;
      if (typeof window !== "undefined")
        window.dispatchEvent(
          new CustomEvent("notes:storage-failure", { detail: String(e) }),
        );
    });
}
export async function flushPreferences() {
  await pending;
  if (error) throw error;
}
