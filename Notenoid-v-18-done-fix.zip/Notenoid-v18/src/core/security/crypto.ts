/** Portable, versioned WebCrypto primitives. Never use these with a reused IV. */
export const ITERATIONS = 600_000;
export const utf8 = (s: string) => new TextEncoder().encode(s);
export const text = (b: Uint8Array) =>
  new TextDecoder("utf-8", { fatal: true }).decode(b);
export function random(n = 32): Uint8Array<ArrayBuffer> {
  return crypto.getRandomValues(new Uint8Array(n));
}
export function b64(b: Uint8Array): string {
  let s = "";
  for (let i = 0; i < b.length; i += 8192)
    s += String.fromCharCode(...b.subarray(i, i + 8192));
  return btoa(s);
}
export function unb64(s: string): Uint8Array<ArrayBuffer> {
  return Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
}
export const id = () =>
  Array.from(random(16), (b) => b.toString(16).padStart(2, "0")).join("");
export const hexBytes = (s: string) =>
  Uint8Array.from(s.match(/../g) ?? [], (x) => parseInt(x, 16));
export async function aes(raw: Uint8Array, extractable = false) {
  if (raw.length !== 32) throw Error("Invalid key length");
  return crypto.subtle.importKey(
    "raw",
    new Uint8Array(raw),
    "AES-GCM",
    extractable,
    ["encrypt", "decrypt"],
  );
}
export async function derive(
  password: string,
  salt: Uint8Array,
  iterations = ITERATIONS,
) {
  if (iterations < 100_000 || iterations > 2_000_000 || salt.length < 16)
    throw Error("Invalid password parameters");
  const material = await crypto.subtle.importKey(
    "raw",
    utf8(password),
    "PBKDF2",
    false,
    ["deriveKey"],
  );
  return crypto.subtle.deriveKey(
    { name: "PBKDF2", hash: "SHA-256", salt: new Uint8Array(salt), iterations },
    material,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"],
  );
}
export async function seal(
  key: CryptoKey,
  bytes: Uint8Array,
  context: string,
): Promise<Uint8Array<ArrayBuffer>> {
  const iv = random(12);
  const encrypted = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv, additionalData: utf8(context), tagLength: 128 },
    key,
    new Uint8Array(bytes),
  );
  const out = new Uint8Array(12 + encrypted.byteLength);
  out.set(iv);
  out.set(new Uint8Array(encrypted), 12);
  return out;
}
export async function open(
  key: CryptoKey,
  bytes: Uint8Array,
  context: string,
): Promise<Uint8Array<ArrayBuffer>> {
  if (bytes.length < 28) throw Error("Invalid encrypted data");
  return new Uint8Array(
    await crypto.subtle.decrypt(
      {
        name: "AES-GCM",
        iv: new Uint8Array(bytes.subarray(0, 12)),
        additionalData: utf8(context),
        tagLength: 128,
      },
      key,
      new Uint8Array(bytes.subarray(12)),
    ),
  );
}
export async function digest(bytes: Uint8Array) {
  return b64(
    new Uint8Array(
      await crypto.subtle.digest("SHA-256", new Uint8Array(bytes)),
    ),
  );
}
