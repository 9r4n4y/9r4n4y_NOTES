// ---------------------------------------------------------------------------
// Platform detection + adapter singleton.
//
//   Android APK (AndroidBridge present) → AndroidFSAdapter (real FS via bridge)
//   Chromium browser                    → WebFSAdapter (user-picked real folder)
//   other browsers                      → OpfsFSAdapter (private local storage)
//
// The chosen kind is remembered so a user who picked a real folder is never
// silently downgraded to in-app storage on the next visit.
// ---------------------------------------------------------------------------

import { encryptedAdapter, EncryptedFS } from "../security/encrypted-fs";
import { type FSAdapter } from "./adapter";
import { AndroidFSAdapter, getBridge } from "./android-fs";
import { OpfsFSAdapter, supportsOpfs } from "./opfs-fs";
import { WebFSAdapter, supportsFileSystemAccess } from "./web-fs";

const KIND_KEY = "notes-fs-kind";

export function isAndroidPlatform(): boolean {
  return typeof window !== "undefined" && getBridge() != null;
}

function storedKind(): string | null {
  try {
    return localStorage.getItem(KIND_KEY);
  } catch {
    return null;
  }
}

function storeKind(kind: string): void {
  try {
    localStorage.setItem(KIND_KEY, kind);
  } catch {
    /* ignore */
  }
}

let instance: FSAdapter | null = null;

export function getFS(): FSAdapter {
  if (instance) return instance;
  const bridge = getBridge();
  if (bridge) {
    instance = encryptedAdapter(new AndroidFSAdapter(bridge));
    storeKind("android");
    return instance;
  }
  const remembered = storedKind();
  if (remembered === "web" && supportsFileSystemAccess()) {
    instance = encryptedAdapter(new WebFSAdapter());
    return instance;
  }
  if (remembered === "opfs" && supportsOpfs()) {
    instance = encryptedAdapter(new OpfsFSAdapter());
    return instance;
  }
  if (supportsFileSystemAccess()) {
    instance = encryptedAdapter(new WebFSAdapter());
    return instance;
  }
  if (supportsOpfs()) {
    instance = encryptedAdapter(new OpfsFSAdapter());
    storeKind("opfs");
    return instance;
  }
  throw new Error("This browser does not support local file storage");
}

/** Remember a successful root choice so reloads use the same adapter kind. */
export function rememberKind(adapter: FSAdapter): void {
  storeKind(adapter.kind);
}

/** Explicitly switch the web adapter implementation (e.g. to OPFS). */
export function switchToOpfs(): FSAdapter {
  if (!supportsOpfs()) {
    throw new Error("In-app storage is not supported in this browser");
  }
  if (instance?.kind !== "opfs") {
    (instance as EncryptedFS | null)?.invalidate();
    instance = encryptedAdapter(new OpfsFSAdapter());
    storeKind("opfs");
  }
  return instance;
}

/** Choose a real browser folder even after using the private-storage fallback. */
export async function pickBrowserFolder(): Promise<FSAdapter | null> {
  if (!supportsFileSystemAccess()) throw new Error("This browser cannot choose external folders. Use encrypted backups for recovery.");
  const raw = new WebFSAdapter();
  if (!await raw.pickRoot()) return null;
  (instance as EncryptedFS | null)?.invalidate();
  instance = encryptedAdapter(raw);
  storeKind("web");
  return instance;
}
