# Optional exact word selection

## Identity

`exact-selection.ts` maps rendered text leaves to original UTF-16 source ranges using Markdown parser positions. A second mapping accounts for attachment URLs and math preprocessing. Each preview text span carries its character map. Pointer caret APIs identify the tapped character within that span; the editor stores `{word, start, end}` source identity rather than searching for another occurrence of the same word.

Fenced code and task-list text need explicit handling because the renderer can omit one or both text-leaf positions. The pipeline resolves those within their own source block, not against the whole note. No selection markup is written into saved Markdown.

## Highlight and centering

One geometry loop draws pointer-transparent yellow overlay rectangles from either a DOM Range in preview or the textarea's style-matched measurement mirror. It does not depend on native selection painting or alter React-owned text nodes for selection. A selected range is visible before confirmation. Done changes the mode and starts a three-second pulse; five 600ms animation cycles run unless reduced motion is enabled.

The actual scroll container is measured, with the visual viewport limiting the visible area. Extra half-viewport spacers make both document edges centerable. Centering is retried while the mode transition settles and when geometry changes during the pulse. Spacers remain afterward so the browser does not clamp the scroll position back to an edge.

## Interaction

- Preview/Edit toggles directly by default. If “Ask before Preview/Edit toggle” is enabled, the mode button enters word selection when the note is nonempty.
- Repeated presses on that button do not confirm.
- Word tap changes the pending range and its overlay.
- Done is disabled until a word is selected; it is the confirmation action.
- Cancel clears selection without changing modes.
- Empty notes switch directly.
- Preview click capture suppresses link navigation and task-checkbox changes while selecting a word.
- The edit textarea is read-only during selection to avoid opening an Android keyboard just to select a word.

## Scope

Selection applies to source-backed visible text. Images, generated equation glyphs, Markdown delimiters, and hidden link destinations do not necessarily have a rendered text-word counterpart. There is deliberately no global duplicate-word fallback. Persistent storage schema keys are kept stable independently of release numbering.
