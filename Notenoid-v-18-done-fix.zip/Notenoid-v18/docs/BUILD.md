# Build Notenoid v18

## Requirements

- Node.js 20+ and npm.
- For Android: JDK 17 or newer, Android platform 34, and build-tools 35.0.0 (aapt2, d8, zipalign, apksigner).

Install JavaScript dependencies and validate the source:

```sh
npm ci
npm run typecheck
```

## Web build

```sh
npm run build
```

For the static web payload used by the Android shell:

```sh
bash scripts/build_web_export.sh
```

This writes the static export to `.next-static/` and copies it to `android/assets/`.

## Android APK

The Android shell build is a small aapt2/d8/apksigner pipeline (no Gradle):

```sh
npm run setup:sdk
bash scripts/build_web_export.sh
APK_STORE_PASSWORD='<your keystore password>' npm run build:apk
```

To use another signing key, set `APK_KEYSTORE`, `APK_KEY_ALIAS`, `APK_STORE_PASSWORD`, and (if different) `APK_KEY_PASSWORD`. Output is `out/Notenoid.apk`. The script sets version name **18.0** and version code **180**.

The included signing key is a source-distributed convenience key, not a production secret. Keep signing credentials secure for release engineering; do not treat a public/distributed key as confidential.
