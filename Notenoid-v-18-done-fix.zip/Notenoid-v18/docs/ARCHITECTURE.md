# Notenoid v18 architecture

## Application layers

- `src/app` and `src/components/keep` provide the React/Next.js interface and local-only note workflows.
- `src/core/repo.ts` and `src/core/fs` implement note metadata, attachments, and platform storage adapters (browser storage, filesystem handles, and the Android bridge).
- `src/core/security/encrypted-fs.ts` encrypts the local storage container. Vault access uses independent credentials and recovery questions in `src/lib/vault.ts`.
- `src/components/keep/editor/MarkdownEditor.tsx` stores plain Markdown, renders preview, resolves attachment URLs, and preserves viewport position across edit/preview modes. `exact-selection.ts` carries rendered-text-to-source offsets for exact text mapping.
- `src/core/security/backup.ts` implements two distinct paths: a readable ZIP for portability, and a separate encrypted-container recovery archive.

## Readable ZIP contract

- Notes are stored as `notes/<name>/node.md`; included vault notes are stored under `_vault/<name>/node.md`.
- Attachments are colocated under each note's `attachment/` folder.
- The ZIP is not encrypted and contains no password, vault record, or security-question answers. Vault-note inclusion requires an explicit export choice (enabled by default) and a successful verification of the current vault password.
- The manifest reports note and attachment counts, including its vault-note count. Exports stop on unreadable content rather than silently omitting files.
- Import validates the entire archive before writing. If vault notes are present, import requires a pre-existing destination vault and verification with its password. It never installs or replaces vault credentials/questions from the ZIP. Imported vault notes retain their vault flag and are encrypted using the destination vault/storage path.

## Markdown image sizing

Single images store their width in Markdown title metadata (`size=NN`). Image grids store `data-size` on their `div.img-grid`; the sanitized preview schema explicitly permits that attribute. Both sliders update persistent Markdown, while URLs are converted back to attachment paths before saving.

## Viewport anchoring

Each toggle captures a source character and its viewport delta. Preview spans carry exact source maps; edit mode uses a textarea mirror for character geometry. A settle pin remeasures after layout changes. If a source character belongs to Markdown syntax (such as a table pipe), preview positioning resolves to the nearest mapped rendered character. Newline anchors choose the closest real text before or after the break rather than jumping to the next block.
