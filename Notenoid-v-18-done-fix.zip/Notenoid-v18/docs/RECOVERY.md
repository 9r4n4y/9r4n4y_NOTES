# Recovery guide

## Reconnect encrypted note storage

1. Keep a complete copy of the app's encrypted storage folder/container; do not copy only selected objects.
2. In Notenoid, reconnect the folder containing that container using the storage picker (or select the container itself when the picker supports it).
3. If automatic device unlock is unavailable, choose **Recover your encrypted notes** and enter the original storage seed password.
4. Open the vault separately with its own password. Vault recovery questions remain the destination vault's; readable imports never replace them.

A readable ZIP export is a portability file, not a copy of the encrypted storage container. It is intentionally plaintext and does not carry vault passwords or answers. Keep it private and do not mistake it for an encrypted recovery backup.

## Without Notenoid

Requirements: Python 3.10+ and the `cryptography` package. Install the dependency ahead of time if you need fully offline use:

```sh
python -m pip install -r scripts/requirements-recovery.txt
python scripts/recover.py "/path/notenoid.encrypted" "/path/recovered-new"
```

Passwords are prompted with `getpass` and not printed. Output must be a new directory; existing directories are refused to avoid overwriting data. All selected objects authenticate before output creation.

Vault content requires its independent vault credentials after the encrypted storage is reconnected.
