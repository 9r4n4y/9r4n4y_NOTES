# Notenoid v18.0

Android package `com.notes.app` · version code 180.

## Changes

- Image grid resizing now persists `data-size` through Markdown sanitization and updates preview width. Single-image resizing remains per-image and persists its `size=NN` title metadata.
- Single Markdown attachment images and multi-image grids continue rendering local attachments.
- Readable export asks whether to include vault notes (on by default), requires the current vault password only when vault content is selected, and never writes credentials/security answers into the archive. The ZIP itself is not password-protected. Attachments default on with a separate opt-out. A clear completion report lists exported notes, attachments, and vault notes.
- Vault-containing readable imports now require a separately set-up destination vault and its password. Source/archive vault credentials and security questions are neither imported nor used to overwrite the destination vault. Import validates before writing.
- Direct Preview/Edit switching is now the default. Viewport restoration tracks exact source-backed characters and falls back to the nearest rendered character when the source point is Markdown syntax. Settling handles paragraphs, tables, inline/fenced code, and blank lines.
- Settings default to immediate Preview/Edit switching; the prior select-a-word flow remains an optional preference.

See `VALIDATION-V18.md` for test results and `docs/ARCHITECTURE.md` for current export, import, image sizing, and viewport-anchor behavior.

## Fix: image-size "Done" jumped the note to the top

- Root cause: the Markdown preview `components` map was rebuilt inline on every render (`lineBlock("p")` etc. create new component functions), so react-markdown remounted the whole preview whenever any state changed. Opening or closing the image-size menu (Done) collapsed the preview for a frame and the browser clamped `scrollTop` to 0.
- `MarkdownEditor.tsx` now hands react-markdown stable wrapper components that forward to the latest renderers, so nothing remounts. Opening/closing the size menu also captures and restores the scroll position as a safety net.
- Applies to both single images and image grids. Rebuild the web export / APK (`scripts/build_apk.sh`) to pick up the change.
