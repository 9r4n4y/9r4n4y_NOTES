---
id: "f9114a85-cb5a-4eda-97b5-e993ad92576b"
title: "Test"
type: "text"
color: "default"
pinned: false
archived: false
trashed: false
vaulted: false
folder: null
labels: []
order: null
created: "2026-09-28T13:38:26.498Z"
updated: "2026-09-28T13:39:13.772Z"
---



You are an expert HTML5 game developer. Build a complete Tower Bloxx-inspired game as a single self-contained HTML file using only HTML, CSS, and vanilla JavaScript. Do not use external libraries, frameworks, or assets. The game must run directly in a browser.

Create a polished, fully playable tower-stacking game with the following requirements:

1) Core gameplay
- A crane moves a floor block horizontally above the current tower.
- The player taps/clicks/presses Space to drop the block.
- The new block must land on the tower.
- Any overhang is cut off and falls away as a separate physics object.
- Perfect or near-perfect alignment keeps the tower stable.
- Misaligned blocks make the tower sway more as height increases.
- The tower becomes harder to place on as it gets taller.
- If the player drops a block and it misses the tower entirely, count it as a fail.
- In Quick Mode, the game ends after 3 misses.
- Add score, combo, height, stability, and missed-drop counters.

2) Game modes
- Quick Mode:
  - Endless score-chasing mode.
  - The player builds until 3 misses.
  - Show final score, highest tower height, best combo, and accuracy.
- Build City Mode:
  - After each successful tower completion, place the finished building onto a city grid.
  - The grid has placement rules.
  - Small towers can be placed anywhere.
  - Larger towers require adjacency to compatible lower towers or matching rules.
  - The goal is to maximize city population.
  - Each tower type should add population based on height, alignment quality, and combo bonuses.
  - Show the city map, population total, available tower tiers, and placement hints.

3) Tower physics
- Use believable 2D physics for:
  - block drop acceleration
  - block landing
  - tower sway
  - wind force that increases with height
  - falling cut-off pieces
  - collapse if instability gets too high
- The tower should visibly lean and oscillate when misaligned.
- The higher the tower, the stronger the sway and wind effect.
- Include subtle damping so the tower settles when the player builds carefully.
- Make the physics feel arcade-friendly, not hyper-realistic.

4) Scoring and progression
- Perfect drop gives bonus points.
- Near-perfect drop gives combo multiplier.
- Combo increases when consecutive drops are centered.
- Combo resets on a bad drop or miss.
- Higher floors are worth more points.
- In Build City Mode, better aligned towers produce more residents.
- Unlock larger tower tiers as the player progresses.
- Add a high score save using localStorage.

5) UI/UX
- Clean retro-arcade style with crisp panels and readable HUD.
- Animated crane, tower sway, score popups, and city map transitions.
- Responsive layout for desktop and mobile.
- Touch controls and keyboard controls both supported.
- Add start menu, pause, game over, and mode select screens.
- Include restart, mute, and help buttons.
- Show small on-screen instructions for first-time players.

6) Audio and sound design
- Add sound effects for:
  - crane movement
  - block drop
  - perfect placement
  - near-perfect placement
  - bad landing
  - overhang falling
  - tower sway / wind hum
  - combo increase
  - score popups
  - game over
  - city placement success
- Add background music loops with a light retro arcade feel.
- Use separate audio tracks for menu and gameplay.
- Include a mute toggle and volume control.
- Audio must be generated with the Web Audio API or simple embedded audio logic, no external files.

7) Visual details
- Use layered backgrounds, subtle parallax, and animated skyline elements.
- Show tiny windows, people, or ambient city life on completed towers.
- Add celebration animation for perfect towers and high population milestones.
- Add debris particles when blocks are trimmed or fall.
- Make the tower visually distinct from the city map in Build City Mode.

8) Technical requirements
- Output exactly one HTML file containing all code.
- Use no external dependencies.
- Organize the code cleanly with comments.
- The game must be playable immediately after opening the HTML file.
- Make the code robust, readable, and easy to modify.
- Handle resize events properly.
- Prevent crashes from rapid clicking or repeated input.
- Ensure consistent behavior across modern browsers.

9) Acceptance criteria
- The game must feel like a faithful Tower Bloxx-style stacking game.
- It must be fully playable.
- It must include both Quick Mode and Build City Mode.
- It must have real physics-like sway and overhang trimming.
- It must include scoring, combos, progression, city placement, localStorage, and sounds.
- It must look and feel finished, not like a prototype.

Before coding, briefly outline the architecture inside comments, then generate the full working HTML file.

<div class="img-grid" data-cols="2">
<img src="attachment/1000711924.jpg" alt="1000711924.jpg">
<img src="attachment/1000707834.png" alt="1000707834.png">
<img src="attachment/1000712431.png" alt="1000712431.png">
</div>
