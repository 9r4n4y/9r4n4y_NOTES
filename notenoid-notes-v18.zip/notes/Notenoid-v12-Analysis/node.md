---
id: "075ffa2b-7ed2-4b28-8d5b-f808f0acb8b0"
title: "Notenoid-v12-Analysis"
type: "text"
color: "default"
pinned: false
archived: false
trashed: false
vaulted: false
folder: null
labels: []
order: 0
created: "2026-09-28T03:56:03.259Z"
updated: "2026-09-29T11:02:36.067Z"
---






# Notenoid v12 — Full Code Extraction & Deep Analysis

**Source:** `Notenoid-v12-source.zip`
**Analysed:** 2026-09-28
**Scale:** 311 files · 18,016 lines of TypeScript/TSX under `src/` · 36 bundled themes · Android shell included

> This is a line-level behavioural extraction of the whole application. It is written as
> Markdown but saved with a `.md` extension and reads cleanly as a plain `.txt` file too.

---

## TABLE OF CONTENTS

1. [Executive summary](#1-executive-summary)
2. [Tech stack, libraries and versions](#2-tech-stack-libraries-and-versions)
3. [Project structure — every file and what it does](#3-project-structure--every-file-and-what-it-does)
4. [The data model](#4-the-data-model)
5. [Storage system — how notes physically live on disk](#5-storage-system--how-notes-physically-live-on-disk)
6. [Storage adapters — Web / OPFS / Android](#6-storage-adapters--web--opfs--android)
7. [YAML front-matter engine](#7-yaml-front-matter-engine)
8. [Markdown core library — `core/markdown.ts`](#8-markdown-core-library--coremarkdownts)
9. [**THE MARKDOWN EDITOR — complete anatomy**](#9-the-markdown-editor--complete-anatomy)
   - 9.1 [Component contract and imperative handle](#91-component-contract-and-imperative-handle)
   - 9.2 [Toolbar — every button, its action and exact syntax produced](#92-toolbar--every-button-its-action-and-exact-syntax-produced)
   - 9.3 [Edit mode — the textarea](#93-edit-mode--the-textarea)
   - 9.4 [Preview mode — the render pipeline](#94-preview-mode--the-render-pipeline)
   - 9.5 [Plugin chain, step by step](#95-plugin-chain-step-by-step)
   - 9.6 [Custom component overrides, element by element](#96-custom-component-overrides-element-by-element)
   - 9.7 [Every markdown construct supported](#97-every-markdown-construct-supported)
   - 9.8 [Math / KaTeX support](#98-math--katex-support)
   - 9.9 [Edit ↔ Preview interchange — the fixed-screen system](#99-edit--preview-interchange--the-fixed-screen-system)
   - 9.10 [Image sizing inside the preview](#910-image-sizing-inside-the-preview)
   - 9.11 [History / undo / redo](#911-history--undo--redo)
   - 9.12 [Throttled persistence and flush points](#912-throttled-persistence-and-flush-points)
   - 9.13 [In-note search and highlight](#913-in-note-search-and-highlight)
   - 9.14 [URL round-tripping: attachment paths ↔ display URLs](#914-url-round-tripping-attachment-paths--display-urls)
   - 9.15 [Known limits and edge cases in the editor](#915-known-limits-and-edge-cases-in-the-editor)
10. [**IMAGE UPLOAD SYSTEM — complete anatomy**](#10-image-upload-system--complete-anatomy)
   - 10.1 [The two-zone model: attachment grid above, markdown body below](#101-the-two-zone-model-attachment-grid-above-markdown-body-below)
   - 10.2 [Upload entry points — all six](#102-upload-entry-points--all-six)
   - 10.3 [Compression / preparation pipeline](#103-compression--preparation-pipeline)
   - 10.4 [Attachment writing to disk](#104-attachment-writing-to-disk)
   - 10.5 [Object-URL lifecycle and caching](#105-object-url-lifecycle-and-caching)
   - 10.6 [The thumbnail grid and its four buttons](#106-the-thumbnail-grid-and-its-four-buttons)
   - 10.7 [**Grid rules: 1 image vs many images**](#107-grid-rules-1-image-vs-many-images)
   - 10.8 [Image size metadata and where it is stored](#108-image-size-metadata-and-where-it-is-stored)
   - 10.9 [Image editor, lightbox, and removal](#109-image-editor-lightbox-and-removal)
11. [The note editor screen](#11-the-note-editor-screen)
12. [State store — `store.ts`](#12-state-store--storets)
13. [Notes grid, cards and drag & drop](#13-notes-grid-cards-and-drag--drop)
14. [Settings — every setting explained](#14-settings--every-setting-explained)
15. [Themes, fonts, density, wallpaper](#15-themes-fonts-density-wallpaper)
16. [Vault — password security](#16-vault--password-security)
17. [Import / export (ZIP)](#17-import--export-zip)
18. [Navigation and back handling](#18-navigation-and-back-handling)
19. [Platform shell — Android APK](#19-platform-shell--android-apk)
20. [Build, scripts and config](#20-build-scripts-and-config)
21. [Complete data-flow traces](#21-complete-data-flow-traces)
22. [Full feature inventory](#22-full-feature-inventory)
23. [Settings reference table](#23-settings-reference-table)
24. [Glossary of internal identifiers](#24-glossary-of-internal-identifiers)

---

## 1. Executive summary

**Notenoid** is a local-first, offline, Google Keep–style notes app that ships as **one codebase**
compiled to two targets: a static web app and an Android APK (WebView shell). There is **no
server, no database, no IndexedDB note storage and no cloud**. Every note is a real folder on
the user's own filesystem containing a single `node.md` file (YAML front-matter + Markdown body)
and an `attachment/` folder for images.

The application is roughly 18,000 lines of TypeScript/React across four layers:

| Layer | Location | Responsibility |
|---|---|---|
| UI | `src/components/keep/**` | Views, cards, editor, dialogs, settings, theming |
| State | `src/components/keep/store.ts` | Zustand store: optimistic updates, debounced autosave, draft materialisation, vault, views |
| Core | `src/core/**` | `NoteRepository` (all note/folder/attachment ops), `markdown.ts`, `frontmatter.ts` — platform-agnostic |
| Platform | `src/core/fs/**` | `FSAdapter` implemented by Web (File System Access API), OPFS (in-app) and Android (native JS bridge) |

The two subsystems the user asked to understand in greatest depth — **the Markdown editor** and
**the image upload → grid → markdown pipeline** — are covered in sections 9 and 10 respectively,
including the character-level scroll-anchoring system that keeps the screen fixed when swapping
between edit and preview.

---

## 2. Tech stack, libraries and versions

From `package.json` (name `notenoid`, version `12.0.0`, private):

### Runtime dependencies

| Package | Version | Role in this app |
|---|---|---|
| `next` | ^16.1.1 | App shell / build. Static export for web, asset source for APK |
| `react` | ^19.0.0 | UI runtime |
| `react-dom` | ^19.0.0 | DOM renderer |
| `zustand` | ^5.0.6 | The single global app store (`store.ts`) |
| `react-markdown` | ^10.1.0 | **Preview renderer** — turns Markdown into React elements |
| `remark-gfm` | ^4.0.1 | GitHub-Flavored Markdown: tables, task lists, strikethrough, autolinks |
| `remark-math` | ^6.0.0 | Parses `$…$` and `$$…$$` into math nodes |
| `rehype-raw` | ^7.0.0 | **Required** — parses raw HTML in the Markdown, so `<div class="img-grid">` and `<u>` work |
| `rehype-katex` | ^7.0.1 | Renders math nodes to KaTeX HTML |
| `katex` | ^0.18.9 | The math typesetting engine (fonts bundled — offline) |
| `muuri` | ^0.9.5 | Masonry grid engine with animation + drag & drop for the notes list |
| `jszip` | ^3.10.2 | Build/parse ZIP backups in Import & Export |
| `lucide-react` | ^0.525.0 | All icons |
| `sonner` | ^2.0.6 | Toast notifications (incl. Undo action toasts) |
| `next-themes` | ^0.4.6 | Theme plumbing for `class` strategy |
| `class-variance-authority` | ^0.7.1 | Variant API for `ui/button` |
| `clsx` | ^2.1.1 | Conditional className |
| `tailwind-merge` | ^3.3.1 | Tailwind conflict resolution |
| `tailwindcss-animate` | ^1.0.7 | Animation utilities |
| `@radix-ui/react-*` | various | Accessible primitives: `dialog`, `popover`, `dropdown-menu`, `select`, `tabs`, `switch`, `slider`, `tooltip`, `label`, `separator`, `alert-dialog`, `slot` |

### Dev dependencies

`@tailwindcss/postcss` ^4, `tailwindcss` ^4, `tw-animate-css`, `typescript` ^5, `eslint` ^9,
`eslint-config-next` ^16.1.1, `@types/react` / `@types/react-dom` ^19, `bun-types`.

### Lockfiles present (three!)

`bun.lock`, `pnpm-lock.yaml`, `package-lock.json` — the project has been installed with three
different package managers over its life. This is a minor housekeeping smell; only one will be
used at a time, and they can drift.

### Notable absences

- **No TipTap / ProseMirror.** The V4 release notes and `docs/ARCHITECTURE.md` still describe a
  TipTap-based editor, but the current `MarkdownEditor.tsx` is a **plain controlled `<textarea>`**.
  The architecture doc is stale on this point. (Comments in the code still reference "TipTap
  editor mounts async" — leftovers from the V4 era.)
- **No IndexedDB for notes.** IndexedDB is used *only* to persist the File System Access
  directory handle on the web adapter.
- **No test framework** in `package.json`. There is one script, `scripts/test-storage-naming.ts`,
  run manually with `tsx`-style invocation.

### Build scripts

```
dev            next dev -p 3000 2>&1 | tee dev.log
build          next build && cp -r .next/static .next/standalone/.next/ && cp -r public .next/standalone/
start          NODE_ENV=production node .next/standalone/server.js 2>&1 | tee server.log
lint           eslint .
export:web     STATIC_EXPORT=true next build
build:apk      bash scripts/build_apk.sh
setup:sdk      bash scripts/setup-sdk.sh
```

---

## 3. Project structure — every file and what it does

```
Notenoid-v12-source/
├── Caddyfile                        production static host + APK download headers
├── README.md                        product overview, feature list, disk layout
├── RELEASE-NOTES-V5.md … V12.md     per-version changelogs (V5, V5.1, V5.2, V6, V7, V8, V8.5, V12)
├── package.json / bun.lock / pnpm-lock.yaml / package-lock.json
├── components.json                  shadcn/ui config
├── next.config.ts, next-env.d.ts, postcss.config.mjs, tailwind.config.ts, tsconfig.json
├── eslint.config.mjs
├── docs/
│   ├── ARCHITECTURE.md              layering, adapters, data flow  (partly stale re TipTap)
│   └── BUILD.md                     web + APK build instructions
├── scripts/
│   ├── build_apk.sh                 packages the static export into the Android project
│   ├── build_web_export.sh          produces the static export
│   ├── gen_icons.py                 generates launcher icon densities from a 1024px source
│   ├── setup-sdk.sh                 downloads/configures the Android SDK
│   └── test-storage-naming.ts       checks the [Archive_]Folder_Labels_Title derivation
├── icon-source/1789483250921.png    1024px master icon
├── keystore/notes.keystore          release signing key (shipped in the zip — see §20 caveat)
├── release/                         built artifacts
├── public/robots.txt
├── android/                         full native Android project
│   ├── AndroidManifest.xml
│   ├── assets/                      the exported web app (Next static export, incl. KaTeX fonts)
│   ├── res/…                        launcher icons, adaptive icon XML
│   └── …                            MainActivity.java, gradle files (not listed in the zip)
└── src/                             ← THE APPLICATION (18,016 lines)
    ├── app/
    │   ├── globals.css              1,022 lines — the entire visual system
    │   ├── layout.tsx               Next root layout, self-hosted fonts via next/font
    │   └── page.tsx                 renders <KeepApp/>
    ├── components/
    │   ├── keep/                    26 app components + editor
    │   │   ├── KeepApp.tsx          542  root orchestrator, storage gating, dialogs
    │   │   ├── store.ts             1,366 Zustand store (the state engine)
    │   │   ├── NoteEditorView.tsx   1,150 the full-screen markdown editor screen
    │   │   ├── SettingsDialog.tsx   1,021 5-tab settings
    │   │   ├── ImageEditorDialog.tsx 780  crop / draw / text image editor
    │   │   ├── NoteCard.tsx         729  note card (memoised)
    │   │   ├── MuuriGrid.tsx        632  masonry grid + drag reorder
    │   │   ├── MuuriGridLazy.tsx    lazy wrapper for the grid
    │   │   ├── Sidebar.tsx          395 navigation rail/drawer
    │   │   ├── ImportDialog.tsx     323 ZIP restore
    │   │   ├── ExportDialog.tsx     320 ZIP backup
    │   │   ├── BulkActionBar.tsx    319 V12 mass-select toolbar
    │   │   ├── FolderDialog.tsx     257 create/rename folder
    │   │   ├── VaultDialogs.tsx     246 vault password + first-run setup dialogs
    │   │   ├── FoldersView.tsx      242 folder grid
    │   │   ├── ImageInsertPopover.tsx 234 insert-at-cursor picker
    │   │   ├── TopBar.tsx           216 search, new note, layout toggle, theme, settings
    │   │   ├── Lightbox.tsx         175 full-screen image viewer + actions
    │   │   ├── LabelsManager.tsx    173 label CRUD
    │   │   ├── NotesView.tsx        171 notes list/grid container
    │   │   ├── settings-store.ts    167 AppSettings (localStorage + external store)
    │   │   ├── LabelsPopover.tsx    121 per-note label picker
    │   │   ├── ColorPicker.tsx      123 31-colour note palette
    │   │   ├── MediaPickPopover.tsx 136 footer media picker
    │   │   ├── ThemeController.tsx  118 applies theme CSS vars
    │   │   ├── EmptyState.tsx       empty-list placeholder
    │   │   ├── Composer.tsx         79  "Take a note…" launcher
    │   │   ├── attachment-url.ts    57  lazy object-URL resolution hooks
    │   │   ├── media.ts             103 compression + preparation
    │   │   ├── theme-mode.ts        53  active light/dark resolution
    │   │   ├── system-bars-sync.tsx 54 Android status/nav bar colour
    │   │   ├── FolderPickerDialog.tsx 198 Android in-app filesystem browser
    │   │   └── editor/
    │   │       └── MarkdownEditor.tsx 1,937  ★ THE MARKDOWN EDITOR
    │   └── ui/                      14 shadcn/ui primitives (button, dialog, popover, …)
    ├── core/                        platform-agnostic
    │   ├── repo.ts                  623  NoteRepository — all disk operations
    │   ├── markdown.ts              394  markdown ⇄ note model, task lists, safe naming
    │   ├── frontmatter.ts           182  minimal YAML round-trip
    │   ├── types.ts                 91   DTOs
    │   └── fs/
    │       ├── adapter.ts           154  FSAdapter contract, path helpers, mutex, MIME
    │       ├── android-fs.ts       273  native bridge adapter
    │       ├── handle-fs.ts        214  File System Access API helper layer
    │       ├── web-fs.ts            87  Chromium adapter
    │       ├── opfs-fs.ts           35  OPFS adapter
    │       └── index.ts             85  platform detection + singleton
    ├── hooks/                       use-is-touch.ts, use-mobile.ts
    └── lib/
        ├── themes.ts                715  36 full theme definitions
        ├── themes-special.ts        100 extra CSS for Frutiger Aero / Vaporwave / Aurora
        ├── keep-constants.ts        350  31 note colours, folder emojis/tints
        ├── math-pre.ts              213  math normaliser (V7)
        ├── vault.ts                 316  PBKDF2 vault security
        ├── back-nav.ts              156  layered back handling
        ├── fonts.ts                 74  14 font choices
        ├── android-theme.ts         87  native chrome colour
        ├── save-blob.ts             58  download helper
        ├── types.ts                 6   re-export shim → @/core/types
        └── utils.ts                 cn() helper
```

---

## 4. The data model

Defined in `src/core/types.ts`; `src/lib/types.ts` is a compatibility shim re-exporting it.

```ts
type NoteType = "text" | "list";

type ViewKind = "notes" | "archive" | "trash" | "folders" | "folder" | "label" | "vault";

interface ChecklistItemDTO { id: string; text: string; checked: boolean; order: number }

interface AttachmentDTO {
  id: string;        // file name inside attachment/ (unique per note)
  file: string;      // "attachment/<id>" — path relative to the note folder
  name: string;      // display / original file name
  mime: string;
  kind: "image" | "gif";
  size: number;
  url: string;       // session object-URL for display — NEVER persisted
}

interface LabelDTO  { id: string; name: string }   // identity == name
interface FolderDTO { id: string; name: string; emoji: string; color: string } // identity == name

interface NoteDTO {
  id: string;        // stable UUID, lives in front-matter
  dir: string;       // folder name on disk; changes on rename
  title: string;
  content: string;   // markdown body — the source of truth for content
  type: NoteType;
  color: string;
  pinned: boolean;
  archived: boolean;
  trashed: boolean;
  vaulted: boolean;
  folderId: string | null;
  folder?: FolderDTO | null;
  items: ChecklistItemDTO[];    // derived from markdown task lines
  labels: LabelDTO[];
  attachments: AttachmentDTO[];
  order: number | null;         // manual drag position; null = recency sort
  createdAt: string;            // ISO 8601
  updatedAt: string;            // ISO 8601
  extraMeta?: Record<string, string>;  // unknown front-matter keys, preserved
}

interface NotesConfig {   // .notes/config.json — app-level metadata ONLY
  version: 1;
  folders: { name: string; emoji: string; color: string }[];
  labels: string[];
}
```

**Design principle:** note *data* is never in JSON. `config.json` holds only the *vocabulary*
(folder emoji/tint, known label names). The note→folder and note→label links live in each note's
own front-matter, so a note folder copied to another device is self-describing.

---

## 5. Storage system — how notes physically live on disk

### 5.1 The layout

```
<Selected Root>/
├── .notes/
│   └── config.json                  ← folder emoji/tints + label names ONLY
├── Work_important_Shopping List/    ← note folder, name carries its metadata
│   ├── node.md                      ← YAML front-matter + Markdown body
│   └── attachment/                  ← created on demand, only when images exist
│       ├── 1789483250921.png
│       └── animation.gif
└── Archive_Receipts_March_2026/
    └── node.md
```

### 5.2 Metadata-carrying folder names (V8 scheme)

From `core/repo.ts`, the on-disk folder name encodes the note's metadata in a fixed,
underscore-separated order:

```
[Archive_]FolderName(_LabelName...)_NoteTitle
```

- `Archive_` prefix present only when `archived === true`
- then the folder name (if assigned)
- then each label **in note order**
- then the title
- Each component passes through `safeComponent()` → `sanitizeName(value, 60)`
- The joined string is truncated to `MAX_DIR_NAME = 120`
- Uniqueness applied by `uniqueName()` → `Base (2)`, `Base (3)` …

**Consequence:** changing the title, the archive flag, the folder assignment or *any* label
renames the folder on disk. `resolveDirFor()` handles this on every save.

**The internal title in front-matter stays the user-entered title** — only the folder name is
derived. So `node.md` is always clean and portable.

### 5.3 `node.md` format

Produced by `noteToMarkdown()` in `core/markdown.ts`:

```markdown
---
id: "9f2c1e0a-4b3d-4c88-9a11-2f6b7c9d1e44"
title: "Shopping List"
type: "text"
color: "blue"
pinned: false
archived: false
trashed: false
vaulted: false
folder: "Work"
labels: ["important", "urgent"]
order: 0
created: "2026-09-20T10:15:00.000Z"
updated: "2026-09-28T09:00:00.000Z"
---

# Shopping List

- [x] Milk
- [ ] Bread
```

Rules: every string is JSON-double-quoted (valid YAML); arrays are `["a", "b"]`; the body always
ends with a newline; the front-matter and body are separated by a blank line.

### 5.4 Filename sanitisation

`sanitizeName()` (`core/markdown.ts`):

| Input char | Replacement | Rationale |
|---|---|---|
| `/` | `／` | Windows/Android forbidden — full-width look-alike keeps it readable |
| `\` | `＼` | same |
| `:` | `：` | same |
| `*` | `＊` | same |
| `?` | `？` | same |
| `"` | `＂` | same |
| `<` | `＜` | same |
| `>` | `＞` | same |
| `\|` | `｜` | same |
| `\n`, `\r`, `\0` | `-` | control |
| `\t` | space | control |

Then: strip remaining control chars (`\u0000-\u001f\u007f`), strip trailing dots/spaces
(breaks Windows + some Android FS layers), strip leading dots, trim, truncate to 80 chars.
Empty result → `""` (and `sanitizeFileName` falls back to `"file"`).

`uniqueName()` is **case-insensitive** so it is safe on case-folding filesystems. It detects
whether the string looks like a filename (extension ≤ 12 chars after the last dot) and inserts
the counter before the extension.

### 5.5 Attachment paths in markdown

Markdown references are **relative and percent-encoded**:

```
![alt](attachment/photo%20copy.png)
```

`encodeAttachmentPath()` encodes each path segment with `encodeURIComponent` and additionally
escapes `!'()*` to `%XX` (required by the CommonMark URL spec).
`decodeAttachmentPath()` reverses it; malformed encodings are returned unchanged rather than throwing.

### 5.6 The repository (`core/repo.ts`, 623 lines)

`NoteRepository` wraps an `FSAdapter` and owns **every** disk operation. All mutating calls go
through a `createMutex()` async lock so debounced saves can never interleave.

| Method | Behaviour |
|---|---|
| `ready` | `fs.hasRoot()` |
| `tryRestoreRoot()` | re-attach to the remembered root, then `rememberKind` |
| `pickRoot()` | prompt, then remember |
| `rootLabel()` | human-readable location string |
| `scan()` | list root → for each dir: require `node.md`, parse, **dedupe duplicate ids** (a user copy/pasted folder gets a fresh UUID and is rewritten), list attachments. Skips `.`-prefixed dirs and `.notes`. Returns `{notes, config, skippedDirs}` |
| `createNote(input)` | derive dir name, `uniqueName`, `makeDir`, write `node.md`, write each media file. Runs under the write lock |
| `saveNote(note)` | `resolveDirFor` → `makeDir` (**self-heal** if an interrupted rename left the target missing) → write `node.md` with `noteToMarkdown(model, note.extraMeta)`. Returns the (possibly new) dir |
| `resolveDirFor(note)` | compute desired name; if the desired name exists but is an **empty orphan** (no `node.md`), delete and reclaim it instead of piling up `Name (2)`; then `uniqueName(base, existing, note.dir)`; rename if changed |
| `renameDir(old,new)` | try native `fs.rename` (Android supports dir rename) → on failure copy+delete (browsers cannot rename directories); tolerate an already-gone source; re-key URL cache |
| `copyDir` | recursive; **only recurses into `attachment/`** — other subdirs are skipped by design |
| `deleteNoteDir(dir)` | recursive remove + revoke cached object URLs |
| `duplicateNote(note)` | copy dir, write a fresh `node.md` with a new UUID, `pinned:false`, `trashed:false`, new timestamps, then **copy the source's cached object URLs** so previews work instantly |
| `listAttachments(dir)` | list `attachment/`, skip dotfiles, infer MIME from extension, `kind: mime === "image/gif" ? "gif" : "image"` |
| `addAttachment(note, blob, name)` | → `writeMediaFile` |
| `writeMediaFile(dir, media)` | `makeDir(attachment)`, list existing, `sanitizeFileName`, `uniqueName`, write bytes, return DTO with `url: ""` |
| `removeAttachment` | delete file + `URL.revokeObjectURL` + cache delete |
| `writeAttachment(note, att, blob)` | overwrite bytes, revoke old URL, create a new one |
| `ensureAttachmentUrl(dir, file)` | cache-first; else read bytes → `new Blob` → `URL.createObjectURL` → cache |
| `readAttachmentBlob(dir, file)` | uncached read (used by the image editor) |
| `loadConfig()` / `saveConfig()` | `.notes/config.json`, defensive parsing, falls back to `{version:1,folders:[],labels:[]}` |

---

## 6. Storage adapters — Web / OPFS / Android

### 6.1 The contract (`core/fs/adapter.ts`)

Every path in the app is **root-relative and POSIX-style** (`"Shopping List/node.md"`). The
adapter resolves it against the user-chosen root. This is what lets the core stay
platform-agnostic.

```ts
interface FSAdapter {
  readonly kind: "web" | "opfs" | "android";
  rootLabel(): string;
  hasRoot(): boolean;
  needsPermission(): Promise<boolean>;
  pickRoot(): Promise<boolean>;
  restoreRoot(): Promise<boolean>;
  exists(path): Promise<boolean>;
  listDir(path): Promise<DirEntry[]>;
  readText(path): Promise<string>;
  readBinary(path): Promise<Uint8Array>;
  writeText(path, text): Promise<void>;
  writeBinary(path, data): Promise<void>;
  makeDir(path): Promise<void>;      // mkdir -p
  remove(path, recursive?): Promise<void>;
  rename(oldPath, newPath): Promise<void>;
}
```

Helpers in the same file: `joinPath`, `splitPath`, `basename`, `dirname`, `assertSafePath`
(rejects `..` traversal and control characters), `mimeForName` (extension → MIME, incl. pdf/mp4/
mp3/webm/wav/ogg), `bytesToBase64` / `base64ToBytes` (chunked at 0x8000 to avoid stack
overflow), and `createMutex()`:

```ts
export function createMutex() {
  let tail: Promise<unknown> = Promise.resolve();
  return function run<T>(task: () => Promise<T>): Promise<T> {
    const result = tail.then(task, task);
    tail = result.catch(() => undefined);
    return result;
  };
}
```

### 6.2 Selection (`core/fs/index.ts`)

```
AndroidBridge present?          → AndroidFSAdapter, kind="android"
remembered "web" + supported?   → WebFSAdapter
remembered "opfs" + supported?  → OpfsFSAdapter
File System Access available?  → WebFSAdapter
OPFS available?                 → OpfsFSAdapter, remember "opfs"
otherwise                       → throw "This browser does not support local file storage"
```

The chosen kind is stored in `localStorage["notes-fs-kind"]` and honoured on reload, so a user
who deliberately chose a real folder is never silently downgraded to in-app storage.

`switchToOpfs()` forces the web implementation to OPFS (used by "Use in-app storage").

### 6.3 WebFSAdapter (`core/fs/web-fs.ts` + `handle-fs.ts`, 214 lines)

- Root via `showDirectoryPicker({ mode: "readwrite" })`
- Directory handle persisted in **IndexedDB** (this is the only IndexedDB use in the app)
- On next visit the browser requires re-granting permission → the app shows a "Grant access"
  screen (`storageStatus: "reauth"`)
- `handle-fs.ts` wraps the handle operations and keeps them small/normalised

### 6.4 OpfsFSAdapter (`core/fs/opfs-fs.ts`, 35 lines)

Origin Private File System, same folder layout, no permissions required. Chosen on browsers
without the File System Access API (notably Firefox and Safari). Portability is provided by the
ZIP Import/Export.

### 6.5 AndroidFSAdapter (`core/fs/android-fs.ts`, 273 lines)

Talks to a **synchronous JS bridge** `window.AndroidBridge` exposed by `MainActivity.java`.
Every call returns an envelope that is checked by a `call<T>()` wrapper which throws a friendly
message on `ok: false`.

Bridge methods: `fsInfo, fsList, fsReadText, fsReadBase64, fsWriteText, fsWriteBase64, fsMkdir,
fsRename, fsDelete, fsExists`, plus `hasAllFilesAccess()` / `requestAllFilesAccess()`.

- Paths are **absolute** in the bridge; the adapter joins them with the stored root
- Binary goes over the bridge as **base64**
- Native writes are **atomic** (temp file + rename); deletes are **recursive**
- Permissions: `MANAGE_EXTERNAL_STORAGE` on Android 11+, legacy `WRITE_EXTERNAL_STORAGE` below,
  plus `android:requestLegacyExternalStorage` for ≤ Android 10
- Root is picked with the in-app `FolderPickerDialog` which browses the real filesystem through
  the bridge; the chosen absolute path persists in `localStorage`
- Also offers an **app-private root** (`appPrivateRoot()`) for zero-permission private storage

---

## 7. YAML front-matter engine

`src/core/frontmatter.ts` (182 lines) — a deliberately tiny, well-defined YAML subset:

**Supported value forms:** `key: "string"` (JSON-double-quoted), `true`, `false`, numbers,
`null` / `~`, and `["a", "b"]` arrays.

`serializeFrontMatter()` emits one line per entry, skipping `undefined`.

`parseNoteFile()` is very defensive:

- strips a UTF-8 BOM
- normalises CRLF → LF
- if the file does not start with `---` → whole file is the body
- accepts a closing fence of either `---` **or** `...`
- **if no closing fence is found, the entire file is treated as the body** — user content is
  never lost to a broken fence
- skips blank lines and `#` comments
- `key: value` split on the first `:`; lines with no `:` or a leading `:` are ignored

**Metadata preservation:** `KNOWN_KEYS` is the set of 13 keys the app models (`id, title, type,
color, pinned, archived, trashed, vaulted, folder, labels, order, created, updated`). Any other
key found on disk is stored raw in `parsed.extra` and written back verbatim on save (with a
`/^[A-Za-z0-9_-]+$/` key guard). **The app never destroys metadata written by another tool** —
e.g. Obsidian plugins.

Typed accessors: `fm.str`, `fm.bool` (accepts `true` and the string `"true"`), `fm.num`,
`fm.strArray` (accepts a real array or a scalar that parses as one).

---

## 8. Markdown core library — `core/markdown.ts`

394 lines. This is the shared vocabulary between disk, store and editor.

### 8.1 Constants

```ts
NOTE_FILE       = "node.md"
ATTACHMENT_DIR  = "attachment"
CONFIG_DIR      = ".notes"
CONFIG_FILE     = ".notes/config.json"
```

### 8.2 Task lists

```ts
const TASK_RE = /^(\s*)([-*])\s+\[([ xX])\]\s?(.*)$/;
```

| Function | Behaviour |
|---|---|
| `parseTaskItems(body)` | returns `[{id:"t0", text, checked, order}]` — ids are positional |
| `taskStats(body)` | `{total, done}` for card badges |
| `toggleTaskLine(body, index, checked)` | **immutable** line rewrite, preserving indent + bullet char |
| `setTaskText(body, index, text)` | **immutable** text rewrite, preserving state |
| `tasksToBody(items)` | build a body from drafts |
| `textToListBody(body)` | plain lines → `- [ ] line` (lowercases existing `[X]`) |
| `listToTextBody(body)` | strips the task prefix (multiline) |
| `bodyHasRealContent(body)` | strips task markers then all whitespace — a body of only `- [ ]` is **not** content |

### 8.3 Note ⇄ disk

`noteToMarkdown(note, extraMeta?)` — builds the 13-key meta object, serialises, appends unknown
keys, guarantees a trailing newline on the body, joins with `---\n{yaml}\n---\n\n{body}`.

`markdownToNote(text, dirName)` — **never throws**. Coerces `type` to `list` or `text`, falls
back `id → generateId()`, `title → dirName`, `color → "default"`, `created/updated → now`.
Returns `{model, extraMeta, hadFrontMatter}`.

`generateId()` — `crypto.randomUUID()` when available, else `"n" + Date.now().toString(36) + random`.

### 8.4 `markdownToPlain(md)`

Strips Markdown for **search and card previews**. Order matters: raw HTML first, then fenced
code, inline code, images, links, headings, quotes, horizontal rules, task prefixes, bullets,
ordered prefixes, bold, italic, strikethrough, then leftover `=`.

Critically, the V5 comment notes that **raw HTML must not leak into card previews** — image
grids, `<u>` and `<br>` are explicitly removed.

### 8.5 `stripMarkdownFormat(text)`

The engine behind the **Clear formatting** button. Unlike `markdownToPlain`, it **protects
content** using a `\0N\0` placeholder scheme:

**Protected (never stripped):** fenced code blocks, inline code *text* (only the backticks go),
`![alt](…)` images, `[…](attachment/…)` links.

**Line-level stripped:** `> ` quotes, `#{1,6} ` headings, `- [x] ` task items, `- ` bullets,
`1. ` / `1) ` ordered items, and full-line horizontal rules.

**Character-level stripped:** `[text](url)` → `text`, `<u>`/`</u>`, `**bold**`/`__bold__`,
`~~strike~~`, `*italic*` (asterisk), `_italic_` (**with a lookbehind/lookahead guard so
`snake_case` is never mangled**), then any leftover `*` or `~`.

### 8.6 Attachment path helpers

`referencedAttachmentPaths(body)` — regex-scans markdown for `[…](target)`, decodes, keeps only
`attachment/`-prefixed ones, returns a `Set`. Used for garbage collection.

`encodeAttachmentPath` / `decodeAttachmentPath` — per-segment, with `!'()*` escaped to `%XX`.

---

# 9. THE MARKDOWN EDITOR — complete anatomy

**File:** `src/components/keep/editor/MarkdownEditor.tsx` — **1,937 lines**.
This is the single most complex file in the codebase and the heart of the app.

## 9.1 Component contract and imperative handle

```ts
interface MarkdownEditorProps {
  value: string;                                  // the note body from the store
  onChange: (markdown: string) => void;            // throttled push to the store
  fileToUrl: (file: string) => string;             // "attachment/x.png" → object URL
  urlToFile: Map<string, string>;                  // reverse map
  onRequestInsertImages: () => void;               // attach-only picker (footer/toolbar)
  onRequestInsertAtCursor?: () => void;            // V5 insert-at-cursor picker
  onPasteImages?: (files: File[]) => void;
  onSearchResults?: (results: SearchResults) => void;
  handleRef?: React.RefObject<MarkdownEditorHandle | null>;
  beforeContent?: React.ReactNode;                 // the attachment strip + title, injected above
  placeholder?: string;
  autoFocus?: boolean;
  initialPreview?: boolean;                        // default true
  stateKey?: string;                               // note identity — keeps scroll across remounts
  onOpenImage?: (url: string, alt: string) => void;
}
```

The imperative handle is the entire integration surface with `NoteEditorView`:

```ts
interface MarkdownEditorHandle {
  focus: () => void;
  insertImage: (url: string, alt?: string) => void;                       // one image
  insertImages: (items: {url: string; alt?: string}[]) => void;          // one OR a grid
  removeImageReference: (url: string) => void;                           // strip all refs
  flushPendingPush: () => void;                                          // force a store write
  getMarkdown: () => string;
  getScrollElement: () => HTMLElement | null;
  registerUrl: (url: string, file: string) => void;                      // map a blob URL → path
  setSearchQuery: (query: string) => void;
  goToMatch: (index: number) => void;
}
```

Also exported: `buildUrlToFileMap(attachments)` → `Map<url, file>`.

## 9.2 Toolbar — every button, its action and exact syntax produced

The toolbar is a single horizontally-scrolling row (`overflow-x-auto`, hidden scrollbars) inside
a `sticky top-0 z-20` wrapper. Every `ToolButton` calls `onMouseDown(e => e.preventDefault())`
so clicking a button **never steals the textarea selection**.

`ToolButton` renders `<button type="button" aria-label title disabled>` — 32px tall, rounded,
with an `active` state.

### Left-to-right inventory

| # | Icon | Label | Action name | Exact output |
|---|---|---|---|---|
| 1 | `Eye` / `PenLine` | "Preview rendered note" / "Edit Markdown" | `togglePreview` | mode switch (state is `active` in preview) |
| 2 | `Bold` | Bold | `bold` | `**selection**` |
| 3 | `Italic` | Italic | `italic` | `*selection*` |
| 4 | `Underline` | Underline | `underline` | `<u>selection</u>` |
| 5 | `Strikethrough` | Strikethrough | `strike` | `~~selection~~` |
| 6 | `Code` | Inline code | `code` | `` `selection` `` |
| — | — | *separator* | | `1px` vertical rule |
| 7 | `Heading1` | Heading 1 | `h1` | `# ` line prefix |
| 8 | `Heading2` | Heading 2 | `h2` | `## ` line prefix |
| 9 | `Heading3` | Heading 3 | `h3` | `### ` line prefix |
| 10 | `Braces` rotated | Body text | `paragraph` | removes any line prefix |
| — | — | *separator* | | |
| 11 | `List` | Bullet list | `ul` | `- ` line prefix |
| 12 | `ListOrdered` | Numbered list | `ol` | `1. ` line prefix |
| 13 | `ListChecks` | Checklist | `todo` | `- [ ] ` line prefix |
| 14 | `Quote` | Quote | `quote` | `> ` line prefix |
| 15 | `Braces` | Code block | `codeblock` | ` ```\nselection\n``` ` |
| — | — | *separator* | | |
| 16 | `Link2` | Add link | **Popover** | see below |
| 17 | `Link2Off` | Remove link | `remove-link` | `[text](url)` → `text` (global regex) |
| 18 | `ImagePlus` | "Add image (saved to attachments)" | `onPickImages` | opens the **attach-only** picker |
| 19 | `Images` | "Insert image at cursor — several become a tidy grid" | `onInsertAtCursor` | opens the **insert-at-cursor** popover |
| 20 | `Minus` | Divider | `hr` | `\n\n---\n` |
| 21 | `Table2` | Insert table | `table` | 3×3 GFM table scaffold |
| 22 | `RemoveFormatting` | Clear formatting | `clear` | `stripMarkdownFormat` |
| 23 | `ListPlus` | Choose multiple formats | **Popover** | see below |
| — | — | *separator* | | |
| 24 | `Undo2` | Undo | `undo` | custom history step |
| 25 | `Redo2` | Redo | `redo` | custom history step |
| — | — | `flex-1` spacer | | pushes undo/redo right |

### The Add link popover

A modal Radix `Popover`, `align="start"`, `z-[70]`, `w-[min(92vw,26rem)]`.

- Opening resets `linkUrl` (but keeps `linkLabel`).
- `onOpenAutoFocus` is **prevented**, then a `requestAnimationFrame` focuses + selects the URL input
  (so typing replaces whatever is there).
- Two fields: **"Link text (optional)"** (upper) and **"Link URL"** (`inputMode="url"`,
  placeholder `https://…`).
- `Enter` in the URL field applies; `Escape` closes.
- Apply / Cancel buttons.
- `applyLink()` returns early on an empty URL, calls `onAction("link", url, label.trim())`, closes.
- Inside the action, the link text is `label || selectedText || ""`; with no text the result is
  just the bare URL.

### The multi-format popover

`align="end"`, `w-56`. Title "Apply multiple formats", a 2-column checkbox grid of **8 options**:

```
bold · italic · underline · strike · code · h1 · h2 · h3
```

Confirm button "Done" is disabled when nothing is selected. Sends
`onAction("multi", "bold,italic,code")`.

## 9.3 Edit mode — the textarea

```tsx
<textarea
  ref={textareaRef}
  value={draft}
  onChange={(e) => updateDraft(e.target.value, "type")}
  onKeyDown={handleEditorKeyDown}
  onPaste={pasteHandler}
  placeholder={placeholder ?? "Start writing…"}
  spellCheck
  className="md-textarea min-h-[40vh] w-full resize-none bg-transparent text-[0.925rem] leading-[1.65] outline-none"
/>
```

Key details:
- **Plain controlled textarea.** No rich-text editor, no contenteditable, no ProseMirror. The
  user's raw Markdown is always visible and always what is stored. This is a deliberate design
  decision: existing files, folders, labels, task lists and front-matter stay untouched.
- `spellCheck` on.
- `resize-none`, auto-height via CSS `field-sizing: content` plus `min-h-[40vh]`.
- **`onPaste`**: if the clipboard contains files and **every** file's type starts with
  `image/`, the paste is `preventDefault()`ed and routed to `onPasteImages` — pasting a
  screenshot from a screenshot tool uploads it as an attachment.
- The `MarkdownEditor` is wrapped in `React.memo`, and `NoteEditorView` keeps every callback
  stable via `useCallback` so typing in the body does not rebuild the props of the cards behind it.

### Keyboard behaviour (`handleEditorKeyDown`)

| Keys | Action |
|---|---|
| `Ctrl/Cmd + Z` | **custom undo** (`preventDefault`) |
| `Ctrl/Cmd + Shift + Z` | **custom redo** |
| `Ctrl/Cmd + Y` | **custom redo** |
| `Enter` (no modifiers, no selection) | list continuation (below) |

List continuation rules:
- Only fires when the caret has **no selection** (`s !== end` returns early).
- Matches `bullet = /^(\s*)([-*+])\s+(.*)$/`, `numbered = /^(\s*)(\d+)([.)])\s+(.*)$/`,
  `task = /^(\s*)([-*+])\s+\[[ xX]\]\s*(.*)$/`.
- If the current item is **empty**, Enter **exits the list** (inserts a bare newline, no marker) —
  this prevents the classic "endless empty bullet" noise.
- Otherwise it continues: task → `- [ ] `, bullet → `- `, numbered → `1. `, `2. ` … incrementing.
- The caret is placed after the inserted continuation marker.

## 9.4 Preview mode — the render pipeline

```tsx
<ReactMarkdown
  remarkPlugins={[remarkGfm, ...(appSettings.mathEnabled ? [remarkMath] : [])]}
  rehypePlugins={[rehypeUpgradeDisplayMath, rehypeRaw, ...katexPlugins]}
  urlTransform={previewUrlTransform}
  components={{ /* see 9.6 */ }}
>
  {highlightedPreviewContent || "*Nothing to preview yet.*"}
</ReactMarkdown>
```

Container: `<div ref={previewRef} className="md-preview md-prose min-h-[40vh]" aria-label="Rendered Markdown preview">`

The input to the pipeline is a four-stage `useMemo` chain:

```
draft
  → toDisplay(draft)                      // attachment paths → object URLs   (memo: [draft, toDisplay])
  → preprocessMathMarkdown(...)          // only if mathEnabled                (memo: [previewContent, mathEnabled])
  → highlightedPreviewContent            // wraps search hits in <mark>        (memo: [preview, mathReadyContent, searchQuery])
```

## 9.5 Plugin chain, step by step

### `remarkGfm`
Enables GitHub-Flavored Markdown: **tables**, **strikethrough** `~~x~~`, **task lists**
`- [x]`, autolinked literals, and the tight/loose list handling.

### `remarkMath` (conditional)
Parses `$…$` (inline) and `$$…$$` (display) into `math` / `math-inline` hast nodes. **Skipped
entirely when `settings.mathEnabled` is false**, which also removes the KaTeX rehype plugin.

### `rehypeUpgradeDisplayMath` (custom, runs first)
`remark-math` only treats `$$…$$` as *display* math when the block is on its own lines. The
common single-line form `$$x$$` stays **inline** — yet Obsidian, GitHub and Pandoc all render it
as a display block. This plugin walks the tree; for any element whose `className` includes
`math-inline`, it checks `file.value.slice(node.position.start.offset).startsWith("$$")` and, if
true, swaps the class to `math-display`.

It runs **before `rehype-raw`** specifically so AST positions stay intact.

### `rehypeRaw`
Parses raw HTML embedded in the Markdown. This is **essential** — without it the
`<div class="img-grid">` grids and `<u>` underlines would be escaped and shown as text.

### `rehypeKatex` (conditional)
`[[rehypeKatex, { throwOnError: false, strict: false, errorColor: "#ef4444" }]]` — malformed
LaTeX renders in red instead of crashing the preview.

### `previewUrlTransform(url)`
The stock `defaultUrlTransform` strips `blob:`, `data:` and relative URLs, which made every
inline attachment render as an "unavailable" chip. This override:

```ts
if (/^(blob:|data:image\/|attachment\/)/i.test(url)) return url;   // always allowed
if (/^\/?[\w.@%-]+(\/[\w.@%-]*)*$/.test(url) && !url.includes(":")) return url; // relative
return defaultUrlTransform(url);                                    // stock sanitizer
```

So `blob:`, `data:image/*`, `attachment/*` and plain relative paths pass through, while
`javascript:` and `vbscript:` links remain **blocked** by the stock sanitizer.

### `preprocessMathMarkdown` (`lib/math-pre.ts`, 213 lines) — V7
remark-math understands only `$…$`/`$$…$$`, so this module normalises three more forms *before*
the pipeline:

1. `\[ x = … \]` → `$$ … $$` (display)
2. `\( \sin^2\theta … \)` → `$ … $` (inline)
3. **Bare equation lines** — a line that is "just math" such as `E = mc^2`,
   `a^2 - b^2 = (a-b)(a+b)` → wrapped as `$$ … $$`

Detection is deliberately conservative. `isBareMathLine()` rejects: lines > 160 chars, anything
starting with markdown/HTML structure, URLs, lines already containing `$`, lines with straight or
curly quotes, lines with inline code, sentence-like `. ` + word, lines with `!` or `?`, and
**any line containing a 3+ letter word that is not a known math function name** (LaTeX commands
are stripped before this check, so `\frac` doesn't count as prose). It then requires at least
one of: a LaTeX command, a super/subscript, a relation operator, or a letter+digit combination.

A `MATH_WORDS` allow-list covers `sin cos tan cot sec csc log ln lim sup inf max min det gcd lcm
exp mod deg arg dim var const arc sinh cosh tanh coth and or dx dy dz dt du dv dw pi theta … op
rhs lhs`.

**Hard guarantees (documented in the file):**
- the returned text has **exactly the same number of lines** as the input — every transformation
  happens on the line it was found on. This is what keeps the §9.9 scroll anchors valid.
- fenced code blocks, YAML front-matter, inline code, headings, list items, quotes, tables and
  raw HTML are never touched
- prose is never mathified

## 9.6 Custom component overrides, element by element

### `lineBlock(tag)` — the scroll-anchor factory
```tsx
const srcLineAttr = (node) => {
  const line = node?.position?.start?.line;
  return line ? { "data-src-line": line } : {};
};
function lineBlock(tag) {
  return function LineBlock({ node, children, ...rest }) {
    return React.createElement(tag, { ...rest, ...srcLineAttr(node) }, children);
  };
}
```
Applied to: `p, h1, h2, h3, h4, h5, h6, ul, ol, blockquote, hr`.

**Purpose:** react-markdown gives every node its markdown `position`. Surfacing it as
`data-src-line` on block elements is what makes the edit ↔ preview scroll mapping possible at all.

### `img`
- Resolves `attachment/…` through `fileToUrl(decodeAttachmentPath(raw))` with a fallback to
  `fileToUrl(raw)`.
- If unresolved → `<span className="md-image-missing">{alt || "Image unavailable"}</span>`
  (a dashed-border placeholder, not a broken-image icon).
- Reads the per-image size from the **markdown title**: `parseImageSize(title)` matches
  `/(?:^|\s)size=(\d{1,3})\b/` and accepts only 10–100.
- Wraps in `<span className="md-image-wrap" data-sizable={resolved}>` carrying
  `onPointerDown` (long-press), `onPointerUp`, `onPointerCancel`, `onContextMenu`.
- `loading="lazy"`, `className="md-inline-image"`, `data-size={size}` and inline
  `style={{width: size + "%", maxWidth: "100%"}}` when sized.
- `onClick` → `onOpenImage?.(resolved, alt)` (opens the lightbox), with a
  `closeAfterClickGuard()` check so the click that ends a long-press does not also open the lightbox.
- Renders the size menu as a sibling when active.

### `div`
- Detects a grid via `className.split(/\s+/).includes("img-grid")`.
- Non-grid divs pass through with `data-src-line`.
- For a grid: `key = grid:<sourceLine>`, size from `parseGridSize(props)` reading `data-size`,
  and the width is applied inline (`width: size%"`).
- Carries the same long-press / context-menu handlers, and renders `renderImageSizeMenu`.

### `table`
Wrapped in `<div className="md-table-wrap">` (horizontal scroll container with a border) so wide
GFM tables don't break the layout. The `<table>` itself is rendered inside.

### `pre`
Renders `<div className="md-code-wrap">` with the original `<pre>` **plus a Copy button**. The
code text is extracted from the child element, trailing newline stripped. The button label
switches to "Copied" for 1,400 ms via the `copiedCode` state. `copyCode` swallows clipboard
failures (restricted WebViews).

### `code`
Adds `md-code-content` alongside the className.

### `input` (checkboxes) — the important one
```tsx
input: ({ checked, disabled, ...props }) => (
  <input
    {...props} type="checkbox" checked={!!checked}
    aria-label={checked ? "Completed task" : "Incomplete task"}
    onChange={(event) => {
      const inputs = Array.from(
        event.currentTarget.closest(".md-preview")?.querySelectorAll('input[type="checkbox"]') ?? []
      );
      const index = inputs.indexOf(event.currentTarget);
      if (index >= 0) {
        const anchor = captureAnchor();                    // ← preserve viewport!
        if (anchor) pendingAnchorRef.current = anchor;
        updateDraft(toggleTaskLine(draft, index, event.currentTarget.checked));
      }
    }}
  />
)
```
`disabled` is **destructured out** — react-markdown marks GFM task checkboxes `disabled`, which
made ticking impossible in preview. V4 fixed this by removing `disabled` and writing straight
back to the note via `toggleTaskLine`. Crucially it **captures the scroll anchor first** so
ticking a checkbox in preview does not jump the viewport.

### `a`
Three-way logic:
1. `attachment/…`, `blob:` or `data:` href → **rendered as an `<img>`** (legacy notes stored
   `[filename](attachment/x.png)` instead of `![alt](…)`; those display as pictures). The alt
   text is built by joining the string children. Click → `onOpenImage`.
2. `https?://`, `mailto:`, `tel:`, `sms:`, `geo:` → passed through.
3. A bare `www.x` or `host.tld` → prefixed with `https://`.

All real links get `target="_blank" rel="noopener noreferrer"`.

## 9.7 Every markdown construct supported

| Syntax | Toolbar | Preview | Notes |
|---|---|---|---|
| `**bold**` / `__bold__` | Bold | ✅ | |
| `*italic*` / `_italic_` | Italic | ✅ | underscore form guarded against `snake_case` in *clear* |
| `<u>underline</u>` | Underline | ✅ | needs `rehypeRaw` |
| `~~strike~~` | Strikethrough | ✅ | from `remark-gfm` |
| `` `code` `` | Inline code | ✅ | |
| ` ``` ` fenced | Code block | ✅ | + Copy button |
| `# ` … `###### ` | H1–H3 (+H4-6 by typing) | ✅ | sized in `em` so they scale with note text |
| `- ` bullets | Bullet list | ✅ | Enter continues |
| `1. ` / `1) ` | Numbered list | ✅ | Enter auto-increments |
| `- [ ]` / `- [x]` | Checklist | ✅ + **tickable in preview** | the core "checklist note" type |
| `> ` quote | Quote | ✅ | 3px left border, italic |
| `---` | Divider | ✅ | |
| GFM table | Insert table | ✅ | in a horizontal-scroll wrapper |
| `[text](url)` | Add link | ✅ | scheme normalisation, `_blank` |
| `![alt](attachment/x.png)` | Insert image | ✅ | resolved to an object URL, lazy-loaded |
| `<div class="img-grid">` | Insert-at-cursor (many) | ✅ | see §10.7 |
| `"size=NN"` title | Image size menu | ✅ | per-image width |
| `$…$` / `$$…$$` | type it | ✅ via KaTeX | toggle in Settings |
| `\[…\]` / `\(…\)` / bare equations | type it | ✅ via preprocessor | V7 |
| Raw HTML | type it | ✅ via `rehypeRaw` | |

## 9.8 Math / KaTeX support

**Settings toggle:** `mathEnabled` (default **true**).

When on:
- `remarkMath` + `rehypeKatex` are added
- `preprocessMathMarkdown` runs before the pipeline
- single-line `$$…$$` is upgraded to display math

**CSS** (`globals.css`):
```css
.md-preview .katex-display { margin: .8em 0; overflow-x: auto; overflow-y: hidden; padding: .2em 0; }
.md-preview .katex { font-size: 1.08em; }
.md-preview .katex, .md-preview .katex * { font-family: KaTeX_Main, "Times New Roman", serif; }
```
The explicit font-family is deliberate — otherwise the note-font setting would break KaTeX glyph
alignment.

**Offline:** the KaTeX woff2/ttf fonts are bundled into `_next/static/media/` (visible in the
`android/assets/_next/static/media/KaTeX_*` listing) and preloaded. No CDN request at runtime.

**Graceful degradation:** `throwOnError: false`, `strict: false`, `errorColor: "#ef4444"` — bad
LaTeX renders red rather than throwing.

## 9.9 Edit ↔ Preview interchange — the fixed-screen system

**This is the most sophisticated part of the editor and the thing the user specifically asked
about.** It is a three-generation evolution documented in the code comments.

### The problem
Edit mode is a monospaced-ish plain textarea; preview is styled HTML. **They have completely
different heights and different wrap points.** Saving a raw `scrollTop` and restoring it lands
you in an entirely different place. Worse, the textarea is a *single* element with no DOM per
line, so there is nothing to measure.

### V4 → V5: anchor by block/line
Capture the block that sits at a probe point (35% down the viewport), remember its
`data-src-line`, and on restore find the block with that source line and re-pin.

### V5 → V6: anchor by **source line**
Fixed the block-level drift, but the textarea's *visual rows* are not *source lines* — a
soft-wrapped paragraph has several visual rows per source line, so a line-level anchor slid.

### V6 → **V12 (current): anchor by exact CHARACTER**

The header comment in the source states the design precisely:

> V12 anchors the exact CHARACTER at the viewport probe instead — the same text always stays at
> the same screen pixel, in both directions, on every platform.

**The anchor structure:**
```ts
interface ModeAnchor {
  ratio: number;        // viewport probe as a fraction of the scroll container height
  delta: number;        // px from the anchor character's top to the probe (clamped -64…160)
  charIdx?: number;     // exact source char index (edit-mode capture)
  lineIndex: number;    // 0-based source line
  blockSrcLine?: number;// 1-based source line of the containing preview block
  needle: string;       // normalized text read from the anchor onward — the cross-mode needle
}
const PROBE_RATIO = 0.35;
```

Module-level holders survive remounts (so nothing but the user can change mode or scroll):
```ts
let lastPreviewState: boolean | null = null;
const scrollMemory = new Map<string, number>();
let lastEditorScrollTop = 0;
let lastEditorStateKey: string | null = null;
let lastModeAnchor: ModeAnchor | null = null;
```

### The mirror meter — measuring a textarea that has no DOM

A `<textarea>` exposes no per-character nodes. The solution is a **hidden mirror div**:

```ts
const MIRROR_STYLE_PROPS = [
  "boxSizing","width","paddingTop","paddingRight","paddingBottom","paddingLeft",
  "fontFamily","fontSize","fontWeight","fontStyle","letterSpacing","lineHeight",
  "textTransform","textIndent","whiteSpace","wordBreak","overflowWrap",
  "wordSpacing","tabSize","fontKerning","fontVariantLigatures",
];
```

The mirror is `position: fixed; left: -99999px; visibility: hidden; height: auto`, holds a
single `Text` node mirroring `ta.value`, and **copies every layout-affecting computed style from
the textarea on every `sync()`** — so a live change to the note text size is picked up.

It exposes two functions:

**`topOfChar(charIndex) → y`** — a `Range` over the text node from `i` to `i+1`, read via
`getClientRects()`. Two fallbacks:
- if the char sits on an **empty line** (right after `\n`) a collapsed range yields no rects →
  measure the **preceding** char and step one line down
- last resort → the prefix bounding box of the whole text

**`charAtY(yFromTaTop) → charIndex`** — a **monotonic binary search** for the last char whose top
is ≤ y, then a **walk-back** to the FIRST character of that visual row. Two V12 QA fixes live in
that walk-back:
- anchoring the row's **last** char made the needle start at the end of a wrapped row, which
  lands one rendered row **lower** in the preview (different wrap points)
- the walk-back **stops before newline glyphs** — Chromium reports a `'\n'` box on the row
  *after* the break, so without the guard the anchor could slide onto the blank line preceding a
  paragraph. Guard capped at 4,000 iterations.

### Capture — leaving a mode

**From EDIT:**
1. `getMeter(ta).sync()`
2. `yInTa = probeY - ta.getBoundingClientRect().top`
3. `charIdx = charAtY(yInTa)`
4. **Blank-line fix:** if `draft[charIdx] === "\n"`, scan forward to the next real character. A
   blank source row does not exist in the preview (CSS margins replace it), so anchoring the
   following text keeps the paragraph pixel-exact.
5. `delta = probeY - (taRect.top + topOfChar(charIdx))`
6. `needle = normText(draft.slice(charIdx, charIdx + 160))` — 160 chars from the anchor onward,
   **spanning lines**, because the preview renders a space where the source had a line break
   inside a paragraph and `normText` on both sides keeps them aligned
7. `lineIndex = draft.slice(0, charIdx).split("\n").length - 1`

**From PREVIEW:** `document.caretRangeFromPoint()` returns the exact text node + offset, plus
the containing `[data-src-line]` block.

**Normalisation:** `normText(s) = s.replace(/\s+/g," ").trim().toLocaleLowerCase()`.

**Markdown-approximation helper** `stripMdLine(line)` reduces one source line to its rendered
form (images→alt, links→text, drop tags, drop prefixes, drop table pipes, unwrap bold/italic/
strike/code, drop math delimiters) so source characters can be aligned with preview text nodes.
It is never persisted.

**A subtle correction:** if a settle-pin is currently holding an *intended* position, the DOM
`scrollTop` may lag a frame. `captureAnchor` reads `pinTargetRef.current ?? el.scrollTop`,
computes `scrollCorrection`, and subtracts it from the edit-side delta. Preview capture is
self-consistent (it re-pins the same mode it measured) so it needs no correction.

### Restore — entering a mode

**Into PREVIEW:**
1. Get all top-level blocks with `data-src-line` (one level of nesting for plugin wrappers like
   KaTeX spans).
2. Binary-search the last block whose `data-src-line <= want`.
3. **Search three candidate blocks** (the containing one plus the next two, because a needle tail
   can cross a block boundary) with `findTextTopInBlock`.
4. `findTextTopInBlock` walks the block's text nodes, concatenates normalised content, and
   tries a **candidate set** of needles: the raw needle, the markdown-stripped needle, and
   progressively shorter prefixes of each — but **never below 12 characters**, because a fragment
   like `"paragrap"` matches every repeated block prefix (`"Paragraph N:"`) and pinned the wrong
   block (a documented V12 QA fix).
5. If nothing nearby matches, fall back to the containing block's top. The V12 comment notes
   the old loop returned the start block immediately when its own text didn't contain the needle
   — e.g. anchors captured on the blank line before a paragraph — and landed a block too high.
6. Final scroll:
   `scrollTop + blockTopRel + found + delta - clientHeight * ratio`

**Into EDIT:**
1. `resolveChar()` — once, then memoised in a closure variable.
2. Build per-line stripped text and **4-line sliding windows**.
3. Match `needle.slice(0, 48)` against every window; extend the match; score by **smallest
   `at`, then longest match**. The V12 comment explains the tie-break: the needle is read *from*
   the anchor character onward, so in the true anchor line's window it matches at the smallest
   offset — earlier lines can only contain it further into their window. The old tie-break handed
   repeated-content windows to the **wrong (earlier) line**, anchoring several rows above target.
4. Accept only if `bestLen >= 8` and `bestAt` is within the line's own stripped length.
5. `charIdx = lineStart + round(withinRatio * lineLength)` where `withinRatio = bestAt / stripped[lineK].length`.
6. Measure with the mirror: `contentY = scrollTop + (taRect.top - elRect.top) + topOfChar(charIdx)`.
7. Return `contentY + delta - elRect.height * ratio`.

### The settle-pin — keeping the position while heights settle

```ts
const startScrollPin = (getTarget) => { … }
```
- Runs a `requestAnimationFrame` loop (cap 120 frames ≈ 2 s)
- Each frame: read the target, clamp to `[0, scrollHeight - clientHeight]`, apply if it differs
  by more than 1 px
- **Stops after 45 stable frames** — meaning the heights have settled
- A `ResizeObserver` on the scroll element **and** its first child resets `stableFrames` whenever
  async images or fonts change the new mode's height
- **Hands control back immediately** if the scroll moves more than 6 px from the last set value
  — this prevents the pin from fighting an external scroll that races a frame ahead
- A passive `scroll` listener provides a second user-scroll guard
- When the position is already correct, it still records `lastSet = el.scrollTop` so the guard is
  armed even if the pin never had to move the viewport
- `pinTargetRef` records the *intended* position for capture correction (see above)
- `runAnchorRestore()` is called from an effect that runs **after every render** — so mode
  switches, image resizes and task ticks all re-pin

**`overflowAnchor: "none"`** is set on the scroll container to stop the browser's own
scroll-anchoring from fighting the custom one.

**Per-note scroll memory** (separate from the anchor system): on unmount the current
`scrollTop` is stored in `scrollMemory[stateKey]` and in `lastEditorScrollTop`; on mount the
remembered position is applied **synchronously** first (an async-only pin left a window where a
fast mode toggle captured a stale position and clobbered the restore — the "switch back jumps to
top" bug), then `startScrollPin` keeps it applied as content grows.

**Focus without scroll:** `textareaRef.current?.focus({ preventScroll: true })` — plain
`focus()` scrolled the fresh textarea into view and threw the viewport to the top on every
preview→edit toggle.

**Debug hook:** `window.__lastAnchor = anchor` is set on each toggle — harmless, and lets QA
tooling inspect the captured anchor and restore targets while the pin runs.

**Other actions that preserve the viewport:** `setImageSize` captures `preservedScrollTop`,
stops the pin, clears the pending anchor, and re-applies the scroll across **two** nested
`requestAnimationFrame`s because the browser clamps to 0 while the image reflows.
`insertImage` / `insertImages` likewise save and restore `scrollTop` around the caret
repositioning.

## 9.10 Image sizing inside the preview

V10 replaced an always-visible overlay (a large logo/button over every image) with a
**deliberately hidden control**, so reading and scrolling never shows a big button.

- **Open:** long-press (520 ms timer, `pointerType === "mouse"` requires button 0) or
  right-click / `onContextMenu`.
- **A `suppressClickRef` guard** consumes the click that ends the long-press so it does not also
  open the lightbox.
- The menu is **`position: fixed`** so it is not re-laid out with the image when its width
  changes, and is clamped against the viewport (`menuWidth = 198`, `menuHeight = 132`, `gap = 10`).

**Presets:** `S 35% · M 55% · L 75% · Full 100% · Auto (null)` plus a range slider
`min=20 max=100 step=5` (default 60 when unsized) and a Done button. The current value is shown
as `"Auto"` or `"NN%"`.

**Storage is scoped to the selected object:**
- a normal Markdown image → `size=NN` in **that image's** title
- an HTML grid → `data-size=NN` on **that grid's** div

`setImageSize` locates the exact occurrence **by source line** (it does not depend on a blob
URL lookup, because the persisted draft holds an attachment path while the preview holds a
resolved blob URL). For images it also cross-checks the decoded URL against the display URL, the
mapped file, and the encoded path. `parseImageSize` only accepts 10–100.

**CSS behaviour:**
```css
.md-preview img.md-inline-image {
  display: block;
  max-width: min(100%, var(--note-media-single-max, 100%));
  height: auto; max-height: 60vh; object-fit: contain; cursor: pointer;
}
.md-preview img.md-inline-image[data-size] { max-width: 100%; max-height: none; }
.md-preview .img-grid img.md-inline-image { width: auto; max-height: none; margin: 0; }
```
Unsized images render at **natural width, capped at 100% and 60vh tall**. Explicitly sized ones
get the width inline and lift the auto caps so the explicit width wins.

## 9.11 History / undo / redo

The native textarea undo stack is broken by (a) React's controlled `value` and (b) programmatic
changes from toolbar buttons, task ticks and image inserts. So the editor keeps its own:

```ts
interface HistoryEntry { text: string; selStart: number; selEnd: number }
histRef = { entries, index, lastCommitAt, lastKind }
```

- `resetHistory(text)` on mount and on an external value change
- `commitHistory(text, kind: "type" | "action")`
- **Typing coalescing:** consecutive `type` commits within **650 ms** replace the current entry
  instead of pushing a new one → word-ish chunks
- **Every button action is its own step**
- Capped at **300 entries** (oldest shifted out)
- A new action after an undo truncates the redo tail (`entries.slice(0, index + 1)`)
- `applyHistoryEntry` sets the draft, `pushNow`s it, re-emits search if a query is active, and
  restores the selection inside a `requestAnimationFrame` (wrapped in try/catch for detached nodes)
- Undo/redo clear `lastKind` so the next keystroke starts a new burst

## 9.12 Throttled persistence and flush points

V5 fixed a freeze on large pastes: every keystroke used to flow straight into the Zustand store,
re-rendering the whole app behind the editor.

```ts
pushNow(text)         // set lastPushedRef, set throttle time, call onChange immediately
pushThrottled(text)   // leading edge if ≥140 ms since the last push, else schedule a trailing push
flushPendingPush()    // clear the timer and push draftRef.current right now
```

- **Leading + trailing 140 ms throttle.** Typing updates the local `draft` instantly; the store
  push is throttled. **Programmatic edits (toolbar, images, tasks) push immediately** via `pushNow`.
- `lastPushedRef` lets the value-sync effect recognise its own echo and **not** reset the local
  draft.
- `updateDraft(next, kind)` is the single funnel: `fromDisplay` → `setDraft` → push (throttled for
  type, immediate for action) → `commitHistory` → re-emit search if active.

**Flush points** (all call `flushPendingPush`):
- editor close (`close()` in `NoteEditorView`)
- `visibilitychange → hidden` (app backgrounded mid-typing)
- editor unmount (which also calls `flushUpdate`)
- store `flushAll()` (used by `beforeunload` / Android `onDestroy` via `window.__flushLocalData`)

Then the store's own **600 ms debounce** (`pendingSaves` map, per note, with merged patches) and
the repository's `writeLock` mutex provide the second and third layers.

## 9.13 In-note search and highlight

Opened from the editor header (magnifier). The bar lives in `NoteEditorView`; the engine is in
the editor.

**Edit mode:**
- query is NFKC-normalised and lowercased
- the draft is normalised the same way and scanned with `indexOf` in a loop
- all match offsets are collected
- the active index wraps: `((preferred % count) + count) % count`
- the match is scrolled into view at 35% of the container height with `behavior: "smooth"`,
  computing `el.offsetTop + line * lineHeight`
- **critically:** `el.setSelectionRange(match, match)` is used with **no focus and no select** —
  focusing or selecting would steal focus from the search field and make the next typed character
  replace text

**Preview mode:**
- the query is regex-escaped and injected as `<mark class="search-hit">` into the content
  string before rendering
- HTML in the match is escaped
- an effect toggles `search-hit-active` on the current match and scrolls it to 35%

The view-side query push is **debounced 180 ms**. Keys: `Enter` / `Shift+Enter` navigate
(forward/backward, wrapping), `Escape` closes.

The reported `{count, active}` comes back through `onSearchResults` and drives the `n/m` counter
and the disabled state of the prev/next buttons.

## 9.14 URL round-tripping: attachment paths ↔ display URLs

This is the mechanism that keeps `blob:` URLs **out of the file on disk**.

### `toDisplay(md)` — draft → preview
```ts
md.replace(/(!?\[([^\]]*)\])\(\s*(attachment\/[^)\s]+)((?:\s+"[^"]*")?)\s*\)/g,
  (full, label, alt, file, title) => {
    const decoded = decodeAttachmentPath(file);
    const url = fileToUrl(decoded) || fileToUrl(file);
    return url ? `![${alt || decoded.split("/").pop() || "Attached image"}](${url}${title})` : full;
  })
```
Two behaviours:
- the `!?` makes **attachment links render as images** even when an older note stored them as
  `[filename](attachment/x.png)` rather than `![alt](…)`
- the **title is preserved verbatim**, which is what carries the `size=NN` through the pipeline
- if the file can't be resolved the original text is returned unchanged (graceful)

### `fromDisplay(md)` — preview → draft
```ts
md.replace(/\]\(\s*(blob:[^)\s]+|data:[^)\s]+)((?:\s+"[^"]*")?)\s*\)/g, …)  // markdown images
md.replace(/(<img\b[^>]*?\bsrc=")(blob:[^"]+|data:[^"]+)(")/gi, …)             // grid <img src>
```
Both look the URL up in `urlToFileRef.current` and substitute `encodeAttachmentPath(file)`.
So `![alt](blob:http://…)` becomes `![alt](attachment/photo%20copy.png)` before it is ever
pushed to the store — and therefore before it is ever written to `node.md`.

`fromDisplay` is called from `updateDraft` and from every imperative insert/remove, so **no code
path can leak a blob URL to disk**.

## 9.15 Known limits and edge cases in the editor

1. **Inserting while in preview mode** — the textarea is unmounted, so `insertImage` /
   `insertImages` fall back to appending at the end of the body with `\n\n` padding. This is
   documented in the code; V4 fixed a version where it "silently did nothing".
2. **The multi-format popover does not include headings in a meaningful way with a
   selection spanning lines** — `h1/h2/h3` prepend to `before`, which is correct, but combined
   with `bold` the ordering is `before` appended in iteration order and `after` prepended in
   reverse, so a specific order like `bold + h2` yields `## **text**` only for that selection order.
3. **Clear formatting with a mid-line selection** — the first line of the selection keeps its
   line-level prefix if the selection doesn't start at a line boundary (`atLineStart` check), and
   only that first line is treated specially.
4. **`markdownToPlain` and search** operate on the raw body, so search matches inside fenced code
   blocks and image URLs. This is intentional (find-what-you-searched-for) but means a search for
   `png` matches every image path.
5. **Scroll anchoring is a heuristic**, not exact, for repeated identical text. The 12-character
   needle floor and the three-block candidate window are documented mitigations, not proofs.
6. **`initialPreview` defaults to true**, and `lastPreviewState` is module-level — so the mode is
   remembered *across notes and remounts*, which is what stops a new note's first word from
   "auto-switching" modes, but it also means a user who left preview on will open new notes in
   preview.
7. **The mirror is only disposed when a textarea exists** (`disposeMeter()` in the effect
   cleanup) — a preview-only note has no mirror, which is correct but means the anchor
   measurement in that state is DOM-based only.

---

# 10. IMAGE UPLOAD SYSTEM — complete anatomy

## 10.1 The two-zone model: attachment grid above, markdown body below

**This is a deliberate architectural rule introduced in V8.5, and the user asked about it
specifically.**

The editor screen is a fixed full-viewport dialog:

```
┌──────────────────────────────────────────────┐
│ ←  📌  🔍                          ✕         │  header (h-14)
├──────────────────────────────────────────────┤
│ [ Find in note…            2/5  ⌃ ⌄ ✕ ]       │  optional search bar
├──────────────────────────────────────────────┤
│ ┌──────────────────────────────────────────┐ │  ← beforeContent, ABOVE the body
│ │ ┌────┐┌────┐┌────┐┌────┐        [⊞]      │ │  ← THE ATTACHMENT GRID (max-h-32)
│ │ │ ✎  ││ ✕  ││ ⊕  ││    │                  │ │     4 overlay buttons per thumbnail
│ │ └────┘└────┘└────┘└────┘                  │ │
│ └──────────────────────────────────────────┘ │
│ Title input (text-xl)                        │  ← the title
├──────────────────────────────────────────────┤
│ ══════════════ MARKDOWN TOOLBAR ═══════════ │  ← sticky
│ [👁] [B][I][U][S][`]|H1H2H3¶|lists…|links…  │
│ 👁 👁 | | ⊞ | ➖ | ▦ | ⌫ | ↶ ↷               │
├──────────────────────────────────────────────┤
│                                             │
│         EDIT TEXTAREA  ⇄  PREVIEW           │  ← the body
│         (one shared scroll container)        │
│                                             │
├──────────────────────────────────────────────┤
│ 🎨 🖼 ☑ 🏷 📁 📦 ⋯              [ Done ]     │  footer
└──────────────────────────────────────────────┘
```

**The attachment strip is rendered by `NoteEditorView` as `beforeContent` and passed into
`MarkdownEditor`, which renders it *inside* the same scroll container** — above the title and
the body. This is why both zones scroll together and why a mode toggle never moves it.

**The rules (V8.5, from the source comment):**

> EVERY upload path — footer picker, editor toolbar button, composer shortcut, image paste —
> stores images into the attachments area ONLY. Auto-insertion into the note body is now
> structurally impossible: the old "insert" pick-mode (and the `pickModeRef` that could stay
> poisoned after a cancelled picker) is gone. An image lands in the body exclusively via a
> thumbnail's explicit "Insert into note" button — or the V5 "insert at cursor" picker, which
> registers the upload first and then inserts explicitly.

So:
- **Uploading ≠ inserting.** The two are separate, explicit acts.
- The old `pickModeRef` poisoning bug class is structurally eliminated rather than patched.

## 10.2 Upload entry points — all six

| # | Entry point | Where | Goes to | Inserts into body? |
|---|---|---|---|---|
| 1 | Hidden `<input type="file" accept="image/*,.gif" multiple>` | `NoteEditorView` bottom, `fileInputRef` | `attachPickedFiles` | **No** |
| 2 | Footer `MediaPickPopover` (🖼) | `NoteEditorView` footer | `addNoteMedia` | **No** (V8 bug #2 fix) |
| 3 | Toolbar `ImagePlus` (📷) | `MarkdownEditor` → `onRequestInsertImages` → clicks #1 | `attachPickedFiles` | **No** |
| 4 | Composer "New note with image" | `Composer` → `notes:editor-pick-media` event → clicks #1 | `attachPickedFiles` | **No** |
| 5 | **Paste** images into the textarea | `MarkdownEditor.onPaste` → `onPasteImages` | `attachPickedFiles` | **No** |
| 6 | **Insert-at-cursor popover** → "Choose new images" | `ImageInsertPopover` → `uploadForInsert` | `addNoteMedia` **then** `insertImages` | **Yes** |

Plus two non-upload insertions:
- a thumbnail's **⊕ "Insert into note"** button → `insertAttachmentIntoEditor` → `insertImage`
- the insert-at-cursor picker's "From this note" grid → `insertImages`

The hidden input resets `e.target.value = ""` after every change, so selecting the same file
twice fires the event again.

## 10.3 Compression / preparation pipeline

`src/components/keep/media.ts`:

```ts
const MAX_GIF_BYTES = 8 * 1024 * 1024;   // 8 MB
const MAX = 1600;                          // px, longest edge
```

`compressImage(file, name)`:
1. **GIFs pass through untouched** to preserve animation — but are **rejected above 8 MB** with
   `"…" is too large — GIFs must be under 8MB`
2. `createImageBitmap(file)`
3. If both dimensions ≤ 1600 → close and return the original file untouched (**no re-encode**)
4. Otherwise compute a ratio preserving aspect ratio, floor at 1 px
5. Draw to a `<canvas>` at the target size
6. Output MIME: `image/png` stays PNG (transparency), everything else becomes `image/jpeg`
7. `canvas.toBlob(blob, mime, 0.82)` — **82% quality**
8. Any failure → return the original file (never blocks an upload)

`prepareMedia(files)` → `Promise.all(files.map(compressImage + keep name))`.

`fetchMediaFromUrl(url)` — CORS fetch, rejects non-images, derives a file name from the URL
path (adding `.gif`/`.png`/`.jpg` if there's no extension), returns `{blob, name}`.

`prepareAndUpload` is a kept-for-compatibility sequential variant.

## 10.4 Attachment writing to disk

`store.addNoteMedia(noteId, files)`:

**Draft path (`noteId === DRAFT_ID`)**
- de-duplicate on **name + size** against both `draftMedia` and the current batch
- `URL.createObjectURL` immediately for an instant preview
- push to the module-level `draftMedia` buffer
- append to `draftNote.attachments`
- trigger `__ensureDraftMaterialized()`

**Persisted-note path**
- de-duplicate on **name + size** against `note.attachments` and a per-batch `seenBatch` set
- `repo.addAttachment` → `writeMediaFile`:
  - `makeDir(<dir>/attachment)`
  - list existing names
  - `sanitizeFileName(media.name || "image")`
  - `uniqueName(safe, existing)` → `photo.png`, `photo (2).png`
  - `new Uint8Array(await blob.arrayBuffer())` → `fs.writeBinary`
  - MIME from `blob.type` falling back to `mimeForName`
  - `kind: mime === "image/gif" ? "gif" : "image"`
  - returns the DTO with `url: ""`
- `repo.ensureAttachmentUrl` → an object URL
- append to the note's attachments in the store

**The de-duplication is a documented V8.5 hardening:** Android pickers and WebViews can re-deliver
the last file of a batch as an extra `change` event, which used to duplicate images. Same
name + same size is never stored twice by **any** upload path.

## 10.5 Object-URL lifecycle and caching

`NoteRepository.urlCache: Map<"<dir>/<attachment/file>", "blob:...">`

| Event | Behaviour |
|---|---|
| `ensureAttachmentUrl` | cache-first; miss → read bytes → `new Blob([bytes], {type: mimeForName})` → `createObjectURL` → cache |
| `writeAttachment` (image editor save) | revoke the old URL, delete from cache, create a new one |
| `removeAttachment` | revoke + delete |
| `deleteNoteDir` | `invalidateDirUrls(dir)` — revoke every URL whose key is or starts with `dir/` |
| `renameDir` | `rekeyUrls(old, new)` — **re-keys without revoking**, so a rename does not break every visible image |
| `duplicateNote` | the copy's keys are seeded with the **source's cached URLs** so previews work instantly |

Front-end hooks:
- `useAttachmentUrl(dir, att)` — per-thumbnail lazy resolution, keyed on `${dir}/${att.file}`,
  with an `alive` guard against setting state after unmount
- `resolveAttachmentUrls(dir, attachments)` — batch, used before opening the editor and the gallery

DTOs from a disk `scan()` always have `url: ""`; the URL layer fills them in lazily. This is why
opening a folder with 500 notes does not read 500 images.

## 10.6 The thumbnail grid and its four buttons

`EditorThumb` — 80×80 px (`h-20 w-20`), rounded, `overflow-hidden`:

```tsx
<div className="group relative h-20 w-20 overflow-hidden rounded-md border border-black/10">
  <button onClick={onOpen}>          {/* image or an animate-pulse skeleton */}
    {url ? <img src={url} /> : <div className="… animate-pulse bg-black/5" />}
  </button>
  {att.kind === "gif" && <span>GIF</span>}   {/* bottom-right badge */}
  <button aria-label="Edit image"   … />      {/* ✎ top-left   */}
  <button aria-label="Remove media" … />      {/* ✕ top-right  */}
  <button aria-label="Insert into note" … />  {/* ⊕ bottom-left */}
</div>
```

All three overlay buttons `stopPropagation` so they never open the lightbox. All are 24 px
round translucent-black buttons that darken on hover.

**The strip:**
```tsx
<div className="relative mb-2 max-h-32 overflow-x-hidden overflow-y-auto rounded-lg border … p-2">
  <button aria-label="View all images" … />   {/* ⊞ absolute right-2 top-2, z-10 */}
  <div className="grid min-w-0 grid-cols-[repeat(auto-fill,minmax(5rem,1fr))] gap-2.5 overflow-hidden pr-10">
    {note.attachments.map(…)}
  </div>
</div>
```

- **`max-h-32`** = 128 px — the strip scrolls vertically when there are many images, so it can
  never crowd out the body
- **`grid-cols-[repeat(auto-fill,minmax(5rem,1fr))]`** — auto-fill columns of at least 80 px, so
  the count per row adapts to width automatically (2 on a phone, 3–5 on desktop, more on wide)
- `pr-10` reserves space for the gallery button
- The `⊞` button opens the **full-screen gallery**: a 2-column / 3-column-on-sm grid of square
  (`aspect-square`) thumbnails, each opening the lightbox

**Memoization:** the whole `beforeContent` block is `useMemo`'d on
`[note?.id, note?.attachments, note?.title, urlMap, isDraft]` with an eslint suppression — so
typing in the body does not rebuild the strip or the title on every keystroke.

**Skeletons:** an unresolved URL renders an `animate-pulse` block, never a broken image.

## 10.7 Grid rules: 1 image vs many images

**This is the `insertImages` implementation — the exact decision the user asked about.**

```ts
insertImages: (items) => {
  if (!items || items.length === 0) return;
  const el = textareaRef.current;
  let snippet: string;
  if (items.length === 1) {
    // ── ONE IMAGE → a plain Markdown image (no grid at all)
    snippet = `![${items[0].alt || items[0].url}](${items[0].url})`;
  } else {
    // ── MANY IMAGES → an HTML grid
    const cols = items.length <= 4 ? 2 : 3;
    const imgs = items
      .map((it) => `<img src="${it.url}" alt="${(it.alt || "image").replace(/"/g, "&quot;")}">`)
      .join("\n");
    snippet = `<div class="img-grid" data-cols="${cols}">\n${imgs}\n</div>`;
  }
  …
}
```

### The rule, precisely

| Selected images | Stored as | Columns | Renderer |
|---|---|---|---|
| **1** | `![alt](blob:…)` — **plain Markdown image** | n/a | the `img` component, per-image size menu |
| **2–4** | `<div class="img-grid" data-cols="2">` | **2** | the `div` component, grid size menu |
| **5+** | `<div class="img-grid" data-cols="3">` | **3** | same |

So the threshold is `items.length <= 4 ? 2 : 3`. A single image is *never* wrapped in a grid —
it uses the ordinary inline image path with its own S/M/L/Full size control.

### Grid placement in the body

Padding is computed on both sides so the grid never fuses with adjacent text:
```ts
const padBefore = before && !before.endsWith("\n") ? "\n\n" : before ? "\n" : "";
const padAfter  = after  && !after.startsWith("\n") ? "\n\n" : after  ? "\n" : "";
const next = `${before}${padBefore}${snippet}${padAfter}${after}`;
```
The caret is then placed at `before.length + padBefore.length + snippet.length` inside a
`requestAnimationFrame`, and `scrollTop` is saved and restored around it.

If the textarea is not mounted (preview mode), the snippet is appended at the end with `\n\n`.

### Grid CSS — the actual layout rules

```css
.md-preview .img-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 8px;
  width: 100%;
  max-width: min(100%, var(--note-media-grid-max, 100%));
  margin: 0.6rem 0;
}
.md-preview .img-grid[data-cols="3"] {
  grid-template-columns: repeat(3, minmax(0, 1fr));
}
.md-preview .img-grid img {
  width: 100%; height: auto;
  aspect-ratio: 1 / 1;         /* square tiles */
  object-fit: cover;            /* crop, never distort */
  border-radius: 10px;
  border: 1px solid rgb(0 0 0 / 0.06);
  cursor: pointer; display: block;
  background: rgb(0 0 0 / 0.04);
  -webkit-touch-callout: default;
  transition: transform 200ms cubic-bezier(0.22, 1, 0.36, 1);
}
.md-preview .img-grid img.md-inline-image { max-width: 100%; max-height: none; margin: 0; }
.md-preview .img-grid img:hover { transform: scale(1.015); }
.dark .md-preview .img-grid img { border-color: rgb(255 255 255 / 0.08); }
@media (max-width: 480px) {
  .md-preview .img-grid { gap: 6px; }
  .md-preview .img-grid img { border-radius: 8px; }
}
```

**Every tile gets its own equal square cell** — `aspect-ratio: 1/1` + `object-fit: cover`
means tiles are tightly packed, never overlapping, never clipped and never distorted,
regardless of the source aspect ratios. The header comment in the CSS states this intent
explicitly.

### The grid width setting

`--note-media-grid-max` is injected **per editor instance**:
```tsx
<style>{ ["--note-media-grid-max"]: `${settings.mediaGridWidth}%` }</style>
```
Bound in `loadSettings()` to **40–100, default 75**. This is the *only* global media setting —
single images are sized per-image by design (V6 removed the old `mediaSingleWidth` global).

### Per-grid size override

Long-press / right-click a grid → the same size menu → writes `data-size="NN"` on **that grid
only**:
```ts
const gridRe = /<div\b([^>]*\bclass=(?:"img-grid"|'img-grid')[^>]*)>/gi;
next = next.replace(gridRe, (full, attrs, offset) => {
  if (changed || (target.sourceLine && lineAt(draft, offset) !== target.sourceLine)) return full;
  changed = true;
  let updated = attrs.replace(/\sdata-size=(?:"[^" ]*"|'[^' ]*')/i, "");
  if (size != null) updated += ` data-size="${size}"`;
  return `<div${updated}>`;
});
```
The `div` component then applies `style={{width: size + "%"}}` inline.

### Portability

The grid is **plain HTML whose `<img src>` round-trips to `attachment/…` paths on disk**:

```
<div class="img-grid" data-cols="2">
<img src="blob:http://…" alt="a">
<img src="blob:http://…" alt="b">
</div>
        ↓ fromDisplay() on save
<div class="img-grid" data-cols="2">
<img src="attachment/a.png" alt="a">
<img src="attachment/b.png" alt="b">
</div>
```

So `node.md` stays readable by Obsidian and any HTML-aware Markdown tool, and the relative
paths are the whole point — they resolve relative to the note folder.

### Grid size vs note text scale

`data-cols` is **fixed by the image count, not responsive** — a 2-column grid stays 2 columns
on a phone. Only the *gap* and *border-radius* change below 480 px. This is a deliberate
simplicity choice: the grid column count is a property of the content, so it renders identically
everywhere the note is opened.

## 10.8 Image size metadata and where it is stored

| Object | Storage location | Example |
|---|---|---|
| Single image | markdown **title** | `![alt](attachment/x.png "size=75")` |
| Image grid | **attribute** on the wrapper | `<div class="img-grid" data-cols="2" data-size="60">` |
| Grid columns | `data-cols` | `2` or `3` |
| Grid tiles' aspect | CSS only (`aspect-ratio: 1/1`) | not stored per-image |

Both are plain Markdown/HTML attributes, so they survive the round trip through Obsidian and
through a ZIP export/import.

## 10.9 Image editor, lightbox, and removal

### ImageEditorDialog (780 lines)
Three tools: `crop`, `draw`, `text`. Crop has aspect-ratio presets, drag handles and an
`applyCrop` that re-draws the crop rect into a new canvas. Draw is freehand with a colour
picker. Text places text at a point. Undo, "Reset to original", and **Save** which calls
`store.saveEditedImage` → `repo.writeAttachment` (overwrite the bytes, revoke the old URL,
mint a new one). Canvas cursors change per tool (`crosshair` / `text` / `default`).

### Lightbox (175 lines)
Full-screen viewer with four actions:

| Action | Effect |
|---|---|
| Download | `save-blob.ts` → user downloads the original bytes |
| ✎ Edit | opens the ImageEditorDialog |
| ⊘ **Remove from note** | calls `removeImageReference(markdownUrl)` — strips the markdown reference only, **the file stays on disk** |
| 🗑 **Delete** | removes the reference **and** deletes the attachment file |

The last two only appear when the lightbox was opened from inside a note body, because the
payload then carries `noteId` and `markdownUrl`. Opened from a card, the lightbox offers
download + edit.

### `removeImageReference(url)` — the cleanup logic

```ts
const cands = new Set([url]);
const file = urlToFileRef.current.get(url);
if (file) { cands.add(file); cands.add(encodeAttachmentPath(file)); }
for (const cand of cands) {
  next = next.replace(new RegExp(`!\\[[^\\]]*\\]\\(\\s*${esc}[^)]*\\)\\s*`, "g"), "");   // markdown
  next = next.replace(new RegExp(`\\s*<img\\b[^>]*\\bsrc="${esc}"[^>]*>\\s*`, "gi"), ""); // grid
}
next = next.replace(/<div class="img-grid"[^>]*>\s*<\/div>\s*/gi, "");  // collapse empties
next = next.replace(/\n{3,}/g, "\n\n");                                   // tidy blank runs
```
It tries the display URL, the mapped file path and the encoded path, handles both the Markdown
and the grid-HTML form, **collapses a grid that has been emptied**, and collapses runs of 3+
newlines. It is a no-op (no history entry) when nothing changed.

---

## 11. The note editor screen

`NoteEditorView.tsx`, 1,150 lines. A `role="dialog" aria-modal="true"` fixed
`inset-0 z-50 h-[100dvh]` container — **`100dvh`**, so it tracks the mobile dynamic viewport and
does not jump when the on-screen keyboard opens. The note's `noteStyle(color, isDark)` is spread
onto the container so the whole screen takes the note colour.

**Header (h-14):** back (arrow) · pin (rotated 45°, `fill-current` when pinned, hidden when
trashed) · search toggle (with an active background) · spacer · close.

**Search bar** (conditional): icon, input, `n/m` counter in tabular figures, prev/next, close.
`autoFocus` on open.

**Editor:** `<MarkdownEditor stateKey={editorNoteId ?? "editor"} … initialPreview autoFocus />`.
**There is deliberately no React `key`** — the V4 comment explains that keying on `editorNoteId`
remounted the whole editor the moment a new note materialised on disk, which reset the mode
AND the caret mid-word (the "first word auto-flips mode + weird word" bug). The internal value
effect syncs note switches; `stateKey` keeps scroll memory.

**Footer:** colour picker · media picker · checklist/text toggle · labels · folder menu ·
archive toggle · more menu (vault move, copy note text, make a copy, delete with an **Undo** toast
for 6 s) · spacer · **Done**. When the note is trashed the footer is replaced by
restore / delete-forever / "This note is in the trash".

**Escape** closes — but only if no Radix popper is open
(`document.querySelector("[data-radix-popper-content-wrapper]")`), so Escape closes a popover
before the editor.

**Jump buttons:** two floating round buttons (bottom-right, `bottom-20 right-4`) that appear
only when `scrollable` (content > viewport + 24 px), with the top button fading out at the top
and the bottom at the bottom. Scroll-state measurement is refreshed on scroll, on a
`ResizeObserver`, on window/`visualViewport` resize and scroll, immediately + after two rAFs +
after a 350 ms settle timer, and after 250 ms — the code notes that a single stale measurement
used to hide the Down button after closing the keyboard (V8 bug #5).

**Closing** is careful about the draft:
```ts
if (editorNoteId === DRAFT_ID) {
  if (title || bodyHasRealContent(content) || attachments.length) {
    editorHandle.current?.flushPendingPush();
    void __ensureDraftMaterialized().finally(() => setState({ editorNoteId: null }));
  } else {
    // empty draft → discard entirely, never touch the disk
    setState({ draftNote: null, editorNoteId: null });
  }
} else {
  editorHandle.current?.flushPendingPush();
  const md = editorHandle.current?.getMarkdown();
  if (md != null && md !== note.content) updateNote(id, {content: md}, true);  // immediate
  else void flushUpdate(id);
  openEditor(null);
}
```

---

## 12. State store — `store.ts`

1,366 lines, Zustand `create<KeepState>`. This is the app's state engine.

### Debounced save queue (module level, outside React)

```ts
const pendingSaves = new Map<string, { timer; patch; retries? }>();
```

`updateNote(id, patch, immediate = false)`:
1. **Draft path** (`DRAFT_ID`): merge locally into `draftNote`; if the draft is gone but
   `lastMaterializedId` is set, forward the patch to the real note instead of dropping the
   keystrokes; then `scheduleDraftMaterialize()`
2. **Persisted path:** optimistic local update via `applyPatchToNote` (which always bumps
   `updatedAt` and re-derives `items` when content changes), then merge into any existing
   pending patch, clear the old timer, and either flush immediately or set a **600 ms** timer

`flushUpdate(id)` clears the timer, deletes the entry, saves. **On failure it re-queues with
exponential-ish backoff** (600 × retries, capped at 8 s, max 6 retries) — V7 fixed a bug where a
failed write was dropped forever (the pending entry had already been deleted), losing the user's
edits when a rename raced the queued save. After 6 failures it shows a toast.

`flushAll()` flushes every pending save and materialises the draft if it has content.

### Draft materialisation

New notes start as **in-memory drafts** (`DRAFT_ID = "__draft__"`) and only touch the disk when
they have real content (`draftHasContent`: non-empty title, content, attachments or buffered
media).

`__ensureDraftMaterialized()` is guarded by `materializeChain` so only one create can run at a
time. It:
- snapshots what it's about to write and drains `draftMedia`
- calls `repo.createNote({...snapshot, media})`
- carries the optimistic preview URLs over by file name
- **detects drift** — whether the draft changed while the create was in flight — and if so
  re-applies the latest patch, persists it immediately, and reports the merged note
  (V8 data-loss fix)
- on failure restores `draftMedia` and returns null
- sets `lastMaterializedId`

**V7 fix:** materialisation used to run on the *first keystroke*, creating a folder named after a
one-character title (`"R"`) that then had to be renamed repeatedly — each rename a chance to race
and orphan folders. It now uses a **500 ms debounce** (`scheduleDraftMaterialize`); closing and
unloading stay immediate.

### Everything else in the store

- **Storage lifecycle:** `bootstrap`, `rescan`, `chooseFolder`, `selectInAppStorage`,
  `reauthorize`, `changeFolder`, with `storageStatus: "loading" | "setup" | "reauth" | "ready" | "error"`
- **Vault:** `requestVaultAccess`, `resolveVaultCode`, `completeVaultSetup`, `closeVault`
- **Attachments:** `addNoteMedia`, `removeNoteAttachment`, `renameNoteAttachment` (**a documented
  no-op** — attachments are referenced from markdown by path, so renames happen through link
  editing, not a dedicated UI action)
- **Lifecycle:** `trashNote` (also un-pins), `restoreNote` (also un-archives), `deleteForever`,
  `emptyTrash`, `duplicateNote`, `reorderNotes`
- **Folders & labels:** full CRUD, all writing `.notes/config.json` and **rewriting the
  front-matter of every affected note** (a folder rename or label rename updates the `folderId`
  / labels of every note pointing at it, and persists each)
- **V12 bulk selection:** `toggleSelectMode`, `exitSelectMode`, `toggleNoteSelected`,
  `setVisibleIds` (maintained by `NotesView` for select-all), `selectAllVisible` (doubles as
  clear when everything is already selected), `clearSelection`, `bulkUpdate`, `bulkTrash`,
  `bulkDeleteForever`
  - `bulkUpdate` and `bulkTrash` write **immediately** per note (not debounced) and report
    failures with a toast
  - `bulkTrash` offers a **single Undo** toast listing up to 3 note titles plus "+N more"
- **Selection helpers:** `scopeNotes(notes, view, folderId, labelId)` implements the view
  filtering rules, `filterBySearch` searches title, raw content, `markdownToPlain(content)`,
  checklist item text, label names, folder name and attachment file names — all NFKC-normalised
  and lowercased; `sortNotes` puts manually-ordered notes first (ascending `order`) and the rest
  by recency after them, falling back to pure recency if nothing has a manual order

---

## 13. Notes grid, cards and drag & drop

### MuuriGrid (632 lines)
Muuri-powered masonry with a **custom shortest-column layout function** (the same packing as
Google Keep). The design note explains the contract precisely:

- `.muuri-item` divs live in **store order**
- Muuri owns the **position** of cards — it writes transforms directly and animates them
- during a drag Muuri only reorders its internal item array, never the DOM
- on drop (`dragReleaseEnd`) React re-renders children in the new order; since Muuri positioned
  everything with transforms, re-parenting is invisible — and Muuri's item array and the
  rendered order are then identical for the next gesture
- **touch scrolling coexists with dragging:** touch-action is `none` only while a drag is
  actually active
- layout: a custom shortest-column masonry so the grid stays symmetric with minimal bottom gaps
  while Muuri animates every reflow
- long-press starts a drag on touch, mouse drags start after 4 px, with a haptic tick on lift;
  **clicks right after a drag are swallowed** so they never open the editor
- autoscroll is **edge-only**; a long-press hold guard stops the browser cancelling drags
- a shared easing curve (`GLIDE`) is used for both layout moves and drop release

`MuuriGridLazy` defers mounting the grid.

### NoteCard (729 lines, `memo`ised)
- Colour from `noteStyle(note.color, isDark)`
- Attachment preview: a 4-tile strip (`h-40` in grid layout, `h-32` in list) with an
  `aspect-square` main tile and a `+N` overflow tile; opens the lightbox; an edit button on the
  main tile
- **Preview text is `markdownToPlain(note.content)`**, memoised, so no markdown or raw HTML
  leaks into the card
- Checklist mode shows a progress count (`doneCount` via `useMemo`) and the first 4 items with a
  "Show N more items" expander
- Text is clamped (`line-clamp-6` in grid, `line-clamp-4` in list) with a "Read full note" /
  "Show less" toggle
- Pin toggle, per-card menu (folder, restore, archive, delete, copy, etc.)
- In V12 selection mode the whole card becomes an `aria-pressed`-style select/deselect target
  and the inner controls stop propagating

---

## 14. Settings — every setting explained

`SettingsDialog.tsx` (1,021 lines) has **5 tabs**: `general`, `appearance`, `search`, `vault`,
`about`.

### The store (`settings-store.ts`, 167 lines)

Settings are **not** in Zustand. They are a module-level object with a manual listener set,
exposed to React through `useSyncExternalStore` — deliberately hydration-safe:

```ts
export function useSettings(): AppSettings {
  return useSyncExternalStore(subscribe, getSettings, getDefaults);
}
const getDefaults = () => DEFAULT_SETTINGS;   // server snapshot = defaults
```

This is why settings are correct on the first paint and never cause a hydration mismatch.
`hydrateSettings()` runs once after mount; `updateSettings()` writes to `localStorage` and
emits; `resetSettings()` clears the key.

**Persistence key:** `localStorage["notes-app-settings-v1"]`

### Every setting

| Setting | Type | Default | Range / values | Where it takes effect |
|---|---|---|---|---|
| `appName` | string | `"Notenoid"` | — | Top bar wordmark; **migrated** if it is still the legacy `"Notes"` |
| `wallpaper` | string (data URL) | `null` | — | Full-viewport `WallpaperLayer` behind everything; compressed to a data URL on pick |
| `wallpaperBlur` | number | `8` | 0–40 px slider | `filter: blur(Npx)` + `scale(1.06)` when > 0 (to hide blurred edges) |
| `wallpaperDim` | number | `35` | 0–80 % slider | A `rgb(0 0 0 / N%)` overlay |
| `wallpaperFixed` | boolean | `true` | switch | `fixed` vs `absolute` positioning |
| `density` | `"compact" \| "cozy" \| "spacious"` | `"cozy"` | — | `DENSITY_CLASS` map: grid gap 12/20/28, card margin `mb-4/6/8`, list gap, padding |
| `uiScale` | number | `100` | **70–150**, step 5 | **The whole app** — root font-size, so every rem-based Tailwind size grows together |
| `markdownScale` | number | `100` | **70–170**, step 5 | **Only note text** — editor textarea, preview, card content, via `--md-scale` |
| `appFont` | font id | `"default"` | 14 fonts | `--app-font` on the root |
| `noteFont` | font id | `"default"` | 14 fonts | `--note-font` on `.md-editor`/`.md-preview` |
| `themeId` | string | `"system"` | 36 themes + system | `ThemeController` writes CSS custom properties on `<html>` |
| `animations` | boolean | `true` | switch | Global animation gate |
| `searchIncludeArchive` | boolean | `true` | switch | Whether search spans archived notes |
| `confirmBeforeDelete` | boolean | `false` | switch | Confirmation dialog before destructive deletes |
| `mathEnabled` | boolean | `true` | switch | Gates `remarkMath` + `rehypeKatex` + `preprocessMathMarkdown` |
| `mediaGridWidth` | number | `75` | **40–100**, step 5 | `--note-media-grid-max` → `max-width` of `.img-grid` **only** |

### Migrations in `loadSettings()`

- `appName === "Notes"` → `"Notenoid"` (only the untouched default, so a user's chosen name survives)
- old `fontSize: "sm"` → `uiScale = 90`
- old `fontSize: "lg"` → `uiScale = 110`
- `mediaSingleWidth` (v5.2) is **ignored** — single images are per-image now
- every numeric setting is `clamp`ed to its range with a fallback

### The two scales, precisely

`uiScale` sets the **root font-size**, so every `rem` in the app moves together — the V6 note
says the old setting only resized *some* parts.

`markdownScale` is applied to note text only:
```css
.md-editor .md-prose, .md-preview {
  font-size: calc(0.925rem * var(--md-scale, 1));
  line-height: 1.65;
  word-break: break-word;
  font-family: var(--note-font, inherit);
}
```
**All heading sizes are `em`-based** (`h1 1.62em`, `h2 1.4em`, `h3 1.21em`, `h4 1.08em`,
`h5 1em`, `h6 0.95em`) so they track the note text scale exactly.

### Vault tab
- **First run:** create a password + answer 2 security questions
- **Set up:** change the password (requires the current one), or **reset by answering the two
  security questions** (no current password needed) — V7 feature
- **Manage:** edit the security questions themselves
- Validation: the new password must be ≥ 3 characters and the two entries must match

### About tab
App identity, storage location and version information.

### Storage section
Shows where the notes live (`rootLabel()`), plus **change folder** and **rescan** actions, and
surfaces `storageError` when set.

---

## 15. Themes, fonts, density, wallpaper

### Themes (`lib/themes.ts`, 715 lines) — 36 themes

Each theme is a `ThemeDef`:
```ts
{ id, name, mode: "light"|"dark", group, swatch: [bg, primary, accent], vars: Record<string,string> }
```

Groups: `classic` (light/dark pair), `light` (colour-tinted), `dark` (comfy dark UI),
`contrast` (accessibility), `comfy` (beloved palettes), `special` (Frutiger Aero, Vaporwave,
Aurora — with **extra CSS in `themes-special.ts`**).

Palettes adapted from real, professionally designed packs: Catppuccin Latte/Mocha, Rosé Pine,
Tokyo Night, Everforest, Nord, Dracula, Gruvbox, Solarized, GitHub Primer, T3 Chat (+Ghost),
One Dark, Twitter Dim, Frutiger Aero, Vaporwave, Aurora.

**Each theme defines the full shadcn/ui CSS variable set**, so every surface — top bar, sidebar,
dialogs, popovers, inputs, menus, scrollbars, editor chrome, toasts, native widgets via
`color-scheme` — follows the theme. `ThemeController` applies them as inline custom properties
on `<html>`.

**Note colours are intentionally independent** (`keep-constants.ts`) so a themed app never fights
the user's per-note colours.

`themes-special.ts` adds the extra gradients/gloss needed by Frutiger Aero, Vaporwave and Aurora.

### Note colours — 31 (`lib/keep-constants.ts`)

`default, blue, brown, gray, teal, green, pink, purple, red, yellow, orange, sky, cyan, mint,
sage, forest, lime, olive, honey, apricot, rust, cherry, rose, magenta, violet, indigo, steel,
sandstone, clay, charcoal` — each with a key, a name, and light/dark styling derived by
`noteStyle(color, isDark)`.

Also: `FOLDER_EMOJIS`, `FOLDER_TINTS` (light/dark per folder colour), and
`MAX_GIF_BYTES = 8 MB`.

### Fonts — 14 (`lib/fonts.ts`)

Kinds: `system`, `sans`, `serif`, `mono`, `geometric`, `handwriting`. IDs include `default`
(System default), `inter`, `roboto`, `open-sans`, `nunito`, `poppins`, `lora`, `merriweather`,
`playfair` and more, plus monospace options.

**All fonts are self-hosted at build time via `next/font/google`** in `app/layout.tsx`, exposed
as CSS variables `--nf-<id>`. They work **fully offline** — the Android APK bundles all font
files and there is no Google request at runtime. Every choice carries a system fallback stack
(`SANS_FALLBACK`, `SERIF_FALLBACK`, `MONO_FALLBACK`) so text renders even while a font chunk
loads.

### Wallpaper

`WallpaperLayer` in `KeepApp.tsx` renders a `pointer-events-none inset-0 z-0` layer **behind all
content** (the app content sits at a higher z-index). Blur > 0 applies `scale(1.06)` so the
blurred edges never show. Picked images are compressed to a data URL before being stored in
localStorage (a quota failure is caught and the setting stays in-memory only).

### Android system bars

`system-bars-sync.tsx` + `android-theme.ts` push the active theme's background/foreground into
the native status and navigation bars so the native chrome matches the app — a detail most web
apps miss on Android.

---

## 16. Vault — password security

`lib/vault.ts` (316 lines).

**Key material:** `localStorage["notes-vault-record-v2"]` for the record,
`notes-vault-code-hash` for a legacy code, `notes-vault-open` for the session.

**Only hashes are stored.** Passwords and answers are hashed with **PBKDF2-SHA256**,
**150,000 iterations**, each with its own random salt, via `crypto.subtle`.

```ts
const PBKDF2_ITERATIONS = 150_000;
const key = await crypto.subtle.importKey("raw", enc.encode(text), {name:"PBKDF2"}, false, ["deriveBits"]);
const bits = await crypto.subtle.deriveBits({name:"PBKDF2", hash:"SHA-256", salt, iterations}, key, 256);
```

The `VaultRecord` stores `salt`, `passwordHash`, `iterations`, and per-question
`{questionId, salt, answerHash}` for the two security questions. Answers are normalised
(`normaliseAnswer`) before hashing — case/whitespace insensitive, so a user is not locked out by
a capitalisation difference.

**Session unlock:** `writeVaultSession(true/false)` — the vault-open state persists across
reloads for the session.

**Recovery:** `verifySecurityAnswers` / `countCorrectSecurityAnswers` /
`resetVaultPassword(answers, newPassword)` — a user who forgets the password can reset it by
answering both questions, with no current password required.

**Visibility model:** vault notes have `vaulted: true` in front-matter and are only ever listed
in `scopeNotes` when the vault is unlocked (`view === "vault"` →
`notes.filter(n => !n.trashed && n.vaulted)`). Moving a note to the vault also unpins it.
Closing the vault while in the vault view returns to the notes view.

**Caveat worth stating plainly:** this is a **UI-level lock, not encryption**. The notes remain
plain readable `node.md` files in the user's own folder, and the password gate lives in
localStorage on the device. It prevents casual access through the app; it does not protect the
files from anything with filesystem access.

---

## 17. Import / Export (ZIP)

### ExportDialog — `notenoid[-with-vault].zip`

```
manifest.json                 ← { app, format, exportedAt, counts }
config.json                   ← the .notes/config.json contents
settings.json                 ← AppSettings snapshot
notes/<dir>/node.md
notes/<dir>/attachment/<files>
_vault/<dir>/node.md          ← only when vault notes are included
```

Built with **JSZip**, `DEFLATE` compression, then downloaded via `save-blob.ts`. Vault notes are
optionally included, which changes the filename suffix.

### ImportDialog

- accepts only `.zip`
- `JSZip.loadAsync`
- reads `config.json` **or** `.notes/config.json`
- reads `notes/…` and `_vault/…`, parsing each `node.md` through the normal
  `markdownToNote()` path, then writing through `repo`
- **V6 exports** (with `manifest.json`) are supported as a distinct layout
- `settings.json` is restored into the settings store
- reports errors through a dialog-level error state rather than a silent failure

---

## 18. Navigation and back handling

`lib/back-nav.ts` (156 lines) implements a **layered** back system.

Android back and browser back both dismiss surfaces **bottom-up**:

- every UI layer pushes a handler via `addBackHandler` / `useBackLayer(open, close)`
- the bottom-most handler pops the main-view history (`notes → folder → notes …`)
- dialogs, the editor, the lightbox, the gallery, the bulk bar, the mobile drawer, delete
  confirmations, folder dialogs, labels and the vault all push their own layer above it

**Web:** guarded history entries. Opening a layer does `history.pushState({notesGuard: depth})`;
a `popstate` closes the top layer; closing a layer through its own UI consumes its own history
entry via `history.back()`. A guard depth check ensures a UI close never walks real history.

**Escape** closes the editor (but not while a Radix popper is open).

`viewHistory: {view, activeFolderId, activeLabelId}[]` in the store, with `backView()` popping it
and returning whether it consumed the back press.

---

## 19. Platform shell — Android APK

- **One source tree** compiles to a **100% client-side static bundle**
  (`next build` with static export); the same bundle is deployed as the web app and embedded into
  `android/assets/`
- The native shell serves it over the private origin
  `https://appassets.androidplatform.net`
- No server routes, no Prisma/SQLite, no IndexedDB note storage — **only the platform filesystem
  adapters differ**
- `MainActivity.java` exposes `window.AndroidBridge` with envelope-returning methods:
  `fsInfo, fsList, fsReadText, fsReadBase64, fsWriteText, fsWriteBase64, fsMkdir, fsRename,
  fsDelete, fsExists` (+ `hasAllFilesAccess`, `requestAllFilesAccess`)
- Native writes are atomic (temp + rename); deletes recursive
- Permissions: `MANAGE_EXTERNAL_STORAGE` on 11+, legacy `WRITE_EXTERNAL_STORAGE` below,
  `requestLegacyExternalStorage` for ≤ Android 10
- The root folder is picked with the in-app `FolderPickerDialog`, which browses the real
  filesystem through the bridge — the same UX as the browser picker. The chosen absolute path
  persists in localStorage
- `android/assets/` contains the full export including `__next._full.txt`, `__next._tree.txt`,
  the turbopack chunk, KaTeX and font media, and the page RSC payloads
- Also present: the launcher icons (adaptive icon XML + mipmap densities), `notes.keystore` and
  gradle files for `scripts/build_apk.sh`

---

## 20. Build, scripts and config

| File | Role |
|---|---|
| `next.config.ts` | Next config; `STATIC_EXPORT` env drives the export build |
| `tailwind.config.ts` + `postcss.config.mjs` | Tailwind v4 setup (`@tailwindcss/postcss`) |
| `tsconfig.json` | `@/*` path alias → `src/*` |
| `components.json` | shadcn/ui config |
| `eslint.config.mjs` | flat ESLint config |
| `Caddyfile` | static hosting + APK download |
| `scripts/build_web_export.sh` | produces the static export |
| `scripts/build_apk.sh` | packages the export into the Android project |
| `scripts/gen_icons.py` | generates launcher icons from the 1024px master |
| `scripts/setup-sdk.sh` | Android SDK setup |
| `scripts/test-storage-naming.ts` | checks the folder-name derivation |

**Two housekeeping issues worth flagging:**

1. **`keystore/notes.keystore` is present in the source zip.** A release signing key should not
   be distributed with source. If this key has ever been published, treat it as compromised and
   rotate it. At minimum it should be git-ignored and supplied via CI secrets.
2. **Three lockfiles** (`bun.lock`, `pnpm-lock.yaml`, `package-lock.json`) can drift and produce
   different dependency trees on different machines. Pick one.

---

## 21. Complete data-flow traces

### 21.1 Typing a character, end to end

```
keypress
  → textarea onChange
  → updateDraft(text, "type")
      → fromDisplay(text)          // blob:/data: URLs → attachment/ paths
      → setDraft                   // instant local paint
      → pushThrottled(clean)       // ≤ 1 store write per 140 ms
      → commitHistory(clean,"type") // coalesced within 650 ms
      → emitSearch(...) if a query is active
  ↓ (leading edge, or the trailing 140 ms timer)
  → props.onChange(clean)
  → NoteEditorView.onContentChange
  → store.updateNote(id, {content})      // optimistic
      → applyPatchToNote                 // bumps updatedAt, re-parses items
      → pendingSaves[id] = {patch, timer(600 ms)}
  ↓ 600 ms
  → store.flushUpdate(id)
  → repo.saveNote(note)
      → resolveDirFor (rename if title/archive/folder/labels changed)
      → makeDir(target)
      → writeText(node.md, noteToMarkdown(model, extraMeta))
      → renameDir → fs.rename OR copyDir + remove
  ↓ fs adapter
  → Web: File System Access API | OPFS | Android: bridge → java.io
```

### 21.2 Uploading an image and putting it in the body as a grid

```
1. Toolbar "Insert image at cursor" (Images icon)
2. → ImageInsertPopover opens
3a. "Choose new images" → prepareMedia(files) → compressImage (≤1600px, q0.82, PNG kept)
                          → onUploadFiles = uploadForInsert
                          → store.addNoteMedia → repo.addAttachment → writeMediaFile
                              makeDir(attachment) → uniqueName → writeBinary
                          → repo.ensureAttachmentUrl → blob: URL
                          → registerUrl(url, file)   // urlToFileRef
4. onConfirm([{url, alt}, …])
5. → editorHandle.insertImages(items)
6. items.length > 1 → cols = ≤4 ? 2 : 3
   snippet = <div class="img-grid" data-cols="2">
               <img src="blob:…" alt="a">
               <img src="blob:…" alt="b">
             </div>
7. → splice into the draft at the caret with \n\n padding
8. → fromDisplay() rewrites every blob: src to attachment/<encoded>
9. → setDraft + pushNow + commitHistory("action")
10. Preview renders: rehypeRaw parses the div → the custom `div` component sees
    className includes "img-grid" → applies data-cols + any data-size → CSS grid,
    aspect-ratio 1/1, object-fit cover, max-width var(--note-media-grid-max)
```

### 21.3 Toggling a checklist box in preview

```
click checkbox
  → the custom `input` component (disabled was destructured out)
  → captureAnchor()            // preserve the viewport!
  → pendingAnchorRef.current = anchor
  → updateDraft(toggleTaskLine(draft, index, checked))
  → the source line is rewritten from "- [ ] x" to "- [x] x" (indent + bullet preserved)
  → fromDisplay → setDraft → pushNow → commitHistory
  → runAnchorRestore() runs after the render → startScrollPin re-pins the viewport
  → 600 ms later the store saves, and node.md is written with the ticked box
```

### 21.4 Switching edit ⇄ preview

```
toolbar 👁 click
  → captureAnchor()
      preview ? caretRangeFromPoint(probe) : mirrorDiv.charAtY(probe)
      → ModeAnchor {ratio, delta, charIdx, lineIndex, blockSrcLine, needle(160 chars)}
  → lastModeAnchor / pendingAnchorRef / scrollMemory[stateKey]
  → setPreview(…)   // lastPreviewState is module-level
  → re-render
  → the effect that runs after EVERY render calls runAnchorRestore()
  → startScrollPin(makeAnchorGetter())
      re-measure the needle in the NEW mode every frame
      clamp + apply scrollTop
      ResizeObserver resets stability on late image/font layout
      stop after 45 stable frames, 120 frames, or a >6px user scroll
```

---

## 22. Full feature inventory

**Notes**
- Text notes and checklist notes (`type: text | list`)
- 31 note colours
- Pin, archive, trash (with restore), delete forever, empty trash
- Duplicate, copy note text
- Manual drag reorder (Muuri) with persisted `order`
- Titles stored separately from the body, sanitised into the folder name
- Draft notes that never touch the disk unless they have content

**Organisation**
- Folders (genre) with emoji + tint
- Labels (tags), colour-independent
- Folder and label renames rewrite every affected note's front-matter
- Views: Notes, Folders, Archive, Vault, Trash, per-folder, per-label
- Search across title, body, plain-text body, checklist items, labels, folder, attachment names
  (NFKC-normalised)
- Grid and list layouts

**Markdown editor**
- Edit ⇄ preview with character-anchored scroll preservation
- 25 toolbar controls + 2 popovers
- Bold, italic, underline, strikethrough, inline code, code blocks
- H1–H6, body text, bullets, numbered, checklists, quotes, dividers
- GFM tables in a horizontal-scroll wrapper
- Links (add/remove), with URL scheme normalisation
- Multi-format application
- Clear formatting (content-preserving)
- Custom undo/redo (300 entries, 650 ms typing coalescing)
- Enter list continuation, auto-increment, empty-item list exit
- Image paste
- KaTeX math: `$…$`, `$$…$$`, `\[…\]`, `\(…\)`, bare equations
- In-note search with highlight, count, wrap-around navigation
- Code-block copy button
- 140 ms throttled store propagation with multiple flush points

**Images**
- Six upload entry points, all landing in the attachments area
- Attach-only by design; insertion is always explicit
- Client-side compression (1600 px cap, q0.82, PNG transparency preserved)
- 8 MB GIF limit, GIFs never re-encoded
- Attachment grid above the body: auto-fill columns, 128 px max height, 4 buttons per thumbnail
- Full-screen gallery
- Single image → plain markdown; 2–4 → 2-column grid; 5+ → 3-column grid
- Square `aspect-ratio: 1/1` tiles, `object-fit: cover`, hover zoom
- Per-image size (S 35 / M 55 / L 75 / Full 100 / Auto + 20–100% slider) stored in the markdown title
- Per-grid size stored in `data-size`
- Long-press or right-click to open the size menu
- Tapping an image opens the lightbox
- Download, edit (crop/draw/text), remove from note, delete everywhere
- Object-URL cache with re-keying on rename and revocation on delete
- Duplicate-upload protection on name+size

**Customisation**
- 36 themes + system
- 14 fonts, separate for UI and notes
- App text scale 70–150%, note text scale 70–170%
- 3 densities
- Wallpaper with blur, dim, fixed
- Animations toggle
- Math toggle
- Search-includes-archive toggle
- Confirm-before-delete toggle

**Platform**
- Web (File System Access API), OPFS fallback, Android native
- ZIP export and import incl. settings and vault
- Layered back navigation
- Vault with PBKDF2-SHA256 × 150,000, 2 security questions, session unlock, password reset
- V12 bulk selection: pin, colour, archive, move to folder/vault, trash (single undo), delete
- Android system bar theming
- Offline fonts and KaTeX assets

---

## 23. Settings reference table

| Key | localStorage path | Default | Range | Consumed by |
|---|---|---|---|---|
| `appName` | `notes-app-settings-v1` | `"Notenoid"` | free text | `TopBar` |
| `wallpaper` | ↑ | `null` | data URL | `WallpaperLayer` |
| `wallpaperBlur` | ↑ | `8` | 0–40 | `WallpaperLayer` |
| `wallpaperDim` | ↑ | `35` | 0–80 | `WallpaperLayer` |
| `wallpaperFixed` | ↑ | `true` | bool | `WallpaperLayer` |
| `density` | ↑ | `"cozy"` | compact/cozy/spacious | `DENSITY_CLASS` → Tailwind classes |
| `uiScale` | ↑ | `100` | 70–150 | root font-size |
| `markdownScale` | ↑ | `100` | 70–170 | `--md-scale` |
| `appFont` | ↑ | `"default"` | 14 ids | `--app-font` |
| `noteFont` | ↑ | `"default"` | 14 ids | `--note-font` |
| `themeId` | ↑ | `"system"` | 36 + system | `ThemeController` |
| `animations` | ↑ | `true` | bool | global |
| `searchIncludeArchive` | ↑ | `true` | bool | `filterBySearch` |
| `confirmBeforeDelete` | ↑ | `false` | bool | delete flows |
| `mathEnabled` | ↑ | `true` | bool | `MarkdownEditor` plugin chain |
| `mediaGridWidth` | ↑ | `75` | 40–100 | `--note-media-grid-max` |

**Other storage keys:** `notes-fs-kind` (adapter choice), `notes-vault-record-v2`,
`notes-vault-code-hash` (legacy), `notes-vault-open` (session), the web directory handle in
IndexedDB, and the Android absolute root path in localStorage.

---

> hapnoid

`Pranay`

```
Tanay
```


## 24. Glossary of internal identifiers

| Identifier | Meaning |
|---|---|
| `DRAFT_ID` = `"__draft__"` | an in-memory note that has no folder on disk yet |
| `node.md` | the single file that holds a note's front-matter + body |
| `.notes/config.json` | app-level metadata only (folder emoji/tints, label names) |
| `attachment/` | per-note image directory, created on demand |
| `img-grid` / `data-cols` / `data-size` | the image grid wrapper, its column count, its width % |
| `md-inline-image` | class on every image in the preview |
| `md-prose` / `md-preview` | the preview container classes |
| `data-src-line` | the markdown source line of a preview block (scroll anchoring) |
| `ModeAnchor` | `{ratio, delta, charIdx, lineIndex, blockSrcLine, needle}` — the V12 scroll anchor |
| `lastPreviewState` / `scrollMemory` / `pinTargetRef` | module-level mode + scroll holders that survive remounts |
| `pendingSaves` | the store's per-note debounced write queue |
| `urlToFileRef` | the live blob-URL → attachment-path map used by `fromDisplay` |
| `urlCache` | the repository's object-URL cache keyed `<dir>/<file>` |
| `lastMaterializedId` | catches patches that land right after a draft becomes a real note |
| `scanning` states | `storageStatus: loading / setup / reauth / ready / error` |
| `EMPTY_TASK_LIST_HTML` | seeds an empty checklist note with a real task item so Enter continues it |
| `stripMarkdownFormat` | the content-preserving "Clear formatting" engine |
| `markdownToPlain` | markdown → plain text for cards and search |
| `storageDirBase` | builds `[Archive_]Folder_Labels_Title` |
| `resolveDirFor` | decides the on-disk folder name and renames when it changes |
| `Glide` easing | the shared Muuri animation curve |

---

## Closing note

Three things stand out as genuinely well-engineered in this codebase, and they are all in the
markdown/image area that the user asked about most:

1. **The scroll-anchor system (§9.9)** is a three-generation piece of work — block anchor, then
   line anchor, then exact character anchor with a hidden mirror div and a binary search, plus a
   needle-based cross-mode search with a documented 12-character floor, plus a settle-pin with a
   ResizeObserver and a user-scroll guard. The code comments record the specific QA failures each
   iteration fixed, which makes the reasoning recoverable.

2. **The attachment-path round trip (§9.14)** — `toDisplay` on the way in, `fromDisplay` on the
   way out, called from a single `updateDraft` funnel plus every imperative insert/remove — means
   there is no code path that can write a `blob:` URL into `node.md`, while the on-disk file
   stays portable, relative and Obsidian-readable.

3. **The grid rules (§10.7)** are a hard, readable branch: one image → plain Markdown, two to
   four → `data-cols="2"`, five or more → `data-cols="3"`, with square `object-fit: cover` tiles
   that can neither overlap nor distort, and a global `--note-media-grid-max` width alongside
   per-grid and per-image overrides.

The most valuable single improvement, given how carefully these two subsystems are built, would
be to add tests around them. `scripts/test-storage-naming.ts` is the only test-like artefact in
the repo, and there is no test runner in `package.json`. The scroll anchoring, the URL round trip
and the grid thresholds are exactly the kind of logic that regresses silently.
