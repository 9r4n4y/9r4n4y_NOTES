---
id: "187a91af-7d60-45c3-a9e1-b4401c85e6ee"
title: "CARTOON - March 2026 - 144[128]"
type: "text"
color: "orange"
pinned: false
archived: false
trashed: false
vaulted: false
folder: "Personal"
labels: []
order: 1
created: "2026-09-21T12:34:55.961Z"
updated: "2026-09-29T11:04:29.553Z"
---






### **Cartoons show / movies / cartoon channels live show**

1. Super Robot Monkey Team Hyperforce Go!
2. Crayon Shin-chan
3. Doraemon
4. Perman
5. Star vs. the Forces of Evil
6. Hotel Transylvania
7. Adventure Time
8. Wander Over Yonder
9. Dragon Ball
10. Tsurupika Hagemaru
11. Oggy and the Cockroaches
12. Kung Fu Panda
13. Uncle Grandpa
14. Ben 10
15. Pokémon
16. Tom and Jerry
17. Zig & Sharko
18. Obocchama-kun
19. Idaten Jump
20. Courage the Cowardly Dog
21. Haddi Mera Buddy (The Grim Adventures of Billy & Mandy)
22. Teen Titans Go!
23. Scooby-Doo
24. Johnny Test
25. Jake and the Never Land Pirates
26. Supa Strikas
27. SpongeBob SquarePants
28. DuckTales
29. Power Rangers (All Series)
30. Phineas and Ferb
31. Kick Buttowski: Suburban Daredevil
32. Dinosaur King
33. Keymon Ache
34. The Daltons
35. Best of Luck Nikki
36. Dinosaur Train
37. Beyblade
38. We Bare Bears
39. Milo Murphy's Law
40. Big Hero 6: The Series
41. Steven Universe
42. Teenage Mutant Ninja Turtles
43. The Amazing World of Gumball
44. Kiteretsu Daihyakka
45. Gon: The Stone Age Boy
46. Horrid Henry
47. Bernard
48. Oscar's Oasis
49. Larva
50. Gon dinosaur
51. Roll no 21
52. Lamput
53. Minuscule: Valley of the Lost Ants
54. Sofia (may be on discovery kids)
55. Mickey mouse club house
56. Paw patrol
57. Mr bean
58. Thomas & Friends. 
59. Monsuno
60. Hulk and the Agents of S.M.A.S.H ( basically Marvel HQ / disney XD -All shows)
61. Avengers Assemble
62. Ultimate Spider-Man 
63. Guardians of the Galaxy animated
64. Iron Man: Armored Adventures
65. Marvel's Spider-Man - young boy fluffy hair
66. MechX4
67. Lucky man

### Live-Action / Reality Shows
1. Storage Wars
2. Man vs. Wild
3. Expedition Unknown (Josh Gates)
4. Forged in Fire
5. Food Factory
6. Pawn Stars
7. Kings of Restoration
8. Science of Stupid
9. Counting Cars
10. Baggage Battles
11. Ancient Aliens
12. Gold Rush
13. River Monsters
14. Takeshi’s Castle
15. Shipping Wars
16. Oh my god Yah mera India

### Anime
1. Your Name (Kimi no Na wa) / Suzume
2. Chainsaw Man
3. Attack on Titan
4. Jujutsu Kaisen
5. Pokémon / Doraemon / Shinchan (Classic Trio)
6. One Punch Man (OPM)
7. Lookism
8. Baki
9. Naruto
10. Dragon Ball Z
11. One Piece
12. Dr. Stone
13. Bleach
14. Black Clover
15. Death Note
16. spare me my great lord

### Movies & Miscellaneous (🔮 means one of the first Hollywood movies i seen) 

1. All Christopher Nolan Movies
2. The Thing (Both parts – classic alien horror)
3. Final Destination (All parts)🔮
4. Harry Potter (Full Series) ⭐

<div class="img-grid" data-cols="2" data-size="70">
<img src="attachment/1000722056.jpg" alt="1000722056.jpg">
<img src="attachment/1000722053.png" alt="1000722053.png">
<img src="attachment/1000722055.png" alt="1000722055.png">
</div>

5. Marvel Cinematic Universe (All / Selected movies)
6. The Good Doctor (Series)
7. Fight Club
8. Titanic
9. Jurassic Park (All parts)
10. Slasher Classics (Jason/Friday the 13th and Leatherface/Texas Chainsaw)
11. Stephen King Adaptations (IT, Misery, etc.)
12. Alien & Predator Series
13. Zathura: A Space Adventure
14. The Mummy ⭐
15. The Kid (2000 - Disney) 🔮
16. Armageddon (1998)🔮
17. Jail Cell / Taxi🔮
18. Kaalo / Jeepers Creepers
19. Art Attack
20. M.A.D. (Music Art Dance)
21. Maze runner
22. Angry Birds Toons
23. Dark matter ⭐ 💚
24. Detachment ⭐
25. Prison break ⭐ 💚😡
26. Real steel 🔮
27. Chronicles of Narnia
28. 

### shows - random 
1. Adaalat⭐
2. Chakra Ashoka 
3. Tenali rama
4. CID
5. Alaadin - sony sab
6. F.I.R
7. Gutar Gu ⭐
8. Best of luck nikki ⭐

### Favorite Rangers & Characters
1. Koragg (Wolf Knight)
<img src="attachment/1000722045.png" alt="1000722045.png">
2. Lunar Wolf Ranger
<img src="attachment/1000722046.jpg" alt="1000722046.jpg" title="size=40">
3. White Dino Ranger

<img src="attachment/1000722047.jpg" alt="1000722047.jpg">

4. Omega Ranger

<img src="attachment/1000722050.png" alt="1000722050.png" title="size=30">

5. Solaris Knight

<img src="attachment/1000722280.png" alt="1000722280.png">

6. Gold Samurai Ranger

<img src="attachment/1000722283.png" alt="1000722283.png">

7. Super Megaforce Silver

<img src="attachment/1000722282.png" alt="1000722282.png">

8. Magna Defender

<img src="attachment/1000722285.png" alt="1000722285.png">

9. Anubis "Doggie" Cruger (SPD Shadow Ranger)

<img src="attachment/1000722287.png" alt="1000722287.png">

10. Tommy Oliver

<img src="attachment/1000722288.png" alt="1000722288.png">

11. Madan Senki Ryukendo (God Dragon Warrior)

<img src="attachment/1000722289.jpg" alt="1000722289.jpg">

12. Lord drakkon

<img src="attachment/1000722291.png" alt="1000722291.png">

13. Dino Charge Silver

<img src="attachment/1000722293.png" alt="1000722293.png">




### Quote to Remember
> "Don’t cry because it’s gone; be happy because it happened."

# 
