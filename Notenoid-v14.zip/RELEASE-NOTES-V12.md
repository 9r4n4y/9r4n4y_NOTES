# Release Notes — Notenoid V12

V12 is a power-user release: bulk operations over your whole library, a
polished sidebar, and a completely rebuilt scroll engine for the
edit ↔ preview toggle that anchors the exact character you were reading.

---

## 1. Bulk (mass) selection mode

Tap the new **Select notes** button in the top bar (checklist icon) to enter
selection mode:

- Every card shows a selection circle — tap cards to tick/untick them, or tap
  **"N selected"** in the action bar to select every note in the current view
  (tap again to clear). Search-aware: select-all only grabs what you see.
- The floating bottom action bar applies one action to all selected notes:
  - **Pin / Unpin** — pins the batch (or unpins when every selected note is
    already pinned)
  - **Colour** — one tap on a swatch repaints the whole batch
  - **Archive / Unarchive** — respects the view you started from
  - **Move to folder** — pick any folder, or "No folder"
  - **Move to vault / Remove from vault** — while the vault is open
  - **Trash** — single undo toast restores the whole batch
  - Inside the **Trash** view the bar switches to **Restore** and
    **Delete forever** (with a confirmation)
- Cards render in a clean selection look: action rows and pin buttons hide,
  selected notes get a ring. Drag-to-reorder is suspended while selecting.
- Bulk actions write through to disk immediately per note; failures are
  counted and surfaced ("Could not save 2 notes to disk").
- Selection is reset when you switch views, open a note, close the vault, or
  press the system BACK button — no accidental cross-view batch edits.

## 2. Sidebar & vault count fixes

- The vault row's count no longer overlaps the lock icon: the count is its
  own pill, the lock is its own button, both gap-spaced and non-shrinking.
  Long counts can no longer collide with the "Vault" label.
- All count pills (Notes / Archive / Trash / folders / labels) are now
  `shrink-0` — long note counts squash the label text instead of overlapping.
- The active-row indicator dot is no longer clipped in half by the panel's
  scrollbar guard (the rail got proper horizontal padding).
- Locked-vault pill styling now matches the other count pills.

## 3. Exact character-anchored edit ↔ preview switching

The old system anchored by *source line*, which drifted whenever the editor
soft-wrapped a paragraph (visual rows ≠ source lines) or the anchor sat in
the middle of a long block. V12 anchors the **exact character** at the
viewport probe:

- **Capture (leaving a mode)** — the character under the probe (35% viewport
  height) is found exactly:
  - edit mode → a hidden mirror div with identical font/width/wrap turns the
    probe pixel into an exact source char index (binary search +
    `Range.getBoundingClientRect()`);
  - preview mode → `caretRangeFromPoint()` returns the exact text node and
    offset, plus the containing block's `data-src-line`.
  The anchor stores the logical position (char index / block + needle text
  read at that point) **plus the pixel distance between the character top
  and the probe** — no scrollTop is ever saved.
- **Restore (entering a mode)** — the same logical position is re-located in
  the new mode's DOM (needle search over text nodes, markdown-stripped
  matching, source-line fallbacks) and measured with
  `getBoundingClientRect()`; the scroll is adjusted by the exact difference,
  so the same text sits at the same screen pixel. Zero visible jumping.
- A settle-pin keeps re-measuring and re-applying while images/fonts change
  the new mode's height, and hands control back the instant you scroll.
- Works for the other anchor users too: ticking a task checkbox in preview
  and changing image sizes re-pin to the same character.

## 4. Platform

- `versionCode` 120, `versionName` "12.0" — same unified codebase for web
  and APK, same on-disk `node.md` format (no migration needed).
