"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useKeepStore } from "./store";
import { getSettings, updateSettings, useSettings } from "./settings-store";
import { getTheme } from "@/lib/themes";
import { cn } from "@/lib/utils";
import {
  Grid2x2,
  Menu,
  Monitor,
  Moon,
  Plus,
  Search,
  Sun,
  Rows3,
  X,
  Settings,
  LockOpen,
  Palette,
  ListChecks,
} from "lucide-react";
import { useSyncExternalStore } from "react";
import { toast } from "sonner";

const emptySubscribe = () => () => {};

/** Hydration-safe mount flag without setState-in-effect. */
function useMounted() {
  return useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false
  );
}

/** Resolve the ACTIVE theme ("system" follows the OS, Android-aware). */
function resolveActiveTheme(): NonNullable<ReturnType<typeof getTheme>> {
  const id = getSettings().themeId;
  if (id && id !== "system") return getTheme(id) ?? getTheme("classic-light")!;
  let dark = false;
  try {
    dark = window.matchMedia("(prefers-color-scheme: dark)").matches;
  } catch {
    dark = false;
  }
  return dark ? getTheme("classic-dark")! : getTheme("classic-light")!;
}

export function TopBar({ onToggleSidebar }: { onToggleSidebar: () => void }) {
  const search = useKeepStore((s) => s.search);
  const setSearch = useKeepStore((s) => s.setSearch);
  const layout = useKeepStore((s) => s.layout);
  const setLayout = useKeepStore((s) => s.setLayout);
  const vaultOpen = useKeepStore((s) => s.vaultOpen);
  const setSettingsOpen = useKeepStore((s) => s.setSettingsOpen);
  const beginNewNote = useKeepStore((s) => s.beginNewNote);
  const selectionMode = useKeepStore((s) => s.selectionMode);
  const toggleSelectMode = useKeepStore((s) => s.toggleSelectMode);
  const settings = useSettings();
  const mounted = useMounted();
  // V7 bug fix: "system" now follows the OS dark mode (previously the
  // moon/sun button always looked like the light theme while on "system").
  const isDarkMode = mounted && resolveActiveTheme().mode === "dark";

  return (
    <header className="sticky top-0 z-40 flex h-16 items-center gap-2 bg-background/80 px-3 backdrop-blur-xl md:px-5">
      <Button
        variant="ghost"
        size="icon"
        className="rounded-full transition-transform active:scale-90"
        onClick={onToggleSidebar}
        aria-label="Toggle sidebar"
      >
        <Menu className="h-5 w-5" />
      </Button>

      <a className="mr-2 flex select-none items-center gap-2" href="/" aria-label={settings.appName}>
        <span className="hidden text-xl font-medium tracking-tight text-foreground/85 sm:block">
          {mounted ? settings.appName : "Notenoid"}
        </span>
      </a>

      <div className="relative mx-auto w-full max-w-2xl">
        <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search notes, lists, labels…"
          aria-label="Search notes"
          className="h-11 rounded-full border-transparent bg-accent/90 pl-11 pr-10 text-sm shadow-sm transition-colors focus-visible:border-border focus-visible:bg-background"
        />
        {search ? (
          <button
            type="button"
            aria-label="Clear search"
            onClick={() => setSearch("")}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        ) : null}
      </div>

      <div className="ml-auto flex items-center gap-1">
        {vaultOpen ? (
          <button
            type="button"
            className="mr-1 hidden items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 text-xs font-medium text-emerald-600 transition-colors hover:bg-emerald-500/20 dark:text-emerald-400 sm:flex"
            title="Lock vault now"
            onClick={() => {
              useKeepStore.getState().closeVault();
              toast.success("Vault locked");
            }}
          >
            <LockOpen className="h-3.5 w-3.5" /> Vault open
          </button>
        ) : null}

        {/* V8 — the + New-note button wears the theme's DEFAULT note colour
            (exactly like the default cards): --note-default-bg/fg, applied in
            globals.css under button.note-default-btn */}
        <Button
          variant="default"
          size="sm"
          className="note-default-btn gap-1.5 rounded-full"
          onClick={() => beginNewNote()}
          aria-label="New note"
          title="New note"
        >
          <Plus className="h-4 w-4" />
          <span className="hidden sm:inline">New note</span>
        </Button>

        {/* V12 — bulk (mass) selection mode toggle: tap once, tick notes,
            then delete / pin / colour / archive / move them in one go */}
        <Button
          variant="ghost"
          size="icon"
          className={cn(
            "rounded-full transition-transform active:scale-90",
            selectionMode && "bg-foreground/10 text-foreground dark:bg-white/15"
          )}
          onClick={toggleSelectMode}
          aria-label={selectionMode ? "Exit selection mode" : "Select notes"}
          aria-pressed={selectionMode}
          title={selectionMode ? "Exit selection mode" : "Select notes"}
        >
          <ListChecks className="h-5 w-5" />
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className="rounded-full transition-transform active:scale-90"
          onClick={() => setLayout(layout === "grid" ? "list" : "grid")}
          aria-label={layout === "grid" ? "Switch to list layout" : "Switch to grid layout"}
          title={layout === "grid" ? "List layout" : "Grid layout"}
        >
          {mounted && layout === "grid" ? <Rows3 className="h-5 w-5" /> : <Grid2x2 className="h-5 w-5" />}
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className="rounded-full transition-transform active:scale-90"
          onClick={() => setSettingsOpen(true)}
          aria-label="Settings"
          title="Settings"
        >
          <Settings className="h-5 w-5" />
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="rounded-full transition-transform active:scale-90" aria-label="Change theme">
              {mounted && isDarkMode ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-40">
            <DropdownMenuItem
              onClick={() => updateSettings({ themeId: "classic-light" })}
              className={cn(mounted && settings.themeId === "classic-light" && "bg-accent")}
            >
              <Sun className="mr-2 h-4 w-4" /> Light
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => updateSettings({ themeId: "classic-dark" })}
              className={cn(mounted && settings.themeId === "classic-dark" && "bg-accent")}
            >
              <Moon className="mr-2 h-4 w-4" /> Dark
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => updateSettings({ themeId: "system" })}
              className={cn(mounted && settings.themeId === "system" && "bg-accent")}
            >
              <Monitor className="mr-2 h-4 w-4" /> System
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => setSettingsOpen(true)}>
              <Palette className="mr-2 h-4 w-4" /> All themes…
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
