"use client";

// ---------------------------------------------------------------------------
// V8 — single source of truth for the ACTIVE theme's light/dark mode.
//
// Bug this fixes: components used next-themes' `resolvedTheme`, which follows
// the OS/system — NOT the theme the user picked in Settings (that one is
// applied by ThemeController). Picking a dark theme while the OS was light
// made custom-coloured cards render their light variants (unreadable).
//
// This hook mirrors ThemeController.resolve exactly:
//   themeId "system" → follows the OS (Android-aware via matchMedia shim)
//   anything else    → the picked theme's own mode
// NOTE (text colour rule): light themes → black note text, dark themes →
// white note text; keep-constants.noteStyle() relies on this hook's verdict.
// ---------------------------------------------------------------------------

import { useEffect, useState } from "react";
import { getTheme } from "@/lib/themes";
import { useSettings } from "./settings-store";

function systemPrefersDark(): boolean {
  try {
    return window.matchMedia("(prefers-color-scheme: dark)").matches;
  } catch {
    return false;
  }
}

export function useActiveThemeMode(): "light" | "dark" {
  const themeId = useSettings().themeId;
  const [sysDark, setSysDark] = useState(systemPrefersDark);

  useEffect(() => {
    if (themeId !== "system") return;
    let mql: MediaQueryList | null = null;
    try {
      mql = window.matchMedia("(prefers-color-scheme: dark)");
      const onChange = () => setSysDark(mql!.matches);
      onChange();
      mql.addEventListener("change", onChange);
      return () => mql?.removeEventListener("change", onChange);
    } catch {
      return undefined; // old WebViews — startup value only
    }
  }, [themeId]);

  if (themeId !== "system") {
    const t = getTheme(themeId);
    if (t) return t.mode;
  }
  return sysDark ? "dark" : "light";
}
