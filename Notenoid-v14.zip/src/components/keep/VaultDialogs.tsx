"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useKeepStore } from "./store";
import { ArrowLeft, KeyRound, Loader2, LockKeyhole, ShieldQuestion } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useBackLayer } from "@/lib/back-nav";
import {
  SECURITY_QUESTIONS,
  getSecurityQuestionIds,
  questionText,
  resetVaultPassword,
} from "@/lib/vault";

export function VaultPasswordDialog() {
  const open = useKeepStore((s) => s.vaultCodePrompt);
  const setOpen = useKeepStore((s) => s.setVaultCodePrompt);
  const resolveVaultCode = useKeepStore((s) => s.resolveVaultCode);
  useBackLayer(open, () => setOpen(false));

  const [mode, setMode] = useState<"password" | "forgot">("password");
  const [password, setPassword] = useState("");
  const questionIds = getSecurityQuestionIds();
  const [answers, setAnswers] = useState(["", ""]);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  function close() {
    setOpen(false);
    setMode("password");
    setPassword("");
    setAnswers(["", ""]);
    setNewPassword("");
    setConfirmPassword("");
    setError("");
  }

  async function unlock() {
    if (!password) return;
    setBusy(true);
    const ok = await resolveVaultCode(password);
    setBusy(false);
    if (!ok) {
      setError("Incorrect password.");
      return;
    }
    close();
    toast.success("Vault unlocked", { description: "It stays open until you close the app." });
  }

  async function recover() {
    setError("");
    if (questionIds.length !== 2) {
      setError("Security questions are not configured. Use the password to set them in Settings.");
      return;
    }
    if (!answers.some((answer) => answer.trim())) {
      setError("Answer at least one security question.");
      return;
    }
    if (newPassword.length < 3) {
      setError("The new password must be at least 3 characters.");
      return;
    }
    if (newPassword !== confirmPassword) {
      setError("The new passwords do not match.");
      return;
    }
    setBusy(true);
    const ok = await resetVaultPassword(
      questionIds.map((id, index) => ({ id, answer: answers[index] })),
      newPassword
    );
    if (ok) await useKeepStore.getState().resolveVaultCode(newPassword);
    setBusy(false);
    if (!ok) {
      setError("At least one answer must be correct. You may leave the other answer blank or incorrect.");
      return;
    }
    close();
    toast.success("Password reset", { description: "The vault is unlocked for this session." });
  }

  return (
    <Dialog open={open} onOpenChange={(next) => { if (!next) close(); }}>
      <DialogContent className="max-w-sm">
        {mode === "password" ? (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2"><KeyRound className="h-5 w-5" /> Unlock vault</DialogTitle>
              <DialogDescription>Enter the one password you created for this vault.</DialogDescription>
            </DialogHeader>
            <div className="space-y-2">
              <Input
                type="password"
                autoFocus
                value={password}
                onChange={(e) => { setPassword(e.target.value); setError(""); }}
                onKeyDown={(e) => { if (e.key === "Enter") void unlock(); }}
                placeholder="Vault password"
                autoComplete="current-password"
              />
              {error ? <p className="text-xs text-destructive">{error}</p> : null}
            </div>
            <div className="flex items-center justify-between gap-2">
              {questionIds.length === 2 ? (
                <Button variant="outline" size="sm" className="gap-1.5" onClick={() => { setMode("forgot"); setError(""); }}>
                  <ShieldQuestion className="h-4 w-4" /> Forgot password
                </Button>
              ) : <span />}
              <div className="ml-auto flex gap-2">
                <Button variant="ghost" onClick={close}>Cancel</Button>
                <Button onClick={() => void unlock()} disabled={busy || !password}>
                  {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null} Unlock
                </Button>
              </div>
            </div>
          </>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2"><ShieldQuestion className="h-5 w-5" /> Forgot password</DialogTitle>
              <DialogDescription>Answer at least one of your two security questions correctly, then choose a new password. The other answer may be wrong or blank.</DialogDescription>
            </DialogHeader>
            <div className="space-y-3">
              {questionIds.map((id, index) => (
                <div key={id} className="space-y-1.5">
                  <Label>{questionText(id)}</Label>
                  <Input
                    value={answers[index] ?? ""}
                    onChange={(e) => setAnswers((current) => current.map((value, i) => i === index ? e.target.value : value))}
                    autoComplete="off"
                    placeholder="Answer"
                  />
                </div>
              ))}
              <div className="space-y-1.5">
                <Label>New vault password</Label>
                <Input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="At least 3 characters" autoComplete="new-password" />
              </div>
              <div className="space-y-1.5">
                <Label>Confirm new password</Label>
                <Input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") void recover(); }} placeholder="Repeat new password" autoComplete="new-password" />
              </div>
              {error ? <p className="text-xs text-destructive">{error}</p> : null}
            </div>
            <div className="flex justify-between gap-2">
              <Button variant="ghost" className="gap-1.5" onClick={() => { setMode("password"); setError(""); }} disabled={busy}><ArrowLeft className="h-4 w-4" /> Back</Button>
              <Button onClick={() => void recover()} disabled={busy}>{busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null} Reset password</Button>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

export function VaultSetupDialog() {
  const open = useKeepStore((s) => s.vaultSetupOpen);
  const setOpen = useKeepStore((s) => s.setVaultSetupOpen);
  const completeVaultSetup = useKeepStore((s) => s.completeVaultSetup);
  useBackLayer(open, () => setOpen(false));

  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [questionIds, setQuestionIds] = useState<[string, string]>([SECURITY_QUESTIONS[0].id, SECURITY_QUESTIONS[1].id]);
  const [answers, setAnswers] = useState(["", ""]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const used = new Set(questionIds);

  function close() {
    setOpen(false);
    setPassword("");
    setConfirmPassword("");
    setAnswers(["", ""]);
    setError("");
  }

  async function submit() {
    setError("");
    if (password.length < 3) return setError("The password must be at least 3 characters.");
    if (password !== confirmPassword) return setError("The passwords do not match.");
    if (questionIds[0] === questionIds[1]) return setError("Choose two different security questions.");
    if (answers.some((answer) => !answer.trim())) return setError("Answer both security questions.");
    setBusy(true);
    const ok = await completeVaultSetup(password, [
      { id: questionIds[0], answer: answers[0] },
      { id: questionIds[1], answer: answers[1] },
    ]);
    setBusy(false);
    if (!ok) return setError("Could not save the vault. Try again.");
    close();
    toast.success("Vault ready", { description: "One password and two recovery questions are now set." });
  }

  return (
    <Dialog open={open} onOpenChange={(next) => { if (!next) close(); }}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><LockKeyhole className="h-5 w-5" /> Set up vault protection</DialogTitle>
          <DialogDescription>Create one vault password and two security questions. Later you can change the password with the current password, or recover it with at least one correct answer.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5"><Label>Password</Label><Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="At least 3 characters" autoComplete="new-password" /></div>
            <div className="space-y-1.5"><Label>Confirm password</Label><Input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="Repeat it" autoComplete="new-password" /></div>
          </div>
          <div className="rounded-lg border bg-accent/30 p-3">
            <p className="mb-1 text-sm font-medium">Two recovery questions</p>
            <p className="mb-3 text-xs text-muted-foreground">You need both questions during setup. For forgotten-password recovery, at least one answer must be correct.</p>
            <div className="space-y-3">
              {[0, 1].map((slot) => (
                <div key={slot} className="grid gap-2 sm:grid-cols-[1.4fr_1fr]">
                  <select
                    value={questionIds[slot]}
                    aria-label={`Security question ${slot + 1}`}
                    onChange={(e) => setQuestionIds((current) => slot === 0 ? [e.target.value, current[1]] : [current[0], e.target.value])}
                    className="h-9 min-w-0 rounded-md border bg-background px-2 text-sm"
                  >
                    {SECURITY_QUESTIONS.map((question) => <option key={question.id} value={question.id} disabled={used.has(question.id) && questionIds[slot] !== question.id}>{question.text}</option>)}
                  </select>
                  <Input value={answers[slot] ?? ""} onChange={(e) => setAnswers((current) => current.map((value, i) => i === slot ? e.target.value : value))} autoComplete="off" placeholder="Your answer" />
                </div>
              ))}
            </div>
          </div>
          {error ? <p className="text-xs text-destructive">{error}</p> : null}
        </div>
        <div className="flex justify-end gap-2"><Button variant="ghost" onClick={close} disabled={busy}>Cancel</Button><Button onClick={() => void submit()} disabled={busy}>{busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null} Protect my notes</Button></div>
      </DialogContent>
    </Dialog>
  );
}
