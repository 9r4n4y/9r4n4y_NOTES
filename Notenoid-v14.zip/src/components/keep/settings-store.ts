"use client";

import { create } from "zustand";
import { useSyncExternalStore } from "react";

// ---------------------------------------------------------------------------
// App settings (UI configuration) — persisted to localStorage, synced across
// all hook consumers via a module-level store + manual subscription.
//
// V6 model:
//   • uiScale        — scales the WHOLE app (root font-size, so every
//                      rem-based Tailwind size grows/shrinks together —
//                      fixes the old setting that only resized some parts).
//   • markdownScale  — scales ONLY note (markdown) text: editor textarea,
//                      rendered preview and note-card content. Fully separate
//                      from the app UI scale.
//   • appFont/noteFont — font choices from lib/fonts.ts (incl. monospace).
//   • themeId        — theme id from lib/themes.ts ("system" follows the OS).
//   • mathEnabled    — KaTeX rendering of $…$ / $$…$$ in the preview.
//   • mediaGridWidth — image GRID width in notes. (Single images are sized
//                      per-image via the button on each image — V6.)
// ---------------------------------------------------------------------------

export type Density = "compact" | "cozy" | "spacious";

export interface AppSettings {
  appName: string;
  wallpaper: string | null; // data URL
  wallpaperBlur: number; // 0-40 px
  wallpaperDim: number; // 0-80 %
  wallpaperFixed: boolean;
  density: Density;
  /** V6: app-wide UI scale in % (70–150). 100 = default. */
  uiScale: number;
  /** V6: note/markdown text scale in % (70–170). 100 = default. */
  markdownScale: number;
  /** V6: font id for the app UI (see lib/fonts.ts). */
  appFont: string;
  /** V6: font id for note content — editor, preview, cards. */
  noteFont: string;
  /** V6: theme id (see lib/themes.ts). "system" = classic light/dark auto. */
  themeId: string;
  animations: boolean;
  searchIncludeArchive: boolean;
  /** V14: require selecting and confirming one exact word before mode changes. */
  confirmModeToggle: boolean;
  confirmBeforeDelete: boolean;
  /** V6: render $…$ and $$…$$ math in the markdown preview (KaTeX). */
  mathEnabled: boolean;
  /** max width of image grids inside the note body (%) */
  mediaGridWidth: number;
}

export const DEFAULT_SETTINGS: AppSettings = {
  appName: "Notenoid",
  wallpaper: null,
  wallpaperBlur: 8,
  wallpaperDim: 35,
  wallpaperFixed: true,
  density: "cozy",
  uiScale: 100,
  markdownScale: 100,
  appFont: "default",
  noteFont: "default",
  themeId: "system",
  animations: true,
  searchIncludeArchive: true,
  confirmModeToggle: false,
  confirmBeforeDelete: false,
  mathEnabled: true,
  mediaGridWidth: 75,
};

const SETTINGS_KEY = "notes-app-settings-v1";

function clamp(n: unknown, min: number, max: number, fallback: number): number {
  const v = typeof n === "number" && Number.isFinite(n) ? n : fallback;
  return Math.max(min, Math.min(max, Math.round(v)));
}

function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return { ...DEFAULT_SETTINGS };
    const saved = JSON.parse(raw) as Partial<AppSettings> & {
      fontSize?: string;
      mediaSingleWidth?: number;
    };
    // Migrate only the old untouched default; preserve any user-selected name.
    if ((saved as { appName?: string }).appName === "Notes") saved.appName = DEFAULT_SETTINGS.appName;
    const next: AppSettings = { ...DEFAULT_SETTINGS, ...saved } as AppSettings;
    // ---- V6 migrations -----------------------------------------------------
    // old fontSize (sm/md/lg) → uiScale (whole app)
    if (saved.fontSize === "sm") next.uiScale = 90;
    else if (saved.fontSize === "lg") next.uiScale = 110;
    // v5.2 mediaSingleWidth is gone — single images are per-image now
    // (the stored value is simply ignored)
    next.uiScale = clamp(next.uiScale, 70, 150, 100);
    next.markdownScale = clamp(next.markdownScale, 70, 170, 100);
    next.mediaGridWidth = clamp(next.mediaGridWidth, 40, 100, 75);
    return next;
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

let state: AppSettings = { ...DEFAULT_SETTINGS };
let hydrated = false;
const listeners = new Set<() => void>();

function emit() {
  listeners.forEach((l) => l());
}

export function getSettings(): AppSettings {
  return state;
}

export function hydrateSettings() {
  if (hydrated) return;
  hydrated = true;
  state = loadSettings();
  emit();
}

export function updateSettings(patch: Partial<AppSettings>) {
  state = { ...state, ...patch };
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(state));
  } catch {
    // quota exceeded (large wallpaper) — keep in-memory only
  }
  emit();
}

export function resetSettings() {
  state = { ...DEFAULT_SETTINGS };
  try {
    localStorage.removeItem(SETTINGS_KEY);
  } catch {
    // ignore
  }
  emit();
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

/** Hydration-safe settings hook: defaults on the server, persisted after mount. */
export function useSettings(): AppSettings {
  const s = useSyncExternalStore(subscribe, getSettings, getDefaults);
  return s;
}

const getDefaults = () => DEFAULT_SETTINGS;

/** Plain snapshot for backup/export (settings-store.ts stays import-free). */
export function getSettingsSnapshot(): AppSettings {
  return { ...state };
}

// CSS helpers ---------------------------------------------------------------

export const DENSITY_CLASS: Record<Density, { gridGap: number; cardMb: string; listGap: string; pad: string }> = {
  compact: { gridGap: 12, cardMb: "mb-4", listGap: "gap-3", pad: "px-3 py-2.5" },
  cozy: { gridGap: 20, cardMb: "mb-6", listGap: "gap-5", pad: "px-4 py-3" },
  spacious: { gridGap: 28, cardMb: "mb-8", listGap: "gap-7", pad: "px-5 py-4" },
};
