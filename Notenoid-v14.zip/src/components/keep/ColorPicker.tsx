"use client";

import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { KEEP_COLORS, noteStyle } from "@/lib/keep-constants";
import { useActiveThemeMode } from "./theme-mode";
import { useState } from "react";

/** Icon button that adapts to the note it sits on (used inside colored cards). */
export function CardIconButton({
  children,
  onClick,
  label,
  colorKey,
  className = "",
}: {
  children: React.ReactNode;
  onClick?: (e: React.MouseEvent) => void;
  label: string;
  colorKey?: string;
  className?: string;
}) {
  const isDark = useActiveThemeMode() === "dark";
  const style = colorKey ? noteStyle(colorKey, isDark) : undefined;

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          type="button"
          aria-label={label}
          onClick={(e) => {
            e.stopPropagation();
            onClick?.(e);
          }}
          className={`inline-flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-black/10 dark:hover:bg-white/10 ${className}`}
          style={{ color: style?.color }}
        >
          {children}
        </button>
      </TooltipTrigger>
      <TooltipContent side="bottom" className="text-xs">
        {label}
      </TooltipContent>
    </Tooltip>
  );
}

export function ColorPicker({
  color,
  onChange,
  children,
  align = "start",
  colorKey,
}: {
  color: string;
  onChange: (key: string) => void;
  children: React.ReactNode;
  align?: "start" | "center" | "end";
  colorKey?: string;
}) {
  const [open, setOpen] = useState(false);
  const isDark = useActiveThemeMode() === "dark";
  const triggerStyle = colorKey ? noteStyle(colorKey, isDark) : undefined;

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          type="button"
          aria-label="Change color"
          onClick={(e) => e.stopPropagation()}
          className={`inline-flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-black/10 dark:hover:bg-white/10`}
          style={{ color: triggerStyle?.color }}
        >
          {children}
        </button>
      </PopoverTrigger>
      <PopoverContent align={align} side="top" className="w-auto p-3" onClick={(e) => e.stopPropagation()}>
        <p className="mb-2 text-xs font-medium text-muted-foreground">Note colour</p>
        <div className="grid max-h-[52vh] grid-cols-6 gap-2 overflow-y-auto pr-1 sm:max-h-none">
          {KEEP_COLORS.map((c) => (
            <Tooltip key={c.key}>
              <TooltipTrigger asChild>
                <button
                  type="button"
                  aria-label={c.name}
                  onClick={(e) => {
                    e.stopPropagation();
                    onChange(c.key);
                    setOpen(false);
                  }}
                  className={`h-8 w-8 rounded-full border transition-transform hover:scale-110 ${
                    color === c.key
                      ? "ring-2 ring-ring ring-offset-2 ring-offset-background"
                      : ""
                  }`}
                  style={{
                    // V8 — the first ("Theme default") swatch previews the
                    // live theme-matched card colour
                    backgroundColor:
                      c.key === "default"
                        ? "var(--note-default-bg, #ffffff)"
                        : isDark
                          ? c.dark
                          : c.light,
                    borderColor: "rgba(0,0,0,0.12)",
                  }}
                />
              </TooltipTrigger>
              <TooltipContent side="bottom" className="text-xs">
                {c.name}
              </TooltipContent>
            </Tooltip>
          ))}
        </div>
        <p className="mt-2 max-w-[15rem] text-[10px] leading-snug text-muted-foreground">
          “Theme default” follows the app theme; a chosen colour stays on the note permanently.
        </p>
      </PopoverContent>
    </Popover>
  );
}
