"use client";

/**
 * V12 — bulk (mass) selection action bar.
 *
 * Visible while `selectionMode` is on. Floating card pinned to the bottom of
 * the viewport with the same actions a single note card offers, applied to
 * every selected note at once: pin/unpin, colour, archive/unarchive, move to
 * folder, trash (or delete-forever inside the trash view). Select-all /
 * clear + an exit button live on the left.
 */

import { Fragment, useState } from "react";
import {
  Archive,
  ArchiveRestore,
  FolderInput,
  ListChecks,
  Lock,
  LockOpen,
  MoreVertical,
  Palette,
  Pin,
  Tag,
  Trash2,
  Undo2,
  X,
  Check,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { ColorPicker } from "./ColorPicker";
import { useKeepStore } from "./store";
import { useBackLayer } from "@/lib/back-nav";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

function BarButton({
  label,
  onClick,
  children,
  danger,
}: {
  label: string;
  onClick?: () => void;
  children: React.ReactNode;
  danger?: boolean;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={(e) => {
        e.stopPropagation();
        onClick?.();
      }}
      className={cn(
        "inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full transition-colors hover:bg-black/10 active:scale-90 dark:hover:bg-white/10",
        danger && "text-destructive hover:bg-destructive/10"
      )}
    >
      {children}
    </button>
  );
}

export function BulkActionBar() {
  const selectionMode = useKeepStore((s) => s.selectionMode);
  const selectedIds = useKeepStore((s) => s.selectedIds);
  const notes = useKeepStore((s) => s.notes);
  const folders = useKeepStore((s) => s.folders);
  const view = useKeepStore((s) => s.view);
  const vaultOpen = useKeepStore((s) => s.vaultOpen);
  const toggleSelectMode = useKeepStore((s) => s.toggleSelectMode);
  const selectAllVisible = useKeepStore((s) => s.selectAllVisible);
  const bulkUpdate = useKeepStore((s) => s.bulkUpdate);
  const bulkTrash = useKeepStore((s) => s.bulkTrash);
  const bulkDeleteForever = useKeepStore((s) => s.bulkDeleteForever);

  const [confirmDeleteForever, setConfirmDeleteForever] = useState(false);
  useBackLayer(!!confirmDeleteForever, () => setConfirmDeleteForever(false));

  if (!selectionMode) return null;

  const count = selectedIds.length;
  const selected = notes.filter((n) => selectedIds.includes(n.id));
  const allPinned = count > 0 && selected.every((n) => n.pinned);
  const allArchived = count > 0 && selected.every((n) => n.archived);
  const isTrashView = view === "trash";
  const inVaultView = view === "vault";
  const allVaulted = count > 0 && selected.every((n) => n.vaulted);

  return (
    <>
      <div
        role="toolbar"
        aria-label="Bulk actions"
        className="fixed bottom-[calc(1rem+env(safe-area-inset-bottom))] left-1/2 z-50 w-[min(96vw,42rem)] -translate-x-1/2 rounded-2xl border border-black/10 bg-card/95 p-2 shadow-2xl backdrop-blur-xl dark:border-white/15"
      >
        <div className="flex items-center gap-1 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {/* exit selection */}
          <BarButton
            label="Exit selection mode"
            onClick={() => {
              toggleSelectMode();
              toast("Selection closed");
            }}
          >
            <X className="h-5 w-5" />
          </BarButton>

          {/* count + select-all */}
          <button
            type="button"
            onClick={selectAllVisible}
            className="flex shrink-0 items-center gap-1.5 rounded-full px-2 py-1.5 text-left transition-colors hover:bg-black/5 dark:hover:bg-white/10"
            title="Select every note in this view (tap again to clear)"
          >
            <ListChecks className="h-4 w-4 shrink-0 text-primary" />
            <span className="whitespace-nowrap text-sm font-semibold tabular-nums">
              {count} selected
            </span>
          </button>

          <span className="mx-0.5 hidden h-6 w-px shrink-0 bg-black/10 sm:block dark:bg-white/15" />

          <div className="ml-auto flex shrink-0 items-center gap-0.5">
            {/* pin / unpin */}
            {!isTrashView ? (
              <BarButton
                label={allPinned ? "Unpin selected notes" : "Pin selected notes"}
                onClick={() =>
                  void bulkUpdate(
                    { pinned: !allPinned },
                    `${count} note${count === 1 ? "" : "s"} ${allPinned ? "unpinned" : "pinned"}`
                  )
                }
              >
                <Pin className={cn("h-5 w-5 rotate-45", allPinned && "fill-current")} />
              </BarButton>
            ) : (
              <BarButton
                label="Restore selected notes"
                onClick={() =>
                  void bulkUpdate(
                    { trashed: false, archived: false },
                    `${count} note${count === 1 ? "" : "s"} restored`
                  )
                }
              >
                <Undo2 className="h-5 w-5" />
              </BarButton>
            )}

            {/* colour */}
            {!isTrashView ? (
              <ColorPicker
                color="default"
                align="center"
                onChange={(key) =>
                  void bulkUpdate(
                    { color: key },
                    `Colour applied to ${count} note${count === 1 ? "" : "s"}`
                  )
                }
              >
                <Palette className="h-5 w-5" />
              </ColorPicker>
            ) : null}

            {/* archive / unarchive */}
            {!isTrashView && !inVaultView ? (
              <BarButton
                label={allArchived ? "Unarchive selected notes" : "Archive selected notes"}
                onClick={() =>
                  void bulkUpdate(
                    { archived: !allArchived },
                    `${count} note${count === 1 ? "" : "s"} ${allArchived ? "unarchived" : "archived"}`
                  )
                }
              >
                {allArchived ? (
                  <ArchiveRestore className="h-5 w-5" />
                ) : (
                  <Archive className="h-5 w-5" />
                )}
              </BarButton>
            ) : null}

            {/* vault move (only while the vault is open) */}
            {vaultOpen && !isTrashView ? (
              <BarButton
                label={allVaulted ? "Remove selected notes from vault" : "Move selected notes to vault"}
                onClick={() =>
                  void bulkUpdate(
                    allVaulted
                      ? { vaulted: false, archived: false }
                      : { vaulted: true, pinned: false },
                    `${count} note${count === 1 ? "" : "s"} ${allVaulted ? "removed from vault" : "moved to vault"}`
                  )
                }
              >
                {allVaulted ? <LockOpen className="h-5 w-5" /> : <Lock className="h-5 w-5" />}
              </BarButton>
            ) : null}

            {/* move to folder */}
            {!isTrashView && !inVaultView ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button
                    type="button"
                    aria-label="Move selected notes to folder"
                    title="Move to folder"
                    className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full transition-colors hover:bg-black/10 active:scale-90 dark:hover:bg-white/10"
                  >
                    <FolderInput className="h-5 w-5" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent
                  align="end"
                  side="top"
                  className="max-h-64 w-56 overflow-y-auto"
                >
                  <DropdownMenuLabel className="text-xs text-muted-foreground">
                    Move {count} note{count === 1 ? "" : "s"} to…
                  </DropdownMenuLabel>
                  <DropdownMenuItem
                    onClick={() =>
                      void bulkUpdate({ folderId: null }, `Removed ${count} note${count === 1 ? "" : "s"} from folders`)
                    }
                  >
                    No folder
                  </DropdownMenuItem>
                  {folders.map((f) => (
                    <DropdownMenuItem
                      key={f.id}
                      onClick={() =>
                        void bulkUpdate(
                          { folderId: f.id },
                          `${count} note${count === 1 ? "" : "s"} moved to ${f.emoji} ${f.name}`
                        )
                      }
                    >
                      {f.emoji} {f.name}
                    </DropdownMenuItem>
                  ))}
                  {folders.length === 0 ? (
                    <Fragment>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem disabled>
                        <Tag className="mr-2 h-4 w-4" /> No folders yet
                      </DropdownMenuItem>
                    </Fragment>
                  ) : null}
                </DropdownMenuContent>
              </DropdownMenu>
            ) : null}

            {/* trash / delete forever */}
            <BarButton
              label={isTrashView ? "Delete selected notes forever" : "Move selected notes to trash"}
              danger
              onClick={() => {
                if (isTrashView) setConfirmDeleteForever(true);
                else void bulkTrash();
              }}
            >
              <Trash2 className="h-5 w-5" />
            </BarButton>
          </div>
        </div>
      </div>

      <AlertDialog open={confirmDeleteForever} onOpenChange={setConfirmDeleteForever}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Delete {count} note{count === 1 ? "" : "s"} forever?
            </AlertDialogTitle>
            <AlertDialogDescription>
              The selected notes and their media will be permanently deleted. This
              action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={() => void bulkDeleteForever()}
            >
              <Check className="mr-1 h-4 w-4" /> Delete forever
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
