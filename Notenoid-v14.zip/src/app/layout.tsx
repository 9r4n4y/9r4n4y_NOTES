import type { Metadata, Viewport } from "next";
import "./globals.css";
import "katex/dist/katex.min.css";
import { Toaster } from "@/components/ui/sonner";
import { ThemeProvider } from "@/components/keep/theme-provider";
import {
  Inter,
  Roboto,
  Open_Sans,
  Nunito,
  Poppins,
  Lora,
  Merriweather,
  Playfair_Display,
  JetBrains_Mono,
  Fira_Code,
  IBM_Plex_Mono,
  Comic_Neue,
  Caveat,
} from "next/font/google";

/**
 * V6: 13 self-hosted font families (next/font downloads + subsets them at
 * BUILD time — no runtime network request), exposed as CSS variables that
 * lib/fonts.ts maps into the app/note font pickers. Works fully offline in
 * the Android APK.
 */
const inter = Inter({ subsets: ["latin"], variable: "--nf-inter", display: "swap" });
const roboto = Roboto({ subsets: ["latin"], weight: ["400", "500", "700"], variable: "--nf-roboto", display: "swap" });
const openSans = Open_Sans({ subsets: ["latin"], variable: "--nf-open-sans", display: "swap" });
const nunito = Nunito({ subsets: ["latin"], variable: "--nf-nunito", display: "swap" });
const poppins = Poppins({ subsets: ["latin"], weight: ["400", "500", "600", "700"], variable: "--nf-poppins", display: "swap" });
const lora = Lora({ subsets: ["latin"], variable: "--nf-lora", display: "swap" });
const merriweather = Merriweather({ subsets: ["latin"], weight: ["400", "700"], variable: "--nf-merriweather", display: "swap" });
const playfair = Playfair_Display({ subsets: ["latin"], variable: "--nf-playfair", display: "swap" });
const jetbrainsMono = JetBrains_Mono({ subsets: ["latin"], variable: "--nf-jetbrains-mono", display: "swap" });
const firaCode = Fira_Code({ subsets: ["latin"], variable: "--nf-fira-code", display: "swap" });
const ibmPlexMono = IBM_Plex_Mono({ subsets: ["latin"], weight: ["400", "500", "600"], variable: "--nf-ibm-plex-mono", display: "swap" });
const comicNeue = Comic_Neue({ subsets: ["latin"], weight: ["400", "700"], variable: "--nf-comic-neue", display: "swap" });
const caveat = Caveat({ subsets: ["latin"], variable: "--nf-caveat", display: "swap" });

export const metadata: Metadata = {
  title: "Notenoid — Notes, Lists & Folders",
  description:
    "Notenoid is a fast, beautifully organised local-first Markdown notepad with notes, checklists, photos, folders and a vault.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  // V7: the runtime theme-color is owned by ThemeController (follows the
  // active theme); this static entry is only the pre-hydration default.
  themeColor: "#f1f3f4",
};

const fontVars = [
  inter,
  roboto,
  openSans,
  nunito,
  poppins,
  lora,
  merriweather,
  playfair,
  jetbrainsMono,
  firaCode,
  ibmPlexMono,
  comicNeue,
  caveat,
]
  .map((f) => f.variable)
  .join(" ");

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={fontVars} suppressHydrationWarning>
      <body className="antialiased">
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster richColors position="bottom-left" closeButton />
        </ThemeProvider>
      </body>
    </html>
  );
}
