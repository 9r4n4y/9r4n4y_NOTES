// Google Keep-inspired design constants
//
// V8 colour model:
//   • The "default" key (always FIRST in the picker) = "follow the theme".
//     Selecting it clears any custom colour and the card wears the
//     theme-matched default published by ThemeController as
//     --note-default-bg / --note-default-fg (light themes: theme background a
//     little darker; dark themes: a little lighter; generic dark = black).
//   • Custom colours are PERMANENT: they are stored on the note and never
//     rewritten by theme changes — switching themes only swaps their
//     light/dark variant for readability.
//   • Text colour is FIXED per theme mode: black on light themes, white on
//     dark themes — for every colour, always. (fgLight/fgDark below are kept
//     only as legacy fallbacks for pre-hydration paint.)

export interface KeepColor {
  key: string;
  name: string;
  light: string;
  dark: string;
  /** text color that stays readable on top of the note background */
  fgLight: string;
  fgDark: string;
  /** dot shown in pickers */
  swatch: string;
}

export const KEEP_COLORS: KeepColor[] = [
  {
    key: "default",
    name: "Theme default",
    light: "#ffffff",
    dark: "#1e1f20",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#ffffff",
  },
  {
    key: "blue",
    name: "Cerulean",
    light: "#aecbfa",
    dark: "#3b4a6b",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#aecbfa",
  },
  {
    key: "brown",
    name: "Brown",
    light: "#e6c9a8",
    dark: "#57493a",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#e6c9a8",
  },
  {
    key: "gray",
    name: "Gray",
    light: "#e8eaed",
    dark: "#323232",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#e8eaed",
  },
  {
    key: "teal",
    name: "Teal",
    light: "#a7ffeb",
    dark: "#2d554e",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#a7ffeb",
  },
  {
    key: "green",
    name: "Green",
    light: "#ccff90",
    dark: "#414d33",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#ccff90",
  },
  {
    key: "pink",
    name: "Pink",
    light: "#fdcfe8",
    dark: "#5d3b51",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#fdcfe8",
  },
  {
    key: "purple",
    name: "Purple",
    light: "#d7aefb",
    dark: "#4b3d69",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#d7aefb",
  },
  {
    key: "red",
    name: "Coral",
    light: "#f28b82",
    dark: "#66332f",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#f28b82",
  },
  {
    key: "yellow",
    name: "Sand",
    light: "#fff475",
    dark: "#665f2e",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#fff475",
  },
  {
    key: "orange",
    name: "Orange",
    light: "#fbbc04",
    dark: "#6f5311",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#fbbc04",
  },
  // ------------------------------------------------------ V8 — 18 new colours
  {
    key: "sky",
    name: "Sky",
    light: "#d3e6fd",
    dark: "#2b4a6f",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#d3e6fd",
  },
  {
    key: "cyan",
    name: "Cyan",
    light: "#c9f0f7",
    dark: "#1e4d55",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#c9f0f7",
  },
  {
    key: "mint",
    name: "Mint",
    light: "#c8f5dd",
    dark: "#1f5741",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#c8f5dd",
  },
  {
    key: "sage",
    name: "Sage",
    light: "#d5ecc2",
    dark: "#44543a",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#d5ecc2",
  },
  {
    key: "forest",
    name: "Forest",
    light: "#bfe4b4",
    dark: "#2f4a33",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#bfe4b4",
  },
  {
    key: "lime",
    name: "Lime",
    light: "#e4f8a8",
    dark: "#4f5c1f",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#e4f8a8",
  },
  {
    key: "olive",
    name: "Olive",
    light: "#e8eeb4",
    dark: "#56582c",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#e8eeb4",
  },
  {
    key: "honey",
    name: "Honey",
    light: "#fbe3a8",
    dark: "#6f5b1a",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#fbe3a8",
  },
  {
    key: "apricot",
    name: "Apricot",
    light: "#f9d9b5",
    dark: "#6b4a26",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#f9d9b5",
  },
  {
    key: "rust",
    name: "Rust",
    light: "#f6cdb9",
    dark: "#6f3b22",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#f6cdb9",
  },
  {
    key: "cherry",
    name: "Cherry",
    light: "#f8c9c9",
    dark: "#6b2f2f",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#f8c9c9",
  },
  {
    key: "rose",
    name: "Rose",
    light: "#fbd0dc",
    dark: "#6e3448",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#fbd0dc",
  },
  {
    key: "magenta",
    name: "Magenta",
    light: "#fbd3ec",
    dark: "#6e3a5e",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#fbd3ec",
  },
  {
    key: "violet",
    name: "Violet",
    light: "#e4d9fb",
    dark: "#463a7a",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#e4d9fb",
  },
  {
    key: "indigo",
    name: "Indigo",
    light: "#d6defb",
    dark: "#36427a",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#d6defb",
  },
  {
    key: "steel",
    name: "Steel",
    light: "#dae0e8",
    dark: "#3a4450",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#dae0e8",
  },
  {
    key: "sandstone",
    name: "Sandstone",
    light: "#efe3c8",
    dark: "#5f543a",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#efe3c8",
  },
  {
    key: "clay",
    name: "Clay",
    light: "#e7dcd2",
    dark: "#4a4038",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#e7dcd2",
  },
  {
    key: "charcoal",
    name: "Charcoal",
    light: "#d3d6da",
    dark: "#33363a",
    fgLight: "#1a1b1e",
    fgDark: "#f7f8f9",
    swatch: "#d3d6da",
  },
];

export function getColor(key: string, isDark: boolean): KeepColor {
  return KEEP_COLORS.find((c) => c.key === key) ?? KEEP_COLORS[0];
}

/**
 * V8 — inline style for a note surface.
 *
 * • "default" → CSS vars published by ThemeController (theme-matched colour,
 *   updates live when the theme changes, no re-render needed).
 * • custom colours → fixed per-mode swatch + the FIXED note text colour:
 *   black on light themes, white on dark themes — never anything else.
 */
export function noteStyle(
  colorKey: string,
  isDark: boolean
): React.CSSProperties {
  const c = getColor(colorKey, isDark);
  if (c.key === "default") {
    return {
      backgroundColor: `var(--note-default-bg, ${c.light})`,
      color: `var(--note-default-fg, ${isDark ? c.fgDark : c.fgLight})`,
    };
  }
  return {
    backgroundColor: isDark ? c.dark : c.light,
    color: isDark ? c.fgDark : c.fgLight,
  };
}

export const FOLDER_EMOJIS = [
  "📁", "⭐", "💼", "🏠", "❤️", "📚", "🎵", "🎬", "✈️", "🍳",
  "💪", "💡", "🎨", "🔬", "🌱", "🐶", "🎉", "⚽", "🕹️", "💰",
];

export const FOLDER_TINTS: Record<string, { light: string; dark: string }> = {
  default: { light: "#f1f3f4", dark: "#2a2b2c" },
  blue: { light: "#d3e3fd", dark: "#394457" },
  red: { light: "#fadbd9", dark: "#54302d" },
  yellow: { light: "#fef0c0", dark: "#57502a" },
  green: { light: "#dff3d0", dark: "#3c4a2e" },
  purple: { light: "#ead3fc", dark: "#463a5e" },
};

export function folderTint(color: string, isDark: boolean) {
  return FOLDER_TINTS[color] ?? FOLDER_TINTS.default;
}

/** Max size (bytes) allowed for a raw GIF upload */
export const MAX_GIF_BYTES = 8 * 1024 * 1024;
