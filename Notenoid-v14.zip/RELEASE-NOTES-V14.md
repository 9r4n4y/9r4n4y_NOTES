# Notenoid V14.0

- Reworked Preview/Edit confirmation into a staged exact-word selection flow.
- A selected word is highlighted dark yellow as the actual tapped DOM/textarea range in both modes; repeated words are not selected together.
- Preview/Edit mode changes happen only after the in-editor confirmation **Done** button.
- The selected occurrence is restored in the other mode, centered on screen, and blinks for three seconds without forcing the viewport to the top or bottom.
- Added Windows **Shift+X** shortcut to start/confirm Preview/Edit mode changes.
- Markdown link Apply now preserves the original caret and scroll viewport, including on Android/WebView, instead of jumping to the document bottom.
- Pending selections remain visibly highlighted before Done, including in Preview mode where native browser selection colors are inconsistent.
- Bumped Android version code/name to 140 / 14.0.
