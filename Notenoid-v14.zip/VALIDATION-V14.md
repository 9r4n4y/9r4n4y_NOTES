
## Final centered-pulse pass

After the final overlay-coordinate correction, the production export was rebuilt and the browser fixture was rerun with a middle-of-document repeated word. The selection flow showed `pending: true`, switched into Edit mode only after Done, and produced one `.md-editor-pulse-overlay` containing only `repeat` with the dark-yellow animated background. The final browser screenshot was captured at `/home/ubuntu/screenshots/4173-ipn4jfjjt07ckhq_2026-09-28_11-11-36_9899.webp`.

The final source bundle also includes `docs/V14-SELECTION-FEATURE.md`, documenting the exact occurrence algorithm, midpoint/clamped scrolling contract, three-second pulse implementation, shortcut, Android/WebView behavior, and validation matrix.
