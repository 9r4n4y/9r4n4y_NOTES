# Release Notes — Notenoid V7.0

V7 is a quality release: the navigation panel is now a true full-height app
shell, the theme engine was rebuilt around professionally designed palettes,
math rendering understands every common notation, and the vault password can
always be recovered — with or without the current password.

---

## 1. Full-height side panel (new navigation shell)

- **The 📝 icon beside the app name is gone.** The panel now opens with the
  app name itself, cleaner and more focused.
- **The panel covers the ENTIRE left side of the screen — top to bottom:**
  - **Mobile:** the drawer now starts at the very top of the screen (no more
    floating below the top bar with a dead blurred strip above it) and runs
    down to the bottom. A ✕ button in the header closes it.
  - **Desktop:** the top bar moved inside the content column, so the
    navigation rail is a true edge-to-edge app sidebar — full screen height,
    themed glass surface, subtle divider, sticky while content scrolls.
- Polished nav items: an accent pill marks the active section, smoother hover
  states, themed counts and safe-area padding for notched phones.

## 2. Themes — rebuilt from real theme packs

The V6 themes were hand-made approximations. V7 ships **36 themes** built
from the canonical palettes of well-known, professionally designed theme
packs — the same ones used by modern editors and apps:

- **New:** Catppuccin Latte & Mocha, Rosé Pine, Tokyo Night, Everforest,
  Kanagawa, GitHub Light & Dark, One Dark, Twitter Dim, T3 Chat & T3 Ghost
- **Special themes rebuilt with real depth:**
  - **Frutiger Aero** — bright sky-to-leaf gradient with slow floating
    bubbles, glossy glass top bar / sidebar / note cards / dialogs, glossy
    blue primary buttons and inset-glow inputs.
  - **Vaporwave** — the classic neon grid backdrop, glowing pink/cyan cards,
    glass top bar and sidebar.
  - **Aurora (new)** — borealis glass in deep teal/indigo with soft light
    bleeds.
- **The theme now reaches every corner:**
  - scrollbars and text selection are derived from the active theme,
  - native widgets follow via `color-scheme` (checkboxes, inputs, keyboard),
  - the browser/Android UI (status bar colour via `theme-color`) follows the
    active theme live,
  - glass top bar + themed sidebar rail on every palette,
  - the moon/sun quick-switch icon now reflects the real active theme even in
    "System" mode (V6 bug).

## 3. Math markdown — every notation works

The KaTeX pipeline gained a smart preprocessor (`math-pre.ts`), so all of
these render beautifully in the preview:

- `\[ … \]` display blocks — including multi-line ones
  (`\begin{bmatrix}`, `\begin{aligned}`, …)
- `\( … \)` inline math
- `$$ … $$` and `$ … $` (as before)
- **Bare equations — no delimiters at all.** A line that is "just math" is
  detected automatically and rendered as display math:
  - `x = \frac{-b \pm \sqrt{b^2 - 4ac}}{2a}`
  - `a^2 - b^2 = (a-b)(a+b)`
  - `\log_a(xy) = \log_a x + \log_a y`
  - `E = mc^2`
  - even plain `a + b = c`
- Prose is never mathified: ordinary sentences, headings, lists, task items,
  tables, block quotes, inline code and fenced code blocks are left alone.
- Malformed LaTeX shows a red inline hint instead of crashing the preview
  (`throwOnError: false`).
- Line count is preserved by the preprocessor, so the V6 edit↔preview exact
  scroll restoration still lands on the same content.

## 4. Vault — password reset, two ways

- **With the current password** (as before).
- **With the two security questions — no current password needed.**
  Settings → Vault → Change password now has a two-way switch:
  "With current password" / "With security questions". Answer BOTH questions,
  type the new password twice, done.
- The unlock dialog's "Forgot password?" path (questions → new password →
  vault opens) is unchanged and now consistent with the settings flow.

## 5. Bug hunting (V7 fixes)

- Moon/sun quick-switch now resolves the *system* theme instead of always
  showing light (V6 bug).
- Theme variables are now written with `color-scheme`, fixing washed-out
  native inputs in dark themes.
- The stale hard-coded "24 themes" text in About → now always accurate.
- Settings → Vault shows the real registered security questions when
  resetting with answers (V6 guessed the first two).
- Static meta `theme-color` no longer fights the active theme on mobile
  browsers.
- Version badge (About) bumped to v7.0; APK `versionCode 70` / `versionName 7.0`.

## 6. Compatibility

- Same file format on disk (`node.md` + `attachment/`), same backup ZIPs,
  same vault records — upgrading from V6 keeps everything untouched.
- Old stored settings (theme ids, fonts, scales) carry over; unknown theme
  ids gracefully fall back.
