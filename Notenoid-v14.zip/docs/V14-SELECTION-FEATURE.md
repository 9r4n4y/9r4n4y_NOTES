# V14 Exact Selection and Centered Mode Pulse

## User behavior

When **Confirm mode switch / tap-to-select** is enabled, tapping Preview/Edit does not switch immediately:

1. The editor enters a staged selection state.
2. The user taps one word occurrence.
3. Only that exact occurrence is selected, even when the same word appears many times.
4. The occurrence is shown in dark yellow before confirmation.
5. The fixed/sticky **Done** button confirms the selection; **Cancel** abandons it.
6. The mode changes only after Done.

The behavior is supported in both Preview and Edit mode. Preview uses an exact DOM `mark`; Edit uses the exact textarea range and a dark-yellow `::selection` style.

## After Done

- The selected word is located in the destination mode using its source line and occurrence number.
- The generic mode-switch anchor restore is intentionally skipped for a confirmed exact word, so it cannot override word positioning.
- The word is centered in the scroll viewport whenever document bounds allow it. At the absolute beginning/end of a document, scrolling is safely clamped so the word remains visible rather than producing an invalid scroll position.
- A dark-yellow pulse blinks for exactly three seconds in both modes.
- Preview uses `mark.mode-pulse`; Edit uses a pointer-events-free `.md-editor-pulse-overlay` positioned from the existing textarea mirror meter.
- Repeated words are occurrence-counted within their source line/block; no global text search is used to restore a duplicate.

## Related fixes included in V14

- Markdown link Apply restores the original caret and viewport instead of jumping to the document bottom, including Android/WebView.
- Windows `Shift+X` toggles Preview/Edit using the same confirmation flow.
- Done remains in the sticky selection bar and is disabled until a word is selected.

## Implementation locations

- `src/components/keep/editor/MarkdownEditor.tsx`
  - exact occurrence selection and source metadata
  - pending Preview `mark.mode-selection-preview`
  - confirmed pulse restoration and midpoint positioning
  - textarea mirror geometry and editor overlay
  - confirmation flow and Shift+X shortcut
- `src/app/globals.css`
  - dark-yellow selection/pulse styling and reduced-motion fallback
- `test/mode-selection-regression.mjs`
  - repeated-word, punctuation, Unicode, Markdown syntax, and occurrence regression fixtures
- `VALIDATION-V14.md`
  - release validation summary

## Validation performed for this bundle

- TypeScript: `npx tsc --noEmit` — passed.
- Markdown occurrence regression: `node test/mode-selection-regression.mjs` — **5/5 passed**.
- Static production export: `npm run export:web` — passed.
- Browser fixture: pending Preview selection produced exactly one dark-yellow mark; pending Edit selection produced the exact textarea range with dark-yellow `::selection`; Done controls remained visible; screenshots were captured for pending and post-confirm states.
- Browser fixture covered repeated words, lists/task items, quote, inline code, links, table, fenced code, math, Unicode, and a long 40-paragraph document.
