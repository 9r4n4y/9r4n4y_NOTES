# Notenoid V8.0 — Release Notes

**Theme-matched notes, permanent custom colours, 29-colour palette, fixed text colours, and a true forgot-password vault flow.**

---

## 1. Default note cards now match the theme (every theme)

The default (uncoloured) note card is no longer plain white / flat grey — it is now
**derived from the active theme's own background colour**:

- **Light themes** → the theme background, **a little darker**.
  Example: Frutiger Aero's sky blue becomes a slightly deeper sky blue.
- **Dark themes** → the theme background, **a little lighter**, so cards read as cards.
  The generic dark theme (Keep Dark / System dark) stays in the **black** family —
  just visible against the background.
- **Pure-black / very dark themes** (High Contrast Dark, GitHub Dark, Charcoal…)
  get a slightly bigger lift so cards and the + button never melt into the background.

The colour is computed per theme by `defaultNoteColors()` in `lib/themes.ts` and
published by `ThemeController` as CSS variables (`--note-default-bg`,
`--note-default-fg`, `--note-default-border`), so theme switches restyle every
default card instantly — no storage rewriting, no reload.

## 2. The + New-note button matches the cards

The **New note button at the very top now wears exactly the same colour as the
default note cards** in every theme (same CSS variables). On dark/black themes it is
a little lighter, on light themes a little darker — always identical to the cards,
including Frutiger Aero's glossy finish.

## 3. 29-colour palette (18 new colours) + permanent custom colours

The colour picker grows from 11 to **29 options**: Sky, Cyan, Mint, Sage, Forest,
Lime, Olive, Honey, Apricot, Rust, Cherry, Rose, Magenta, Violet, Indigo, Steel,
Sandstone, Clay, Charcoal join the original ten.

Two rules are now guaranteed:

- **"Theme default"** is the first swatch. Selecting it **removes any custom
  colour** and the note follows the theme again (its preview swatch shows the live
  theme colour). Its tooltip explains the behaviour.
- **Custom colours are permanent.** A picked colour is stored on the note and is
  never rewritten by theme changes — switch themes as much as you like, the note
  keeps its colour (only its light/dark variant swaps for readability).

## 4. Fixed text colours — black on light, white on dark

Note text no longer inherits tinted per-colour foregrounds. **Every light theme
renders note text in black; every dark theme renders it in white — always**, on the
default card and on every custom colour. This eliminates the readability problems
where light text landed on light theme backgrounds.

## 5. Vault — security questions are the forgot-password path

- The unlock dialog now says it up front: **"Forgot password?"** answers BOTH
  security questions and sets a new password — **no current password needed**.
- Settings → Vault → Change password: the second tab is now labelled
  **"Forgot password?"** and only asks the two answers + the new password.
- Security questions can also be replaced **without the password**: in
  Settings → Vault → Security questions, choose **"Verify with answers"** and
  answer your *current* two questions instead of typing the password
  (`setSecurityQuestionsByAnswers` in `lib/vault.ts`).

## 6. Frutiger Aero polish

The signature glass veil on note cards was lightened so the new theme-matched
default (slightly darker sky blue) actually shows through — dialogs, header and
sidebar keep the full glass. The + button keeps the Aero gloss on top of the card
colour.

---

### Technical notes

- `lib/themes.ts` — `NOTE_FG_LIGHT` / `NOTE_FG_DARK`, `defaultNoteColors(theme)` (sRGB
  mixing + WCAG relative luminance), theme background is the base for the default card.
- `ThemeController.tsx` — publishes `--note-default-bg/fg/border` on every theme
  application (including live "system" dark-mode switches).
- `lib/keep-constants.ts` — `noteStyle()` returns `var(--note-default-bg)` for the
  default key and the fixed black/white text colours; `KEEP_COLORS` expanded to 29.
- `ColorPicker.tsx` — first swatch = "Theme default" (live preview), scrollable grid,
  helper caption.
- `TopBar.tsx` + `globals.css` — `button.note-default-btn` styles the + button with
  the same variables (with `!important` to beat theme primary styling).
- `lib/vault.ts` — `setSecurityQuestionsByAnswers()`.
- `SettingsDialog.tsx` / `VaultDialogs.tsx` — forgot-password labels + verify-with-answers
  mode; About tab updated to v8.0 (29 colours).
- `package.json` 8.0.0 · APK `versionCode 80` / `versionName "8.0"`.
