const wordChars = /[\p{L}\p{N}_-]/u;
const isWord = (c) => !!c && wordChars.test(c);
function occurrence(text, word, offset) {
  const lower = text.normalize('NFKC').toLocaleLowerCase();
  const target = word.normalize('NFKC').toLocaleLowerCase();
  let count = 0, at = lower.indexOf(target);
  while (at >= 0 && at < offset) {
    if (!isWord(lower[at - 1]) && !isWord(lower[at + target.length])) count++;
    at = lower.indexOf(target, at + Math.max(1, target.length));
  }
  return count;
}
const cases = [
  ['repeat repeat repeat', 'repeat', 14, 2],
  ['- [ ] ship ship', 'ship', 10, 1],
  ['**word** and `word` and [word](https://x.test)', 'word', 18, 2],
  ['one\n\n## one\n> one', 'one', 5, 1],
  ['café café CAFÉ', 'café', 6, 2],
];
for (const [text, word, offset, expected] of cases) {
  const actual = occurrence(text, word, offset);
  if (actual !== expected) throw new Error(`${text}: expected ${expected}, got ${actual}`);
}
console.log(`mode-selection regression: ${cases.length}/${cases.length} passed`);
