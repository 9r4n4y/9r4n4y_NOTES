"use client";

// ---------------------------------------------------------------------------
// Vault — password + security-question protection for private notes.
//
// Design goals (V6):
//   • A visible "Vault" section in the sidebar; tapping it asks for the
//     password the first time. After one successful unlock the vault stays
//     open for the whole app session (sessionStorage) and never asks again
//     until the app is closed.
//   • Password is stored as a PBKDF2-SHA256 hash (150k iterations) with a
//     per-vault random salt — never in plain text.
//   • Exactly TWO security questions (chosen from a bank of many different
//     types) are required at setup; both answers must be provided to reset
//     a forgotten password. Answers are normalised (trim + lowercase +
//     collapsed whitespace) and hashed with their own salts.
//   • Migration from the legacy SHA-256-only code (V5 "secret code"):
//     the first successful unlock with the old hash transparently upgrades
//     the record to the V2 format.
// ---------------------------------------------------------------------------

export const VAULT_RECORD_KEY = "notes-vault-record-v2"; // permanent (localStorage)
export const VAULT_LEGACY_CODE_KEY = "notes-vault-code-hash"; // V5 format
export const VAULT_SESSION_KEY = "notes-vault-open"; // session only (sessionStorage)

/** Security-question bank — ids are stable, texts may be reworded later. */
export const SECURITY_QUESTIONS: { id: string; text: string }[] = [
  { id: "first_school", text: "What was the name of your first school?" },
  { id: "maiden_name", text: "What is your mother's maiden name?" },
  { id: "first_pet", text: "What was the name of your first pet?" },
  { id: "birth_city", text: "In which city were you born?" },
  { id: "favourite_book", text: "What is your favourite book?" },
  { id: "childhood_friend", text: "Who was your best childhood friend?" },
  { id: "first_vehicle", text: "What was the model of your first car or bike?" },
  { id: "favourite_food", text: "What is your favourite food?" },
  { id: "nickname", text: "What was your childhood nickname?" },
  { id: "grew_up_street", text: "What street did you grow up on?" },
  { id: "favourite_movie", text: "What is your favourite movie?" },
  { id: "first_job", text: "Where did you work for the first time?" },
  { id: "oldest_cousin", text: "What is your oldest cousin's name?" },
  { id: "first_teacher", text: "What was the name of your first teacher?" },
  { id: "dream_place", text: "What is your dream travel destination?" },
];

export function questionText(id: string): string {
  return SECURITY_QUESTIONS.find((q) => q.id === id)?.text ?? "Security question";
}

export interface VaultQuestionRecord {
  id: string;
  salt: string; // hex
  answerHash: string; // hex
}

export interface VaultRecord {
  v: 2;
  salt: string; // hex, per-vault
  passwordHash: string; // hex, PBKDF2-SHA256
  iterations: number;
  questions: VaultQuestionRecord[]; // always exactly 2 in V6 setups
}

// ------------------------------------------------------------------ helpers

function toHex(buf: ArrayBuffer | Uint8Array): string {
  const bytes = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function randomHex(bytes = 16): string {
  const arr = new Uint8Array(bytes);
  crypto.getRandomValues(arr);
  return toHex(arr);
}

async function sha256Hex(text: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return toHex(digest);
}

async function pbkdf2Hex(password: string, saltHex: string, iterations: number): Promise<string> {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, [
    "deriveBits",
  ]);
  const salt = new Uint8Array(saltHex.match(/.{2}/g)!.map((b) => parseInt(b, 16)));
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", salt: salt as unknown as BufferSource, iterations },
    keyMaterial,
    256
  );
  return toHex(bits);
}

/** Normalise an answer: trim, collapse inner whitespace, lowercase. */
function normaliseAnswer(s: string): string {
  return s.trim().replace(/\s+/g, " ").toLocaleLowerCase();
}

const PBKDF2_ITERATIONS = 150_000;

function readRecord(): VaultRecord | null {
  try {
    const raw = localStorage.getItem(VAULT_RECORD_KEY);
    if (!raw) return null;
    const rec = JSON.parse(raw) as VaultRecord;
    if (rec && rec.v === 2 && rec.passwordHash && rec.salt) return rec;
    return null;
  } catch {
    return null;
  }
}

function writeRecord(rec: VaultRecord | null): void {
  try {
    if (rec) localStorage.setItem(VAULT_RECORD_KEY, JSON.stringify(rec));
    else localStorage.removeItem(VAULT_RECORD_KEY);
  } catch {
    // storage unavailable — vault cannot persist
  }
}

// ------------------------------------------------------------------ queries

/** True when a vault password has been set (either V2 record or legacy hash). */
export function vaultPasswordExists(): boolean {
  if (readRecord()) return true;
  try {
    return !!localStorage.getItem(VAULT_LEGACY_CODE_KEY);
  } catch {
    return false;
  }
}

export function hasSecurityQuestions(): boolean {
  const rec = readRecord();
  return !!rec && rec.questions.length === 2;
}

export function getSecurityQuestionIds(): string[] {
  const rec = readRecord();
  return rec ? rec.questions.map((q) => q.id) : [];
}

/** Read the raw record (used to carry it inside an export). */
export function readVaultRecord(): VaultRecord | null {
  return readRecord();
}

/** Restore a record from an export. Only used when no vault exists locally. */
export function writeVaultRecord(rec: VaultRecord): void {
  if (rec && rec.v === 2 && typeof rec.passwordHash === "string" && typeof rec.salt === "string") {
    writeRecord({
      ...rec,
      iterations: rec.iterations || PBKDF2_ITERATIONS,
      questions: Array.isArray(rec.questions) ? rec.questions : [],
    });
  }
}

// ------------------------------------------------------------------ setup

export interface SetupQuestionInput {
  id: string;
  answer: string;
}

/** Create the vault record: password + exactly two security questions. */
export async function setupVaultPassword(
  password: string,
  questions: [SetupQuestionInput, SetupQuestionInput]
): Promise<void> {
  const salt = randomHex(16);
  const passwordHash = await pbkdf2Hex(password, salt, PBKDF2_ITERATIONS);
  const qRecords: VaultQuestionRecord[] = [];
  for (const q of questions) {
    const qSalt = randomHex(16);
    qRecords.push({
      id: q.id,
      salt: qSalt,
      answerHash: await pbkdf2Hex(normaliseAnswer(q.answer), qSalt, PBKDF2_ITERATIONS),
    });
  }
  const rec: VaultRecord = {
    v: 2,
    salt,
    passwordHash,
    iterations: PBKDF2_ITERATIONS,
    questions: qRecords,
  };
  writeRecord(rec);
  // legacy key is superseded once a V2 record exists
  try {
    localStorage.removeItem(VAULT_LEGACY_CODE_KEY);
  } catch {
    /* ignore */
  }
}

// ------------------------------------------------------------------ verify

/**
 * Verify a password. Transparently migrates a legacy V5 code on success.
 * (Legacy: plain SHA-256 hash comparison — replaced by PBKDF2.)
 */
export async function verifyVaultPassword(password: string): Promise<boolean> {
  const rec = readRecord();
  if (rec) {
    const hash = await pbkdf2Hex(password, rec.salt, rec.iterations || PBKDF2_ITERATIONS);
    return hash === rec.passwordHash;
  }
  // legacy V5 code
  let legacy: string | null = null;
  try {
    legacy = localStorage.getItem(VAULT_LEGACY_CODE_KEY);
  } catch {
    legacy = null;
  }
  if (legacy) {
    const hash = await sha256Hex(password);
    if (hash === legacy) {
      // upgrade to V2 with no questions — the user can add questions later
      const salt = randomHex(16);
      writeRecord({
        v: 2,
        salt,
        passwordHash: await pbkdf2Hex(password, salt, PBKDF2_ITERATIONS),
        iterations: PBKDF2_ITERATIONS,
        questions: [],
      });
      try {
        localStorage.removeItem(VAULT_LEGACY_CODE_KEY);
      } catch {
        /* ignore */
      }
      return true;
    }
    return false;
  }
  return false; // no vault set — nothing to verify
}

/** Change the password (requires the current one). Keeps security questions. */
export async function changeVaultPassword(current: string, next: string): Promise<boolean> {
  if (!(await verifyVaultPassword(current))) return false;
  const rec = readRecord();
  if (!rec) return false;
  const salt = randomHex(16);
  rec.salt = salt;
  rec.passwordHash = await pbkdf2Hex(next, salt, PBKDF2_ITERATIONS);
  rec.iterations = PBKDF2_ITERATIONS;
  writeRecord(rec);
  return true;
}

/**
 * Verify BOTH security answers. Order-insensitive; both must match.
 * False when the vault has no questions recorded (legacy upgrade path).
 */
export async function verifySecurityAnswers(
  answers: { id: string; answer: string }[]
): Promise<boolean> {
  const rec = readRecord();
  if (!rec || rec.questions.length !== 2) return false;
  if (answers.length !== 2) return false;
  const byId = new Map(rec.questions.map((q) => [q.id, q]));
  for (const a of answers) {
    const q = byId.get(a.id);
    if (!q) return false;
    const hash = await pbkdf2Hex(normaliseAnswer(a.answer), q.salt, rec.iterations || PBKDF2_ITERATIONS);
    if (hash !== q.answerHash) return false;
  }
  return true;
}

/**
 * Full recovery path: verify both security answers and set a new password.
 * On success the vault is considered legitimately unlocked by the owner.
 */
export async function resetVaultPassword(
  answers: { id: string; answer: string }[],
  newPassword: string
): Promise<boolean> {
  if (!(await verifySecurityAnswers(answers))) return false;
  const rec = readRecord();
  if (!rec) return false;
  const salt = randomHex(16);
  rec.salt = salt;
  rec.passwordHash = await pbkdf2Hex(newPassword, salt, PBKDF2_ITERATIONS);
  rec.iterations = PBKDF2_ITERATIONS;
  writeRecord(rec);
  return true;
}

/** Add/replace the two security questions (requires the current password). */
export async function setSecurityQuestions(
  current: string,
  questions: [SetupQuestionInput, SetupQuestionInput]
): Promise<boolean> {
  if (!(await verifyVaultPassword(current))) return false;
  return writeQuestions(questions);
}

/**
 * V8 — add/replace the two security questions by verifying the CURRENT
 * answers instead of the password. This is the forgot-password path: an
 * owner who cannot remember the password (but knows the answers) can still
 * rotate their questions — and then reset the password with the new ones.
 */
export async function setSecurityQuestionsByAnswers(
  currentAnswers: { id: string; answer: string }[],
  questions: [SetupQuestionInput, SetupQuestionInput]
): Promise<boolean> {
  if (!(await verifySecurityAnswers(currentAnswers))) return false;
  return writeQuestions(questions);
}

/** Shared writer used by both question-change paths (password / answers). */
async function writeQuestions(
  questions: [SetupQuestionInput, SetupQuestionInput]
): Promise<boolean> {
  const rec = readRecord();
  if (!rec) return false;
  const qRecords: VaultQuestionRecord[] = [];
  for (const q of questions) {
    const qSalt = randomHex(16);
    qRecords.push({
      id: q.id,
      salt: qSalt,
      answerHash: await pbkdf2Hex(normaliseAnswer(q.answer), qSalt, PBKDF2_ITERATIONS),
    });
  }
  rec.questions = qRecords;
  writeRecord(rec);
  return true;
}

// ------------------------------------------------------------------ session

/** Read the session-scoped vault-open flag (client only). */
export function readVaultSession(): boolean {
  try {
    return sessionStorage.getItem(VAULT_SESSION_KEY) === "1";
  } catch {
    return false;
  }
}

export function writeVaultSession(open: boolean): void {
  try {
    if (open) sessionStorage.setItem(VAULT_SESSION_KEY, "1");
    else sessionStorage.removeItem(VAULT_SESSION_KEY);
  } catch {
    // ignore
  }
}
