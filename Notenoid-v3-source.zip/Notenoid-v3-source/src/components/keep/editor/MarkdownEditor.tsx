"use client";

import * as React from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeRaw from "rehype-raw";
import {
  Bold,
  Braces,
  Code,
  Eye,
  Heading1,
  Heading2,
  Heading3,
  ImagePlus,
  Italic,
  Link2,
  Link2Off,
  ListPlus,
  List,
  ListChecks,
  ListOrdered,
  Minus,
  PenLine,
  Quote,
  Redo2,
  RemoveFormatting,
  Strikethrough,
  Table2,
  Underline as UnderlineIcon,
  Undo2,
} from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { decodeAttachmentPath, encodeAttachmentPath, toggleTaskLine } from "@/core/markdown";
import type { SearchResults } from "./search-highlight";

/**
 * Notenoid Markdown editor surface.
 *
 * The persisted document remains plain Markdown. Edit mode is intentionally a
 * transparent textarea so existing files, folders, labels, task lists and
 * front-matter stay untouched. Preview mode uses GitHub-Flavored Markdown,
 * including tables, task lists and strikethrough. Attachments continue to be
 * owned by NoteEditorView and are only inserted when the user explicitly asks.
 */

export interface MarkdownEditorHandle {
  focus: () => void;
  insertImage: (url: string, alt?: string) => void;
  getMarkdown: () => string;
  getScrollElement: () => HTMLElement | null;
  registerUrl: (url: string, file: string) => void;
  setSearchQuery: (query: string) => void;
  goToMatch: (index: number) => void;
}

interface ToolbarProps {
  editor: HTMLTextAreaElement | null;
  preview: boolean;
  onTogglePreview: () => void;
  onPickImages: () => void;
  onAction: (action: string, value?: string, label?: string) => void;
}

function ToolButton({
  onClick,
  active,
  disabled,
  label,
  children,
}: {
  onClick?: () => void;
  active?: boolean;
  disabled?: boolean;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      disabled={disabled}
      onMouseDown={(e) => e.preventDefault()}
      onClick={onClick}
      className={cn(
        "inline-flex h-8 min-w-8 shrink-0 items-center justify-center rounded-md px-1.5 text-foreground/75 transition-colors hover:bg-black/10 hover:text-foreground disabled:opacity-30 dark:hover:bg-white/10",
        active && "bg-foreground/10 text-foreground dark:bg-white/15"
      )}
    >
      {children}
    </button>
  );
}

function Toolbar({ editor, preview, onTogglePreview, onPickImages, onAction }: ToolbarProps) {
  const [linkOpen, setLinkOpen] = React.useState(false);
  const [linkUrl, setLinkUrl] = React.useState("");
  const [linkLabel, setLinkLabel] = React.useState("");
  const [multiOpen, setMultiOpen] = React.useState(false);
  const [multiSelection, setMultiSelection] = React.useState<string[]>([]);
  const linkInputRef = React.useRef<HTMLInputElement | null>(null);

  const applyLink = () => {
    const url = linkUrl.trim();
    if (!url) return;
    onAction("link", url, linkLabel.trim());
    setLinkOpen(false);
  };

  const multiOptions = [
    ["bold", "Bold"], ["italic", "Italic"], ["underline", "Underline"],
    ["strike", "Strikethrough"], ["code", "Inline code"],
    ["h1", "Heading 1"], ["h2", "Heading 2"], ["h3", "Heading 3"],
  ] as const;
  const applyMulti = () => {
    onAction("multi", multiSelection.join(","));
    setMultiOpen(false);
    setMultiSelection([]);
  };

  return (
    <div className="relative border-b border-black/5 bg-background/60 backdrop-blur dark:border-white/10">
      <div className="flex items-center gap-0.5 overflow-x-auto px-2 py-1.5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        <ToolButton label={preview ? "Edit Markdown" : "Preview rendered note"} active={preview} onClick={onTogglePreview}>
          {preview ? <PenLine className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
        </ToolButton>
        <ToolButton label="Bold" onClick={() => onAction("bold")}><Bold className="h-4 w-4" /></ToolButton>
        <ToolButton label="Italic" onClick={() => onAction("italic")}><Italic className="h-4 w-4" /></ToolButton>
        <ToolButton label="Underline" onClick={() => onAction("underline")}><UnderlineIcon className="h-4 w-4" /></ToolButton>
        <ToolButton label="Strikethrough" onClick={() => onAction("strike")}><Strikethrough className="h-4 w-4" /></ToolButton>
        <ToolButton label="Inline code" onClick={() => onAction("code")}><Code className="h-4 w-4" /></ToolButton>
        <span className="mx-1 h-5 w-px shrink-0 bg-black/10 dark:bg-white/15" />
        <ToolButton label="Heading 1" onClick={() => onAction("h1")}><Heading1 className="h-4 w-4" /></ToolButton>
        <ToolButton label="Heading 2" onClick={() => onAction("h2")}><Heading2 className="h-4 w-4" /></ToolButton>
        <ToolButton label="Heading 3" onClick={() => onAction("h3")}><Heading3 className="h-4 w-4" /></ToolButton>
        <ToolButton label="Body text" onClick={() => onAction("paragraph")}><Braces className="h-4 w-4 rotate-90" /></ToolButton>
        <span className="mx-1 h-5 w-px shrink-0 bg-black/10 dark:bg-white/15" />
        <ToolButton label="Bullet list" onClick={() => onAction("ul")}><List className="h-4 w-4" /></ToolButton>
        <ToolButton label="Numbered list" onClick={() => onAction("ol")}><ListOrdered className="h-4 w-4" /></ToolButton>
        <ToolButton label="Checklist" onClick={() => onAction("todo")}><ListChecks className="h-4 w-4" /></ToolButton>
        <ToolButton label="Quote" onClick={() => onAction("quote")}><Quote className="h-4 w-4" /></ToolButton>
        <ToolButton label="Code block" onClick={() => onAction("codeblock")}><Braces className="h-4 w-4" /></ToolButton>
        <span className="mx-1 h-5 w-px shrink-0 bg-black/10 dark:bg-white/15" />
        <Popover modal open={linkOpen} onOpenChange={(open) => {
          if (open) setLinkUrl("");
          setLinkOpen(open);
        }}>
          <PopoverTrigger asChild>
            <span className="inline-flex shrink-0"><ToolButton label="Add link"><Link2 className="h-4 w-4" /></ToolButton></span>
          </PopoverTrigger>
          <PopoverContent align="start" side="bottom" sideOffset={6} collisionPadding={8} className="z-[70] w-[min(92vw,26rem)] rounded-xl p-2 shadow-xl" onOpenAutoFocus={(e) => {
            e.preventDefault();
            requestAnimationFrame(() => { linkInputRef.current?.focus(); linkInputRef.current?.select(); });
          }}>
            <div className="space-y-2">
              <input ref={linkInputRef} value={linkLabel} onChange={(e) => setLinkLabel(e.target.value)} placeholder="Link text (optional)" aria-label="Link text" className="w-full rounded-md bg-transparent px-2 py-1.5 text-sm outline-none ring-1 ring-black/10 focus:ring-foreground/30 dark:ring-white/15" />
              <div className="flex items-center gap-2">
                <input value={linkUrl} onChange={(e) => setLinkUrl(e.target.value)} onKeyDown={(e) => {
                  if (e.key === "Enter") { e.preventDefault(); applyLink(); }
                  if (e.key === "Escape") setLinkOpen(false);
                }} inputMode="url" placeholder="https://…" aria-label="Link URL" className="min-w-0 flex-1 rounded-md bg-transparent px-2 py-1.5 text-sm outline-none ring-1 ring-black/10 focus:ring-foreground/30 dark:ring-white/15" />
                <button type="button" onClick={applyLink} className="shrink-0 rounded-md bg-foreground px-3 py-1.5 text-sm font-medium text-background">Apply</button>
                <button type="button" onClick={() => setLinkOpen(false)} className="shrink-0 rounded-md px-2 py-1.5 text-sm text-muted-foreground">Cancel</button>
              </div>
            </div>
          </PopoverContent>
        </Popover>
        <ToolButton label="Remove link" onClick={() => onAction("remove-link")}><Link2Off className="h-4 w-4" /></ToolButton>
        <ToolButton label="Add image (saved to attachments)" onClick={onPickImages}><ImagePlus className="h-4 w-4" /></ToolButton>
        <ToolButton label="Divider" onClick={() => onAction("hr")}><Minus className="h-4 w-4" /></ToolButton>
        <ToolButton label="Insert table" onClick={() => onAction("table")}><Table2 className="h-4 w-4" /></ToolButton>
        <ToolButton label="Clear formatting" onClick={() => onAction("clear")}><RemoveFormatting className="h-4 w-4" /></ToolButton>
        <Popover modal open={multiOpen} onOpenChange={setMultiOpen}>
          <PopoverTrigger asChild>
            <span className="inline-flex shrink-0"><ToolButton label="Choose multiple formats"><ListPlus className="h-4 w-4" /></ToolButton></span>
          </PopoverTrigger>
          <PopoverContent align="end" side="bottom" sideOffset={6} collisionPadding={8} className="z-[70] w-56 rounded-xl p-3 shadow-xl">
            <p className="mb-2 text-sm font-medium">Apply multiple formats</p>
            <div className="grid grid-cols-2 gap-1.5">
              {multiOptions.map(([value, label]) => <label key={value} className="flex items-center gap-2 rounded-md px-1.5 py-1 text-xs hover:bg-accent"><input type="checkbox" checked={multiSelection.includes(value)} onChange={(e) => setMultiSelection((current) => e.target.checked ? [...current, value] : current.filter((item) => item !== value))} />{label}</label>)}
            </div>
            <button type="button" disabled={multiSelection.length === 0} onClick={applyMulti} className="mt-3 w-full rounded-md bg-foreground px-3 py-1.5 text-sm font-medium text-background disabled:opacity-40">Done</button>
          </PopoverContent>
        </Popover>
        <span className="mx-1 h-5 w-px shrink-0 bg-black/10 dark:bg-white/15" />
        <ToolButton label="Undo" onClick={() => onAction("undo")}><Undo2 className="h-4 w-4" /></ToolButton>
        <ToolButton label="Redo" onClick={() => onAction("redo")}><Redo2 className="h-4 w-4" /></ToolButton>
        <span className="flex-1" />
      </div>
    </div>
  );
}

export interface MarkdownEditorProps {
  value: string;
  onChange: (markdown: string) => void;
  fileToUrl: (file: string) => string;
  urlToFile: Map<string, string>;
  onRequestInsertImages: () => void;
  onPasteImages?: (files: File[]) => void;
  onSearchResults?: (results: SearchResults) => void;
  handleRef?: React.RefObject<MarkdownEditorHandle | null>;
  beforeContent?: React.ReactNode;
  placeholder?: string;
  autoFocus?: boolean;
  initialPreview?: boolean;
}

const EMPTY_TASK_LIST_HTML = '<ul data-type="taskList"><li data-type="taskItem" data-checked="false"><p></p></li></ul>';

export const MarkdownEditor = ({
  value,
  onChange,
  fileToUrl,
  urlToFile,
  onRequestInsertImages,
  onPasteImages,
  onSearchResults,
  handleRef,
  beforeContent,
  placeholder,
  autoFocus,
  initialPreview = true,
}: MarkdownEditorProps) => {
  const scrollRef = React.useRef<HTMLDivElement | null>(null);
  const textareaRef = React.useRef<HTMLTextAreaElement | null>(null);
  const urlToFileRef = React.useRef(urlToFile);
  const searchQueryRef = React.useRef("");
  const [preview, setPreview] = React.useState(initialPreview);
  const [draft, setDraft] = React.useState(value === EMPTY_TASK_LIST_HTML ? "- [ ] " : value);
  const [searchQuery, setSearchQuery] = React.useState("");
  const [searchIndex, setSearchIndex] = React.useState(0);
  const [copiedCode, setCopiedCode] = React.useState<string | null>(null);
  const togglePreview = React.useCallback(() => {
    const scrollTop = scrollRef.current?.scrollTop ?? 0;
    setPreview((current) => !current);
    requestAnimationFrame(() => requestAnimationFrame(() => {
      if (scrollRef.current) scrollRef.current.scrollTop = scrollTop;
    }));
  }, []);
  React.useEffect(() => { urlToFileRef.current = urlToFile; }, [urlToFile]);

  const toDisplay = React.useCallback((md: string) => md.replace(/(!?\[([^\]]*)\])\(\s*(attachment\/[^)\s]+)((?:\s+"[^"]*")?)\s*\)/g, (full, label: string, alt: string, file: string, title: string) => {
    const decoded = decodeAttachmentPath(file);
    const url = fileToUrl(decoded) || fileToUrl(file);
    // Attachment links are rendered as images even when older notes stored
    // them as `[filename](attachment/...)` instead of `![alt](...)`.
    return url ? `![${alt || decoded.split("/").pop() || "Attached image"}](${url}${title})` : full;
  }), [fileToUrl]);

  const fromDisplay = React.useCallback((md: string) => md.replace(/\]\(\s*(blob:[^)\s]+|data:[^)\s]+)((?:\s+"[^"]*")?)\s*\)/g, (full, url: string, title: string) => {
    const file = urlToFileRef.current.get(url);
    return file ? `](${encodeAttachmentPath(file)}${title})` : full;
  }), []);

  React.useEffect(() => {
    const normalized = value === EMPTY_TASK_LIST_HTML ? "- [ ] " : value;
    if (normalized !== draft) setDraft(normalized);
  }, [value]); // eslint-disable-line react-hooks/exhaustive-deps

  React.useEffect(() => {
    if (!autoFocus || preview) return;
    requestAnimationFrame(() => textareaRef.current?.focus());
  }, [autoFocus, preview]);

  const emitSearch = React.useCallback((query: string, preferred = 0) => {
    const q = query.trim().normalize("NFKC").toLocaleLowerCase();
    if (!q) {
      onSearchResults?.({ count: 0, active: 0 });
      return;
    }
    const matches: number[] = [];
    const searchable = draft.normalize("NFKC").toLocaleLowerCase();
    let at = searchable.indexOf(q);
    while (at !== -1) {
      matches.push(at);
      at = searchable.indexOf(q, at + Math.max(1, q.length));
    }
    const index = matches.length ? ((preferred % matches.length) + matches.length) % matches.length : 0;
    setSearchIndex(index);
    onSearchResults?.({ count: matches.length, active: index });
    if (matches[index] != null && textareaRef.current && !preview) {
      const el = textareaRef.current;
      const match = matches[index];
      // Never focus the editor or select the match: doing either steals focus
      // from the search field and makes the next typed character replace text.
      el.setSelectionRange(match, match);
      const line = draft.slice(0, match).split("\n").length - 1;
      const lineHeight = Number.parseFloat(getComputedStyle(el).lineHeight) || 24;
      const container = scrollRef.current;
      if (container) {
        const target = el.offsetTop + line * lineHeight - container.clientHeight * 0.35;
        container.scrollTo({ top: Math.max(0, target), behavior: "smooth" });
      }
    }
  }, [draft, onSearchResults, preview]);

  React.useImperativeHandle(handleRef, () => ({
    focus: () => textareaRef.current?.focus(),
    registerUrl: (url, file) => { urlToFileRef.current = new Map(urlToFileRef.current).set(url, file); },
    setSearchQuery: (query) => {
      searchQueryRef.current = query;
      setSearchQuery(query);
      emitSearch(query, 0);
    },
    goToMatch: (index) => {
      setSearchIndex(index);
      emitSearch(searchQueryRef.current, index);
    },
    insertImage: (url, alt = "") => {
      const el = textareaRef.current;
      if (!el) return;
      const s = el.selectionStart;
      const next = `${draft.slice(0, s)}\n![${alt}](${url})\n${draft.slice(el.selectionEnd)}`;
      const clean = fromDisplay(next);
      setDraft(clean); onChange(clean);
      requestAnimationFrame(() => {
        const scrollTop = scrollRef.current?.scrollTop ?? 0;
        el.setSelectionRange(s + clean.slice(s).indexOf("\n", 1) + 1, s + clean.slice(s).indexOf("\n", 1) + 1);
        if (scrollRef.current) scrollRef.current.scrollTop = scrollTop;
      });
    },
    getMarkdown: () => draft,
    getScrollElement: () => scrollRef.current,
  }), [draft, emitSearch, fromDisplay, handleRef, onChange, searchQuery]);

  function updateDraft(next: string) {
    const clean = fromDisplay(next);
    setDraft(clean);
    onChange(clean);
    if (searchQueryRef.current) emitSearch(searchQueryRef.current, searchIndex);
  }

  function replaceSelection(replacement: string, cursorOffset = replacement.length) {
    const el = textareaRef.current;
    if (!el) return;
    const s = el.selectionStart, e = el.selectionEnd;
    updateDraft(`${draft.slice(0, s)}${replacement}${draft.slice(e)}`);
    requestAnimationFrame(() => { el.focus(); const p = s + cursorOffset; el.setSelectionRange(p, p); });
  }

  function wrap(before: string, after = before, placeholder = "text") {
    const el = textareaRef.current; if (!el) return;
    const s = el.selectionStart, e = el.selectionEnd;
    const selected = draft.slice(s, e) || placeholder;
    const replacement = `${before}${selected}${after}`;
    updateDraft(`${draft.slice(0, s)}${replacement}${draft.slice(e)}`);
    // Never leave the textarea selection highlighted after a toolbar action.
    // With no selection, put the caret between the opening and closing marks;
    // with selected text, put it after the complete formatted text.
    const cursor = s === e ? s + before.length : s + replacement.length;
    requestAnimationFrame(() => { el.focus(); el.setSelectionRange(cursor, cursor); });
  }

  function prefix(prefix: string) {
    const el = textareaRef.current; if (!el) return;
    const s = el.selectionStart, e = el.selectionEnd;
    const start = draft.lastIndexOf("\n", s - 1) + 1;
    // Prefixes are line syntax. If there is no selection, insert at the
    // current line and leave the caret immediately after the prefix.
    if (s === e) {
      const line = draft.slice(start, draft.indexOf("\n", s) === -1 ? draft.length : draft.indexOf("\n", s));
      const marker = /^(#{1,6}\s+|[-*+]\s+|\d+[.)]\s+|>\s+)/.exec(line)?.[0] ?? "";
      const nextPrefix = prefix === "" ? "" : prefix;
      const insert = marker && (prefix.startsWith("#") || /^\d/.test(prefix) || prefix === "> ") ? nextPrefix : prefix;
      const next = `${draft.slice(0, start)}${insert}${draft.slice(start)}`;
      updateDraft(next);
      requestAnimationFrame(() => { el.focus(); const p = s + insert.length; el.setSelectionRange(p, p); });
      return;
    }
    const segment = draft.slice(start, e);
    const patched = segment.split("\n").map((line) => line.startsWith(prefix) ? line : `${prefix}${line}`).join("\n");
    updateDraft(`${draft.slice(0, start)}${patched}${draft.slice(e)}`);
    requestAnimationFrame(() => { el.focus(); const p = start + patched.length; el.setSelectionRange(p, p); });
  }

  function paragraph() {
    const el = textareaRef.current; if (!el) return;
    const s = el.selectionStart, e = el.selectionEnd;
    const start = draft.lastIndexOf("\n", s - 1) + 1;
    const end = draft.indexOf("\n", Math.max(s, e));
    const lineEnd = end === -1 ? draft.length : end;
    const line = draft.slice(start, lineEnd);
    const cleaned = line.replace(/^(#{1,6}\s+|[-*+]\s+|\d+[.)]\s+|>\s+)/, "");
    updateDraft(`${draft.slice(0, start)}${cleaned}${draft.slice(lineEnd)}`);
    requestAnimationFrame(() => { el.focus(); const p = start + Math.min(Math.max(s - start, 0), cleaned.length); el.setSelectionRange(p, p); });
  }

  function handleEditorKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key !== "Enter" || e.shiftKey || e.altKey || e.ctrlKey || e.metaKey) return;
    const el = e.currentTarget;
    const s = el.selectionStart, end = el.selectionEnd;
    if (s !== end) return;
    const lineStart = draft.lastIndexOf("\n", s - 1) + 1;
    const line = draft.slice(lineStart, s);
    const bullet = /^(\s*)([-*+])\s+(.*)$/.exec(line);
    const numbered = /^(\s*)(\d+)([.)])\s+(.*)$/.exec(line);
    const task = /^(\s*)([-*+])\s+\[[ xX]\]\s*(.*)$/.exec(line);
    if (!bullet && !numbered) return;
    e.preventDefault();
    // Enter on an empty list item exits the list instead of creating noise.
    const isEmpty = task ? !task[3].trim() : bullet ? !bullet[3].trim() : !numbered![4].trim();
    const continuation = isEmpty
      ? ""
      : task
        ? `${task[1]}${task[2]} [ ] `
        : bullet
          ? `${bullet[1]}${bullet[2]} `
          : `${numbered![1]}${Number(numbered![2]) + 1}${numbered![3]} `;
    const next = `${draft.slice(0, s)}\n${isEmpty ? "" : continuation}${draft.slice(end)}`;
    updateDraft(next);
    requestAnimationFrame(() => { el.focus(); const p = s + 1 + continuation.length; el.setSelectionRange(p, p); });
  }

  function table() {
    const value = "| Column 1 | Column 2 | Column 3 |\n| --- | --- | --- |\n| Row 1 | Value | Value |\n| Row 2 | Value | Value |";
    const el = textareaRef.current;
    if (!el) return;
    const s = el.selectionStart, e = el.selectionEnd;
    const separator = s > 0 && draft[s - 1] !== "\n" ? "\n\n" : "";
    replaceSelection(`${separator}${value}\n`);
  }

  function action(actionName: string, replacement?: string, label?: string) {
    switch (actionName) {
      case "bold": return wrap("**", "**", "");
      case "italic": return wrap("*", "*", "");
      case "underline": return wrap("<u>", "</u>", "");
      case "strike": return wrap("~~", "~~", "");
      case "code": return wrap("`", "`", "");
      case "h1": return prefix("# ");
      case "h2": return prefix("## ");
      case "h3": return prefix("### ");
      case "paragraph": return paragraph();
      case "ul": return prefix("- ");
      case "ol": return prefix("1. ");
      case "todo": return prefix("- [ ] ");
      case "quote": return prefix("> ");
      case "codeblock": return wrap("```\n", "\n```", "");
      case "multi": {
        const el = textareaRef.current; if (!el) return;
        const s = el.selectionStart, e = el.selectionEnd;
        const selected = draft.slice(s, e);
        const formats = (replacement ?? "").split(",").filter(Boolean);
        let content = selected;
        let before = "";
        let after = "";
        for (const format of formats) {
          if (format === "bold") { before += "**"; after = "**" + after; }
          else if (format === "italic") { before += "*"; after = "*" + after; }
          else if (format === "underline") { before += "<u>"; after = "</u>" + after; }
          else if (format === "strike") { before += "~~"; after = "~~" + after; }
          else if (format === "code") { before += "`"; after = "`" + after; }
          else if (format === "h1") before = "# " + before;
          else if (format === "h2") before = "## " + before;
          else if (format === "h3") before = "### " + before;
        }
        const replacementText = `${before}${content}${after}`;
        updateDraft(`${draft.slice(0, s)}${replacementText}${draft.slice(e)}`);
        const cursor = s === e ? s + before.length : s + replacementText.length;
        requestAnimationFrame(() => { el.focus(); el.setSelectionRange(cursor, cursor); });
        return;
      }
      case "hr": return replaceSelection("\n\n---\n");
      case "table": return table();
      case "replace-selection": return replaceSelection(replacement ?? "");
      case "link": {
        const el = textareaRef.current; if (!el) return;
        const s = el.selectionStart, e = el.selectionEnd;
        const selected = label || draft.slice(s, e) || "";
        return replaceSelection(replacement ? `[${selected}](${replacement})` : selected);
      }
      case "remove-link": return updateDraft(draft.replace(/\[([^\]]+)\]\(([^)]+)\)/g, "$1"));
      case "clear": return updateDraft(draft.replace(/(\*\*|__|~~|`|<u>|<\/u>)/g, ""));
      case "undo": return document.execCommand("undo");
      case "redo": return document.execCommand("redo");
    }
  }

  const copyCode = React.useCallback(async (code: string) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopiedCode(code);
      window.setTimeout(() => setCopiedCode((current) => current === code ? null : current), 1400);
    } catch {
      /* Clipboard may be unavailable in restricted WebViews. */
    }
  }, []);
  const previewContent = React.useMemo(() => toDisplay(draft), [draft, toDisplay]);
  const highlightedPreviewContent = React.useMemo(() => {
    const query = searchQuery.trim();
    if (!preview || !query) return previewContent;
    const escaped = query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const escapeHtml = (text: string) => text.replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[char] ?? char);
    return previewContent.replace(new RegExp(escaped, "giu"), (match) => `<mark class="search-hit">${escapeHtml(match)}</mark>`);
  }, [preview, previewContent, searchQuery]);
  React.useEffect(() => {
    if (!preview || !searchQuery.trim()) return;
    const matches = Array.from(scrollRef.current?.querySelectorAll("mark.search-hit") ?? []);
    matches.forEach((match, index) => match.classList.toggle("search-hit-active", index === searchIndex));
    const match = matches[searchIndex];
    const container = scrollRef.current;
    if (match && container) {
      const r = match.getBoundingClientRect();
      const c = container.getBoundingClientRect();
      container.scrollTo({ top: Math.max(0, container.scrollTop + r.top - c.top - container.clientHeight * 0.35), behavior: "smooth" });
    }
  }, [preview, previewContent, searchIndex, searchQuery]);

  return (
    <div className="md-editor flex min-h-0 flex-1 flex-col">
      <div className="sticky top-0 z-20 shrink-0">
        <Toolbar editor={textareaRef.current} preview={preview} onTogglePreview={togglePreview} onPickImages={onRequestInsertImages} onAction={action} />
      </div>
      <div ref={scrollRef} className="min-h-0 flex-1 overflow-y-auto px-4 pb-8 pt-2">
        {beforeContent}
        {preview ? (
          <div className="md-preview md-prose min-h-[40vh]" aria-label="Rendered Markdown preview">
            <ReactMarkdown
              remarkPlugins={[remarkGfm]}
              rehypePlugins={[rehypeRaw]}
              components={{
                table: ({ children }) => <div className="md-table-wrap"><table>{children}</table></div>,
                pre: ({ children }) => {
                  const codeElement = React.Children.toArray(children).find((child) => React.isValidElement(child));
                  const text = codeElement && React.isValidElement(codeElement)
                    ? String(codeElement.props.children).replace(/\n$/, "")
                    : "";
                  return (
                    <div className="md-code-wrap">
                      <pre>{children}</pre>
                      <button type="button" className="md-code-copy" onClick={() => void copyCode(text)} aria-label="Copy code">
                        {copiedCode === text ? "Copied" : "Copy"}
                      </button>
                    </div>
                  );
                },
                code: ({ children, className, ...props }) => <code {...props} className={cn(className, "md-code-content")}>{children}</code>,
                input: ({ checked, ...props }) => (
                  <input
                    {...props}
                    type="checkbox"
                    checked={!!checked}
                    aria-label={checked ? "Completed task" : "Incomplete task"}
                    onChange={(event) => {
                      const inputs = Array.from(
                        event.currentTarget.closest(".md-preview")?.querySelectorAll('input[type="checkbox"]') ?? []
                      );
                      const index = inputs.indexOf(event.currentTarget);
                      if (index >= 0) updateDraft(toggleTaskLine(draft, index, event.currentTarget.checked));
                    }}
                  />
                ),
                img: ({ src, alt, ...props }) => {
                  const raw = typeof src === "string" ? src : "";
                  const resolved = raw.startsWith("attachment/")
                    ? fileToUrl(decodeAttachmentPath(raw)) || fileToUrl(raw)
                    : raw;
                  return resolved ? <img {...props} src={resolved} alt={alt ?? ""} /> : <span className="md-image-missing">{alt || "Image unavailable"}</span>;
                },
                a: ({ href, children, ...props }) => {
                  const rawHref = typeof href === "string" ? href : "";
                  const attachmentUrl = rawHref.startsWith("attachment/")
                    ? fileToUrl(decodeAttachmentPath(rawHref)) || fileToUrl(rawHref)
                    : rawHref.startsWith("blob:") || rawHref.startsWith("data:")
                      ? rawHref
                      : "";
                  if (attachmentUrl) {
                    const alt = React.Children.toArray(children).filter((child) => typeof child === "string").join(" ");
                    return <img {...props} src={attachmentUrl} alt={alt || "Attached image"} />;
                  }
                  const normalizedHref = /^(https?:\/\/|mailto:|tel:|sms:|geo:)/i.test(rawHref)
                    ? rawHref
                    : /^(www\.)|^[^\s/?#]+\.[^\s/?#]+$/i.test(rawHref)
                      ? `https://${rawHref}`
                      : rawHref;
                  return <a {...props} href={normalizedHref} target="_blank" rel="noopener noreferrer">{children}</a>;
                },
              }}
            >{highlightedPreviewContent || "*Nothing to preview yet.*"}</ReactMarkdown>
          </div>
        ) : (
          <textarea
            ref={textareaRef}
            value={draft}
            onChange={(e) => updateDraft(e.target.value)}
            onKeyDown={handleEditorKeyDown}
            onPaste={(e) => {
              const files = e.clipboardData.files;
              if (files.length > 0 && [...files].every((f) => f.type.startsWith("image/"))) {
                e.preventDefault();
                onPasteImages?.(Array.from(files));
              }
            }}
            placeholder={placeholder ?? "Start writing…"}
            spellCheck
            className="md-textarea min-h-[40vh] w-full resize-none bg-transparent text-[0.925rem] leading-[1.65] outline-none"
          />
        )}
      </div>
    </div>
  );
};

export function buildUrlToFileMap(attachments: { file: string; url: string }[]): Map<string, string> {
  const map = new Map<string, string>();
  for (const a of attachments) if (a.url) map.set(a.url, a.file);
  return map;
}
