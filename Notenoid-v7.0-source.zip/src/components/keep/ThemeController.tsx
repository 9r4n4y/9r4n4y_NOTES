"use client";

// ---------------------------------------------------------------------------
// ThemeController — applies the selected theme, font choices and text scales
// to <html> as CSS custom properties / classes. Lives at the app root so a
// settings change restyles the entire application in one pass.
//
//   • themeId "system" follows the OS light/dark (Android-aware via the
//     matchMedia shim from lib/android-theme.ts) and re-applies live when the
//     system theme changes.
//   • uiScale / markdownScale drive --ui-scale / --md-scale; globals.css maps
//     the root font-size and the note typography onto them.
//   • appFont / noteFont drive --app-font / --note-font.
// ---------------------------------------------------------------------------

import { useEffect } from "react";
import { useSettings } from "./settings-store";
import { getTheme, isKnownTheme } from "@/lib/themes";
import { getFont } from "@/lib/fonts";

export const THEME_CLASS_PREFIX = "theme-";

export function applyThemeToDocument(themeId: string): void {
  const root = document.documentElement;
  const resolved = (() => {
    if (themeId !== "system") return getTheme(themeId) ?? getTheme("classic-light")!;
    let dark = false;
    try {
      dark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    } catch {
      dark = false;
    }
    return dark ? getTheme("classic-dark")! : getTheme("classic-light")!;
  })();

  // theme class (used by globals.css for the special-surface decorations and
  // as a stable selector); classic-light is the default → no class needed
  for (const cls of Array.from(root.classList)) {
    if (cls.startsWith(THEME_CLASS_PREFIX)) root.classList.remove(cls);
  }
  if (resolved.id !== "classic-light") root.classList.add(`${THEME_CLASS_PREFIX}${resolved.id}`);

  // mode class for tailwind `dark:` utilities
  root.classList.toggle("dark", resolved.mode === "dark");

  // native widgets (scrollbars, form controls, keyboard) follow the theme
  root.style.colorScheme = resolved.mode;

  // full variable set — inline so nothing can partially fall back
  for (const [key, value] of Object.entries(resolved.vars)) {
    root.style.setProperty(`--${key}`, value);
  }

  // keep the browser chrome (mobile address bar / PWA) on the theme colour
  try {
    const meta =
      document.querySelector<HTMLMetaElement>('meta[name="theme-color"]:not([media])') ??
      (() => {
        const el = document.createElement("meta");
        el.name = "theme-color";
        document.head.appendChild(el);
        return el;
      })();
    meta.content = resolved.vars.background ?? "#f1f3f4";
  } catch {
    /* ignore */
  }
  return;
}

export function ThemeController() {
  const settings = useSettings();

  useEffect(() => {
    const themeId = isKnownTheme(settings.themeId) ? settings.themeId : "system";
    applyThemeToDocument(themeId);

    // live follow for "system"
    if (themeId !== "system") return;
    let mql: MediaQueryList | null = null;
    const onChange = () => applyThemeToDocument("system");
    try {
      mql = window.matchMedia("(prefers-color-scheme: dark)");
      mql.addEventListener("change", onChange);
    } catch {
      /* old WebViews — startup value only */
    }
    return () => mql?.removeEventListener("change", onChange);
  }, [settings.themeId]);

  // app-wide UI scale → root font-size (every rem-based size scales together)
  useEffect(() => {
    const pct = Math.max(70, Math.min(150, Math.round(settings.uiScale || 100)));
    document.documentElement.style.fontSize = `${(16 * pct) / 100}px`;
  }, [settings.uiScale]);

  // markdown scale → note typography
  useEffect(() => {
    const pct = Math.max(70, Math.min(170, Math.round(settings.markdownScale || 100)));
    document.documentElement.style.setProperty("--md-scale", String(pct / 100));
  }, [settings.markdownScale]);

  // fonts
  useEffect(() => {
    document.documentElement.style.setProperty("--app-font", getFont(settings.appFont).stack);
    document.documentElement.style.setProperty("--note-font", getFont(settings.noteFont).stack);
  }, [settings.appFont, settings.noteFont]);

  return null;
}
