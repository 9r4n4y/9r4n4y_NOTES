#!/usr/bin/env python3
"""Generate centered Android launcher icons from the supplied Notes artwork.

V4 fix (icon exceeding its boundary): the adaptive-icon foreground used to be
scaled to 0.68 of the 108dp canvas, i.e. ~73dp of artwork — wider than the 72dp
masked viewport and the 66dp safe-zone circle, so the white card's corners were
clipped by the launcher mask. The foreground is now scaled to 0.56 (~60dp,
safely inside the 66dp safe zone), the background layer is white so the artwork
card blends seamlessly under any mask shape, and foregrounds are generated for
ALL densities (mdpi/hdpi/xhdpi were missing before).
"""
from PIL import Image, ImageDraw
from pathlib import Path
import os

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "android" / "res"
DEFAULT_SOURCE = ROOT / "icon-source" / "1789483250921.png"
SOURCE = Path(os.environ.get("NOTES_ICON_SOURCE", str(DEFAULT_SOURCE)))
if not SOURCE.exists():
    SOURCE = Path("/home/ubuntu/upload/1789483250921.png")

DENSITIES = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}

# Adaptive-icon canvas sizes per density (108dp bucket)
ADAPTIVE_DENSITIES = {"mdpi": 108, "hdpi": 162, "xhdpi": 216, "xxhdpi": 324, "xxxhdpi": 432}
# 108dp canvas, 72dp visible, 66dp safe zone → artwork ≤ 0.61 of canvas.
# 0.56 leaves a comfortable margin on every mask shape.
FOREGROUND_SCALE = 0.56


def source_image(size: int, scale: float, mask: str | None = None) -> Image.Image:
    src = Image.open(SOURCE).convert("RGBA")
    src.thumbnail((int(size * scale), int(size * scale)), Image.Resampling.LANCZOS)
    canvas = Image.new("RGBA", (size, size), (255, 255, 255, 255))
    canvas.alpha_composite(src, ((size - src.width) // 2, (size - src.height) // 2))
    if mask:
        alpha = Image.new("L", (size, size), 0)
        d = ImageDraw.Draw(alpha)
        if mask == "circle":
            d.ellipse((0, 0, size - 1, size - 1), fill=255)
        else:
            d.rounded_rectangle((0, 0, size - 1, size - 1), radius=max(2, size // 5), fill=255)
        canvas.putalpha(alpha)
    return canvas


def adaptive_foreground(size: int) -> Image.Image:
    """Artwork inside the 66dp safe zone on a transparent 108dp canvas."""
    src = Image.open(SOURCE).convert("RGBA")
    src.thumbnail((int(size * FOREGROUND_SCALE), int(size * FOREGROUND_SCALE)), Image.Resampling.LANCZOS)
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    canvas.alpha_composite(src, ((size - src.width) // 2, (size - src.height) // 2))
    return canvas


for density, px in DENSITIES.items():
    for suffix, mask in (("", "rounded"), ("_round", "circle")):
        path = RES / f"mipmap-{density}" / f"ic_launcher{suffix}.png"
        path.parent.mkdir(parents=True, exist_ok=True)
        source_image(px, 0.86, mask).save(path, "PNG", optimize=True)

for density, px in ADAPTIVE_DENSITIES.items():
    path = RES / f"mipmap-{density}" / "ic_launcher_foreground.png"
    path.parent.mkdir(parents=True, exist_ok=True)
    adaptive_foreground(px).save(path, "PNG", optimize=True)

print(f"Generated APK icons from {SOURCE}")
print(f"Adaptive foreground scale: {FOREGROUND_SCALE} (safe zone = 0.61 of canvas)")
