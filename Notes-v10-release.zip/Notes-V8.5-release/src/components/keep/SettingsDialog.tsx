"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { useKeepStore } from "./store";
import {
  DEFAULT_SETTINGS,
  resetSettings,
  updateSettings,
  useSettings,
  type Density,
  type FontSize,
} from "./settings-store";
import { setVaultCode, vaultCodeExists } from "@/lib/vault";
import { ExportDialog } from "./ExportDialog";
import { getRepo } from "./store";
import { useBackLayer } from "@/lib/back-nav";
import {
  Brush,
  Download,
  FolderCog,
  HardDrive,
  Image as ImageIcon,
  Info,
  KeyRound,
  Loader2,
  Lock,
  RefreshCcw,
  RotateCcw,
  Search,
  Sparkles,
  X,
} from "lucide-react";
import { useRef, useState } from "react";
import { toast } from "sonner";

type Tab = "general" | "appearance" | "search" | "vault" | "about";

const TABS: { key: Tab; label: string }[] = [
  { key: "general", label: "General" },
  { key: "appearance", label: "Appearance" },
  { key: "search", label: "Search & Notes" },
  { key: "vault", label: "Vault" },
  { key: "about", label: "About app" },
];

async function fileToCompressedDataUrl(file: File, maxSize = 1600): Promise<string> {
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = reject;
      el.src = dataUrl;
    });
    const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
    const w = Math.max(1, Math.round(img.width * scale));
    const h = Math.max(1, Math.round(img.height * scale));
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) return dataUrl;
    ctx.drawImage(img, 0, 0, w, h);
    return canvas.toDataURL("image/jpeg", 0.82);
  } catch {
    return dataUrl;
  }
}

export function SettingsDialog() {
  const open = useKeepStore((s) => s.settingsOpen);
  const setSettingsOpen = useKeepStore((s) => s.setSettingsOpen);
  const vaultOpen = useKeepStore((s) => s.vaultOpen);
  // V8 (bug #3): BACK closes settings
  useBackLayer(open, () => setSettingsOpen(false));
  // Keyed remount: fresh state (name draft, active tab, code existence) on
  // every open — no setState-in-effect needed.
  if (!open) return null;
  return <SettingsBody key={vaultOpen ? "vault-open" : "vault-closed"} />;
}

function SettingsBody() {
  const setOpen = useKeepStore((s) => s.setSettingsOpen);
  const vaultOpen = useKeepStore((s) => s.vaultOpen);
  const closeVault = useKeepStore((s) => s.closeVault);
  const settings = useSettings();

  const [tab, setTab] = useState<Tab>("general");
  const [nameDraft, setNameDraft] = useState(settings.appName);
  const [exportOpen, setExportOpen] = useState(false);
  const [secretOpen, setSecretOpen] = useState(false);
  const [codeDraft, setCodeDraft] = useState("");
  const [codeBusy, setCodeBusy] = useState(false);
  const [hasCode, setHasCode] = useState(() => vaultCodeExists());
  const fileRef = useRef<HTMLInputElement>(null);

  async function pickWallpaper(file: File) {
    if (!file.type.startsWith("image/")) {
      toast.error("Choose an image file");
      return;
    }
    try {
      const dataUrl = await fileToCompressedDataUrl(file);
      updateSettings({ wallpaper: dataUrl });
      toast.success("Wallpaper applied");
    } catch {
      toast.error("Could not load that image");
    }
  }

  async function saveCode() {
    const code = codeDraft.trim();
    if (code.length < 3) {
      toast.error("Code must be at least 3 characters");
      return;
    }
    setCodeBusy(true);
    await setVaultCode(code);
    setCodeBusy(false);
    setCodeDraft("");
    setHasCode(true);
    toast.success("Vault code saved", { description: "open_vault will now ask for it" });
  }

  return (
    <>
      <Dialog open onOpenChange={setOpen}>
        <DialogContent className="flex h-[85vh] max-w-2xl flex-col overflow-hidden p-0 sm:h-[600px]">
          <DialogHeader className="px-5 pt-5">
            <DialogTitle>Settings</DialogTitle>
            <DialogDescription>Make the app truly yours.</DialogDescription>
          </DialogHeader>

          <div className="flex min-h-0 flex-1 flex-col sm:flex-row">
            {/* tab rail */}
            <div className="flex shrink-0 gap-1 overflow-x-auto border-b px-3 py-2 sm:w-44 sm:flex-col sm:border-b-0 sm:border-r sm:py-3">
              {TABS.filter((t) => t.key !== "vault" || vaultOpen).map((t) => (
                <button
                  key={t.key}
                  type="button"
                  onClick={() => setTab(t.key)}
                  className={`flex items-center gap-2 whitespace-nowrap rounded-lg px-3 py-2 text-sm transition-colors ${
                    tab === t.key
                      ? "bg-accent font-medium text-foreground"
                      : "text-muted-foreground hover:bg-accent/60 hover:text-foreground"
                  }`}
                >
                  {t.key === "general" ? <Sparkles className="h-4 w-4" /> : null}
                  {t.key === "appearance" ? <Brush className="h-4 w-4" /> : null}
                  {t.key === "search" ? <Search className="h-4 w-4" /> : null}
                  {t.key === "vault" ? <KeyRound className="h-4 w-4" /> : null}
                  {t.key === "about" ? <Info className="h-4 w-4" /> : null}
                  {t.label}
                  {t.key === "vault" ? (
                    <span className="ml-auto hidden text-[10px] text-emerald-600 sm:inline dark:text-emerald-400">
                      open
                    </span>
                  ) : null}
                </button>
              ))}
            </div>

            {/* tab body */}
            <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">
              {tab === "general" ? (
                <div className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="app-name">App name</Label>
                    <div className="flex gap-2">
                      <Input
                        id="app-name"
                        value={nameDraft}
                        maxLength={24}
                        onChange={(e) => setNameDraft(e.target.value)}
                        placeholder="Notes"
                      />
                      <Button
                        variant="secondary"
                        onClick={() => {
                          const name = nameDraft.trim() || "Notes";
                          updateSettings({ appName: name });
                          setNameDraft(name);
                          toast.success(`App renamed to “${name}”`);
                        }}
                      >
                        Save
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Renames the app everywhere — header, tab title and exports.
                    </p>
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Confirm before deleting</p>
                      <p className="text-xs text-muted-foreground">
                        Ask before moving notes to trash (undo toast is always available)
                      </p>
                    </div>
                    <Switch
                      checked={settings.confirmBeforeDelete}
                      onCheckedChange={(v) => updateSettings({ confirmBeforeDelete: v })}
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Export data</p>
                      <p className="text-xs text-muted-foreground">
                        Download notes as a ZIP (folder or everything, images optional)
                      </p>
                    </div>
                    <Button variant="outline" size="sm" onClick={() => setExportOpen(true)}>
                      <Download className="mr-2 h-4 w-4" /> Export
                    </Button>
                  </div>

                  <Separator />

                  {/* ---- local storage ---- */}
                  <StorageSection />

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-destructive">Reset appearance settings</p>
                      <p className="text-xs text-muted-foreground">
                        Restore name, wallpaper and all toggles to defaults
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        resetSettings();
                        setNameDraft(DEFAULT_SETTINGS.appName);
                        toast.success("Settings reset");
                      }}
                    >
                      <RotateCcw className="mr-2 h-4 w-4" /> Reset
                    </Button>
                  </div>
                </div>
              ) : null}

              {tab === "appearance" ? (
                <div className="space-y-6">
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Custom wallpaper</p>
                    {settings.wallpaper ? (
                      <div className="relative overflow-hidden rounded-lg border">
                        { }
                        <img src={settings.wallpaper} alt="Wallpaper preview" className="h-28 w-full object-cover" />
                        <button
                          type="button"
                          aria-label="Remove wallpaper"
                          className="absolute right-2 top-2 flex h-7 w-7 items-center justify-center rounded-full bg-black/60 text-white hover:bg-black/80"
                          onClick={() => {
                            updateSettings({ wallpaper: null });
                            toast.success("Wallpaper removed");
                          }}
                        >
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => fileRef.current?.click()}
                        className="flex h-24 w-full flex-col items-center justify-center gap-1 rounded-lg border border-dashed text-sm text-muted-foreground transition-colors hover:bg-accent/50"
                      >
                        <ImageIcon className="h-5 w-5" />
                        Upload an image
                      </button>
                    )}
                    <input
                      ref={fileRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        if (f) void pickWallpaper(f);
                        e.target.value = "";
                      }}
                    />
                    {settings.wallpaper ? (
                      <Button variant="outline" size="sm" onClick={() => fileRef.current?.click()}>
                        Replace image
                      </Button>
                    ) : null}
                  </div>

                  {settings.wallpaper ? (
                    <>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Label>Background blur</Label>
                          <span className="text-xs text-muted-foreground">{settings.wallpaperBlur}px</span>
                        </div>
                        <Slider
                          min={0}
                          max={40}
                          step={1}
                          value={[settings.wallpaperBlur]}
                          onValueChange={([v]) => updateSettings({ wallpaperBlur: v })}
                        />
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Label>Background dim</Label>
                          <span className="text-xs text-muted-foreground">{settings.wallpaperDim}%</span>
                        </div>
                        <Slider
                          min={0}
                          max={80}
                          step={5}
                          value={[settings.wallpaperDim]}
                          onValueChange={([v]) => updateSettings({ wallpaperDim: v })}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium">Fixed wallpaper</p>
                          <p className="text-xs text-muted-foreground">Keep it still while scrolling</p>
                        </div>
                        <Switch
                          checked={settings.wallpaperFixed}
                          onCheckedChange={(v) => updateSettings({ wallpaperFixed: v })}
                        />
                      </div>
                    </>
                  ) : null}

                  <Separator />

                  <div className="space-y-2">
                    <Label>Note spacing</Label>
                    <Select value={settings.density} onValueChange={(v) => updateSettings({ density: v as Density })}>
                      <SelectTrigger className="w-full">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="compact">Compact — snug grid</SelectItem>
                        <SelectItem value="cozy">Cozy — balanced (default)</SelectItem>
                        <SelectItem value="spacious">Spacious — airy layout</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Note text size</Label>
                    <Select value={settings.fontSize} onValueChange={(v) => updateSettings({ fontSize: v as FontSize })}>
                      <SelectTrigger className="w-full">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sm">Small</SelectItem>
                        <SelectItem value="md">Medium (default)</SelectItem>
                        <SelectItem value="lg">Large</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Animations</p>
                      <p className="text-xs text-muted-foreground">
                        Card entrances, hover lifts and micro-motion
                      </p>
                    </div>
                    <Switch
                      checked={settings.animations}
                      onCheckedChange={(v) => updateSettings({ animations: v })}
                    />
                  </div>
                </div>
              ) : null}

              {tab === "search" ? (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Include Archive in search</p>
                      <p className="text-xs text-muted-foreground">
                        Searching from the main view also surfaces archived notes. The Archive
                        page always searches its own notes regardless.
                      </p>
                    </div>
                    <Switch
                      checked={settings.searchIncludeArchive}
                      onCheckedChange={(v) => updateSettings({ searchIncludeArchive: v })}
                    />
                  </div>

                  <Separator />

                  <div className="rounded-lg border bg-accent/30 px-3 py-3 text-xs leading-relaxed text-muted-foreground">
                    <p className="mb-1 font-medium text-foreground">Search covers</p>
                    Titles, note bodies, checklist items, labels, folder names and image file
                    names — in every view (Notes, Folders, Archive, Trash and Vault). The editor
                    also has its own find-in-note search with highlights.
                  </div>
                </div>
              ) : null}

              {tab === "vault" && vaultOpen ? (
                <div className="space-y-6">
                  <div className="flex items-center gap-2 rounded-lg border border-emerald-500/30 bg-emerald-500/5 px-3 py-2.5 text-sm">
                    <Lock className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                    Vault is unlocked in this session. It auto-locks when the app is closed.
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="vault-code">{hasCode ? "Change vault code" : "Set a vault code"}</Label>
                    <div className="flex gap-2">
                      <Input
                        id="vault-code"
                        type="password"
                        value={codeDraft}
                        onChange={(e) => setCodeDraft(e.target.value)}
                        placeholder="New secret code"
                        onKeyDown={(e) => {
                          if (e.key === "Enter") void saveCode();
                        }}
                      />
                      <Button variant="secondary" onClick={() => void saveCode()} disabled={codeBusy}>
                        {codeBusy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                        Save
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {hasCode
                        ? "A code is set — typing open_vault will now require it. Saved permanently on this device."
                        : "No code yet: open_vault opens directly. Set one to require a code from now on."}
                    </p>
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Lock vault now</p>
                      <p className="text-xs text-muted-foreground">
                        Hides the Vault section and all secret notes immediately
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        closeVault();
                        toast.success("Vault locked");
                      }}
                    >
                      <Lock className="mr-2 h-4 w-4" /> Lock
                    </Button>
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Export vault</p>
                      <p className="text-xs text-muted-foreground">
                        Vault notes can only be exported while the vault is open
                      </p>
                    </div>
                    <Button variant="outline" size="sm" onClick={() => setExportOpen(true)}>
                      <Download className="mr-2 h-4 w-4" /> Export
                    </Button>
                  </div>
                </div>
              ) : null}

              {tab === "about" ? (
                <div className="space-y-4 text-sm">
                  <div>
                    <p className="font-medium">{settings.appName}</p>
                    <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                      A fast, private notepad inspired by Google Keep. Everything below works
                      offline-first and saves automatically.
                    </p>
                  </div>

                  <Separator />

                  <ul className="space-y-2 text-xs leading-relaxed">
                    <li><b>Notes & lists</b> — tap “Take a note”. Switch type with the checklist icon. Unlimited length.</li>
                    <li><b>Full-screen editor</b> — notes open in a dedicated full-screen view with a back arrow; typing stays anchored even when the keyboard opens.</li>
                    <li><b>Organise</b> — pin, 11 colours, labels (sidebar), folders (genres) with preview cards, archive, trash with undo.</li>
                    <li><b>Reorder</b> — long-press a note and drag it anywhere in the list; the arrangement is remembered.</li>
                    <li><b>Find in note</b> — the magnifier inside the editor highlights every match; jump between them with ↑ / ↓.</li>
                    <li><b>Media</b> — add images & GIFs from the toolbar; click any image to view, edit (crop, draw, text, remove) or download.</li>
                    <li><b>Search</b> — the top bar searches everywhere: titles, bodies, checklists, labels, folders, file names.</li>
                    <li><b>Layout</b> — grid/list toggle; dark/light in the moon/sun menu.</li>
                    <li><b>Personalise</b> — rename the app, set a wallpaper, blur/dim it, change spacing, text size, animations — all in Settings.</li>
                    <li><b>Backup</b> — Settings → Export downloads a ZIP (markdown + JSON + images).</li>
                    <li><b>Vault</b> — a hidden chamber; see “Know the secret” below.</li>
                  </ul>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <p className="text-xs text-muted-foreground">Made to feel instant on phone and desktop.</p>
                    <Button size="sm" variant="secondary" onClick={() => setSecretOpen(true)}>
                      <Sparkles className="mr-2 h-4 w-4" /> Know the secret
                    </Button>
                  </div>
                </div>
              ) : null}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <ExportDialog open={exportOpen} onOpenChange={setExportOpen} />

      {/* Know-the-secret dialog */}
      <Dialog open={secretOpen} onOpenChange={setSecretOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5" /> The secret chamber
            </DialogTitle>
            <DialogDescription>
              There is a hidden vault inside the app. Here is how it works:
            </DialogDescription>
          </DialogHeader>
          <ol className="list-decimal space-y-2 pl-5 text-sm leading-relaxed">
            <li>
              Type <code className="rounded bg-accent px-1.5 py-0.5 font-mono text-xs">open_vault</code> into
              the search bar (exactly like that) and press nothing — it opens instantly.
            </li>
            <li>A <b>Vault</b> section appears in the sidebar, like Archive.</li>
            <li>
              Move notes in via any note’s <b>⋮ menu → Move to vault</b>. They vanish from every
              other view and search.
            </li>
            <li>
              Type <code className="rounded bg-accent px-1.5 py-0.5 font-mono text-xs">close_vault</code> in
              the search bar to lock it again — or just close the app, it auto-locks.
            </li>
            <li>
              While open: Settings gains a <b>Vault tab</b> — set/change a secret code (saved
              permanently). After that, <code className="rounded bg-accent px-1.5 py-0.5 font-mono text-xs">open_vault</code> asks
              for the code first.
            </li>
            <li>
              While open: Export gains the option to include vault notes in your ZIP backup.
            </li>
          </ol>
          <div className="flex justify-end">
            <Button onClick={() => setSecretOpen(false)}>Got it</Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

/* ------------------------------------------------------------------ */
/* Storage section — shows where notes live + change/rescan actions    */
/* ------------------------------------------------------------------ */

function StorageSection() {
  const storageKind = useKeepStore((s) => s.storageKind);
  const rootLabel = useKeepStore((s) => s.rootLabel);
  const changeFolder = useKeepStore((s) => s.changeFolder);
  const rescan = useKeepStore((s) => s.rescan);
  const [busy, setBusy] = useState(false);

  const kindLabel =
    storageKind === "android"
      ? "Phone storage (real files)"
      : storageKind === "web"
        ? "Local folder (real files)"
        : "In-app local storage";

  return (
    <div className="flex items-center justify-between gap-3">
      <div className="min-w-0">
        <p className="flex items-center gap-1.5 text-sm font-medium">
          <HardDrive className="h-3.5 w-3.5" /> Storage
        </p>
        <p className="truncate text-xs text-muted-foreground" title={rootLabel}>
          {kindLabel}
          {rootLabel ? ` — ${rootLabel}` : ""}
        </p>
        <p className="mt-0.5 text-[11px] leading-snug text-muted-foreground">
          Each note = a folder with node.md + attachment/
        </p>
      </div>
      <div className="flex shrink-0 flex-col gap-1.5">
        <Button
          variant="outline"
          size="sm"
          className="gap-1.5"
          disabled={busy}
          onClick={() => {
            setBusy(true);
            void changeFolder().finally(() => setBusy(false));
          }}
        >
          <FolderCog className="h-3.5 w-3.5" /> Change
        </Button>
        <Button
          variant="outline"
          size="sm"
          className="gap-1.5"
          disabled={busy}
          onClick={() => {
            setBusy(true);
            void rescan().finally(() => {
              setBusy(false);
              toast.success("Notes folder rescanned");
            });
          }}
        >
          {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCcw className="h-3.5 w-3.5" />}
          Rescan
        </Button>
      </div>
    </div>
  );
}
