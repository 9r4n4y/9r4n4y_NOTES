"use client";

import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { useKeepStore } from "./store";
import type { AttachmentDTO } from "@/lib/types";
import { Download, PenLine } from "lucide-react";
import { toast } from "sonner";
import { saveBlob } from "@/lib/save-blob";
import { useBackLayer } from "@/lib/back-nav";

export function Lightbox({
  attachment,
  onClose,
}: {
  attachment: AttachmentDTO | null;
  onClose: () => void;
}) {
  // V8 (bug #3): BACK closes the lightbox first
  useBackLayer(!!attachment, onClose);
  return (
    <Dialog open={!!attachment} onOpenChange={(o) => !o && onClose()}>
      <DialogContent
        className="max-w-3xl border-none bg-transparent p-0 shadow-none [&>button]:rounded-full [&>button]:bg-primary/80 [&>button]:p-1"
        onClick={(e) => e.stopPropagation()}
      >
        <DialogTitle className="sr-only">Media preview</DialogTitle>
        {attachment ? (
          <div className="flex flex-col items-center gap-3">
            <img
              src={attachment.url}
              alt={attachment.name}
              className="mx-auto max-h-[78vh] w-auto max-w-full rounded-lg object-contain"
            />
            <LightboxToolbar att={attachment} />
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}

function LightboxToolbar({ att }: { att: AttachmentDTO }) {
  const notes = useKeepStore((s) => s.notes);
  const openImageEditor = useKeepStore((s) => s.openImageEditor);

  function edit() {
    const noteId = notes.find((n) => n.attachments.some((a) => a.id === att.id))?.id;
    if (noteId) {
      openImageEditor(noteId, att);
    } else {
      toast.error("Could not find the note this image belongs to");
    }
  }

  return (
    <div className="flex items-center gap-2 pb-1">
      <button
        type="button"
        onClick={edit}
        className="inline-flex items-center gap-1.5 rounded-full bg-neutral-900/85 px-3.5 py-1.5 text-xs font-medium text-white shadow transition-colors hover:bg-neutral-900"
      >
        <PenLine className="h-3.5 w-3.5" /> Edit image
      </button>
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          try {
            fetch(att.url)
              .then((r) => r.blob())
              .then((b) => saveBlob(att.name || "image", b))
              .catch(() => toast.error("Download failed"));
          } catch {
            toast.error("Download failed");
          }
        }}
        className="inline-flex items-center gap-1.5 rounded-full bg-neutral-900/85 px-3.5 py-1.5 text-xs font-medium text-white shadow transition-colors hover:bg-neutral-900"
      >
        <Download className="h-3.5 w-3.5" /> Download
      </button>
      {att.kind === "gif" ? (
        <span className="rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-medium text-white backdrop-blur-sm">
          GIF
        </span>
      ) : null}
    </div>
  );
}
