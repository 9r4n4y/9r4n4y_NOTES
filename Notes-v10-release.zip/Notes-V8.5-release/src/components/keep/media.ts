"use client";

import type { AttachmentDTO } from "@/core/types";

const MAX_GIF_BYTES = 8 * 1024 * 1024;

/**
 * Downscale non-GIF images client-side so attachments stay light.
 * GIFs are passed through untouched to preserve animation.
 */
export async function compressImage(file: File | Blob, name = "image"): Promise<Blob> {
  if (file.type === "image/gif") {
    if (file.size > MAX_GIF_BYTES) {
      throw new Error(`"${name}" is too large — GIFs must be under 8MB`);
    }
    return file;
  }
  try {
    const bitmap = await createImageBitmap(file);
    const MAX = 1600;
    let { width, height } = bitmap;
    if (width <= MAX && height <= MAX) {
      bitmap.close();
      return file;
    }
    if (width > MAX || height > MAX) {
      const ratio = Math.min(MAX / width, MAX / height);
      width = Math.max(1, Math.round(width * ratio));
      height = Math.max(1, Math.round(height * ratio));
    }
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (!ctx) return file;
    ctx.drawImage(bitmap, 0, 0, width, height);
    const mime = file.type === "image/png" ? "image/png" : "image/jpeg";
    const blob = await new Promise<Blob | null>((resolve) =>
      canvas.toBlob(resolve, mime, 0.82)
    );
    bitmap.close();
    return blob ?? file;
  } catch {
    return file;
  }
}

export interface PendingMediaBlob {
  blob: Blob;
  name: string;
}

/** Compress (if needed) a list of files into locally-storable blobs. */
export async function prepareMedia(files: File[]): Promise<PendingMediaBlob[]> {
  return Promise.all(
    files.map(async (file) => ({
      blob: await compressImage(file, file.name),
      name: file.name || "image",
    }))
  );
}

/**
 * Fetch a remote image into a blob (stored locally afterwards).
 * CORS applies in browsers — failures surface a friendly error.
 */
export async function fetchMediaFromUrl(url: string): Promise<PendingMediaBlob> {
  const res = await fetch(url, { mode: "cors" });
  if (!res.ok) throw new Error(`Could not fetch that URL (${res.status})`);
  const blob = await res.blob();
  if (!blob.type.startsWith("image/")) {
    throw new Error("That URL does not point to an image");
  }
  let name = "image";
  try {
    const raw = url.split("/").pop()?.split("?")[0] ?? "";
    if (raw) name = decodeURIComponent(raw);
  } catch {
    /* keep default */
  }
  if (!/\.[a-z0-9]{2,5}$/i.test(name)) {
    const ext = blob.type === "image/gif" ? ".gif" : blob.type === "image/png" ? ".png" : ".jpg";
    name = `${name}${ext}`;
  }
  return { blob, name };
}

/** Compatibility helpers kept for older call sites. */
export async function prepareAndUpload(
  files: File[],
  onEach?: (m: PendingMediaBlob, total: number) => void
): Promise<PendingMediaBlob[]> {
  const out: PendingMediaBlob[] = [];
  for (const file of files) {
    const blob = await compressImage(file, file.name);
    const m: PendingMediaBlob = { blob, name: file.name || "image" };
    out.push(m);
    onEach?.(m, files.length);
  }
  return out;
}

export type { AttachmentDTO };
