"use client";

import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Check, Plus } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useKeepStore } from "./store";
import type { LabelDTO } from "@/lib/types";

export function LabelsPopover({
  note,
  onDone,
  children,
}: {
  note: { id: string; labels: LabelDTO[] };
  onDone?: () => void;
  children: React.ReactNode;
}) {
  const labels = useKeepStore((s) => s.labels);
  const toggleLabel = useKeepStore((s) => s.toggleLabel);
  const createLabel = useKeepStore((s) => s.createLabel);
  const [open, setOpen] = useState(false);
  const [newName, setNewName] = useState("");

  async function handleCreate() {
    const name = newName.trim();
    if (!name) return;
    const res = await createLabel(name);
    if (!res.ok) {
      toast.error(res.error ?? "Could not create label");
      return;
    }
    setNewName("");
    toast.success(`Label "${name}" created`);
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          type="button"
          aria-label="Edit labels"
          onClick={(e) => e.stopPropagation()}
          className="inline-flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-black/10 dark:hover:bg-white/10"
        >
          {children}
        </button>
      </PopoverTrigger>
      <PopoverContent align="start" side="top" className="w-64 p-2" onClick={(e) => e.stopPropagation()}>
        <p className="px-2 pb-1 pt-1 text-xs font-medium text-muted-foreground">Label note</p>
        <div className="max-h-56 overflow-y-auto">
          {labels.length === 0 ? (
            <p className="px-2 py-3 text-xs text-muted-foreground">
              No labels yet — create your first one below.
            </p>
          ) : (
            labels.map((l) => {
              const checked = note.labels.some((nl) => nl.id === l.id);
              return (
                <button
                  key={l.id}
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleLabel(note.id, l);
                  }}
                  className="flex w-full items-center gap-3 rounded-md px-2 py-2 text-sm hover:bg-accent"
                >
                  <span
                    className={`flex h-4 w-4 items-center justify-center rounded-sm border ${
                      checked
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-muted-foreground/50"
                    }`}
                  >
                    {checked ? <Check className="h-3 w-3" /> : null}
                  </span>
                  {l.name}
                </button>
              );
            })
          )}
        </div>
        <div className="mt-2 flex items-center gap-2 border-t pt-2">
          <Input
            placeholder="New label…"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.stopPropagation();
                handleCreate();
              }
            }}
            className="h-8 text-xs"
            onClick={(e) => e.stopPropagation()}
          />
          <Button size="icon" variant="ghost" className="h-8 w-8" onClick={handleCreate} aria-label="Create label">
            <Plus className="h-4 w-4" />
          </Button>
        </div>
        {onDone ? (
          <Button
            size="sm"
            variant="ghost"
            className="mt-1 w-full text-xs"
            onClick={(e) => {
              e.stopPropagation();
              onDone();
              setOpen(false);
            }}
          >
            Done
          </Button>
        ) : null}
      </PopoverContent>
    </Popover>
  );
}
