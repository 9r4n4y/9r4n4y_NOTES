"use client";

import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useKeepStore, getRepo } from "./store";
import { useSettings } from "./settings-store";
import type { NoteDTO } from "@/lib/types";
import { NOTE_FILE, ATTACHMENT_DIR } from "@/core/markdown";
import { joinPath } from "@/core/fs/adapter";
import { Download, FileArchive, Loader2, Lock } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import JSZip from "jszip";
import { saveBlob } from "@/lib/save-blob";
import { useBackLayer } from "@/lib/back-nav";

function sanitize(name: string, fallback: string): string {
  const clean = name.replace(/[\\/:*?"<>|\n\r]+/g, " ").trim().slice(0, 80);
  return clean || fallback;
}

export function ExportDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  // V8 (bug #3): BACK closes the export dialog
  useBackLayer(open, () => onOpenChange(false));
  const notes = useKeepStore((s) => s.notes);
  const folders = useKeepStore((s) => s.folders);
  const vaultOpen = useKeepStore((s) => s.vaultOpen);
  const settings = useSettings();

  const [scope, setScope] = useState<string>("all");
  const [includeImages, setIncludeImages] = useState(true);
  const [includeVault, setIncludeVault] = useState(false);
  const [busy, setBusy] = useState(false);

  // notes included given the current options
  const selected = useMemo(() => {
    let list = notes.filter((n) => !n.trashed && !n.vaulted);
    if (scope !== "all") {
      list = list.filter((n) => n.folderId === scope);
    }
    return list;
  }, [notes, scope]);

  const vaultCount = notes.filter((n) => n.vaulted && !n.trashed).length;

  const mediaCount = selected.reduce((acc, n) => acc + n.attachments.length, 0);

  async function buildZip() {
    setBusy(true);
    try {
      const zip = new JSZip();
      const repo = getRepo();
      const usedNames = new Map<string, number>();

      // optional vault subset for the vault-only export path
      const vaultSubset = vaultOpen && includeVault ? notes.filter((n) => n.vaulted && !n.trashed) : [];

      async function addNoteToZip(note: NoteDTO, prefix: string) {
        let base = sanitize(note.title || "note", "note");
        const count = usedNames.get(base) ?? 0;
        usedNames.set(base, count + 1);
        if (count > 0) base = `${base} (${count})`;

        const dir = zip.folder(`${prefix}${base}`)!;

        // the raw node.md is exactly what lives on disk — no conversion
        try {
          const raw = await repo.fs.readText(joinPath(note.dir, NOTE_FILE));
          dir.file(NOTE_FILE, raw);
        } catch {
          dir.file(NOTE_FILE, `---\ntitle: ${JSON.stringify(note.title)}\n---\n\n${note.content}\n`);
        }

        if (includeImages && note.attachments.length) {
          const mediaDir = dir.folder(ATTACHMENT_DIR)!;
          for (const att of note.attachments) {
            try {
              const blob = await repo.readAttachmentBlob(note.dir, att.file);
              if (blob) mediaDir.file(att.name, blob);
            } catch {
              // skip unreadable files
            }
          }
        }
      }

      for (const note of selected) {
        const folder = note.folder ? sanitize(note.folder.name, "folder") : null;
        await addNoteToZip(note, folder ? `${folder}/` : "");
      }
      for (const note of vaultSubset) {
        await addNoteToZip(note, "_vault/");
      }

      zip.file(
        "README.txt",
        [
          `${settings.appName} export`,
          "",
          "Every note is a folder with a node.md markdown file (YAML front-matter + content)",
          `plus an ${ATTACHMENT_DIR}/ folder holding its images and GIFs — identical to the`,
          "layout the app stores on your device.",
          includeImages ? "" : `(attachments were skipped — images disabled)`,
          vaultOpen && includeVault ? "_vault/ contains the secret vault notes." : "",
        ]
          .filter(Boolean)
          .join("\n")
      );

      const blob = await zip.generateAsync({ type: "blob", compression: "DEFLATE" });
      const scopeName = scope === "all" ? "all-notes" : sanitize(folders.find((f) => f.id === scope)?.name ?? "folder", "folder");
      await saveBlob(
        `${settings.appName.toLowerCase().replace(/\s+/g, "-")}-${scopeName}${includeVault ? "-with-vault" : ""}.zip`,
        blob
      );
      toast.success("Export ready", {
        description: `${selected.length + (includeVault ? vaultSubset.length : 0)} note(s) zipped`,
      });
      onOpenChange(false);
    } catch (e) {
      console.error(e);
      toast.error("Export failed", { description: "Could not build the ZIP file" });
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileArchive className="h-5 w-5" /> Export as ZIP
          </DialogTitle>
          <DialogDescription>
            Zip your notes exactly as they are stored locally: one folder per note with
            node.md plus its attachments.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-5">
          <div className="space-y-2">
            <Label>What to export</Label>
            <Select value={scope} onValueChange={setScope}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Choose scope" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">
                  All notes ({notes.filter((n) => !n.trashed && !n.vaulted).length})
                </SelectItem>
                {folders.map((f) => (
                  <SelectItem key={f.id} value={f.id}>
                    {f.emoji} {f.name} ({notes.filter((n) => !n.trashed && !n.vaulted && n.folderId === f.id).length})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between rounded-lg border px-3 py-2.5">
            <div>
              <p className="text-sm font-medium">Include images & GIFs</p>
              <p className="text-xs text-muted-foreground">
                {includeImages ? `${mediaCount} file(s) will be embedded` : "Notes only, smaller file"}
              </p>
            </div>
            <Switch checked={includeImages} onCheckedChange={setIncludeImages} />
          </div>

          {vaultOpen ? (
            <div className="space-y-3 rounded-lg border border-emerald-500/30 bg-emerald-500/5 px-3 py-2.5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="flex items-center gap-1.5 text-sm font-medium">
                    <Lock className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" />
                    Include vault notes
                  </p>
                  <p className="text-xs text-muted-foreground">{vaultCount} secret note(s) in _vault/</p>
                </div>
                <Switch checked={includeVault} onCheckedChange={setIncludeVault} />
              </div>
              <p className="text-[11px] leading-snug text-muted-foreground">
                Vault notes are grouped in a separate <code>_vault/</code> folder inside the ZIP
                (plus <code>notes.json</code> includes them). This option only appears while the
                vault is unlocked.
              </p>
            </div>
          ) : null}

          <div className="flex justify-end gap-2 pt-1">
            <Button variant="ghost" onClick={() => onOpenChange(false)} disabled={busy}>
              Cancel
            </Button>
            <Button onClick={buildZip} disabled={busy || (selected.length === 0 && !(vaultOpen && includeVault))}>
              {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Download className="mr-2 h-4 w-4" />}
              {busy ? "Zipping…" : `Export ${selected.length + (includeVault ? vaultCount : 0)} note(s)`}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
