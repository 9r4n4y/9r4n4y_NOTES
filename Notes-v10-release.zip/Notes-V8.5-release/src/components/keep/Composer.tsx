"use client";

import { useKeepStore } from "./store";
import { ListChecks, ImagePlus, PenLine } from "lucide-react";

/**
 * Keep-style "Take a note…" launcher.
 *
 * Every entry point immediately opens the full markdown editing panel
 * (requirement: tapping New Note opens the editor right away):
 *   - the bar itself → new text note
 *   - the checklist button → new checklist note
 *   - the image button → new note with the media picker opened
 */
export function Composer() {
  const beginNewNote = useKeepStore((s) => s.beginNewNote);
  const view = useKeepStore((s) => s.view);
  const activeFolderId = useKeepStore((s) => s.activeFolderId);
  const activeLabelId = useKeepStore((s) => s.activeLabelId);
  const labels = useKeepStore((s) => s.labels);
  const folders = useKeepStore((s) => s.folders);

  const presetFolder = view === "folder" ? folders.find((f) => f.id === activeFolderId) : null;
  const presetLabel = view === "label" ? labels.find((l) => l.id === activeLabelId) : null;
  const inVault = view === "vault";

  function newNote(opts?: { type?: "text" | "list"; withImagePicker?: boolean }) {
    beginNewNote({ type: opts?.type ?? "text" });
    if (opts?.withImagePicker) {
      setTimeout(() => window.dispatchEvent(new CustomEvent("notes:editor-pick-media")), 80);
    }
  }

  return (
    <div
      className="mx-auto flex max-w-3xl items-center gap-2 rounded-xl border border-black/10 bg-card px-4 py-3 shadow-sm transition-shadow hover:shadow-md dark:border-white/10"
      role="button"
      tabIndex={0}
      aria-label="New note"
      onClick={() => newNote()}
      onKeyDown={(e) => {
        if (e.key === "Enter") newNote();
      }}
    >
      <PenLine className="h-4.5 w-4.5 shrink-0 text-muted-foreground" />
      <span className="flex-1 truncate text-sm text-muted-foreground">
        {inVault
          ? "Add a secret note to the vault…"
          : `New note${presetFolder ? ` in ${presetFolder.emoji} ${presetFolder.name}` : ""}${presetLabel ? ` · ${presetLabel.name}` : ""} — tap to write`}
      </span>
      <div className="flex items-center">
        <button
          type="button"
          aria-label="New checklist"
          title="New checklist"
          className="inline-flex h-9 w-9 items-center justify-center rounded-full text-muted-foreground hover:bg-accent"
          onClick={(e) => {
            e.stopPropagation();
            newNote({ type: "list" });
          }}
        >
          <ListChecks className="h-4.5 w-4.5" />
        </button>
        <button
          type="button"
          aria-label="New note with image"
          title="New note with image"
          className="inline-flex h-9 w-9 items-center justify-center rounded-full text-muted-foreground hover:bg-accent"
          onClick={(e) => {
            e.stopPropagation();
            newNote({ withImagePicker: true });
          }}
        >
          <ImagePlus className="h-4.5 w-4.5" />
        </button>
      </div>
    </div>
  );
}
