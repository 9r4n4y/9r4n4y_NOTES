"use client";

import { create } from "zustand";
import { useSyncExternalStore } from "react";

// ---------------------------------------------------------------------------
// App settings (UI configuration) — persisted to localStorage, synced across
// all hook consumers via a module-level store + manual subscription.
// ---------------------------------------------------------------------------

export type Density = "compact" | "cozy" | "spacious";
export type FontSize = "sm" | "md" | "lg";

export interface AppSettings {
  appName: string;
  wallpaper: string | null; // data URL
  wallpaperBlur: number; // 0-40 px
  wallpaperDim: number; // 0-80 %
  wallpaperFixed: boolean;
  density: Density;
  fontSize: FontSize;
  animations: boolean;
  searchIncludeArchive: boolean;
  confirmBeforeDelete: boolean;
}

export const DEFAULT_SETTINGS: AppSettings = {
  appName: "Notes",
  wallpaper: null,
  wallpaperBlur: 8,
  wallpaperDim: 35,
  wallpaperFixed: true,
  density: "cozy",
  fontSize: "md",
  animations: true,
  searchIncludeArchive: true,
  confirmBeforeDelete: false,
};

const SETTINGS_KEY = "notes-app-settings-v1";

function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return { ...DEFAULT_SETTINGS };
    return { ...DEFAULT_SETTINGS, ...(JSON.parse(raw) as Partial<AppSettings>) };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

let state: AppSettings = { ...DEFAULT_SETTINGS };
let hydrated = false;
const listeners = new Set<() => void>();

function emit() {
  listeners.forEach((l) => l());
}

export function getSettings(): AppSettings {
  return state;
}

export function hydrateSettings() {
  if (hydrated) return;
  hydrated = true;
  state = loadSettings();
  emit();
}

export function updateSettings(patch: Partial<AppSettings>) {
  state = { ...state, ...patch };
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(state));
  } catch {
    // quota exceeded (large wallpaper) — keep in-memory only
  }
  emit();
}

export function resetSettings() {
  state = { ...DEFAULT_SETTINGS };
  try {
    localStorage.removeItem(SETTINGS_KEY);
  } catch {
    // ignore
  }
  emit();
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

/** Hydration-safe settings hook: defaults on the server, persisted after mount. */
export function useSettings(): AppSettings {
  const s = useSyncExternalStore(subscribe, getSettings, getDefaults);
  return s;
}

const getDefaults = () => DEFAULT_SETTINGS;

// CSS helpers ---------------------------------------------------------------

export const DENSITY_CLASS: Record<Density, { gridGap: string; cardMb: string; listGap: string; pad: string }> = {
  compact: { gridGap: "gap-4", cardMb: "mb-4", listGap: "gap-3", pad: "px-3 py-2.5" },
  cozy: { gridGap: "gap-6", cardMb: "mb-6", listGap: "gap-5", pad: "px-4 py-3" },
  spacious: { gridGap: "gap-8", cardMb: "mb-8", listGap: "gap-7", pad: "px-5 py-4" },
};

export const FONT_CLASS: Record<FontSize, string> = {
  sm: "text-[0.85rem]",
  md: "text-sm",
  lg: "text-base",
};
