"use client";

// ---------------------------------------------------------------------------
// SearchHighlight — TipTap extension powering "find in note".
//
// V8.5: the old implementation counted matches in the markdown SOURCE and
// always scrolled to the first DOM node containing the query — the Up/Down
// buttons only changed the "3/102" counter and there was no visual highlight
// at all.
//
// This extension uses ProseMirror DECORATIONS (the official, view-only way to
// highlight without mutating the document), so:
//   - every occurrence of the query is wrapped in a .search-hit decoration
//   - the ACTIVE occurrence additionally gets .search-hit-active
//   - decorations are recomputed on every relevant transaction, they never
//     leak into the saved markdown
//   - goToMatch(i) scrolls the active match into view inside the editor's
//     scroll container and reports the true match count back to React via
//     the onResults callback
// ---------------------------------------------------------------------------

import { Extension } from "@tiptap/core";
import { Plugin, PluginKey } from "@tiptap/pm/state";
import { Decoration, DecorationSet, type EditorView } from "@tiptap/pm/view";

export interface SearchResults {
  /** total matches in the rendered document (0-based info) */
  count: number;
  /** currently active match index (0-based, clamped) */
  active: number;
}

interface SearchPluginState {
  query: string;
  activeIndex: number;
}

export const searchPluginKey = new PluginKey<SearchPluginState>("searchHighlight");

const MAX_MATCHES = 999;

/** All (case-insensitive) occurrences of `query` inside one string. */
function indexesOf(haystack: string, needle: string, limit = MAX_MATCHES): number[] {
  const out: number[] = [];
  if (!needle) return out;
  const lower = haystack.toLowerCase();
  const q = needle.toLowerCase();
  let idx = lower.indexOf(q);
  while (idx !== -1) {
    out.push(idx);
    if (out.length >= limit) break;
    idx = lower.indexOf(q, idx + q.length);
  }
  return out;
}

/** Walk the doc and collect {from,to} ranges for every match (per text node). */
function findMatches(doc: import("@tiptap/pm/model").Node, query: string): { from: number; to: number }[] {
  const out: { from: number; to: number }[] = [];
  if (!query) return out;
  doc.descendants((node, pos) => {
    if (out.length >= MAX_MATCHES) return false;
    if (!node.isText || !node.text) return;
    for (const idx of indexesOf(node.text, query)) {
      out.push({ from: pos + idx, to: pos + idx + query.length });
      if (out.length >= MAX_MATCHES) break;
    }
    return;
  });
  return out;
}

export interface SearchHighlightOptions {
  /** stable callback — reported whenever (query | count | active) changes */
  onResults?: (results: SearchResults) => void;
}

export const SearchHighlight = Extension.create<SearchHighlightOptions>({
  name: "searchHighlight",

  addOptions() {
    return { onResults: undefined };
  },

  addProseMirrorPlugins() {
    const options = this.options;

    return [
      new Plugin<SearchPluginState>({
        key: searchPluginKey,
        state: {
          init: () => ({ query: "", activeIndex: 0 }),
          apply(tr, prev) {
            const meta = tr.getMeta(searchPluginKey) as
              | { type: "set"; query: string }
              | { type: "goto"; index: number }
              | undefined;
            if (meta?.type === "set") {
              return { query: meta.query, activeIndex: 0 };
            }
            if (meta?.type === "goto") {
              return { ...prev, activeIndex: meta.index };
            }
            // doc changed underneath (typing, content sync): keep query,
            // decorations recompute automatically and the index is clamped
            if (tr.docChanged) return { ...prev };
            return prev;
          },
        },
        props: {
          decorations(state) {
            const ps = searchPluginKey.getState(state);
            if (!ps || !ps.query) return DecorationSet.empty;
            const matches = findMatches(state.doc, ps.query);
            if (matches.length === 0) return DecorationSet.empty;
            const activeIndex = Math.min(ps.activeIndex, matches.length - 1);
            return DecorationSet.create(
              state.doc,
              matches.map((m, i) =>
                Decoration.inline(m.from, m.to, {
                  class: i === activeIndex ? "search-hit search-hit-active" : "search-hit",
                })
              )
            );
          },
        },
        view() {
          let lastSig = "";
          return {
            update: (view: EditorView, prevState) => {
              const ps = searchPluginKey.getState(view.state);
              const prevPs = searchPluginKey.getState(prevState);
              const docChanged = view.state.doc !== prevState.doc;
              // nothing relevant happened → don't spam the callback
              if (ps === prevPs && !docChanged && lastSig !== "") return;
              const query = ps?.query ?? "";
              const matches = query ? findMatches(view.state.doc, query) : [];
              const activeIndex = matches.length
                ? Math.min(ps?.activeIndex ?? 0, matches.length - 1)
                : 0;
              const sig = `${query}\u0000${matches.length}\u0000${activeIndex}`;
              if (sig === lastSig) return;
              lastSig = sig;
              options.onResults?.({ count: matches.length, active: activeIndex });
            },
          };
        },
      }),
    ];
  },
});

/** Dispatch a new search query (resets the active match to the first one). */
export function dispatchSearchQuery(
  editor: import("@tiptap/core").Editor | undefined | null,
  query: string
) {
  if (!editor) return;
  const tr = editor.state.tr.setMeta(searchPluginKey, { type: "set", query });
  editor.view.dispatch(tr);
}

/**
 * Jump to match `index` (wraps around), re-highlight, and scroll it into view
 * inside `scrollEl`. Returns false when there is nothing to jump to.
 */
export function goToMatch(
  editor: import("@tiptap/core").Editor | undefined | null,
  index: number,
  scrollEl: HTMLElement | null
): boolean {
  if (!editor) return false;
  const ps = searchPluginKey.getState(editor.state);
  const query = ps?.query ?? "";
  if (!query) return false;
  const matches = findMatches(editor.state.doc, query);
  if (matches.length === 0) return false;
  const wrapped = ((index % matches.length) + matches.length) % matches.length;
  editor.view.dispatch(
    editor.state.tr.setMeta(searchPluginKey, { type: "goto", index: wrapped })
  );
  // scroll after the browser has painted the new decoration
  requestAnimationFrame(() => {
    const el = (editor.view.dom as HTMLElement).querySelector(".search-hit-active");
    if (!el || !scrollEl) return;
    const r = el.getBoundingClientRect();
    const c = scrollEl.getBoundingClientRect();
    // aim the match at 1/3 of the VISIBLE (visual) viewport — on Android the
    // software keyboard shrinks the visual viewport, not the layout one, so
    // this keeps the active match clear of the keyboard
    const vv = typeof window !== "undefined" ? window.visualViewport : null;
    const visTop = vv?.offsetTop ?? 0;
    const visHeight = vv?.height ?? c.height;
    const matchContentY = scrollEl.scrollTop + (r.top - c.top);
    const target = matchContentY + c.top - (visTop + visHeight / 3);
    scrollEl.scrollTo({ top: Math.max(0, target), behavior: "smooth" });
  });
  return true;
}
