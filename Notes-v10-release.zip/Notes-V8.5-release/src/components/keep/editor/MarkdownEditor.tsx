"use client";

// ---------------------------------------------------------------------------
// MarkdownEditor — TipTap-based WYSIWYG markdown editor.
//
// The note content on disk is MARKDOWN. This component:
//   - loads markdown text (parsed by tiptap-markdown)
//   - offers a complete formatting toolbar (all controls toggle: when active,
//     newly typed text carries the format; toggled off → plain typing again)
//   - serialises back to markdown on every change (debounced by the caller)
//   - swaps `attachment/…` paths for display object-URLs and back
// ---------------------------------------------------------------------------

import { useCallback, useEffect, useImperativeHandle, useRef, useState } from "react";
import { EditorContent, useEditor, type Editor } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Underline from "@tiptap/extension-underline";
import Link from "@tiptap/extension-link";
import Image from "@tiptap/extension-image";
import TaskList from "@tiptap/extension-task-list";
import TaskItem from "@tiptap/extension-task-item";
import Placeholder from "@tiptap/extension-placeholder";
import { Markdown } from "tiptap-markdown";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  SearchHighlight,
  dispatchSearchQuery,
  goToMatch,
  type SearchResults,
} from "./search-highlight";
import {
  Bold,
  Braces,
  Code,
  Heading1,
  Heading2,
  Heading3,
  ImagePlus,
  Italic,
  Link2,
  Link2Off,
  List,
  ListChecks,
  ListOrdered,
  Minus,
  Quote,
  Redo2,
  RemoveFormatting,
  Strikethrough,
  Underline as UnderlineIcon,
  Undo2,
} from "lucide-react";
import { cn } from "@/lib/utils";
import {
  decodeAttachmentPath,
  encodeAttachmentPath,
} from "@/core/markdown";

export interface MarkdownEditorHandle {
  focus: () => void;
  insertImage: (url: string, alt?: string) => void;
  getMarkdown: () => string;
  getScrollElement: () => HTMLElement | null;
  /** register a display-url → attachment-path mapping (must run before insertImage) */
  registerUrl: (url: string, file: string) => void;
  /** V8.5: set/clear the find-in-note query (highlights every match) */
  setSearchQuery: (query: string) => void;
  /** V8.5: jump to a match (wraps) and scroll it into view */
  goToMatch: (index: number) => void;
}

interface ToolbarProps {
  editor: Editor;
  onPickImages: () => void;
}

function ToolButton({
  onClick,
  active,
  disabled,
  label,
  children,
}: {
  onClick?: () => void;
  active?: boolean;
  disabled?: boolean;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      disabled={disabled}
      onMouseDown={(e) => e.preventDefault()} // keep editor selection
      onClick={onClick}
      className={cn(
        "inline-flex h-8 min-w-8 shrink-0 items-center justify-center rounded-md px-1.5 text-foreground/75 transition-colors hover:bg-black/10 hover:text-foreground disabled:opacity-30 dark:hover:bg-white/10",
        active && "bg-foreground/10 text-foreground dark:bg-white/15"
      )}
    >
      {children}
    </button>
  );
}

function Toolbar({ editor, onPickImages }: ToolbarProps) {
  // V8 fix (bug #1): the link input previously rendered as an absolutely
  // positioned div INSIDE the toolbar — it overlapped the editor below and on
  // touch devices the editor could steal the taps, making the URL field
  // unusable. It is now a real Radix Popover: portalled to <body> (always
  // above the editor, modal so the editor cannot intercept touches), with
  // normal focus, keyboard (Enter/Escape) and outside-tap handling.
  const [linkOpen, setLinkOpen] = useState(false);
  const [linkUrl, setLinkUrl] = useState("");
  const linkInputRef = useRef<HTMLInputElement | null>(null);

  const applyLink = () => {
    const url = linkUrl.trim();
    if (!url) {
      editor.chain().focus().extendMarkRange("link").unsetLink().run();
    } else if (editor.isActive("link")) {
      editor.chain().focus().extendMarkRange("link").setLink({ href: url }).run();
    } else if (editor.state.selection.empty) {
      // no selection → insert a visible link with the URL as text
      editor
        .chain()
        .focus()
        .insertContent(`<a href="${url.replace(/"/g, "&quot;")}">${url}</a>`)
        .run();
    } else {
      editor.chain().focus().setLink({ href: url }).run();
    }
    setLinkOpen(false);
  };

  const removeLink = () => {
    editor.chain().focus().extendMarkRange("link").unsetLink().run();
    setLinkOpen(false);
  };

  return (
    <div className="relative border-b border-black/5 bg-background/60 backdrop-blur dark:border-white/10">
      <div className="flex items-center gap-0.5 overflow-x-auto px-2 py-1.5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        <ToolButton
          label="Bold"
          active={editor.isActive("bold")}
          onClick={() => editor.chain().focus().toggleBold().run()}
        >
          <Bold className="h-4 w-4" />
        </ToolButton>
        <ToolButton
          label="Italic"
          active={editor.isActive("italic")}
          onClick={() => editor.chain().focus().toggleItalic().run()}
        >
          <Italic className="h-4 w-4" />
        </ToolButton>
        <ToolButton
          label="Underline"
          active={editor.isActive("underline")}
          onClick={() => editor.chain().focus().toggleUnderline().run()}
        >
          <UnderlineIcon className="h-4 w-4" />
        </ToolButton>
        <ToolButton
          label="Strikethrough"
          active={editor.isActive("strike")}
          onClick={() => editor.chain().focus().toggleStrike().run()}
        >
          <Strikethrough className="h-4 w-4" />
        </ToolButton>
        <ToolButton
          label="Inline code"
          active={editor.isActive("code")}
          onClick={() => editor.chain().focus().toggleCode().run()}
        >
          <Code className="h-4 w-4" />
        </ToolButton>

        <span className="mx-1 h-5 w-px shrink-0 bg-black/10 dark:bg-white/15" />

        <ToolButton
          label="Heading 1"
          active={editor.isActive("heading", { level: 1 })}
          onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}
        >
          <Heading1 className="h-4 w-4" />
        </ToolButton>
        <ToolButton
          label="Heading 2"
          active={editor.isActive("heading", { level: 2 })}
          onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
        >
          <Heading2 className="h-4 w-4" />
        </ToolButton>
        <ToolButton
          label="Heading 3"
          active={editor.isActive("heading", { level: 3 })}
          onClick={() => editor.chain().focus().toggleHeading({ level: 3 }).run()}
        >
          <Heading3 className="h-4 w-4" />
        </ToolButton>
        <ToolButton
          label="Body text"
          active={editor.isActive("paragraph") && !editor.isActive("taskList")}
          onClick={() => editor.chain().focus().setParagraph().run()}
        >
          <Braces className="h-4 w-4 rotate-90" />
        </ToolButton>

        <span className="mx-1 h-5 w-px shrink-0 bg-black/10 dark:bg-white/15" />

        <ToolButton
          label="Bullet list"
          active={editor.isActive("bulletList")}
          onClick={() => editor.chain().focus().toggleBulletList().run()}
        >
          <List className="h-4 w-4" />
        </ToolButton>
        <ToolButton
          label="Numbered list"
          active={editor.isActive("orderedList")}
          onClick={() => editor.chain().focus().toggleOrderedList().run()}
        >
          <ListOrdered className="h-4 w-4" />
        </ToolButton>
        <ToolButton
          label="Checklist"
          active={editor.isActive("taskList")}
          onClick={() => editor.chain().focus().toggleTaskList().run()}
        >
          <ListChecks className="h-4 w-4" />
        </ToolButton>
        <ToolButton
          label="Quote"
          active={editor.isActive("blockquote")}
          onClick={() => editor.chain().focus().toggleBlockquote().run()}
        >
          <Quote className="h-4 w-4" />
        </ToolButton>
        <ToolButton
          label="Code block"
          active={editor.isActive("codeBlock")}
          onClick={() => editor.chain().focus().toggleCodeBlock().run()}
        >
          <Braces className="h-4 w-4" />
        </ToolButton>

        <span className="mx-1 h-5 w-px shrink-0 bg-black/10 dark:bg-white/15" />

        <Popover
          modal
          open={linkOpen}
          onOpenChange={(o) => {
            if (o) {
              // seed with the existing link (if the cursor is on one) — the
              // editor selection is preserved because ToolButton prevents
              // default on mousedown
              const existing = (editor.getAttributes("link").href as string) ?? "";
              setLinkUrl(existing);
            }
            setLinkOpen(o);
          }}
        >
          <PopoverTrigger asChild>
            <span className="inline-flex shrink-0">
              <ToolButton label="Add link" active={editor.isActive("link")}>
                <Link2 className="h-4 w-4" />
              </ToolButton>
            </span>
          </PopoverTrigger>
          <PopoverContent
            align="start"
            side="bottom"
            sideOffset={6}
            collisionPadding={8}
            className="z-[70] w-[min(92vw,26rem)] rounded-xl p-2 shadow-xl"
            onOpenAutoFocus={(e) => {
              // focus + select the URL field ourselves so editing/replacing
              // an existing URL is one gesture
              e.preventDefault();
              requestAnimationFrame(() => {
                linkInputRef.current?.focus();
                linkInputRef.current?.select();
              });
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2">
              <input
                ref={linkInputRef}
                autoFocus
                value={linkUrl}
                onChange={(e) => setLinkUrl(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    applyLink();
                  } else if (e.key === "Escape") {
                    e.stopPropagation();
                    setLinkOpen(false);
                  }
                }}
                inputMode="url"
                autoComplete="off"
                spellCheck={false}
                placeholder="https://…  (leave empty to remove)"
                aria-label="Link URL"
                className="min-w-0 flex-1 rounded-md bg-transparent px-2 py-1.5 text-sm outline-none ring-1 ring-black/10 focus:ring-foreground/30 dark:ring-white/15"
              />
              <button
                type="button"
                onClick={applyLink}
                className="shrink-0 rounded-md bg-foreground px-3 py-1.5 text-sm font-medium text-background"
              >
                Apply
              </button>
              <button
                type="button"
                onClick={() => setLinkOpen(false)}
                className="shrink-0 rounded-md px-2 py-1.5 text-sm text-muted-foreground hover:bg-black/5 dark:hover:bg-white/10"
              >
                Cancel
              </button>
            </div>
          </PopoverContent>
        </Popover>
        <ToolButton label="Remove link" disabled={!editor.isActive("link")} onClick={removeLink}>
          <Link2Off className="h-4 w-4" />
        </ToolButton>
        <ToolButton label="Add image (saved to attachments)" onClick={onPickImages}>
          <ImagePlus className="h-4 w-4" />
        </ToolButton>
        <ToolButton
          label="Divider"
          onClick={() => editor.chain().focus().setHorizontalRule().run()}
        >
          <Minus className="h-4 w-4" />
        </ToolButton>
        <ToolButton
          label="Clear formatting"
          onClick={() => editor.chain().focus().unsetAllMarks().clearNodes().run()}
        >
          <RemoveFormatting className="h-4 w-4" />
        </ToolButton>

        <span className="mx-1 h-5 w-px shrink-0 bg-black/10 dark:bg-white/15" />

        <ToolButton
          label="Undo"
          disabled={!editor.can().undo()}
          onClick={() => editor.chain().focus().undo().run()}
        >
          <Undo2 className="h-4 w-4" />
        </ToolButton>
        <ToolButton
          label="Redo"
          disabled={!editor.can().redo()}
          onClick={() => editor.chain().focus().redo().run()}
        >
          <Redo2 className="h-4 w-4" />
        </ToolButton>
      </div>
    </div>
  );
}

export interface MarkdownEditorProps {
  /** markdown source to display */
  value: string;
  /** called (debounced by caller) with the serialised markdown */
  onChange: (markdown: string) => void;
  /** display URL for an `attachment/…` path */
  fileToUrl: (file: string) => string;
  /** reverse mapping used when serialising (object-URL → attachment path) */
  urlToFile: Map<string, string>;
  /** parent opens the media picker / handles the disk write */
  onRequestInsertImages: () => void;
  /** V8.5: pasted image(s) — the parent stores them as ATTACHMENTS (never auto-inserted into the body) */
  onPasteImages?: (files: File[]) => void;
  /** V8.5: reported whenever the find-in-note (query | count | active) changes */
  onSearchResults?: (results: SearchResults) => void;
  /** imperative API host (insertImage / focus / getMarkdown) */
  handleRef?: React.RefObject<MarkdownEditorHandle | null>;
  /** content rendered before the markdown body inside the independently scrolling note area */
  beforeContent?: React.ReactNode;
  placeholder?: string;
  autoFocus?: boolean;
}

export const MarkdownEditor = ({
  value,
  onChange,
  fileToUrl,
  urlToFile,
  onRequestInsertImages,
  onPasteImages,
  onSearchResults,
  handleRef,
  beforeContent,
  placeholder,
  autoFocus,
}: MarkdownEditorProps) => {
  const suppressChange = useRef(false);
  const lastEmitted = useRef<string | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  // stable callbacks for the editor created once with [] deps (V8.5)
  const onPasteImagesRef = useRef(onPasteImages);
  useEffect(() => {
    onPasteImagesRef.current = onPasteImages;
  }, [onPasteImages]);
  const onSearchResultsRef = useRef(onSearchResults);
  useEffect(() => {
    onSearchResultsRef.current = onSearchResults;
  }, [onSearchResults]);

  // always-fresh reverse map so onUpdate never serialises stale mappings
  const urlToFileRef = useRef(urlToFile);
  useEffect(() => {
    urlToFileRef.current = urlToFile;
  }, [urlToFile]);

  /** markdown (on disk) → editor display markdown (object URLs) */
  const toDisplay = useCallback(
    (md: string) =>
      md.replace(
        /\]\(\s*(attachment\/[^)\s]+)((?:\s+"[^"]*")?)\s*\)/g,
        (full, file: string, title: string) => {
          const raw = decodeAttachmentPath(file);
          const url = fileToUrl(raw);
          return url ? `](${url}${title})` : full;
        }
      ),
    [fileToUrl]
  );

  /** editor display markdown → disk markdown (attachment paths, encoded) */
  const fromDisplay = useCallback(
    (md: string) =>
      md.replace(
        /\]\(\s*(blob:[^)\s]+|data:[^)\s]+)((?:\s+"[^"]*")?)\s*\)/g,
        (full, url: string, title: string) => {
          const file = urlToFileRef.current.get(url);
          return file ? `](${encodeAttachmentPath(file)}${title})` : full;
        }
      ),
    []
  );

  const editor = useEditor(
    {
      extensions: [
        StarterKit.configure({
          heading: { levels: [1, 2, 3, 4] },
          codeBlock: { HTMLAttributes: { class: "md-codeblock" } },
        }),
        Underline,
        Link.configure({
          openOnClick: false,
          autolink: true,
          linkOnPaste: true,
          HTMLAttributes: { rel: "noopener noreferrer", target: "_blank" },
        }),
        Image.configure({ inline: false, allowBase64: true }),
        TaskList,
        TaskItem.configure({ nested: true }),
        Placeholder.configure({ placeholder: placeholder ?? "Start writing…" }),
        // V8.5: find-in-note decorations (highlight + active match)
        // The ref read happens at plugin view-update time (outside React
        // render); the ref keeps the callback fresh for the editor that is
        // created exactly once.
        // eslint-disable-next-line react-hooks/refs
        SearchHighlight.configure({
          onResults: (r) => onSearchResultsRef.current?.(r),
        }),
        Markdown.configure({
          html: true,
          linkify: true,
          breaks: false,
          transformPastedText: true,
          transformCopiedText: false,
        }),
      ],
      content: toDisplay(value),
      immediatelyRender: false,
      autofocus: autoFocus ? "end" : false,
      editorProps: {
        attributes: {
          class: "md-prose min-h-[40vh] outline-none",
          spellcheck: "true",
        },
        handlePaste: (view, event) => {
          const files = event.clipboardData?.files;
          if (files && files.length > 0 && [...files].every((f) => f.type.startsWith("image/"))) {
            event.preventDefault();
            // V8.5 fix: pasting an image used to DISCARD the file and open the
            // file picker (which also left the pick-mode poisoned to "insert",
            // so a later batch upload auto-inserted images into the body).
            // Pasted images are now stored as attachments — never the body.
            onPasteImagesRef.current?.(Array.from(files));
            return true;
          }
          return false;
        },
      },
      onUpdate: ({ editor: e }) => {
        if (suppressChange.current) return;
        const md = (e.storage as { markdown?: { getMarkdown: () => string } }).markdown?.getMarkdown();
        if (typeof md !== "string") return;
        const clean = fromDisplay(md);
        lastEmitted.current = clean;
        onChange(clean);
      },
    },
    []
  );

  // content switched underneath us (different note opened / URLs resolved)
  useEffect(() => {
    if (!editor) return;
    // images still showing raw attachment/ paths that now have a display URL?
    const staleImgs = editor.view.dom.querySelectorAll('img[src^="attachment/"], img[src*="attachment/%"]');
    if (lastEmitted.current === value && staleImgs.length === 0) return;
    const current = fromDisplay(
      (editor.storage as { markdown?: { getMarkdown: () => string } }).markdown?.getMarkdown() ?? ""
    );
    if (current === value && staleImgs.length === 0) return;
    suppressChange.current = true;
    editor.commands.setContent(toDisplay(value));
    suppressChange.current = false;
  }, [value, editor, fileToUrl]);

  // re-render toolbar active states on every selection/format change
  const [, forceRender] = useState(0);
  useEffect(() => {
    if (!editor) return;
    const bump = () => forceRender((x) => x + 1);
    editor.on("transaction", bump);
    return () => {
      editor.off("transaction", bump);
    };
  }, [editor]);

  useImperativeHandle(
    handleRef,
    () => ({
      focus: () => editor?.commands.focus("end"),
      registerUrl: (url: string, file: string) => {
        urlToFileRef.current = new Map(urlToFileRef.current).set(url, file);
      },
      setSearchQuery: (query: string) => dispatchSearchQuery(editor, query),
      goToMatch: (index: number) => goToMatch(editor, index, scrollRef.current),
      insertImage: (url: string, alt?: string) => {
        if (!editor) return;
        editor
          .chain()
          .focus()
          .setImage({ src: url, alt: alt ?? "", title: alt ?? "" })
          .run();
      },
      getMarkdown: () =>
        (editor?.storage as { markdown?: { getMarkdown: () => string } })?.markdown
          ?.getMarkdown() ?? "",
      getScrollElement: () => scrollRef.current,
    }),
    [editor]
  );

  if (!editor) {
    return (
      <div className="flex min-h-[40vh] items-center justify-center text-sm text-muted-foreground">
        Loading editor…
      </div>
    );
  }

  return (
    <div className="md-editor flex min-h-0 flex-1 flex-col">
      <div className="sticky top-0 z-20 shrink-0">
        <Toolbar editor={editor} onPickImages={onRequestInsertImages} />
      </div>
      <div ref={scrollRef} className="min-h-0 flex-1 overflow-y-auto px-4 pb-8 pt-2">
        {beforeContent}
        <EditorContent editor={editor} />
      </div>
    </div>
  );
};

/** Convenience: build the url→file reverse map from a note's attachments. */
export function buildUrlToFileMap(
  attachments: { file: string; url: string }[]
): Map<string, string> {
  const map = new Map<string, string>();
  for (const a of attachments) {
    if (a.url) map.set(a.url, a.file);
  }
  return map;
}
