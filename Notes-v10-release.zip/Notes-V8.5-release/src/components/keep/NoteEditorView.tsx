"use client";

import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  Archive,
  ArchiveRestore,
  ArrowDown,
  ArrowUp,
  ArrowLeft,
  Brush,
  ListChecks,
  Copy,
  FolderInput,
  ImagePlus,
  Lock,
  LockOpen,
  MoreVertical,
  NotepadText,
  PenLine,
  Pin,
  Search,
  Undo2,
  Tag,
  ChevronUp,
  ChevronDown,
  Delete as TrashIcon,
  Images,
  X,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ColorPicker } from "./ColorPicker";
import { LabelsPopover } from "./LabelsPopover";
import { MediaPickPopover } from "./MediaPickPopover";
import { Lightbox } from "./Lightbox";
import {
  useKeepStore,
  DRAFT_ID,
  type NotePatch,
} from "./store";
import { noteStyle } from "@/lib/keep-constants";
import { useTheme } from "next-themes";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import type { AttachmentDTO, NoteDTO } from "@/core/types";
import {
  bodyHasRealContent,
  listToTextBody,
  textToListBody,
} from "@/core/markdown";
import { prepareMedia } from "./media";
import { useAttachmentUrl, resolveAttachmentUrls } from "./attachment-url";
import { useBackLayer } from "@/lib/back-nav";
import {
  MarkdownEditor,
  buildUrlToFileMap,
  type MarkdownEditorHandle,
} from "./editor/MarkdownEditor";
import type { SearchResults } from "./editor/search-highlight";

/* ------------------------------------------------------------------ */
/* Attachment thumbnail with lazy URL resolution                       */
/* ------------------------------------------------------------------ */

function EditorThumb({
  note,
  att,
  onOpen,
  onEdit,
  onRemove,
  onInsert,
}: {
  note: NoteDTO;
  att: AttachmentDTO;
  onOpen: () => void;
  onEdit: () => void;
  onRemove: () => void;
  onInsert: () => void;
}) {
  const url = useAttachmentUrl(note.dir, att);
  return (
    <div className="group relative h-20 w-20 overflow-hidden rounded-md border border-black/10">
      <button type="button" className="h-full w-full" onClick={onOpen} aria-label={`View ${att.name}`}>
        {url ? (
          <img src={url} alt={att.name} className="h-full w-full object-cover" />
        ) : (
          <div className="h-full w-full animate-pulse bg-black/5" />
        )}
      </button>
      {att.kind === "gif" ? (
        <span className="absolute bottom-0 right-0 rounded-tl bg-black/60 px-1 text-[8px] font-bold text-white">
          GIF
        </span>
      ) : null}
      <button
        type="button"
        aria-label="Edit image"
        onClick={(e) => {
          e.stopPropagation();
          onEdit();
        }}
        className="absolute left-1 top-1 flex h-6 w-6 items-center justify-center rounded-full bg-black/55 text-white shadow-sm transition-colors hover:bg-black/80"
      >
        <PenLine className="h-3.5 w-3.5" />
      </button>
      <button
        type="button"
        aria-label="Remove media"
        onClick={(e) => {
          e.stopPropagation();
          onRemove();
        }}
        className="absolute right-1 top-1 flex h-6 w-6 items-center justify-center rounded-full bg-black/55 text-white shadow-sm transition-colors hover:bg-black/80"
      >
        <X className="h-3.5 w-3.5" />
      </button>
      <button
        type="button"
        aria-label="Insert into note"
        title="Insert into note"
        onClick={(e) => {
          e.stopPropagation();
          onInsert();
        }}
        className="absolute bottom-1 left-1 flex h-6 w-6 items-center justify-center rounded-full bg-black/55 text-white shadow-sm transition-colors hover:bg-black/80"
      >
        <ImagePlus className="h-3.5 w-3.5" />
      </button>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Full-screen markdown note editor                                    */
/* ------------------------------------------------------------------ */

export function NoteEditorView() {
  const editorNoteId = useKeepStore((s) => s.editorNoteId);
  const draftNote = useKeepStore((s) => s.draftNote);
  const storeNote = useKeepStore((s) => s.notes.find((n) => n.id === s.editorNoteId));
  const openEditor = useKeepStore((s) => s.openEditor);
  const updateNote = useKeepStore((s) => s.updateNote);
  const flushUpdate = useKeepStore((s) => s.flushUpdate);
  const duplicateNote = useKeepStore((s) => s.duplicateNote);
  const trashNote = useKeepStore((s) => s.trashNote);
  const restoreNote = useKeepStore((s) => s.restoreNote);
  const deleteForever = useKeepStore((s) => s.deleteForever);
  const folders = useKeepStore((s) => s.folders);
  const setLightbox = useKeepStore((s) => s.setLightbox);
  const openImageEditor = useKeepStore((s) => s.openImageEditor);
  const addNoteMedia = useKeepStore((s) => s.addNoteMedia);
  const removeNoteAttachment = useKeepStore((s) => s.removeNoteAttachment);
  const vaultOpen = useKeepStore((s) => s.vaultOpen);
  const { resolvedTheme } = useTheme();

  const isDraft = editorNoteId === DRAFT_ID;
  const note = isDraft ? draftNote : storeNote;

  const editorHandle = useRef<MarkdownEditorHandle | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // ---- in-note search state (V8.5)
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [searchState, setSearchState] = useState<SearchResults>({ count: 0, active: 0 });
  const searchDebounce = useRef<ReturnType<typeof setTimeout> | null>(null);

  // ---- scroll state (jump buttons)
  const [scrollable, setScrollable] = useState(false);
  const [atTop, setAtTop] = useState(true);
  const [atBottom, setAtBottom] = useState(false);
  const [galleryOpen, setGalleryOpen] = useState(false);
  const [galleryUrls, setGalleryUrls] = useState<Map<string, string>>(new Map());

  const open = !!editorNoteId && !!note;
  const isDark = resolvedTheme === "dark";
  const style = note ? noteStyle(note.color, isDark) : undefined;

  /* ------------------------------------------------ url resolution map */

  const attachmentKey = note
    ? note.attachments.map((a) => `${a.file}:${a.url}`).join("|")
    : "";

  const [urlMap, setUrlMap] = useState<Map<string, string>>(new Map());
  useEffect(() => {
    if (!open || !note) return;
    let alive = true;
    resolveAttachmentUrls(note.dir, note.attachments).then((map) => {
      if (alive) setUrlMap(map);
    });
    return () => {
      alive = false;
    };
  }, [editorNoteId, attachmentKey, open]);

  const fileToUrl = useCallback((file: string) => urlMap.get(file) ?? "", [urlMap]);
  const urlToFile = useMemo(() => {
    const inverted = new Map<string, string>();
    for (const [file, url] of urlMap.entries()) inverted.set(url, file);
    // attachments that already carry an url (drafts) join in too
    for (const att of note?.attachments ?? []) {
      if (att.url) inverted.set(att.url, att.file);
    }
    return inverted;
  }, [urlMap, note]);

  /* ------------------------------------------------------- helpers */

  function patch(p: NotePatch, immediate = false) {
    if (note) updateNote(note.id, p, immediate);
  }

  const close = useCallback(() => {
    const state = useKeepStore.getState();
    if (state.editorNoteId === DRAFT_ID) {
      const d = state.draftNote;
      if (d && (d.title.trim() || bodyHasRealContent(d.content) || d.attachments.length > 0)) {
        void state.__ensureDraftMaterialized().finally(() => {
          useKeepStore.setState({ editorNoteId: null });
        });
      } else {
        useKeepStore.setState({ draftNote: null, editorNoteId: null });
      }
    } else if (state.editorNoteId) {
      void state.flushUpdate(state.editorNoteId);
      state.openEditor(null);
    }
  }, []);

  // flush pending saves when the editor unmounts
  useEffect(() => {
    if (!editorNoteId) return;
    return () => {
      if (editorNoteId !== DRAFT_ID) void flushUpdate(editorNoteId);
    };
  }, [editorNoteId, flushUpdate]);

  /* --------------------------------------------------- media picking */

  /** Register a display-URL → attachment-path mapping for markdown round-trips. */
  const registerAttachmentUrl = useCallback((att: AttachmentDTO, url: string) => {
    if (!url) return;
    editorHandle.current?.registerUrl(url, att.file);
    setUrlMap((m) => new Map(m).set(att.file, url));
  }, []);

  /** Insert an attachment image into the editor body (explicit user action). */
  const insertAttachmentIntoEditor = useCallback((att: AttachmentDTO, url: string) => {
    if (!url || !editorHandle.current) return;
    editorHandle.current.registerUrl(url, att.file);
    editorHandle.current.insertImage(url, att.name);
    setUrlMap((m) => new Map(m).set(att.file, url));
  }, []);

  /**
   * V8.5 (user regression report on V8): EVERY upload path — footer picker,
   * editor toolbar button, composer shortcut, image paste — stores images
   * into the attachments area ONLY. Auto-insertion into the note body is
   * now structurally impossible: the old "insert" pick-mode (and the
   * pickModeRef that could stay poisoned after a cancelled picker) is gone.
   * An image lands in the body exclusively via a thumbnail's explicit
   * "Insert into note" button.
   */
  const attachPickedFiles = useCallback(
    async (files: FileList | File[]) => {
      if (!note) return;
      try {
        const media = await prepareMedia(Array.from(files));
        if (media.length === 0) return;
        const atts = await addNoteMedia(note.id, media);
        for (const att of atts) {
          const url = att.url || (await resolveAttachmentUrls(note.dir, [att])).get(att.file) || "";
          registerAttachmentUrl(att, url);
        }
        toast.success(atts.length === 1 ? "Image added" : `${atts.length} files added`);
      } catch (e) {
        toast.error(e instanceof Error ? e.message : "Could not add the image");
      }
    },
    [note, addNoteMedia, registerAttachmentUrl]
  );

  // Composer's "note with image" shortcut opens the picker here (attach-only)
  useEffect(() => {
    const onPick = () => fileInputRef.current?.click();
    window.addEventListener("notes:editor-pick-media", onPick);
    return () => window.removeEventListener("notes:editor-pick-media", onPick);
  }, []);

  /* --------------------------------------------------- search in note (V8.5) */

  // the extension reports the TRUE rendered-document match count + active idx
  const onSearchResults = useCallback((r: SearchResults) => setSearchState(r), []);

  const searchStateRef = useRef(searchState);
  useEffect(() => {
    searchStateRef.current = searchState;
  }, [searchState]);

  /** debounced push of the query into the editor → highlight + jump to first */
  const applySearchQuery = useCallback((q: string) => {
    if (searchDebounce.current) clearTimeout(searchDebounce.current);
    searchDebounce.current = setTimeout(() => {
      editorHandle.current?.setSearchQuery(q);
      if (q.trim()) editorHandle.current?.goToMatch(0); // always land on a match
    }, 180);
  }, []);

  const closeSearch = useCallback(() => {
    if (searchDebounce.current) clearTimeout(searchDebounce.current);
    setQuery("");
    setSearchState({ count: 0, active: 0 });
    editorHandle.current?.setSearchQuery("");
  }, []);

  /** Up/Down (and Enter/Shift+Enter): move the active highlight, wrapping */
  const navigateMatch = useCallback((dir: 1 | -1) => {
    const s = searchStateRef.current;
    if (s.count > 0) editorHandle.current?.goToMatch(s.active + dir);
  }, []);

  /* --------------------------------------------------- scroll state */

  const refreshScrollState = useCallback(() => {
    const el = editorHandle.current?.getScrollElement();
    if (!el) return;
    const canScroll = el.scrollHeight > el.clientHeight + 24;
    setScrollable(canScroll);
    setAtTop(el.scrollTop <= 4);
    setAtBottom(el.scrollTop + el.clientHeight >= el.scrollHeight - 4);
  }, []);

  useEffect(() => {
    if (!open) return;
    let raf1 = 0;
    let raf2 = 0;
    const settleTimer = { id: 0 as unknown as ReturnType<typeof setTimeout> };

    // viewport/keyboard transitions need a few frames before layout settles —
    // re-check immediately AND after the settle delay (V8 bug #5: a single
    // stale measurement used to hide the Down button after closing the
    // keyboard)
    const recheckAfterLayoutSettles = () => {
      cancelAnimationFrame(raf1);
      cancelAnimationFrame(raf2);
      raf1 = requestAnimationFrame(() => {
        raf2 = requestAnimationFrame(refreshScrollState);
      });
      clearTimeout(settleTimer.id);
      settleTimer.id = setTimeout(refreshScrollState, 350);
    };

    window.addEventListener("resize", recheckAfterLayoutSettles);
    window.visualViewport?.addEventListener("resize", recheckAfterLayoutSettles);
    window.visualViewport?.addEventListener("scroll", recheckAfterLayoutSettles);

    // the scroll element mounts with the TipTap editor (async) — attach the
    // scroll listener + size observers as soon as it exists
    let scrollEl: HTMLElement | null = null;
    let attempts = 0;
    let attachTimer: ReturnType<typeof setTimeout> | null = null;
    let ro: ResizeObserver | null = null;
    const attach = () => {
      scrollEl = editorHandle.current?.getScrollElement() ?? null;
      if (!scrollEl) {
        if (attempts++ < 60) attachTimer = setTimeout(attach, 50);
        return;
      }
      scrollEl.addEventListener("scroll", refreshScrollState, { passive: true });
      ro = new ResizeObserver(refreshScrollState);
      ro.observe(scrollEl);
      if (scrollEl.firstElementChild) ro.observe(scrollEl.firstElementChild);
      refreshScrollState();
    };
    attach();

    const t = setTimeout(refreshScrollState, 250);
    recheckAfterLayoutSettles();
    return () => {
      window.removeEventListener("resize", recheckAfterLayoutSettles);
      window.visualViewport?.removeEventListener("resize", recheckAfterLayoutSettles);
      window.visualViewport?.removeEventListener("scroll", recheckAfterLayoutSettles);
      if (scrollEl) scrollEl.removeEventListener("scroll", refreshScrollState);
      ro?.disconnect();
      if (attachTimer) clearTimeout(attachTimer);
      clearTimeout(settleTimer.id);
      clearTimeout(t);
      cancelAnimationFrame(raf1);
      cancelAnimationFrame(raf2);
    };
  }, [open, refreshScrollState]);

  // re-measure when the note switches or its content/attachments change size
  const contentKey = note ? `${note.id}:${note.content.length}:${note.attachments.length}` : "";
  useEffect(() => {
    if (!open) return;
    refreshScrollState();
    const t = setTimeout(refreshScrollState, 120);
    return () => clearTimeout(t);
  }, [open, contentKey, refreshScrollState]);

  /* --------------------------------------------------- escape to close */

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      if (document.querySelector("[data-radix-popper-content-wrapper]")) return;
      e.preventDefault();
      close();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, close]);

  // V8 (bug #3): system/browser BACK closes the editor first (returns to the
  // list), before being allowed to leave the app
  useBackLayer(open, close);
  useBackLayer(galleryOpen, () => setGalleryOpen(false));

  // reset transient state when switching notes (render-adjust pattern)
  const [prevNoteId, setPrevNoteId] = useState<string | null>(null);
  if (prevNoteId !== editorNoteId) {
    setPrevNoteId(editorNoteId);
    setSearchOpen(false);
    setQuery("");
    setSearchState({ count: 0, active: 0 });
  }

  // clear any in-note search decorations when another note is opened
  useEffect(() => {
    editorHandle.current?.setSearchQuery("");
  }, [editorNoteId]);

  if (!open || !note) return <LightboxHost />;
  const activeNote = note;

  /**
   * V8 fix: an empty checklist note used to seed the editor with the literal
   * markdown "- [ ] ", which tiptap-markdown parsed as a plain bullet item
   * containing the TEXT "[ ]" — so checkboxes never appeared. Seed a real
   * task-list item (HTML) instead; Enter then continues the checklist.
   */
  const EMPTY_TASK_LIST_HTML =
    '<ul data-type="taskList"><li data-type="taskItem" data-checked="false"><p></p></li></ul>';

  const displayValue =
    note.type === "list" && note.content.trim() === ""
      ? EMPTY_TASK_LIST_HTML
      : note.content;

  async function openAttachmentPreview(att: AttachmentDTO) {
    const url = att.url || urlMap.get(att.file) || (await resolveAttachmentUrls(activeNote.dir, [att])).get(att.file) || "";
    if (url) setLightbox({ ...att, url });
    else toast.error("Could not load this image");
  }

  async function openGallery() {
    const urls = await resolveAttachmentUrls(activeNote.dir, activeNote.attachments);
    setGalleryUrls(urls);
    setGalleryOpen(true);
  }

  /* -------------------------------------------------------------------- */
  return (
    <>
      <div
        role="dialog"
        aria-modal="true"
        aria-label={note.title || "Note"}
        className="fixed inset-0 z-50 flex h-[100dvh] flex-col overflow-hidden bg-background text-foreground"
        style={style}
      >
        {/* ---------------- header ---------------- */}
        <header className="flex h-14 shrink-0 items-center gap-1 px-2">
          <button
            type="button"
            aria-label="Back to notes"
            onClick={close}
            className="inline-flex h-10 w-10 items-center justify-center rounded-full transition-transform active:scale-90 hover:bg-black/10 dark:hover:bg-white/10"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>

          {!note.trashed ? (
            <button
              type="button"
              aria-label={note.pinned ? "Unpin note" : "Pin note"}
              onClick={() => patch({ pinned: !note.pinned }, true)}
              className="inline-flex h-10 w-10 items-center justify-center rounded-full transition-transform active:scale-90 hover:bg-black/10 dark:hover:bg-white/10"
            >
              <Pin className={cn("h-5 w-5 rotate-45", note.pinned && "fill-current")} />
            </button>
          ) : null}

          <button
            type="button"
            aria-label={searchOpen ? "Close search" : "Search in note"}
            title="Search in note"
            onClick={() => {
              if (searchOpen) {
                closeSearch();
                setSearchOpen(false);
              } else {
                setSearchOpen(true);
              }
            }}
            className={cn(
              "inline-flex h-10 w-10 items-center justify-center rounded-full transition-transform active:scale-90 hover:bg-black/10 dark:hover:bg-white/10",
              searchOpen && "bg-black/10 dark:bg-white/10"
            )}
          >
            <Search className="h-5 w-5" />
          </button>

          <div className="flex-1" />

          <button
            type="button"
            aria-label="Close"
            onClick={close}
            className="inline-flex h-10 w-10 items-center justify-center rounded-full transition-transform active:scale-90 hover:bg-black/10 dark:hover:bg-white/10"
          >
            <X className="h-5 w-5" />
          </button>
        </header>

        {/* ---------------- in-note search bar ---------------- */}
        {searchOpen ? (
          <div className="mx-3 mb-2 flex shrink-0 items-center gap-1.5 rounded-xl border border-black/10 bg-card px-3 py-2 shadow-sm dark:border-white/10">
            <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
            <input
              autoFocus
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                applySearchQuery(e.target.value);
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  navigateMatch(e.shiftKey ? -1 : 1);
                } else if (e.key === "Escape") {
                  setSearchOpen(false);
                  closeSearch();
                }
              }}
              placeholder="Find in note…"
              aria-label="Find in note"
              className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:opacity-50"
            />
            <span className="shrink-0 text-xs tabular-nums text-muted-foreground" aria-live="polite">
              {query.trim()
                ? searchState.count > 0
                  ? `${searchState.active + 1}/${searchState.count}`
                  : "0/0"
                : ""}
            </span>
            <button
              type="button"
              aria-label="Previous match"
              disabled={searchState.count === 0}
              onClick={() => navigateMatch(-1)}
              className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full hover:bg-black/10 disabled:opacity-30 dark:hover:bg-white/10"
            >
              <ChevronUp className="h-4 w-4" />
            </button>
            <button
              type="button"
              aria-label="Next match"
              disabled={searchState.count === 0}
              onClick={() => navigateMatch(1)}
              className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full hover:bg-black/10 disabled:opacity-30 dark:hover:bg-white/10"
            >
              <ChevronDown className="h-4 w-4" />
            </button>
            <button
              type="button"
              aria-label="Close search"
              onClick={() => {
                setSearchOpen(false);
                closeSearch();
              }}
              className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full hover:bg-black/10 dark:hover:bg-white/10"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        ) : null}

        {/* ---------------- markdown editor ---------------- */}
        <MarkdownEditor
          value={displayValue}
          onChange={(md) => patch({ content: md })}
          fileToUrl={fileToUrl}
          urlToFile={urlToFile}
          onRequestInsertImages={() => {
            // V8.5: opens the picker in ATTACH-ONLY mode — images go to the
            // attachments area; placing them in the body is a separate,
            // explicit action on each thumbnail ("Insert into note").
            fileInputRef.current?.click();
          }}
          onPasteImages={(files) => void attachPickedFiles(files)}
          onSearchResults={onSearchResults}
          handleRef={editorHandle}
          beforeContent={
            <>
              {note.attachments.length > 0 ? (
                <div className="relative mb-2 max-h-32 overflow-x-hidden overflow-y-auto rounded-lg border border-black/10 p-2 [scrollbar-color:rgba(128,128,128,.45)_transparent] [&::-webkit-scrollbar-corner]:bg-transparent dark:border-white/10">
                  <button
                    type="button"
                    aria-label="View all images"
                    title="View all images"
                    onClick={openGallery}
                    className="absolute right-2 top-2 z-10 inline-flex h-8 w-8 items-center justify-center rounded-full bg-black/65 text-white shadow-md transition-colors hover:bg-black/85"
                  >
                    <Images className="h-4 w-4" />
                  </button>
                  <div className="grid min-w-0 grid-cols-[repeat(auto-fill,minmax(5rem,1fr))] gap-2.5 overflow-hidden pr-10">
                    {note.attachments.map((m) => (
                      <EditorThumb
                        key={m.file}
                        note={note}
                        att={m}
                        onOpen={() => void openAttachmentPreview(m)}
                        onEdit={() => {
                          const url = m.url || urlMap.get(m.file) || "";
                          if (url) {
                            openImageEditor(note.id, { ...m, url });
                            return;
                          }
                          void resolveAttachmentUrls(note.dir, [m]).then((map) => {
                            const resolved = map.get(m.file) || "";
                            if (resolved) {
                              openImageEditor(note.id, { ...m, url: resolved });
                            } else {
                              toast.error("Could not load this image");
                            }
                          });
                        }}
                        onRemove={() => {
                          void removeNoteAttachment(note.id, m);
                          toast.success("Attachment deleted");
                        }}
                        onInsert={() => {
                          const url = m.url || urlMap.get(m.file) || "";
                          if (url) {
                            insertAttachmentIntoEditor(m, url);
                          } else {
                            void resolveAttachmentUrls(note.dir, [m]).then((map) => {
                              const resolved = map.get(m.file) || "";
                              registerAttachmentUrl(m, resolved);
                              insertAttachmentIntoEditor(m, resolved);
                            });
                          }
                        }}
                      />
                    ))}
                  </div>
                </div>
              ) : null}
              <div>
                <input
                  className="w-full bg-transparent pb-1 pt-1 text-xl font-medium outline-none placeholder:opacity-40"
                  placeholder="Title"
                  value={note.title}
                  onChange={(e) => patch({ title: e.target.value })}
                  onBlur={() => {
                    if (!isDraft) void flushUpdate(note.id);
                  }}
                />
              </div>
            </>
          }
          placeholder={
            note.type === "list"
              ? "List item — press Enter for the next one…"
              : "Start writing… markdown supported"
          }
          autoFocus
        />

        {galleryOpen ? (
          <div className="fixed inset-0 z-[70] flex flex-col bg-background/98 text-foreground">
            <div className="flex h-14 shrink-0 items-center justify-between border-b border-black/10 px-4 dark:border-white/10">
              <span className="text-sm font-medium">All images</span>
              <button
                type="button"
                aria-label="Close image gallery"
                onClick={() => setGalleryOpen(false)}
                className="inline-flex h-10 w-10 items-center justify-center rounded-full hover:bg-black/10 dark:hover:bg-white/10"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="min-h-0 flex-1 overflow-y-auto p-4">
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                {note.attachments.map((m) => {
                  const url = m.url || galleryUrls.get(m.file) || "";
                  return (
                    <button
                      key={m.file}
                      type="button"
                      aria-label={`View ${m.name}`}
                      onClick={() => {
                        if (url) setLightbox({ ...m, url });
                        else void openAttachmentPreview(m);
                      }}
                      className="relative aspect-square overflow-hidden rounded-xl border border-black/10 bg-black/5 shadow-sm dark:border-white/10"
                    >
                      {url ? (
                        <img src={url} alt={m.name} className="h-full w-full object-cover" />
                      ) : (
                        <div className="h-full w-full animate-pulse bg-black/10" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        ) : null}

        {/* ---------------- jump to top / bottom ---------------- */}
        {scrollable ? (
          <div className="pointer-events-none absolute bottom-20 right-4 z-10 flex flex-col gap-1.5">
            <button
              type="button"
              aria-label="Jump to top"
              title="Jump to top"
              onClick={() => {
                const el = editorHandle.current?.getScrollElement();
                el?.scrollTo({ top: 0, behavior: "smooth" });
              }}
              className={cn(
                "pointer-events-auto inline-flex h-10 w-10 items-center justify-center rounded-full border border-black/10 bg-card/95 text-foreground shadow-lg backdrop-blur transition-all hover:bg-accent dark:border-white/10",
                atTop ? "pointer-events-none opacity-0" : "opacity-100"
              )}
            >
              <ArrowUp className="h-5 w-5" />
            </button>
            <button
              type="button"
              aria-label="Jump to bottom"
              title="Jump to bottom"
              onClick={() => {
                const el = editorHandle.current?.getScrollElement();
                el?.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
              }}
              className={cn(
                "pointer-events-auto inline-flex h-10 w-10 items-center justify-center rounded-full border border-black/10 bg-card/95 text-foreground shadow-lg backdrop-blur transition-all hover:bg-accent dark:border-white/10",
                atBottom ? "pointer-events-none opacity-0" : "opacity-100"
              )}
            >
              <ArrowDown className="h-5 w-5" />
            </button>
          </div>
        ) : null}

        {/* ---------------- bottom toolbar ---------------- */}
        <footer className="flex shrink-0 items-center gap-0.5 border-t border-black/5 px-2 py-1.5 dark:border-white/10">
          {note.trashed ? (
            <>
              <button
                type="button"
                aria-label="Restore note"
                onClick={() => {
                  restoreNote(note.id);
                  close();
                  toast.success("Note restored");
                }}
                className="inline-flex h-10 w-10 items-center justify-center rounded-full hover:bg-black/10 dark:hover:bg-white/10"
              >
                <Undo2 className="h-5 w-5" />
              </button>
              <button
                type="button"
                aria-label="Delete forever"
                onClick={() => {
                  deleteForever(note.id);
                  close();
                }}
                className="inline-flex h-10 w-10 items-center justify-center rounded-full hover:bg-black/10 dark:hover:bg-white/10"
              >
                <TrashIcon className="h-5 w-5" />
              </button>
              <span className="ml-3 text-xs text-muted-foreground">This note is in the trash</span>
            </>
          ) : (
            <>
              <ColorPicker color={note.color} onChange={(c) => patch({ color: c }, true)}>
                <Brush className="h-5 w-5" />
              </ColorPicker>
              <MediaPickPopover
                onPicked={(media) => {
                  void (async () => {
                    // V8 (bug #2): uploads from the attachment picker go to the
                    // attachments area ONLY — they are never auto-inserted
                    // into the note body. Use the thumb's insert button or
                    // the editor toolbar's Insert-image to place them.
                    const atts = await addNoteMedia(note.id, media);
                    for (const att of atts) {
                      const url =
                        att.url ||
                        (await resolveAttachmentUrls(note.dir, [att])).get(att.file) ||
                        "";
                      registerAttachmentUrl(att, url);
                    }
                  })();
                }}
              >
                <ImagePlus className="h-5 w-5" />
              </MediaPickPopover>
              <button
                type="button"
                aria-label={note.type === "list" ? "Hide checkboxes" : "Show checkboxes"}
                onClick={() => {
                  const nextType = note.type === "list" ? "text" : "list";
                  const nextContent =
                    nextType === "list" ? textToListBody(note.content) : listToTextBody(note.content);
                  patch({ type: nextType, content: nextContent }, true);
                }}
                className="inline-flex h-10 w-10 items-center justify-center rounded-full hover:bg-black/10 dark:hover:bg-white/10"
              >
                {note.type === "list" ? (
                  <NotepadText className="h-5 w-5" />
                ) : (
                  <ListChecks className="h-5 w-5" />
                )}
              </button>
              <LabelsPopover note={note}>
                <Tag className="h-5 w-5" />
              </LabelsPopover>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button
                    type="button"
                    aria-label="Move to folder"
                    className="inline-flex h-10 w-10 items-center justify-center rounded-full hover:bg-black/10 dark:hover:bg-white/10"
                  >
                    <FolderInput className="h-5 w-5" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="max-h-64 w-52 overflow-y-auto">
                  <DropdownMenuItem onClick={() => patch({ folderId: null }, true)}>
                    No folder
                  </DropdownMenuItem>
                  {folders.map((f) => (
                    <DropdownMenuItem key={f.id} onClick={() => patch({ folderId: f.id }, true)}>
                      {f.emoji} {f.name}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>

              {note.archived ? (
                <button
                  type="button"
                  aria-label="Unarchive"
                  onClick={() => patch({ archived: false }, true)}
                  className="inline-flex h-10 w-10 items-center justify-center rounded-full hover:bg-black/10 dark:hover:bg-white/10"
                >
                  <ArchiveRestore className="h-5 w-5" />
                </button>
              ) : (
                <button
                  type="button"
                  aria-label="Archive"
                  onClick={() => patch({ archived: true }, true)}
                  className="inline-flex h-10 w-10 items-center justify-center rounded-full hover:bg-black/10 dark:hover:bg-white/10"
                >
                  <Archive className="h-5 w-5" />
                </button>
              )}

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button
                    type="button"
                    aria-label="More options"
                    className="inline-flex h-10 w-10 items-center justify-center rounded-full hover:bg-black/10 dark:hover:bg-white/10"
                  >
                    <MoreVertical className="h-5 w-5" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-56">
                  {vaultOpen ? (
                    note.vaulted ? (
                      <DropdownMenuItem
                        onClick={() => {
                          patch({ vaulted: false, archived: false }, true);
                          close();
                          toast.success("Removed from vault");
                        }}
                      >
                        <LockOpen className="mr-2 h-4 w-4" /> Remove from vault
                      </DropdownMenuItem>
                    ) : (
                      <DropdownMenuItem
                        onClick={() => {
                          patch({ vaulted: true, pinned: false }, true);
                          close();
                          toast.success("Moved to vault", {
                            description: "Only visible while the vault is open",
                          });
                        }}
                      >
                        <Lock className="mr-2 h-4 w-4" /> Move to vault
                      </DropdownMenuItem>
                    )
                  ) : null}
                  <DropdownMenuItem
                    onClick={() => {
                      navigator.clipboard
                        .writeText(`${note.title}\n\n${note.content}`.trim())
                        .then(() => toast.success("Note text copied"));
                    }}
                  >
                    <Copy className="mr-2 h-4 w-4" /> Copy note text
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => {
                      duplicateNote(note.id);
                      close();
                      toast.success("Note copied");
                    }}
                  >
                    <Copy className="mr-2 h-4 w-4" /> Make a copy
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    className="text-destructive focus:text-destructive"
                    onClick={() => {
                      trashNote(note.id);
                      close();
                      toast("Note moved to trash", {
                        action: { label: "Undo", onClick: () => restoreNote(note.id) },
                        duration: 6000,
                      });
                    }}
                  >
                    <TrashIcon className="mr-2 h-4 w-4" /> Delete note
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              <div className="flex-1" />

              <button
                type="button"
                onClick={close}
                className="rounded-full px-4 py-2 text-sm font-medium hover:bg-black/10 dark:hover:bg-white/10"
              >
                Done
              </button>
            </>
          )}
        </footer>

        {/* hidden media input — uploads NEVER touch the note body (V8.5) */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*,.gif"
          multiple
          className="hidden"
          onChange={(e) => {
            if (e.target.files && e.target.files.length > 0) {
              void attachPickedFiles(e.target.files);
            }
            e.target.value = "";
          }}
        />
      </div>

      <LightboxHost />
    </>
  );
}

/** Rendered once at app root so the lightbox works from cards AND the editor. */
export function LightboxHost() {
  const lightbox = useKeepStore((s) => s.lightbox);
  const setLightbox = useKeepStore((s) => s.setLightbox);
  return <Lightbox attachment={lightbox} onClose={() => setLightbox(null)} />;
}
