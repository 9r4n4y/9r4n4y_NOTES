"use client";

import { ThemeProvider as NextThemesProvider } from "next-themes";
import type { ComponentProps } from "react";
import { installAndroidThemeShim } from "@/lib/android-theme";

// V8 (bug #4): inside the Android shell the prefers-color-scheme media query
// is backed by the native uiMode (see src/lib/android-theme.ts). Installing
// at module scope guarantees the shim exists before next-themes reads it.
if (typeof window !== "undefined") {
  installAndroidThemeShim();
}

export function ThemeProvider({ children, ...props }: ComponentProps<typeof NextThemesProvider>) {
  return <NextThemesProvider {...props}>{children}</NextThemesProvider>;
}
