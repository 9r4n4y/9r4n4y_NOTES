"use client";

import { useEffect } from "react";
import { useTheme } from "next-themes";
import { isAndroidShell } from "@/lib/android-theme";

/**
 * V8 (bug #4): keep the Android system bars in sync with the resolved theme.
 * The WebView page paints itself, but the status/navigation-bar chrome is
 * native — this component pushes the correct colors + icon contrast to the
 * shell whenever the app's resolved theme changes (Light/Dark/System).
 * On web this is a no-op (the themeColor <meta> covers mobile browsers).
 */
export function SystemBarsSync() {
  const { resolvedTheme, theme } = useTheme();

  useEffect(() => {
    if (!isAndroidShell()) return;
    if (!theme) return; // wait until hydrated (next-themes resolves after mount)
    const dark = resolvedTheme === "dark";
    const statusHex = dark ? "#111113" : "#f1f3f4";
    const navHex = dark ? "#202124" : "#f1f3f4";
    const bridge = (
      window as unknown as {
        AndroidBridge?: {
          setSystemBars?: (s: string, n: string, darkStatus: boolean, darkNav: boolean) => void;
          setWebViewBackground?: (hex: string) => void;
        };
      }
    ).AndroidBridge;
    try {
      bridge?.setSystemBars?.(statusHex, navHex, !dark, !dark);
      bridge?.setWebViewBackground?.(statusHex);
    } catch {
      /* bridge missing — ignore */
    }
  }, [resolvedTheme, theme]);

  return null;
}
