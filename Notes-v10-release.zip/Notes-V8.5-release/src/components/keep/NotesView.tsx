"use client";

import { useState } from "react";
import { NoteCard } from "./NoteCard";
import { EmptyState } from "./EmptyState";
import { useDragReorder } from "./use-drag-reorder";
import { useKeepStore, filterBySearch, scopeNotes, sortNotes } from "./store";
import { useSettings, DENSITY_CLASS } from "./settings-store";
import { StickyNote } from "lucide-react";
import type { NoteDTO } from "@/lib/types";

function Section({
  title,
  notes,
  layout,
  small,
  dragEnabled,
  onReorderCommit,
}: {
  title?: string;
  notes: NoteDTO[];
  layout: "grid" | "list";
  small?: boolean;
  dragEnabled?: boolean;
  onReorderCommit?: (ids: string[]) => void;
}) {
  const { density } = useSettings();
  const d = DENSITY_CLASS[density];

  // live preview order while dragging (null = follow the store order)
  const [previewIds, setPreviewIds] = useState<string[] | null>(null);
  const ids = previewIds ?? notes.map((n) => n.id);

  const drag = useDragReorder({
    itemIds: ids,
    enabled: !!dragEnabled && notes.length > 1,
    onPreview: setPreviewIds,
    onCommit: (ordered) => {
      setPreviewIds(null);
      onReorderCommit?.(ordered);
    },
  });

  if (notes.length === 0) return null;

  const ordered = ids
    .map((id) => notes.find((n) => n.id === id))
    .filter((n): n is NoteDTO => !!n);

  return (
    <section aria-label={title}>
      {title ? (
        <h2 className={`mb-4 font-medium text-foreground/70 ${small ? "text-xs uppercase tracking-wider" : "text-sm"}`}>
          {title}
        </h2>
      ) : null}
      {layout === "grid" ? (
        // CSS-columns masonry: horizontal gap comes from `gap-*`, vertical
        // breathing room from each card's own margin-bottom (kept intact —
        // do NOT collapse child margins here or notes will touch).
        <div
          ref={drag.containerRef}
          className={`columns-1 ${d.gridGap} sm:columns-2 lg:columns-3 2xl:columns-4`}
        >
          {ordered.map((n, i) => (
            <NoteCard
              key={n.id}
              note={n}
              layout={layout}
              index={i}
              dragEnabled={!!dragEnabled}
              dragging={drag.draggingId === n.id}
              onDragPointerDown={(e) => drag.handlePointerDown(e, n.id)}
            />
          ))}
        </div>
      ) : (
        <div
          ref={drag.containerRef}
          className={`mx-auto flex max-w-4xl flex-col ${d.listGap}`}
        >
          {ordered.map((n, i) => (
            <NoteCard
              key={n.id}
              note={n}
              layout={layout}
              index={i}
              dragEnabled={!!dragEnabled}
              dragging={drag.draggingId === n.id}
              onDragPointerDown={(e) => drag.handlePointerDown(e, n.id)}
            />
          ))}
        </div>
      )}
    </section>
  );
}

export function NotesView({ heading }: { heading?: string }) {
  const notes = useKeepStore((s) => s.notes);
  const view = useKeepStore((s) => s.view);
  const activeFolderId = useKeepStore((s) => s.activeFolderId);
  const activeLabelId = useKeepStore((s) => s.activeLabelId);
  const search = useKeepStore((s) => s.search);
  const layout = useKeepStore((s) => s.layout);
  const reorderNotes = useKeepStore((s) => s.reorderNotes);
  const settings = useSettings();

  let scoped = scopeNotes(notes, view, activeFolderId, activeLabelId);

  // Optional: when searching from the main view, also surface archived notes
  // (setting-controlled; archived notes show an "Archived" badge + unarchive).
  if (search && settings.searchIncludeArchive && view === "notes") {
    const archived = notes.filter((n) => !n.trashed && n.archived && !n.vaulted);
    const seen = new Set(scoped.map((n) => n.id));
    scoped = [...scoped, ...archived.filter((n) => !seen.has(n.id))];
  }

  const results = sortNotes(filterBySearch(scoped, search));

  // drag-and-drop ordering: main list views without an active search filter
  const canReorder = !search && (view === "notes" || view === "folder" || view === "label");

  if (results.length === 0) {
    if (search) {
      return <EmptyState icon={StickyNote} title="No matching notes" subtitle={`Nothing matches "${search}" in this view`} />;
    }
    switch (view) {
      case "vault":
        return <EmptyState icon={StickyNote} title="Your vault is empty" subtitle="Move notes here from a note's menu while the vault is open" />;
      case "archive":
        return <EmptyState icon={StickyNote} title="No archived notes" subtitle="Archive notes to tuck them away without deleting" />;
      case "trash":
        return <EmptyState icon={StickyNote} title="Nothing in trash" subtitle="Deleted notes rest here until you remove them forever" />;
      case "folder":
        return <EmptyState icon={StickyNote} title="This folder is empty" subtitle="Move notes here from a note's menu" />;
      case "label":
        return <EmptyState icon={StickyNote} title="No notes with this label" subtitle="Tag notes from a note's toolbar" />;
      default:
        return <EmptyState icon={StickyNote} title="Notes you add appear here" />;
    }
  }

  const showSections = view === "notes" || view === "folder" || view === "label";
  const pinned = results.filter((n) => n.pinned);
  const others = results.filter((n) => !n.pinned);

  const commit = (ids: string[]) => {
    if (ids.length > 0) reorderNotes(ids);
  };

  if (!showSections || pinned.length === 0) {
    return (
      <div className="space-y-8">
        {heading ? <h1 className="text-sm font-medium uppercase tracking-wider text-foreground/60">{heading}</h1> : null}
        <Section
          notes={results}
          layout={layout}
          dragEnabled={canReorder}
          onReorderCommit={commit}
        />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {heading ? <h1 className="text-sm font-medium uppercase tracking-wider text-foreground/60">{heading}</h1> : null}
      <Section
        title="PINNED"
        notes={pinned}
        layout={layout}
        small
        dragEnabled={canReorder}
        onReorderCommit={commit}
      />
      <Section
        title="OTHERS"
        notes={others}
        layout={layout}
        small
        dragEnabled={canReorder}
        onReorderCommit={commit}
      />
    </div>
  );
}
