"use client";

import type { LucideIcon } from "lucide-react";

export function EmptyState({
  icon: Icon,
  title,
  subtitle,
}: {
  icon: LucideIcon;
  title: string;
  subtitle?: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-24 text-center select-none">
      <div className="mb-4 flex h-24 w-24 items-center justify-center rounded-full bg-black/5 dark:bg-white/5">
        <Icon className="h-10 w-10 text-muted-foreground/60" strokeWidth={1.5} aria-hidden />
      </div>
      <p className="text-lg font-medium text-foreground/80">{title}</p>
      {subtitle ? <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p> : null}
    </div>
  );
}
