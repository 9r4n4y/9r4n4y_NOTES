"use client";

import { CardIconButton, ColorPicker } from "./ColorPicker";
import { LabelsPopover } from "./LabelsPopover";
import { MediaPickPopover } from "./MediaPickPopover";
import { useKeepStore, type NotePatch } from "./store";
import { useSettings, DENSITY_CLASS } from "./settings-store";
import { useAttachmentUrl } from "./attachment-url";
import { noteStyle } from "@/lib/keep-constants";
import { useIsTouch } from "@/hooks/use-is-touch";
import type { AttachmentDTO, NoteDTO } from "@/lib/types";
import { markdownToPlain } from "@/core/markdown";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Archive,
  ArchiveRestore,
  Brush,
  Check,
  ChevronDown,
  ChevronUp,
  Copy,
  FolderInput,
  ImagePlus,
  Lock,
  LockOpen,
  MoreVertical,
  Palette,
  PenLine,
  Pin,
  Undo2,
  Tag,
  Delete as TrashIcon,
} from "lucide-react";
import { useTheme } from "next-themes";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useBackLayer } from "@/lib/back-nav";

const PREVIEW_ITEMS = 5;

/** <img> that lazily resolves an attachment's local file into a display URL. */
function AttImage({
  note,
  att,
  className,
}: {
  note: NoteDTO;
  att: AttachmentDTO;
  className?: string;
}) {
  const url = useAttachmentUrl(note.dir, att);
  if (!url) {
    return <div className={cn("h-full w-full animate-pulse bg-black/5", className)} />;
  }
  return <img src={url} alt={att.name} loading="lazy" className={className} />;
}

/**
 * V8.5: renders `text` with every (case-insensitive) occurrence of the
 * active list-search query wrapped in a <mark class="search-chip"> — the
 * same visual language as the in-note find bar, so every search surface
 * highlights matches the same way.
 */
function HighlightedText({ text, query }: { text: string; query: string }) {
  const q = query.trim();
  if (!q) return <>{text}</>;
  const parts: React.ReactNode[] = [];
  const lower = text.toLowerCase();
  const ql = q.toLowerCase();
  let from = 0;
  let key = 0;
  for (;;) {
    const idx = lower.indexOf(ql, from);
    if (idx === -1) {
      if (from < text.length) parts.push(text.slice(from));
      break;
    }
    if (idx > from) parts.push(text.slice(from, idx));
    parts.push(
      <mark key={key++} className="search-chip">
        {text.slice(idx, idx + ql.length)}
      </mark>
    );
    from = idx + ql.length;
  }
  return <>{parts}</>;
}

export function NoteCard({
  note,
  layout,
  index = 0,
  dragEnabled = false,
  dragging = false,
  onDragPointerDown,
}: {
  note: NoteDTO;
  layout: "grid" | "list";
  index?: number;
  /** drag-and-drop (long-press) props injected by NotesView */
  dragEnabled?: boolean;
  dragging?: boolean;
  onDragPointerDown?: (e: React.PointerEvent) => void;
}) {
  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === "dark";
  const style = noteStyle(note.color, isDark);
  const isTouch = useIsTouch();
  const settings = useSettings();
  const density = DENSITY_CLASS[settings.density];

  const openEditor = useKeepStore((s) => s.openEditor);
  const updateNote = useKeepStore((s) => s.updateNote);
  const toggleItem = useKeepStore((s) => s.toggleItem);
  const duplicateNote = useKeepStore((s) => s.duplicateNote);
  const trashNote = useKeepStore((s) => s.trashNote);
  const restoreNote = useKeepStore((s) => s.restoreNote);
  const deleteForever = useKeepStore((s) => s.deleteForever);
  const addNoteMedia = useKeepStore((s) => s.addNoteMedia);
  const setLightbox = useKeepStore((s) => s.setLightbox);
  const openImageEditor = useKeepStore((s) => s.openImageEditor);
  const folders = useKeepStore((s) => s.folders);
  const vaultOpen = useKeepStore((s) => s.vaultOpen);
  const view = useKeepStore((s) => s.view);
  const search = useKeepStore((s) => s.search);
  const confirmBeforeDelete = settings.confirmBeforeDelete;

  const [confirmDelete, setConfirmDelete] = useState(false);
  // V8 (bug #3): BACK cancels the delete confirmation
  useBackLayer(confirmDelete, () => setConfirmDelete(false));

  // expandable preview state (read full text without opening the editor)
  const [textExpanded, setTextExpanded] = useState(false);
  const [itemsExpanded, setItemsExpanded] = useState(false);
  const [textClamped, setTextClamped] = useState(false);
  const textRef = useRef<HTMLParagraphElement | null>(null);

  const main = note.attachments[0];
  const rest = note.attachments.slice(1);
  const maxPreviewItems = itemsExpanded ? 200 : PREVIEW_ITEMS;
  const shownItems = note.items.slice(0, maxPreviewItems);
  const extraItems = note.items.length - shownItems.length;

  // detect when the text preview is actually being clamped
  useEffect(() => {
    const el = textRef.current;
    if (!el) {
      setTextClamped(false);
      return;
    }
    const check = () => setTextClamped(el.scrollHeight > el.clientHeight + 2);
    check();
    // re-check when layout-affecting inputs change
    const ro = new ResizeObserver(check);
    ro.observe(el);
    return () => ro.disconnect();
  }, [note.content, note.type, layout, textExpanded]);

  const isTrash = note.trashed;
  const inVaultView = view === "vault";

  function patch(p: NotePatch, immediate = false) {
    updateNote(note.id, p, immediate);
  }

  function handleDelete() {
    if (confirmBeforeDelete) {
      setConfirmDelete(true);
      return;
    }
    trashNote(note.id);
    toast("Note moved to trash", {
      description: note.title || "Untitled note",
      action: { label: "Undo", onClick: () => restoreNote(note.id) },
      duration: 6000,
    });
  }

  const checklist =
    note.type !== "list" ? null : (
      <div className="space-y-0.5">
        {shownItems.map((item) => (
          <button
            key={item.id}
            type="button"
            className="flex w-full items-start gap-2.5 rounded px-1 py-0.5 text-left transition-colors hover:bg-black/5 dark:hover:bg-white/5"
            onClick={(e) => {
              e.stopPropagation();
              toggleItem(note.id, item.id);
            }}
          >
            <span
              className={cn(
                "mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-sm border-2 transition-colors",
                item.checked ? "border-current bg-current/20" : "border-current/60"
              )}
            >
              {item.checked ? <Check className="h-3 w-3" /> : null}
            </span>
            <span
              className={cn(
                "min-h-4 text-sm leading-5",
                item.checked && "line-through opacity-50"
              )}
            >
              {item.text ? <HighlightedText text={item.text} query={search} /> : "\u00A0"}
            </span>
          </button>
        ))}
        {extraItems > 0 ? (
          <button
            type="button"
            className="flex items-center gap-1 px-1 pt-1 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground"
            aria-label={`Show ${extraItems} more items`}
            onClick={(e) => {
              e.stopPropagation();
              setItemsExpanded(true);
            }}
          >
            <ChevronDown className="h-3.5 w-3.5" />
            Show {extraItems} more item{extraItems > 1 ? "s" : ""}
          </button>
        ) : itemsExpanded && note.items.length > PREVIEW_ITEMS ? (
          <button
            type="button"
            className="flex items-center gap-1 px-1 pt-1 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground"
            aria-label="Show fewer items"
            onClick={(e) => {
              e.stopPropagation();
              setItemsExpanded(false);
            }}
          >
            <ChevronUp className="h-3.5 w-3.5" />
            Show less
          </button>
        ) : null}
      </div>
    );

  const showActions = isTouch || isTrash;

  return (
    <div
      role="button"
      tabIndex={0}
      aria-label={note.title || "Note"}
      data-note-id={dragEnabled ? note.id : undefined}
      onPointerDown={onDragPointerDown}
      onClick={() => openEditor(note.id)}
      onKeyDown={(e) => {
        if (e.key === "Enter" && !e.shiftKey) {
          e.preventDefault();
          openEditor(note.id);
        }
      }}
      className={cn(
        "note-card group relative block w-full cursor-pointer break-inside-avoid overflow-hidden rounded-xl border border-black/5 shadow-sm transition-[box-shadow,transform,translate] duration-200 hover:-translate-y-0.5 hover:shadow-lg dark:border-white/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
        density.cardMb,
        layout === "list" && "mb-0",
        dragging && "scale-[1.03] opacity-95 shadow-2xl ring-2 ring-primary/50 duration-0"
      )}
      style={{
        ...style,
        animationDelay: settings.animations ? `${Math.min(index, 12) * 35}ms` : undefined,
      }}
    >
      {/* media */}
      {main ? (
        <div className="relative" onClick={(e) => e.stopPropagation()}>
          <div className="relative">
            <button
              type="button"
              className="block w-full"
              aria-label="Open media"
              onClick={() => setLightbox(main)}
            >
              <AttImage
                note={note}
                att={main}
                className={cn(
                  "w-full object-cover transition-transform duration-300",
                  layout === "grid" ? "max-h-60" : "max-h-40"
                )}
              />
            </button>
            {main.kind === "gif" ? (
              <span className="absolute left-2 top-2 rounded bg-black/60 px-1.5 py-0.5 text-[10px] font-bold tracking-wide text-white">
                GIF
              </span>
            ) : null}
            <button
              type="button"
              aria-label="Edit image"
              onClick={(e) => {
                e.stopPropagation();
                openImageEditor(note.id, main);
              }}
              className={cn(
                "absolute bottom-2 left-2 flex h-8 w-8 items-center justify-center rounded-full bg-black/55 text-white shadow-sm transition-all hover:bg-black/75 focus-visible:opacity-100",
                isTouch ? "opacity-90" : "opacity-0 group-hover:opacity-100"
              )}
            >
              <PenLine className="h-4 w-4" />
            </button>
          </div>
          {rest.length > 0 ? (
            <div className="flex gap-1.5 overflow-x-auto px-2 py-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
              {rest.map((att) => (
                <button
                  key={att.id}
                  type="button"
                  className="relative h-12 w-12 shrink-0 overflow-hidden rounded-md border border-black/10"
                  aria-label={`Open ${att.name}`}
                  onClick={() => setLightbox(att)}
                >
                  <AttImage note={note} att={att} className="h-full w-full object-cover" />
                  {att.kind === "gif" ? (
                    <span className="absolute bottom-0 right-0 rounded-tl bg-black/60 px-1 text-[8px] font-bold text-white">
                      GIF
                    </span>
                  ) : null}
                </button>
              ))}
            </div>
          ) : null}
        </div>
      ) : null}

      {/* pin */}
      {!isTrash ? (
        <button
          type="button"
          aria-label={note.pinned ? "Unpin note" : "Pin note"}
          onClick={(e) => {
            e.stopPropagation();
            patch({ pinned: !note.pinned }, true);
          }}
          className={cn(
            "absolute right-2 top-2 flex h-9 w-9 items-center justify-center rounded-full transition-all hover:bg-black/10 active:scale-90 dark:hover:bg-white/10",
            note.pinned || isTouch ? "opacity-100" : "opacity-0 group-hover:opacity-100"
          )}
        >
          {note.pinned ? <Pin className="h-4 w-4 rotate-45 fill-current" /> : <Pin className="h-4 w-4 rotate-45" />}
        </button>
      ) : null}

      <div className={cn("px-4", main ? "pt-3 pb-3" : "py-3")}>
        {note.title ? (
          <p className="mb-1 pr-10 text-[0.95rem] font-medium leading-snug break-words">
            <HighlightedText text={note.title} query={search} />
          </p>
        ) : null}

        {note.type === "text" && note.content ? (
          <>
            <p
              ref={textRef}
              className={cn(
                "whitespace-pre-wrap break-words text-sm leading-relaxed",
                !textExpanded && (layout === "grid" ? "line-clamp-[12]" : "line-clamp-4")
              )}
            >
              <HighlightedText text={markdownToPlain(note.content) || ""} query={search} />
            </p>
            {(textClamped || textExpanded) && note.content.length > 0 ? (
              <button
                type="button"
                className="mt-1 flex items-center gap-1 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground"
                aria-label={textExpanded ? "Show less" : "Read full note"}
                onClick={(e) => {
                  e.stopPropagation();
                  setTextExpanded((v) => !v);
                }}
              >
                {textExpanded ? (
                  <>
                    <ChevronUp className="h-3.5 w-3.5" /> Show less
                  </>
                ) : (
                  <>
                    <ChevronDown className="h-3.5 w-3.5" /> Read full note
                  </>
                )}
              </button>
            ) : null}
          </>
        ) : null}

        {checklist}

        {/* chips */}
        {(note.labels.length > 0 || note.folder || note.archived) ? (
          <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
            {note.folder ? (
              <span className="inline-flex items-center gap-1 rounded-md border border-black/10 bg-black/5 px-2 py-0.5 text-xs dark:border-white/15 dark:bg-white/10">
                <FolderInput className="h-3 w-3" />
                {note.folder.emoji} {note.folder.name}
              </span>
            ) : null}
            {note.labels.map((l) => (
              <span
                key={l.id}
                className="rounded-md border border-black/10 bg-black/5 px-2 py-0.5 text-xs dark:border-white/15 dark:bg-white/10"
              >
                {l.name}
              </span>
            ))}
            {note.archived && !isTrash ? (
              <span className="rounded-md border border-amber-500/30 bg-amber-500/10 px-2 py-0.5 text-xs font-medium text-amber-700 dark:text-amber-300">
                Archived
              </span>
            ) : null}
          </div>
        ) : null}

        {/* actions — always visible on touch devices (hover doesn't exist there) */}
        <div
          className={cn(
            "mt-2 flex items-center gap-0.5 transition-opacity duration-200",
            showActions ? "opacity-100" : "opacity-0 group-hover:opacity-100 focus-within:opacity-100"
          )}
          onClick={(e) => e.stopPropagation()}
        >
          {isTrash ? (
            <>
              <CardIconButton label="Restore note" colorKey={note.color} onClick={() => restoreNote(note.id)}>
                <Undo2 className="h-4 w-4" />
              </CardIconButton>
              <CardIconButton
                label="Delete forever"
                colorKey={note.color}
                onClick={() => setConfirmDelete(true)}
              >
                <TrashIcon className="h-4 w-4" />
              </CardIconButton>
            </>
          ) : (
            <>
              <ColorPicker
                color={note.color}
                colorKey={note.color}
                onChange={(c) => patch({ color: c }, true)}
              >
                <Brush className="h-4 w-4" />
              </ColorPicker>
              {note.archived ? (
                <CardIconButton
                  label="Unarchive"
                  colorKey={note.color}
                  onClick={() => patch({ archived: false }, true)}
                >
                  <ArchiveRestore className="h-4 w-4" />
                </CardIconButton>
              ) : (
                <CardIconButton
                  label="Archive"
                  colorKey={note.color}
                  onClick={() => patch({ archived: true }, true)}
                >
                  <Archive className="h-4 w-4" />
                </CardIconButton>
              )}
              <MediaPickPopover
                colorKey={note.color}
                onPicked={(media) => void addNoteMedia(note.id, media)}
              >
                <ImagePlus className="h-4 w-4" />
              </MediaPickPopover>
              <LabelsPopover note={note}>
                <Tag className="h-4 w-4" />
              </LabelsPopover>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button
                    type="button"
                    aria-label="More options"
                    className="inline-flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-black/10 active:scale-90 dark:hover:bg-white/10"
                  >
                    <MoreVertical className="h-4 w-4" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-56">
                  <DropdownMenuSub>
                    <DropdownMenuSubTrigger>
                      <FolderInput className="mr-2 h-4 w-4" /> Move to folder
                    </DropdownMenuSubTrigger>
                    <DropdownMenuSubContent className="max-h-64 overflow-y-auto">
                      <DropdownMenuItem onClick={() => patch({ folderId: null }, true)}>
                        No folder
                      </DropdownMenuItem>
                      {folders.map((f) => (
                        <DropdownMenuItem
                          key={f.id}
                          onClick={() => patch({ folderId: f.id }, true)}
                        >
                          {f.emoji} {f.name}
                          {note.folderId === f.id ? <Check className="ml-auto h-4 w-4" /> : null}
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuSubContent>
                  </DropdownMenuSub>
                  {vaultOpen ? (
                    inVaultView ? (
                      <DropdownMenuItem
                        onClick={() => {
                          patch({ vaulted: false, archived: false }, true);
                          toast.success("Removed from vault");
                        }}
                      >
                        <LockOpen className="mr-2 h-4 w-4" /> Remove from vault
                      </DropdownMenuItem>
                    ) : (
                      <DropdownMenuItem
                        onClick={() => {
                          patch({ vaulted: true, pinned: false }, true);
                          toast.success("Moved to vault", {
                            description: "Only visible while the vault is open",
                          });
                        }}
                      >
                        <Lock className="mr-2 h-4 w-4" /> Move to vault
                      </DropdownMenuItem>
                    )
                  ) : null}
                  <DropdownMenuItem
                    onClick={() => {
                      navigator.clipboard
                        .writeText(`${note.title}\n\n${note.content}`.trim())
                        .then(() => toast.success("Note text copied"))
                        .catch(() => toast.error("Could not copy"));
                    }}
                  >
                    <Copy className="mr-2 h-4 w-4" /> Copy note text
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => {
                      duplicateNote(note.id);
                      toast.success("Note copied");
                    }}
                  >
                    <Copy className="mr-2 h-4 w-4" /> Make a copy
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    className="text-destructive focus:text-destructive"
                    onClick={handleDelete}
                  >
                    <TrashIcon className="mr-2 h-4 w-4" /> Delete note
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <span className="ml-auto hidden items-center gap-1 pr-1 text-[11px] opacity-50 sm:flex">
                <Palette className="h-3 w-3" /> {note.attachments.length > 0 ? `${note.attachments.length} media` : ""}
              </span>
            </>
          )}
        </div>
      </div>

      <AlertDialog open={confirmDelete} onOpenChange={setConfirmDelete}>
        <AlertDialogContent onClick={(e) => e.stopPropagation()}>
          <AlertDialogHeader>
            <AlertDialogTitle>{isTrash ? "Delete forever?" : "Move to trash?"}</AlertDialogTitle>
            <AlertDialogDescription>
              {isTrash
                ? "This note and its media will be permanently deleted. This action cannot be undone."
                : "The note will be moved to trash. You can restore it from there anytime."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={() => {
                if (isTrash) {
                  deleteForever(note.id);
                } else {
                  trashNote(note.id);
                  toast("Note moved to trash", {
                    description: note.title || "Untitled note",
                    action: { label: "Undo", onClick: () => restoreNote(note.id) },
                    duration: 6000,
                  });
                }
              }}
            >
              {isTrash ? "Delete forever" : "Move to trash"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export type { AttachmentDTO };
