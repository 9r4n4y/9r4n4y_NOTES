"use client";

import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { prepareMedia, fetchMediaFromUrl, type PendingMediaBlob } from "./media";
import { ImagePlus, Loader2, Link2, Upload } from "lucide-react";
import { useRef, useState } from "react";
import { toast } from "sonner";

/**
 * Popover to add media: upload files (images / GIFs) or paste a URL.
 * Everything is stored locally inside the note's attachment/ folder —
 * calls onPicked with locally-storable blobs.
 */
export function MediaPickPopover({
  onPicked,
  children,
  colorKey,
}: {
  onPicked: (media: PendingMediaBlob[]) => void;
  children: React.ReactNode;
  colorKey?: string;
}) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [url, setUrl] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  async function handleFiles(files: FileList | null) {
    if (!files || files.length === 0) return;
    setBusy(true);
    try {
      const media = await prepareMedia(Array.from(files));
      onPicked(media);
      toast.success(
        media.length === 1
          ? "Image added"
          : `${media.length} files added`
      );
      setOpen(false);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not add the files");
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  async function handleUrl() {
    if (!url.trim()) return;
    setBusy(true);
    try {
      const media = await fetchMediaFromUrl(url.trim());
      onPicked([media]);
      toast.success("Image added from URL");
      setUrl("");
      setOpen(false);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not fetch that URL");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          type="button"
          aria-label="Add image or GIF"
          onClick={(e) => e.stopPropagation()}
          className="inline-flex h-9 w-9 items-center justify-center rounded-full transition-colors hover:bg-black/10 dark:hover:bg-white/10"
        >
          {children}
        </button>
      </PopoverTrigger>
      <PopoverContent align="start" side="top" className="w-80 p-0" onClick={(e) => e.stopPropagation()}>
        <Tabs defaultValue="upload">
          <TabsList className="grid w-full grid-cols-2 rounded-b-none">
            <TabsTrigger value="upload" className="gap-1.5 text-xs">
              <Upload className="h-3.5 w-3.5" /> Upload
            </TabsTrigger>
            <TabsTrigger value="url" className="gap-1.5 text-xs">
              <Link2 className="h-3.5 w-3.5" /> By URL
            </TabsTrigger>
          </TabsList>
          <div className="p-4">
            <TabsContent value="upload" className="mt-0">
              <input
                ref={fileRef}
                type="file"
                accept="image/*,.gif"
                multiple
                className="hidden"
                onChange={(e) => handleFiles(e.target.files)}
              />
              <button
                type="button"
                disabled={busy}
                onClick={() => fileRef.current?.click()}
                className="flex w-full flex-col items-center gap-2 rounded-lg border-2 border-dashed border-border px-4 py-6 text-center transition-colors hover:bg-accent disabled:opacity-60"
              >
                {busy ? (
                  <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                ) : (
                  <ImagePlus className="h-6 w-6 text-muted-foreground" />
                )}
                <span className="text-sm font-medium">
                  {busy ? "Adding…" : "Choose images or GIFs"}
                </span>
                <span className="text-xs text-muted-foreground">
                  Saved into the note's attachment folder · multiple allowed
                </span>
              </button>
            </TabsContent>
            <TabsContent value="url" className="mt-0 space-y-3">
              <Input
                placeholder="https://example.com/animation.gif"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleUrl();
                }}
              />
              <Button size="sm" className="w-full" disabled={busy || !url.trim()} onClick={handleUrl}>
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Add from URL"}
              </Button>
            </TabsContent>
          </div>
        </Tabs>
      </PopoverContent>
    </Popover>
  );
}
