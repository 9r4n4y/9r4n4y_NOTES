"use client";

import { useEffect, useState } from "react";
import type { AttachmentDTO } from "@/core/types";
import { getRepo } from "./store";

let repoCache: ReturnType<typeof getRepo> | null = null;
function repo() {
  if (!repoCache) repoCache = getRepo();
  return repoCache;
}

/**
 * Resolves an attachment's display URL (object URL backed by the local file).
 * AttachmentDTOs loaded during a disk scan carry url === "" — this hook loads
 * the bytes lazily and keeps them cached in the repository.
 */
export function useAttachmentUrl(
  dir: string,
  att: AttachmentDTO | null | undefined
): string {
  const fileKey = att ? `${dir}/${att.file}` : "";
  const [loaded, setLoaded] = useState<{ key: string; url: string } | null>(null);
  const url = att ? att.url || (loaded?.key === fileKey ? loaded.url : "") : "";

  useEffect(() => {
    if (!att || att.url) return;
    let alive = true;
    repo()
      .ensureAttachmentUrl(dir, att.file)
      .then((u) => {
        if (alive && u) setLoaded({ key: fileKey, url: u });
      })
      .catch(() => undefined);
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fileKey, att?.url]);

  return url;
}

/** Resolve all of a note's attachments (used before opening the editor). */
export async function resolveAttachmentUrls(
  dir: string,
  attachments: AttachmentDTO[]
): Promise<Map<string, string>> {
  const map = new Map<string, string>();
  await Promise.all(
    attachments.map(async (att) => {
      const url = att.url || (await repo().ensureAttachmentUrl(dir, att.file));
      if (url) map.set(att.file, url);
    })
  );
  return map;
}
