"use client";

import { Button } from "@/components/ui/button";
import { useKeepStore } from "./store";
import { cn } from "@/lib/utils";
import {
  Archive,
  Folder as FolderIcon,
  StickyNote,
  Lock,
  Pencil,
  Plus,
  Tags,
  Trash2,
} from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import type { LucideIcon } from "lucide-react";
import { toast } from "sonner";

interface NavItem {
  key: string;
  label: string;
  icon: LucideIcon;
}

const MAIN_NAV: NavItem[] = [
  { key: "notes", label: "Notes", icon: StickyNote },
  { key: "folders", label: "Folders", icon: FolderIcon },
  { key: "archive", label: "Archive", icon: Archive },
  { key: "trash", label: "Trash", icon: Trash2 },
];

const VAULT_NAV: NavItem = { key: "vault", label: "Vault", icon: Lock };

export function Sidebar({
  open,
  mobileOpen,
  onCloseMobile,
  onNewFolder,
  onManageLabels,
}: {
  open: boolean;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  onNewFolder: () => void;
  onManageLabels: () => void;
}) {
  const view = useKeepStore((s) => s.view);
  const activeFolderId = useKeepStore((s) => s.activeFolderId);
  const activeLabelId = useKeepStore((s) => s.activeLabelId);
  const setView = useKeepStore((s) => s.setView);
  const folders = useKeepStore((s) => s.folders);
  const labels = useKeepStore((s) => s.labels);
  const notes = useKeepStore((s) => s.notes);
  const vaultOpen = useKeepStore((s) => s.vaultOpen);
  const closeVault = useKeepStore((s) => s.closeVault);

  const countFor = (key: string) => {
    switch (key) {
      case "notes":
        return notes.filter((n) => !n.trashed && !n.archived && !n.vaulted).length;
      case "archive":
        return notes.filter((n) => n.archived && !n.trashed && !n.vaulted).length;
      case "trash":
        return notes.filter((n) => n.trashed).length;
      case "vault":
        return notes.filter((n) => n.vaulted && !n.trashed).length;
      default:
        return undefined;
    }
  };

  const isActive = (key: string) => {
    if (key === "folders") return view === "folders";
    return view === key;
  };

  function go(key: string) {
    setView(key as never);
    onCloseMobile();
  }

  function renderButton(
    item: { key: string; label: string; icon: LucideIcon },
    active: boolean,
    onClick: () => void,
    trailing?: React.ReactNode
  ) {
    const content = (
      <button
        type="button"
        onClick={onClick}
        className={cn(
          "flex h-10 items-center gap-3 rounded-r-full pl-5 pr-4 text-sm transition-colors",
          open || mobileOpen ? "w-full" : "mx-auto w-10 justify-center rounded-full px-0",
          active
            ? "bg-[#fef7e0] font-medium text-foreground dark:bg-[#004a8d]/60 dark:text-white"
            : "hover:bg-accent"
        )}
      >
        <item.icon className={cn("h-5 w-5 shrink-0", active ? "text-current" : "text-foreground/70")} />
        {open || mobileOpen ? (
          <>
            <span className="flex-1 truncate text-left">{item.label}</span>
            {trailing}
          </>
        ) : null}
      </button>
    );
    if (!(open || mobileOpen)) {
      return (
        <Tooltip key={item.key}>
          <TooltipTrigger asChild>{content}</TooltipTrigger>
          <TooltipContent side="right" className="text-xs">
            {item.label}
          </TooltipContent>
        </Tooltip>
      );
    }
    return <div key={item.key}>{content}</div>;
  }

  return (
    <>
      {/* mobile scrim */}
      {mobileOpen ? (
        <div
          className="fixed inset-0 z-40 bg-black/40 md:hidden"
          onClick={onCloseMobile}
          aria-hidden
        />
      ) : null}

      <nav
        aria-label="Main navigation"
        className={cn(
          "z-50 flex shrink-0 flex-col gap-0.5 overflow-y-auto pb-6 pt-1",
          // mobile: fixed drawer
          "fixed bottom-0 left-0 top-16 w-64 bg-background transition-transform md:sticky md:top-16 md:h-[calc(100vh-4rem)] md:translate-x-0 md:bg-transparent",
          mobileOpen ? "translate-x-0" : "-translate-x-full",
          open ? "md:w-64" : "md:w-[4.5rem]"
        )}
      >
        {MAIN_NAV.map((item) => renderButton(item, isActive(item.key), () => go(item.key), countFor(item.key) ? (
          <span className="text-xs text-muted-foreground">{countFor(item.key)}</span>
        ) : undefined))}

        {/* Secret vault — only visible while unlocked */}
        {vaultOpen
          ? renderButton(
              VAULT_NAV,
              view === "vault",
              () => go("vault"),
              <span
                role="button"
                tabIndex={0}
                aria-label="Lock vault"
                title="Lock vault"
                className="inline-flex cursor-pointer rounded-full p-1 hover:bg-black/10 dark:hover:bg-white/10"
                onClick={(e) => {
                  e.stopPropagation();
                  closeVault();
                  onCloseMobile();
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.stopPropagation();
                    closeVault();
                    onCloseMobile();
                  }
                }}
              >
                {countFor("vault") || ""}
                <Lock className="h-3.5 w-3.5" />
              </span>
            )
          : null}

        {open || mobileOpen ? (
          <div className="mt-4 px-5">
            <div className="flex items-center justify-between">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Folders
              </p>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                aria-label="New folder"
                onClick={() => {
                  onNewFolder();
                  onCloseMobile();
                }}
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ) : null}

        {folders.map((f) =>
          renderButton(
            { key: f.id, label: `${f.name}`, icon: (() => <span>{f.emoji}</span>) as unknown as LucideIcon },
            view === "folder" && activeFolderId === f.id,
            () => {
              setView("folder", f.id);
              onCloseMobile();
            },
            <span className="text-xs text-muted-foreground">
              {notes.filter((n) => !n.trashed && !n.archived && !n.vaulted && n.folderId === f.id).length || ""}
            </span>
          )
        )}

        {open || mobileOpen ? (
          <div className="mt-4 px-5">
            <div className="flex items-center justify-between">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Labels
              </p>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                aria-label="Edit labels"
                onClick={() => {
                  onManageLabels();
                  onCloseMobile();
                }}
              >
                <Pencil className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>
        ) : null}

        {labels.map((l) =>
          renderButton(
            { key: l.id, label: l.name, icon: Tags },
            view === "label" && activeLabelId === l.id,
            () => {
              setView("label", l.id);
              onCloseMobile();
            },
            <span className="text-xs text-muted-foreground">
              {notes.filter((n) => !n.trashed && !n.archived && !n.vaulted && n.labels.some((nl) => nl.id === l.id)).length || ""}
            </span>
          )
        )}

        {labels.length === 0 && (open || mobileOpen) ? (
          <button
            type="button"
            onClick={() => {
              onManageLabels();
              onCloseMobile();
              toast("Create your first label here", { description: "Labels let you tag and filter notes." });
            }}
            className="mx-4 mt-1 rounded-md px-2 py-2 text-left text-xs text-muted-foreground hover:bg-accent"
          >
            + Create labels to tag notes
          </button>
        ) : null}
      </nav>
    </>
  );
}
