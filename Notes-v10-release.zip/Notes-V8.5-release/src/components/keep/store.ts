"use client";

import { create } from "zustand";
import type {
  AttachmentDTO,
  ChecklistItemDTO,
  FolderDTO,
  LabelDTO,
  NoteDTO,
  NoteType,
  ViewKind,
} from "@/core/types";
import {
  parseTaskItems,
  setTaskText,
  toggleTaskLine,
} from "@/core/markdown";
import { getFS, switchToOpfs } from "@/core/fs";
import { NoteRepository, type PendingMedia } from "@/core/repo";
import {
  readVaultSession,
  writeVaultSession,
  vaultCodeExists,
  verifyVaultCode,
} from "@/lib/vault";

export interface NotePatch {
  title?: string;
  content?: string;
  type?: NoteType;
  color?: string;
  pinned?: boolean;
  archived?: boolean;
  trashed?: boolean;
  vaulted?: boolean;
  folderId?: string | null;
  labels?: LabelDTO[];
  items?: ChecklistItemDTO[];
}

export type CreateNoteInput = NotePatch;

export type StorageStatus = "loading" | "setup" | "reauth" | "ready" | "error";

export const DRAFT_ID = "__draft__";

interface KeepState {
  notes: NoteDTO[];
  folders: FolderDTO[];
  labels: LabelDTO[];
  loaded: boolean;
  loadError: boolean;

  // ---- local storage plumbing ----
  storageStatus: StorageStatus;
  storageKind: "web" | "opfs" | "android" | null;
  rootLabel: string;
  storageError: string;
  /** bumped after every successful (re)scan so views can react */
  scanVersion: number;

  chooseFolder: () => Promise<void>;
  selectInAppStorage: () => Promise<void>;
  reauthorize: () => Promise<void>;
  changeFolder: () => Promise<void>;
  rescan: () => Promise<void>;
  bootstrap: () => Promise<void>;

  view: ViewKind;
  activeFolderId: string | null;
  activeLabelId: string | null;
  search: string;
  layout: "grid" | "list";
  editorNoteId: string | null;
  /** in-memory only note being composed; written to disk on first content */
  draftNote: NoteDTO | null;
  /** previous main views for back navigation (newest last) */
  viewHistory: { view: ViewKind; activeFolderId: string | null; activeLabelId: string | null }[];
  lightbox: AttachmentDTO | null;
  vaultOpen: boolean;
  vaultCodePrompt: boolean;
  settingsOpen: boolean;
  setSettingsOpen: (o: boolean) => void;
  tryOpenVault: () => Promise<void>;
  closeVault: () => void;
  resolveVaultCode: (code: string) => Promise<boolean>;
  setVaultCodePrompt: (o: boolean) => void;
  setLightbox: (a: AttachmentDTO | null) => void;
  imageEditor: { noteId: string; att: AttachmentDTO } | null;
  openImageEditor: (noteId: string, att: AttachmentDTO) => void;
  closeImageEditor: () => void;
  saveEditedImage: (noteId: string, att: AttachmentDTO, blob: Blob) => Promise<void>;

  setView: (view: ViewKind, id?: string | null) => void;
  setSearch: (s: string) => void;
  setLayout: (l: "grid" | "list") => void;

  /** open the editor on an existing note, or start a brand-new draft */
  openEditor: (id: string | null) => void;
  beginNewNote: (opts?: { type?: NoteType; content?: string; title?: string }) => void;

  createNote: (input: CreateNoteInput) => Promise<NoteDTO | null>;
  updateNote: (id: string, patch: NotePatch, immediate?: boolean) => void;
  flushUpdate: (id: string) => Promise<void>;
  flushAll: () => Promise<void>;
  /** internal: create the draft note on disk as soon as it has content */
  __ensureDraftMaterialized: () => Promise<NoteDTO | null>;
  toggleItem: (noteId: string, itemId: string) => void;
  toggleLabel: (noteId: string, label: LabelDTO) => void;

  addNoteMedia: (noteId: string, files: { blob: Blob; name: string }[]) => Promise<AttachmentDTO[]>;
  removeNoteAttachment: (noteId: string, att: AttachmentDTO) => Promise<void>;
  renameNoteAttachment: (noteId: string, att: AttachmentDTO, newName: string) => Promise<void>;

  trashNote: (id: string) => Promise<void>;
  restoreNote: (id: string) => Promise<void>;
  deleteForever: (id: string) => Promise<void>;
  emptyTrash: () => Promise<void>;
  duplicateNote: (id: string) => Promise<void>;
  reorderNotes: (ids: string[]) => Promise<void>;

  createFolder: (name: string, emoji: string, color: string) => Promise<FolderDTO | null>;
  updateFolder: (id: string, patch: Partial<Pick<FolderDTO, "name" | "emoji" | "color">>) => Promise<void>;
  deleteFolder: (id: string) => Promise<void>;

  /**
   * Back-navigation: pop the previous main view (Android back / browser back).
   * Returns true when there was history to pop (back was consumed).
   */
  backView: () => boolean;

  createLabel: (name: string) => Promise<{ ok: boolean; error?: string }>;
  renameLabel: (id: string, name: string) => Promise<{ ok: boolean; error?: string }>;
  deleteLabel: (id: string) => Promise<void>;
}

// ---------------------------------------------------------------- storage

let repo: NoteRepository | null = null;

export function getRepo(): NoteRepository {
  if (!repo) repo = new NoteRepository(getFS());
  return repo;
}

// ---- debounced per-note save queue (module level, outside React) ----
const pendingSaves = new Map<
  string,
  { timer: ReturnType<typeof setTimeout> | null; patch: NotePatch }
>();

// draft-note media buffer (blobs picked before the note exists on disk)
let draftMedia: PendingMedia[] = [];
let materializeChain: Promise<NoteDTO | null> | null = null;
/** id of the note a draft just materialized into (catches in-flight edits) */
let lastMaterializedId: string | null = null;

/**
 * Persist a note to disk and keep the store's `dir` in sync (the on-disk
 * folder may be renamed to follow the V8 metadata storage name).
 */
async function persistNote(note: NoteDTO): Promise<void> {
  try {
    const dir = await getRepo().saveNote(note);
    if (dir !== note.dir) {
      useKeepStore.setState((s) => ({
        notes: s.notes.map((n) => (n.id === note.id ? { ...n, dir } : n)),
      }));
    }
  } catch (e) {
    console.error("persistNote failed", note.dir, e);
  }
}

function applyPatchToNote(n: NoteDTO, patch: NotePatch): NoteDTO {
  const next: NoteDTO = { ...n };
  if (patch.title !== undefined) next.title = patch.title;
  if (patch.content !== undefined) {
    next.content = patch.content;
    next.items = parseTaskItems(patch.content);
  }
  if (patch.type !== undefined) next.type = patch.type;
  if (patch.color !== undefined) next.color = patch.color;
  if (patch.pinned !== undefined) next.pinned = patch.pinned;
  if (patch.archived !== undefined) next.archived = patch.archived;
  if (patch.trashed !== undefined) next.trashed = patch.trashed;
  if (patch.vaulted !== undefined) next.vaulted = patch.vaulted;
  if (patch.folderId !== undefined) next.folderId = patch.folderId;
  if (patch.labels !== undefined) next.labels = patch.labels;
  next.updatedAt = new Date().toISOString();
  return next;
}

/** Does the draft hold anything worth putting on disk? */
function draftHasContent(n: NoteDTO | null): boolean {
  if (!n) return false;
  return (
    n.title.trim().length > 0 ||
    n.content.trim().length > 0 ||
    n.attachments.length > 0 ||
    draftMedia.length > 0
  );
}

export const useKeepStore = create<KeepState>((set, get) => ({
  notes: [],
  folders: [],
  labels: [],
  loaded: false,
  loadError: false,
  draftNote: null,

  storageStatus: "loading",
  storageKind: null,
  rootLabel: "",
  storageError: "",
  scanVersion: 0,

  view: "notes",
  activeFolderId: null,
  activeLabelId: null,
  search: "",
  layout: "grid",
  editorNoteId: null,
  viewHistory: [],
  lightbox: null,
  vaultOpen: false,
  vaultCodePrompt: false,
  settingsOpen: false,
  imageEditor: null,

  // ------------------------------------------------------------ bootstrapping

  bootstrap: async () => {
    if (readVaultSession()) set({ vaultOpen: true });
    try {
      const r = getRepo();
      set({ storageKind: r.fs.kind, storageError: "" });
      if (r.fs.kind === "android") {
        // native shell: root path persisted in localStorage
        const restored = await r.tryRestoreRoot();
        if (!restored) {
          set({ storageStatus: "setup", loaded: true });
          return;
        }
        if (await r.fs.needsPermission()) {
          set({ storageStatus: "reauth", loaded: true });
          return;
        }
      } else {
        const restored = await r.tryRestoreRoot();
        if (!restored) {
          const needs = await r.fs.needsPermission().catch(() => false);
          set({ storageStatus: needs ? "reauth" : "setup", loaded: true });
          return;
        }
      }
      await get().rescan();
      set({ storageStatus: "ready", loaded: true });
    } catch (e) {
      console.error("bootstrap failed", e);
      set({
        loaded: true,
        storageStatus: "error",
        storageError: e instanceof Error ? e.message : String(e),
      });
    }
  },

  rescan: async () => {
    const r = getRepo();
    const result = await r.scan();
    const folders: FolderDTO[] = result.config.folders.map((f) => ({
      id: f.name,
      name: f.name,
      emoji: f.emoji || "📁",
      color: f.color || "default",
    }));
    const labels: LabelDTO[] = result.config.labels.map((name) => ({ id: name, name }));
    const folderById = new Map(folders.map((f) => [f.id, f]));
    for (const n of result.notes) {
      n.folder = n.folderId ? folderById.get(n.folderId) ?? null : null;
    }
    set((s) => ({
      notes: result.notes,
      folders,
      labels,
      rootLabel: r.rootLabel(),
      scanVersion: s.scanVersion + 1,
      storageStatus: "ready",
      loaded: true,
      loadError: false,
    }));
  },

  chooseFolder: async () => {
    try {
      const r = getRepo();
      if (r.fs.kind === "android") {
        const android = r.fs as unknown as {
          hasAllFilesAccess: () => boolean;
          requestAllFilesAccess: () => void;
        };
        if (!android.hasAllFilesAccess()) {
          android.requestAllFilesAccess();
          return; // user returns from system settings → visibilitychange re-checks
        }
        window.dispatchEvent(new CustomEvent("notes:pick-folder"));
        return;
      }
      const ok = await r.pickRoot();
      if (!ok) return;
      await get().rescan();
    } catch (e) {
      set({ storageError: e instanceof Error ? e.message : String(e) });
    }
  },

  selectInAppStorage: async () => {
    try {
      const r = getRepo();
      if (r.fs.kind === "android") {
        const android = r.fs as unknown as {
          appPrivateRoot: () => string;
          setRoot: (p: string) => void;
        };
        const priv = android.appPrivateRoot();
        if (!priv) return;
        android.setRoot(priv);
        await r.tryRestoreRoot();
      } else {
        // web: explicitly switch to the in-app (OPFS) storage implementation
        const opfs = switchToOpfs();
        const ok = await opfs.pickRoot();
        if (!ok) return;
        await new NoteRepository(opfs).tryRestoreRoot();
        repo = new NoteRepository(opfs);
      }
      await get().rescan();
    } catch (e) {
      set({ storageError: e instanceof Error ? e.message : String(e) });
    }
  },

  reauthorize: async () => {
    try {
      const r = getRepo();
      if (r.fs.kind === "android") {
        const android = r.fs as unknown as {
          hasAllFilesAccess: () => boolean;
          requestAllFilesAccess: () => void;
        };
        if (!android.hasAllFilesAccess()) {
          android.requestAllFilesAccess();
          return;
        }
        set({ storageStatus: "ready" });
        await get().rescan();
        return;
      }
      const web = r.fs as { reauthorize?: () => Promise<boolean> };
      if (typeof web.reauthorize === "function") {
        const ok = await web.reauthorize();
        if (ok) {
          await get().rescan();
          return;
        }
      }
      set({ storageStatus: "setup" });
    } catch {
      set({ storageStatus: "setup" });
    }
  },

  changeFolder: async () => {
    const r = getRepo();
    if (r.fs.kind === "android") {
      window.dispatchEvent(new CustomEvent("notes:pick-folder"));
      return;
    }
    await get().chooseFolder();
  },

  // ------------------------------------------------------------ vault / misc

  setSettingsOpen: (settingsOpen) => set({ settingsOpen }),
  tryOpenVault: async () => {
    if (vaultCodeExists()) {
      set({ vaultCodePrompt: true, search: "" });
      return;
    }
    writeVaultSession(true);
    set({ vaultOpen: true, search: "" });
  },
  closeVault: () => {
    writeVaultSession(false);
    set((s) => ({
      vaultOpen: false,
      view: s.view === "vault" ? "notes" : s.view,
    }));
  },
  resolveVaultCode: async (code) => {
    const ok = await verifyVaultCode(code);
    if (ok) {
      writeVaultSession(true);
      set({ vaultOpen: true, vaultCodePrompt: false });
    }
    return ok;
  },
  setVaultCodePrompt: (vaultCodePrompt) => set({ vaultCodePrompt }),
  setLightbox: (lightbox) => set({ lightbox }),
  // V8: opening the image editor no longer closes the note editor behind it —
  // the user returns to their note when the image editor closes.
  openImageEditor: (noteId, att) => set({ imageEditor: { noteId, att }, lightbox: null }),
  closeImageEditor: () => set({ imageEditor: null }),

  saveEditedImage: async (noteId, att, blob) => {
    const note = get().notes.find((n) => n.id === noteId);
    if (!note) return;
    const updated = await getRepo().writeAttachment(note, att, blob);
    set((s) => ({
      notes: s.notes.map((n) =>
        n.id === noteId
          ? {
              ...n,
              attachments: n.attachments.map((a) => (a.file === att.file ? updated : a)),
            }
          : n
      ),
    }));
  },

  setView: (view, id = null) =>
    set((s) => {
      const previous = {
        view: s.view,
        activeFolderId: s.activeFolderId,
        activeLabelId: s.activeLabelId,
      };
      // do not push duplicate / self-transitions onto the back history
      const history = s.viewHistory ?? [];
      const isSame = previous.view === view && previous.activeFolderId === id;
      const nextHistory = isSame ? history : [...history.slice(-24), previous];
      return {
        view,
        viewHistory: nextHistory,
        activeFolderId: id,
        activeLabelId: view === "label" ? id : null,
        search: "",
      };
    }),

  backView: () => {
    const s = get();
    const history = s.viewHistory ?? [];
    if (history.length === 0) return false;
    const prev = history[history.length - 1];
    set({
      view: prev.view,
      viewHistory: history.slice(0, -1),
      activeFolderId: prev.activeFolderId,
      activeLabelId: prev.view === "label" ? prev.activeLabelId : null,
      search: "",
    });
    return true;
  },

  setSearch: (search) => {
    const trimmed = search.trim().toLowerCase();
    if (trimmed === "open_vault") {
      void get().tryOpenVault();
      return;
    }
    if (trimmed === "close_vault") {
      get().closeVault();
      set({ search: "" });
      return;
    }
    set({ search });
  },

  setLayout: (layout) => {
    try {
      localStorage.setItem("keep-layout", layout);
    } catch {}
    set({ layout });
  },

  // ------------------------------------------------------------ editor flow

  openEditor: (editorNoteId) => {
    const prev = get().editorNoteId;
    if (prev && prev !== editorNoteId) void get().flushUpdate(prev);
    set({ editorNoteId });
  },

  beginNewNote: (opts) => {
    const prev = get().editorNoteId;
    if (prev && prev !== DRAFT_ID) void get().flushUpdate(prev);
    const now = new Date().toISOString();
    const inVault = get().view === "vault";
    const draft: NoteDTO = {
      id: DRAFT_ID,
      dir: "",
      title: opts?.title ?? "",
      content: opts?.content ?? "",
      type: opts?.type ?? "text",
      color: "default",
      pinned: false,
      archived: false,
      trashed: false,
      vaulted: inVault,
      folderId:
        get().view === "folder"
          ? get().activeFolderId
          : null,
      folder: null,
      items: parseTaskItems(opts?.content ?? ""),
      labels:
        get().view === "label" && get().activeLabelId
          ? [{ id: get().activeLabelId!, name: get().activeLabelId! }]
          : [],
      attachments: [],
      order: null,
      createdAt: now,
      updatedAt: now,
    };
    draftMedia = [];
    materializeChain = null;
    lastMaterializedId = null; // V8: never forward new drafts to an old note
    set({ draftNote: draft, editorNoteId: DRAFT_ID });
  },

  createNote: async (input) => {
    try {
      // manual ordering: slot new notes at the top without disturbing order
      const orders = get().notes.map((n) => n.order).filter((o): o is number => o != null);
      const order = orders.length > 0 ? Math.min(...orders) - 1 : null;
      const note = await getRepo().createNote({
        title: input.title ?? "",
        content: input.content ?? "",
        type: input.type,
        color: input.color,
        pinned: input.pinned,
        archived: input.archived,
        vaulted: input.vaulted,
        folderId: input.folderId,
        labels: input.labels?.map((l) => l.name),
        order,
      });
      const folder = get().folders.find((f) => f.id === note.folderId) ?? null;
      note.folder = folder;
      set((s) => ({ notes: [note, ...s.notes] }));
      return note;
    } catch (e) {
      console.error("createNote failed", e);
      return null;
    }
  },

  updateNote: (id, patch, immediate = false) => {
    if (id === DRAFT_ID) {
      // V8 (QA): a patch may land while/after the draft materializes — if the
      // draft is gone but was just created on disk, forward to the real note
      // instead of silently dropping the user's keystrokes
      if (!get().draftNote && lastMaterializedId) {
        get().updateNote(lastMaterializedId, patch, immediate);
        return;
      }
      // patches on the draft: merge locally and materialize as soon as there
      // is something worth saving
      set((s) => {
        if (!s.draftNote) return {};
        return { draftNote: applyPatchToNote(s.draftNote, patch) };
      });
      void get().__ensureDraftMaterialized();
      return;
    }

    // optimistic local update
    set((s) => ({
      notes: s.notes.map((n) => (n.id === id ? applyPatchToNote(n, patch) : n)),
    }));

    const existing = pendingSaves.get(id);
    const merged: NotePatch = existing ? { ...existing.patch, ...patch } : patch;
    if (existing?.timer) clearTimeout(existing.timer);

    if (immediate) {
      pendingSaves.set(id, { timer: null, patch: merged });
      void get().flushUpdate(id);
    } else {
      const timer = setTimeout(() => void get().flushUpdate(id), 600);
      pendingSaves.set(id, { timer, patch: merged });
    }
  },

  flushUpdate: async (id) => {
    if (id === DRAFT_ID) {
      await get().__ensureDraftMaterialized();
      return;
    }
    const entry = pendingSaves.get(id);
    if (!entry) return;
    if (entry.timer) clearTimeout(entry.timer);
    pendingSaves.delete(id);

    const note = get().notes.find((n) => n.id === id);
    if (!note) return;
    try {
      const dir = await getRepo().saveNote(note);
      if (dir !== note.dir) {
        // folder renamed to follow the new title
        set((s) => ({
          notes: s.notes.map((n) => (n.id === id ? { ...n, dir } : n)),
        }));
      }
    } catch (e) {
      console.error("flushUpdate failed", e);
    }
  },

  flushAll: async () => {
    const ids = [...pendingSaves.keys()];
    for (const id of ids) await get().flushUpdate(id);
    const draft = get().draftNote;
    if (draft && get().editorNoteId === DRAFT_ID && draftHasContent(draft)) {
      await get().__ensureDraftMaterialized();
    }
  },

  /** internal: create the draft note on disk as soon as it has content */
  __ensureDraftMaterialized: async () => {
    const state = get();
    const draft = state.draftNote;
    if (!draft) return materializeChain;
    if (!draftHasContent(draft)) return materializeChain;
    if (materializeChain) return materializeChain;

    materializeChain = (async () => {
      const media = draftMedia;
      draftMedia = [];
      try {
        // snapshot of what we are writing — patches that land while the
        // create is in flight are re-applied afterwards (V8 data-loss fix)
        const snapshot = {
          title: draft.title.trim() || "Untitled",
          content: draft.content,
          type: draft.type,
          color: draft.color,
          pinned: draft.pinned,
          archived: draft.archived,
          vaulted: draft.vaulted,
          folderId: draft.folderId,
          labels: draft.labels.map((l) => l.name),
        };
        const created = await getRepo().createNote({ ...snapshot, media });
        // carry over the optimistic preview URLs from the draft
        const urlByName = new Map(draft.attachments.map((a) => [a.name, a.url]));
        for (const att of created.attachments) {
          const u = urlByName.get(att.name);
          if (u) att.url = u;
        }
        created.folder = get().folders.find((f) => f.id === created.folderId) ?? null;
        lastMaterializedId = created.id;

        // the draft may have changed while the create was running
        const latest = get().draftNote;
        const drifted =
          latest &&
          (latest.title !== draft.title ||
            latest.content !== draft.content ||
            latest.type !== draft.type ||
            latest.color !== draft.color ||
            latest.pinned !== draft.pinned ||
            latest.archived !== draft.archived ||
            latest.vaulted !== draft.vaulted ||
            latest.folderId !== draft.folderId ||
            latest.labels !== draft.labels);

        if (drifted) {
          const patch = {
            title: latest.title,
            content: latest.content,
            type: latest.type,
            color: latest.color,
            pinned: latest.pinned,
            archived: latest.archived,
            vaulted: latest.vaulted,
            folderId: latest.folderId,
            labels: latest.labels,
          };
          const merged = applyPatchToNote(created, patch);
          set((s) => ({
            notes: [merged, ...s.notes],
            draftNote: null,
            editorNoteId: created.id,
          }));
          // persist the drifted state right away (no pending save exists yet)
          await persistNote(merged);
          return merged;
        }

        set((s) => ({
          notes: [created, ...s.notes],
          draftNote: null,
          editorNoteId: created.id,
        }));
        return created;
      } catch (e) {
        console.error("materialize draft failed", e);
        draftMedia = media;
        return null;
      } finally {
        materializeChain = null;
      }
    })();
    return materializeChain;
  },

  toggleItem: (noteId, itemId) => {
    const note =
      noteId === DRAFT_ID ? get().draftNote : get().notes.find((n) => n.id === noteId);
    if (!note) return;
    const index = note.items.findIndex((it) => it.id === itemId);
    if (index < 0) return;
    const content = toggleTaskLine(note.content, index, !note.items[index].checked);
    get().updateNote(noteId, { content });
  },

  toggleLabel: (noteId, label) => {
    const note = get().notes.find((n) => n.id === noteId);
    if (!note) return;
    const has = note.labels.some((l) => l.id === label.id);
    const labels = has
      ? note.labels.filter((l) => l.id !== label.id)
      : [...note.labels, label];
    get().updateNote(noteId, { labels }, true);
  },

  // ------------------------------------------------------------ attachments

  addNoteMedia: async (noteId, files) => {
    if (noteId === DRAFT_ID) {
      const created: AttachmentDTO[] = [];
      for (const f of files) {
        const safeName = f.name || "image";
        // V8.5 hardening (batch-upload regression): Android pickers/WebViews
        // can re-deliver the last file of a batch as an extra change event.
        // The same name+size is never stored twice — an image can not be
        // duplicated inside one note by any upload path.
        if (
          draftMedia.some((m) => m.name === safeName && m.blob.size === f.blob.size) ||
          created.some((m) => m.name === safeName && m.size === f.blob.size)
        ) {
          continue;
        }
        const url = URL.createObjectURL(f.blob);
        created.push({
          id: safeName,
          file: `attachment/${safeName}`,
          name: safeName,
          mime: f.blob.type || "image/jpeg",
          kind: f.blob.type === "image/gif" ? "gif" : "image",
          size: f.blob.size,
          url,
        });
        draftMedia.push({ blob: f.blob, name: safeName });
      }
      set((s) => {
        if (!s.draftNote) return {};
        return {
          draftNote: {
            ...s.draftNote,
            attachments: [...s.draftNote.attachments, ...created],
          },
        };
      });
      void get().__ensureDraftMaterialized();
      return created;
    }

    const note = get().notes.find((n) => n.id === noteId);
    if (!note) return [];
    const seenBatch = new Set<string>();
    const added = (
      await Promise.all(
        files.map(async (f) => {
      // V8.5 hardening (batch-upload regression): Android WebViews can fire
      // the file-input change event twice — the second time with just the
      // LAST file — and some pickers re-deliver it. Dedupe on name+size so
      // the same image can never be stored twice in one note.
      const batchKey = `${f.name}:${f.blob.size}`;
      if (
        note.attachments.some((a) => a.name === f.name && a.size === f.blob.size) ||
        seenBatch.has(batchKey)
      ) return null;
      seenBatch.add(batchKey);
      try {
        const att = await getRepo().addAttachment(note, f.blob, f.name);
        const url = await getRepo().ensureAttachmentUrl(note.dir, att.file);
        return { ...att, url };
      } catch (e) {
        console.error("addNoteMedia failed", e);
        return null;
      }
        })
      )
    ).filter((att): att is AttachmentDTO => att !== null);
    set((s) => ({
      notes: s.notes.map((n) =>
        n.id === noteId ? { ...n, attachments: [...n.attachments, ...added] } : n
      ),
    }));
    return added;
  },

  removeNoteAttachment: async (noteId, att) => {
    if (noteId === DRAFT_ID) {
      draftMedia = draftMedia.filter((m) => m.name !== att.name);
      set((s) => {
        if (!s.draftNote) return {};
        return {
          draftNote: {
            ...s.draftNote,
            attachments: s.draftNote.attachments.filter((a) => a.file !== att.file),
          },
        };
      });
      return;
    }
    const note = get().notes.find((n) => n.id === noteId);
    if (!note) return;
    await getRepo().removeAttachment(note, att);
    set((s) => ({
      notes: s.notes.map((n) =>
        n.id === noteId
          ? { ...n, attachments: n.attachments.filter((a) => a.file !== att.file) }
          : n
      ),
    }));
  },

  renameNoteAttachment: async (noteId, att, newName) => {
    // attachments are referenced from markdown by path; renames happen through
    // the editor's link editing — not exposed as a dedicated UI action
    void noteId;
    void att;
    void newName;
  },

  // ------------------------------------------------------------ lifecycle ops

  trashNote: async (id) => {
    set((s) => ({
      notes: s.notes.map((n) => (n.id === id ? { ...n, trashed: true, pinned: false } : n)),
    }));
    await get().flushUpdate(id);
    // make sure a note that had no pending save still persists the flag
    const note = get().notes.find((n) => n.id === id);
    if (note) {
      await persistNote({ ...note, updatedAt: new Date().toISOString() });
    }
  },

  restoreNote: async (id) => {
    set((s) => ({
      notes: s.notes.map((n) =>
        n.id === id ? { ...n, trashed: false, archived: false } : n
      ),
    }));
    const note = get().notes.find((n) => n.id === id);
    if (note) {
      await persistNote({ ...note, updatedAt: new Date().toISOString() });
    }
  },

  deleteForever: async (id) => {
    const note = get().notes.find((n) => n.id === id);
    set((s) => ({ notes: s.notes.filter((n) => n.id !== id) }));
    if (note) {
      try {
        await getRepo().deleteNoteDir(note.dir);
      } catch (e) {
        console.error("deleteForever failed", e);
      }
    }
  },

  emptyTrash: async () => {
    const doomed = get().notes.filter((n) => n.trashed);
    set((s) => ({ notes: s.notes.filter((n) => !n.trashed) }));
    for (const note of doomed) {
      try {
        await getRepo().deleteNoteDir(note.dir);
      } catch (e) {
        console.error("emptyTrash: failed to delete", note.dir, e);
      }
    }
  },

  duplicateNote: async (id) => {
    const source = get().notes.find((n) => n.id === id);
    if (!source) return;
    try {
      const copy = await getRepo().duplicateNote(source);
      copy.folder = get().folders.find((f) => f.id === copy.folderId) ?? null;
      set((s) => {
        const idx = s.notes.findIndex((n) => n.id === id);
        const notes = [...s.notes];
        notes.splice(idx < 0 ? 0 : idx, 0, copy);
        return { notes };
      });
    } catch (e) {
      console.error("duplicateNote failed", e);
    }
  },

  reorderNotes: async (ids) => {
    const rank = new Map(ids.map((id, i) => [id, i]));
    const changed: NoteDTO[] = [];
    set((s) => ({
      notes: s.notes.map((n) => {
        if (!rank.has(n.id)) return n;
        const next = { ...n, order: rank.get(n.id)! };
        changed.push(next);
        return next;
      }),
    }));
    for (const note of changed) {
      await persistNote({ ...note, updatedAt: note.updatedAt });
    }
  },

  // ------------------------------------------------------------ folders

  createFolder: async (name, emoji, color) => {
    const trimmed = name.trim();
    if (!trimmed) return null;
    const folders = get().folders;
    if (folders.some((f) => f.name.toLowerCase() === trimmed.toLowerCase())) return null;
    const config = await getRepo().loadConfig();
    config.folders.push({ name: trimmed, emoji, color });
    await getRepo().saveConfig(config);
    const folder: FolderDTO = { id: trimmed, name: trimmed, emoji, color };
    set((s) => ({ folders: [...s.folders, folder] }));
    return folder;
  },

  updateFolder: async (id, patch) => {
    const old = get().folders.find((f) => f.id === id);
    if (!old) return;
    const name = patch.name?.trim() || old.name;
    const next: FolderDTO = {
      id: name,
      name,
      emoji: patch.emoji ?? old.emoji,
      color: patch.color ?? old.color,
    };
    const config = await getRepo().loadConfig();
    const def = config.folders.find((f) => f.name === old.name);
    if (def) {
      def.name = name;
      def.emoji = next.emoji;
      def.color = next.color;
    }
    await getRepo().saveConfig(config);

    // notes pointing at the old folder name get their frontmatter updated
    const affected = get().notes.filter((n) => n.folderId === id);
    set((s) => ({
      folders: s.folders.map((f) => (f.id === id ? next : f)),
      notes: s.notes.map((n) =>
        n.folderId === id ? { ...n, folderId: name, folder: next } : n
      ),
    }));
    for (const n of affected) {
      await persistNote({ ...n, folderId: name, folder: next, updatedAt: n.updatedAt });
    }
  },

  deleteFolder: async (id) => {
    const config = await getRepo().loadConfig();
    config.folders = config.folders.filter((f) => f.name !== id);
    await getRepo().saveConfig(config);

    const affected = get().notes.filter((n) => n.folderId === id);
    set((s) => ({
      folders: s.folders.filter((f) => f.id !== id),
      notes: s.notes.map((n) =>
        n.folderId === id ? { ...n, folderId: null, folder: null } : n
      ),
    }));
    if (get().view === "folder" && get().activeFolderId === id) {
      set({ view: "folders", activeFolderId: null });
    }
    for (const n of affected) {
      await persistNote({ ...n, folderId: null, folder: null, updatedAt: n.updatedAt });
    }
  },

  // ------------------------------------------------------------ labels

  createLabel: async (name) => {
    const trimmed = name.trim();
    if (!trimmed) return { ok: false, error: "Label name is required" };
    if (get().labels.some((l) => l.name.toLowerCase() === trimmed.toLowerCase())) {
      return { ok: false, error: "A label with this name already exists" };
    }
    try {
      const config = await getRepo().loadConfig();
      config.labels.push(trimmed);
      await getRepo().saveConfig(config);
      set((s) => ({
        labels: [...s.labels, { id: trimmed, name: trimmed }].sort((a, b) =>
          a.name.localeCompare(b.name)
        ),
      }));
      return { ok: true };
    } catch {
      return { ok: false, error: "Failed to create label" };
    }
  },

  renameLabel: async (id, name) => {
    const trimmed = name.trim();
    if (!trimmed) return { ok: false, error: "Label name is required" };
    if (trimmed === id) return { ok: true };
    try {
      const config = await getRepo().loadConfig();
      config.labels = config.labels.map((l) => (l === id ? trimmed : l));
      await getRepo().saveConfig(config);
      const affected = get().notes.filter((n) => n.labels.some((l) => l.id === id));
      set((s) => ({
        labels: s.labels
          .map((l) => (l.id === id ? { id: trimmed, name: trimmed } : l))
          .sort((a, b) => a.name.localeCompare(b.name)),
        notes: s.notes.map((n) => ({
          ...n,
          labels: n.labels.map((l) => (l.id === id ? { id: trimmed, name: trimmed } : l)),
        })),
      }));
      for (const n of affected) {
        const updated = {
          ...n,
          labels: n.labels.map((l) => (l.id === id ? { id: trimmed, name: trimmed } : l)),
        };
        await persistNote({ ...updated, updatedAt: n.updatedAt });
      }
      return { ok: true };
    } catch {
      return { ok: false, error: "Failed to rename label" };
    }
  },

  deleteLabel: async (id) => {
    try {
      const config = await getRepo().loadConfig();
      config.labels = config.labels.filter((l) => l !== id);
      await getRepo().saveConfig(config);
    } catch (e) {
      console.error("deleteLabel config failed", e);
    }
    const affected = get().notes.filter((n) => n.labels.some((l) => l.id === id));
    set((s) => ({
      labels: s.labels.filter((l) => l.id !== id),
      notes: s.notes.map((n) => ({ ...n, labels: n.labels.filter((l) => l.id !== id) })),
    }));
    if (get().view === "label" && get().activeLabelId === id) {
      set({ view: "notes", activeLabelId: null });
    }
    for (const n of affected) {
      await persistNote({
        ...n,
        labels: n.labels.filter((l) => l.id !== id),
        updatedAt: n.updatedAt,
      });
    }
  },
}));

// ---------- selectors / helpers ----------

export function scopeNotes(
  notes: NoteDTO[],
  view: ViewKind,
  activeFolderId: string | null,
  activeLabelId: string | null
): NoteDTO[] {
  switch (view) {
    case "notes":
      return notes.filter((n) => !n.trashed && !n.archived && !n.vaulted);
    case "archive":
      return notes.filter((n) => !n.trashed && n.archived && !n.vaulted);
    case "trash":
      return notes.filter((n) => n.trashed);
    case "folder":
      return notes.filter(
        (n) => !n.trashed && !n.archived && !n.vaulted && n.folderId === activeFolderId
      );
    case "label":
      return notes.filter(
        (n) =>
          !n.trashed && !n.archived && !n.vaulted && n.labels.some((l) => l.id === activeLabelId)
      );
    case "vault":
      return notes.filter((n) => !n.trashed && n.vaulted);
    default:
      return notes.filter((n) => !n.trashed && !n.archived && !n.vaulted);
  }
}

export function filterBySearch(notes: NoteDTO[], search: string): NoteDTO[] {
  const q = search.trim().toLowerCase();
  if (!q) return notes;
  return notes.filter((n) => {
    if (n.title.toLowerCase().includes(q)) return true;
    if (n.content.toLowerCase().includes(q)) return true;
    if (n.items.some((it) => it.text.toLowerCase().includes(q))) return true;
    if (n.labels.some((l) => l.name.toLowerCase().includes(q))) return true;
    if (n.folder?.name.toLowerCase().includes(q)) return true;
    if (n.attachments.some((a) => a.name.toLowerCase().includes(q))) return true;
    return false;
  });
}

/**
 * Display order: manually arranged notes keep their position (order asc);
 * notes without a manual position fall back to recency after them.
 */
export function sortNotes(notes: NoteDTO[]): NoteDTO[] {
  const byRecency = (a: NoteDTO, b: NoteDTO) =>
    new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime();
  const hasManual = notes.some((n) => n.order != null);
  if (!hasManual) return [...notes].sort(byRecency);
  return [...notes].sort((a, b) => {
    const ao = a.order, bo = b.order;
    if (ao != null && bo != null) return ao - bo;
    if (ao != null) return -1;
    if (bo != null) return 1;
    return byRecency(a, b);
  });
}

// re-export task helpers used by card/editor components
export { setTaskText };
