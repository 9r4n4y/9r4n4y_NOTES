"use client";

import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useKeepStore } from "./store";
import { useBackLayer } from "@/lib/back-nav";
import type { AttachmentDTO } from "@/lib/types";
import {
  Check,
  Crop,
  Loader2,
  PenLine,
  RotateCcw,
  Trash2,
  Type,
  Undo2,
  X,
} from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

type Tool = "crop" | "draw" | "text";
type CropRect = { x: number; y: number; w: number; h: number };
type Handle = "nw" | "n" | "ne" | "e" | "se" | "s" | "sw" | "w";

const MAX_DIM = 1600;
const UNDO_LIMIT = 15;
const MIN_CROP = 28;

const SWATCHES = [
  "#111111", "#ffffff", "#ea4335", "#f5a623",
  "#34a853", "#4285f4", "#a142f4", "#ff6d9e",
];

const ASPECTS: { label: string; ratio: number | null }[] = [
  { label: "Free", ratio: null },
  { label: "1:1", ratio: 1 },
  { label: "4:3", ratio: 4 / 3 },
  { label: "3:4", ratio: 3 / 4 },
  { label: "16:9", ratio: 16 / 9 },
  { label: "9:16", ratio: 9 / 16 },
];

function clamp(v: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, v));
}

/** Mounted once at app root; remounts per attachment so all state resets. */
export function ImageEditorHost() {
  const editor = useKeepStore((s) => s.imageEditor);
  const closeImageEditor = useKeepStore((s) => s.closeImageEditor);
  // V8 (bug #3): BACK closes the image editor first
  useBackLayer(!!editor, () => closeImageEditor());
  if (!editor) return null;
  return <ImageEditorDialog key={editor.att.id} editor={editor} />;
}

function ImageEditorDialog({
  editor,
}: {
  editor: { noteId: string; att: AttachmentDTO };
}) {
  const closeImageEditor = useKeepStore((s) => s.closeImageEditor);
  const saveEditedImage = useKeepStore((s) => s.saveEditedImage);
  const removeNoteAttachment = useKeepStore((s) => s.removeNoteAttachment);

  const { noteId, att } = editor;

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);
  const origRef = useRef<{ url: string; w: number; h: number } | null>(null);
  const undoRef = useRef<{ url: string; w: number; h: number }[]>([]);
  const drawingRef = useRef(false);
  const dragRef = useRef<{
    mode: Handle | "move";
    startX: number;
    startY: number;
    rect: CropRect;
  } | null>(null);

  const [ready, setReady] = useState(false);
  const [tool, setTool] = useState<Tool | null>(null);
  const [color, setColor] = useState("#ea4335");
  const [strokeWidth, setStrokeWidth] = useState(6);
  const [textValue, setTextValue] = useState("");
  const [textSizePct, setTextSizePct] = useState(7);
  const [pendingTextPos, setPendingTextPos] = useState<{ x: number; y: number } | null>(null);
  const [crop, setCrop] = useState<CropRect | null>(null);
  const [aspect, setAspect] = useState<number | null>(null);
  const [canUndo, setCanUndo] = useState(false);
  const [busy, setBusy] = useState(false);
  const [removeConfirm, setRemoveConfirm] = useState(false);

  // ---- load image into canvas ----
  useEffect(() => {
    const img = new Image();
    img.onload = () => {
      let { width, height } = img;
      if (width > MAX_DIM || height > MAX_DIM) {
        const r = Math.min(MAX_DIM / width, MAX_DIM / height);
        width = Math.max(1, Math.round(width * r));
        height = Math.max(1, Math.round(height * r));
      }
      imgRef.current = img;
      origRef.current = { url: att.url, w: width, h: height };
      const canvas = canvasRef.current;
      if (!canvas) return;
      canvas.width = width;
      canvas.height = height;
      canvas.getContext("2d")?.drawImage(img, 0, 0, width, height);
      setReady(true);
    };
    img.onerror = () => {
      toast.error("Could not load this image");
      closeImageEditor();
    };
    img.src = att.url;
  }, []);

  // ---- Ctrl/Cmd+Z undo ----
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") {
        e.preventDefault();
        e.stopPropagation();
        undo();
      }
    }
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, []);

  const pushUndo = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    undoRef.current.push({
      url: canvas.toDataURL(),
      w: canvas.width,
      h: canvas.height,
    });
    if (undoRef.current.length > UNDO_LIMIT) undoRef.current.shift();
    setCanUndo(true);
  }, []);

  function undo() {
    const snap = undoRef.current.pop();
    const canvas = canvasRef.current;
    if (!snap || !canvas) {
      setCanUndo(undoRef.current.length > 0);
      return;
    }
    const img = new Image();
    img.onload = () => {
      canvas.width = snap.w;
      canvas.height = snap.h;
      canvas.getContext("2d")?.drawImage(img, 0, 0);
      setCanUndo(undoRef.current.length > 0);
    };
    img.src = snap.url;
  }

  function reset() {
    const orig = origRef.current;
    const canvas = canvasRef.current;
    if (!orig || !canvas) return;
    pushUndo();
    const img = new Image();
    img.onload = () => {
      canvas.width = orig.w;
      canvas.height = orig.h;
      canvas.getContext("2d")?.drawImage(img, 0, 0);
    };
    img.src = orig.url;
    setCrop(null);
    setTool(null);
  }

  // ---- pointer coordinate → canvas coordinate ----
  function getPos(e: React.PointerEvent): { x: number; y: number } {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return {
      x: ((e.clientX - rect.left) / rect.width) * canvas.width,
      y: ((e.clientY - rect.top) / rect.height) * canvas.height,
    };
  }

  // ---- draw tool ----
  function onCanvasPointerDown(e: React.PointerEvent<HTMLCanvasElement>) {
    if (e.button !== 0 || !ready) return;
    if (tool === "draw") {
      e.preventDefault();
      e.currentTarget.setPointerCapture(e.pointerId);
      pushUndo();
      const canvas = canvasRef.current!;
      const ctx = canvas.getContext("2d")!;
      const rect = canvas.getBoundingClientRect();
      const p = getPos(e);
      ctx.strokeStyle = color;
      ctx.lineWidth = Math.max(1, strokeWidth * (canvas.width / rect.width));
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
      // dot on click, then live segments
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(p.x + 0.1, p.y);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      drawingRef.current = true;
    } else if (tool === "text") {
      const p = getPos(e);
      setPendingTextPos(p);
    }
  }

  function onCanvasPointerMove(e: React.PointerEvent<HTMLCanvasElement>) {
    if (tool !== "draw" || !drawingRef.current) return;
    const ctx = canvasRef.current!.getContext("2d")!;
    const p = getPos(e);
    ctx.lineTo(p.x, p.y);
    ctx.stroke();
  }

  function onCanvasPointerUp() {
    if (tool === "draw") drawingRef.current = false;
  }

  // ---- text tool ----
  function placeText() {
    const canvas = canvasRef.current;
    if (!canvas || !pendingTextPos || !textValue.trim()) {
      setPendingTextPos(null);
      return;
    }
    pushUndo();
    const ctx = canvas.getContext("2d")!;
    const sizePx = Math.max(10, Math.round((textSizePct / 100) * canvas.height));
    ctx.font = `600 ${sizePx}px ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.save();
    ctx.shadowColor = "rgba(0,0,0,0.35)";
    ctx.shadowBlur = sizePx * 0.12;
    ctx.fillStyle = color;
    ctx.fillText(textValue, pendingTextPos.x, pendingTextPos.y);
    ctx.restore();
    setPendingTextPos(null);
    setTextValue("");
    toast.success("Text added");
  }

  // ---- crop tool ----
  function startCrop() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    setTool("crop");
    setAspect(null);
    setCrop({
      x: canvas.width * 0.1,
      y: canvas.height * 0.1,
      w: canvas.width * 0.8,
      h: canvas.height * 0.8,
    });
  }

  function applyAspect(ratio: number | null) {
    setAspect(ratio);
    const canvas = canvasRef.current;
    if (ratio == null || !crop || !canvas) return;
    const W = canvas.width;
    const H = canvas.height;
    let w = Math.min(W, H * ratio);
    let h = w / ratio;
    if (h > H) {
      h = H;
      w = h * ratio;
    }
    const cx = crop.x + crop.w / 2;
    const cy = crop.y + crop.h / 2;
    setCrop({
      x: clamp(cx - w / 2, 0, W - w),
      y: clamp(cy - h / 2, 0, H - h),
      w,
      h,
    });
  }

  function onCropPointerDown(e: React.PointerEvent, mode: Handle | "move") {
    e.preventDefault();
    e.stopPropagation();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    const p = getPos(e);
    dragRef.current = { mode, startX: p.x, startY: p.y, rect: crop! };
  }

  function onCropPointerMove(e: React.PointerEvent) {
    const d = dragRef.current;
    const canvas = canvasRef.current;
    if (!d || !crop || !canvas) return;
    const p = getPos(e);
    const dx = p.x - d.startX;
    const dy = p.y - d.startY;
    const W = canvas.width;
    const H = canvas.height;
    const min = Math.min(MIN_CROP, W * 0.15, H * 0.15);
    let { x, y, w, h } = d.rect;

    if (d.mode === "move") {
      x = clamp(x + dx, 0, W - w);
      y = clamp(y + dy, 0, H - h);
    } else if (aspect == null) {
      if (d.mode.includes("w")) {
        const nx = clamp(x + dx, 0, x + w - min);
        w = w + (x - nx);
        x = nx;
      }
      if (d.mode.includes("e")) w = clamp(w + dx, min, W - x);
      if (d.mode.includes("n")) {
        const ny = clamp(y + dy, 0, y + h - min);
        h = h + (y - ny);
        y = ny;
      }
      if (d.mode.includes("s")) h = clamp(h + dy, min, H - y);
    } else {
      // aspect-locked resize
      const changedW = d.mode.includes("e") || d.mode.includes("w");
      if (changedW) {
        w = clamp(w + dx, min, W);
        h = w / aspect;
        if (h > H) {
          h = H;
          w = h * aspect;
        }
      } else {
        h = clamp(h + dy, min, H);
        w = h * aspect;
        if (w > W) {
          w = W;
          h = w / aspect;
        }
      }
      const horiz = d.mode.includes("w") ? "left" : d.mode.includes("e") ? "right" : "center";
      const vert = d.mode.includes("n") ? "top" : d.mode.includes("s") ? "bottom" : "center";
      x = horiz === "left" ? d.rect.x + d.rect.w - w : horiz === "right" ? d.rect.x : d.rect.x + d.rect.w / 2 - w / 2;
      y = vert === "top" ? d.rect.y + d.rect.h - h : vert === "bottom" ? d.rect.y : d.rect.y + d.rect.h / 2 - h / 2;
      x = clamp(x, 0, W - w);
      y = clamp(y, 0, H - h);
    }
    setCrop({ x, y, w, h });
  }

  function onCropPointerUp() {
    dragRef.current = null;
  }

  function applyCrop() {
    const canvas = canvasRef.current;
    if (!canvas || !crop) return;
    pushUndo();
    const outW = Math.max(1, Math.round(crop.w));
    const outH = Math.max(1, Math.round(crop.h));
    const out = document.createElement("canvas");
    out.width = outW;
    out.height = outH;
    out
      .getContext("2d")!
      .drawImage(canvas, Math.round(crop.x), Math.round(crop.y), outW, outH, 0, 0, outW, outH);
    canvas.width = outW;
    canvas.height = outH;
    canvas.getContext("2d")!.drawImage(out, 0, 0);
    setCrop(null);
    setTool(null);
    setAspect(null);
  }

  // ---- save / remove ----
  async function save() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    setBusy(true);
    const outMime = att.mime === "image/png" || att.kind === "gif" ? "image/png" : "image/jpeg";
    canvas.toBlob(
      async (blob) => {
        if (!blob) {
          toast.error("Could not export the edited image");
          setBusy(false);
          return;
        }
        try {
          await saveEditedImage(noteId, att, blob);
          toast.success("Image updated");
          closeImageEditor();
        } catch {
          toast.error("Saving the image failed");
        } finally {
          setBusy(false);
        }
      },
      outMime,
      0.92
    );
  }

  function removeImage() {
    void removeNoteAttachment(noteId, att);
    toast.success("Image removed from note");
    setRemoveConfirm(false);
    closeImageEditor();
  }

  const canvasCursor =
    tool === "draw" ? "cursor-crosshair" : tool === "text" ? "cursor-text" : "cursor-default";

  return (
    <Dialog open onOpenChange={(o) => !o && closeImageEditor()}>
      <DialogContent
        showCloseButton={false}
        className="top-[6%] max-h-[88vh] w-[calc(100vw-1.5rem)] translate-y-0 gap-0 overflow-hidden rounded-xl border border-black/10 p-0 shadow-2xl focus:outline-none dark:border-white/10 sm:max-w-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex flex-col overflow-hidden">
          <DialogTitle className="sr-only">Edit image</DialogTitle>

          {/* header */}
          <div className="flex items-center gap-2 border-b border-black/5 px-4 py-2.5 dark:border-white/10">
            <PenLine className="h-4 w-4 shrink-0 text-muted-foreground" />
            <span className="truncate text-sm font-medium">Edit image</span>
            {att.kind === "gif" ? (
              <span className="hidden shrink-0 rounded bg-amber-500/15 px-2 py-0.5 text-[11px] font-medium text-amber-700 sm:inline dark:text-amber-400">
                GIF saves as a still image
              </span>
            ) : null}
            <div className="ml-auto flex items-center gap-0.5">
              <button
                type="button"
                aria-label="Undo"
                disabled={!canUndo}
                onClick={undo}
                className="inline-flex h-8 w-8 items-center justify-center rounded-full hover:bg-black/10 disabled:opacity-30 dark:hover:bg-white/10"
              >
                <Undo2 className="h-4 w-4" />
              </button>
              <button
                type="button"
                aria-label="Reset to original"
                disabled={!ready}
                onClick={reset}
                className="inline-flex h-8 w-8 items-center justify-center rounded-full hover:bg-black/10 disabled:opacity-30 dark:hover:bg-white/10"
              >
                <RotateCcw className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* canvas stage */}
          <div className="flex min-h-[220px] items-center justify-center bg-[#1b1c1d] p-3">
            <div className="relative inline-block max-w-full">
              <canvas
                ref={canvasRef}
                className={cn(
                  "block h-auto max-h-[52vh] w-auto max-w-full rounded",
                  canvasCursor
                )}
                style={{ touchAction: "none" }}
                onPointerDown={onCanvasPointerDown}
                onPointerMove={onCanvasPointerMove}
                onPointerUp={onCanvasPointerUp}
                onPointerLeave={onCanvasPointerUp}
              />

              {/* crop overlay */}
              {tool === "crop" && crop ? (
                <div className="absolute inset-0" style={{ touchAction: "none" }}>
                  <div
                    className="absolute cursor-move border-2 border-white/90 shadow-[0_0_0_9999px_rgba(0,0,0,0.55)]"
                    style={{
                      left: `${(crop.x / canvasRef.current!.width) * 100}%`,
                      top: `${(crop.y / canvasRef.current!.height) * 100}%`,
                      width: `${(crop.w / canvasRef.current!.width) * 100}%`,
                      height: `${(crop.h / canvasRef.current!.height) * 100}%`,
                    }}
                    onPointerDown={(e) => onCropPointerDown(e, "move")}
                    onPointerMove={onCropPointerMove}
                    onPointerUp={onCropPointerUp}
                  >
                    {/* thirds grid */}
                    <div className="pointer-events-none absolute inset-0">
                      <div className="absolute left-1/3 top-0 h-full w-px bg-white/30" />
                      <div className="absolute left-2/3 top-0 h-full w-px bg-white/30" />
                      <div className="absolute left-0 top-1/3 h-px w-full bg-white/30" />
                      <div className="absolute left-0 top-2/3 h-px w-full bg-white/30" />
                    </div>
                    {(
                      [
                        ["nw", "-left-1.5 -top-1.5 cursor-nwse-resize"],
                        ["ne", "-right-1.5 -top-1.5 cursor-nesw-resize"],
                        ["sw", "-bottom-1.5 -left-1.5 cursor-nesw-resize"],
                        ["se", "-bottom-1.5 -right-1.5 cursor-nwse-resize"],
                      ] as [Handle, string][]
                    ).map(([h, cls]) => (
                      <div
                        key={h}
                        className={cn(
                          "absolute h-3 w-3 rounded-sm border border-black/40 bg-white",
                          cls
                        )}
                        onPointerDown={(e) => onCropPointerDown(e, h)}
                        onPointerMove={onCropPointerMove}
                        onPointerUp={onCropPointerUp}
                      />
                    ))}
                    {(
                      [
                        ["n", "left-1/2 -top-1.5 -translate-x-1/2 cursor-ns-resize"],
                        ["s", "bottom-[-6px] left-1/2 -translate-x-1/2 cursor-ns-resize"],
                        ["w", "-left-1.5 top-1/2 -translate-y-1/2 cursor-ew-resize"],
                        ["e", "-right-1.5 top-1/2 -translate-y-1/2 cursor-ew-resize"],
                      ] as [Handle, string][]
                    ).map(([h, cls]) => (
                      <div
                        key={h}
                        className={cn(
                          "absolute h-3 w-3 rounded-sm border border-black/40 bg-white",
                          cls
                        )}
                        onPointerDown={(e) => onCropPointerDown(e, h)}
                        onPointerMove={onCropPointerMove}
                        onPointerUp={onCropPointerUp}
                      />
                    ))}
                  </div>
                </div>
              ) : null}

              {/* floating text input */}
              {tool === "text" && pendingTextPos && canvasRef.current ? (
                <div
                  className="absolute z-10 w-52 -translate-x-1/2 -translate-y-1/2"
                  style={{
                    left: `${clamp((pendingTextPos.x / canvasRef.current.width) * 100, 18, 82)}%`,
                    top: `${clamp((pendingTextPos.y / canvasRef.current.height) * 100, 12, 88)}%`,
                  }}
                  onPointerDown={(e) => e.stopPropagation()}
                >
                  <div className="flex items-center gap-1 rounded-lg border border-black/10 bg-background p-1 shadow-lg dark:border-white/15">
                    <input
                      autoFocus
                      className="min-w-0 flex-1 bg-transparent px-1.5 text-sm outline-none"
                      placeholder="Type text…"
                      value={textValue}
                      onChange={(e) => setTextValue(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          e.preventDefault();
                          placeText();
                        }
                        if (e.key === "Escape") {
                          e.stopPropagation();
                          setPendingTextPos(null);
                        }
                      }}
                    />
                    <button
                      type="button"
                      aria-label="Place text"
                      className="inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground"
                      onClick={placeText}
                    >
                      <Check className="h-4 w-4" />
                    </button>
                    <button
                      type="button"
                      aria-label="Cancel text"
                      className="inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-full hover:bg-black/10 dark:hover:bg-white/10"
                      onClick={() => setPendingTextPos(null)}
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ) : null}
            </div>
          </div>

          {/* tools / panels */}
          <div className="border-t border-black/5 px-3 py-2 dark:border-white/10">
            {!tool ? (
              <div className="flex items-center justify-center gap-1">
                <button
                  type="button"
                  onClick={startCrop}
                  className="inline-flex h-9 items-center gap-1.5 rounded-full px-3.5 text-sm hover:bg-black/10 dark:hover:bg-white/10"
                >
                  <Crop className="h-4 w-4" /> Crop
                </button>
                <button
                  type="button"
                  onClick={() => setTool("draw")}
                  className="inline-flex h-9 items-center gap-1.5 rounded-full px-3.5 text-sm hover:bg-black/10 dark:hover:bg-white/10"
                >
                  <PenLine className="h-4 w-4" /> Draw
                </button>
                <button
                  type="button"
                  onClick={() => setTool("text")}
                  className="inline-flex h-9 items-center gap-1.5 rounded-full px-3.5 text-sm hover:bg-black/10 dark:hover:bg-white/10"
                >
                  <Type className="h-4 w-4" /> Text
                </button>
              </div>
            ) : tool === "crop" ? (
              <div className="flex flex-wrap items-center justify-center gap-1.5">
                {ASPECTS.map((a) => (
                  <button
                    key={a.label}
                    type="button"
                    onClick={() => applyAspect(a.ratio)}
                    className={cn(
                      "rounded-full border px-2.5 py-1 text-xs transition-colors",
                      aspect === a.ratio
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-black/15 hover:bg-black/5 dark:border-white/20 dark:hover:bg-white/10"
                    )}
                  >
                    {a.label}
                  </button>
                ))}
                <div className="mx-1 h-5 w-px bg-black/10 dark:bg-white/15" />
                <Button size="sm" className="h-8 gap-1 rounded-full" onClick={applyCrop} disabled={!crop}>
                  <Check className="h-3.5 w-3.5" /> Apply
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-8 rounded-full"
                  onClick={() => {
                    setCrop(null);
                    setTool(null);
                  }}
                >
                  <X className="h-3.5 w-3.5" /> Cancel
                </Button>
              </div>
            ) : (
              <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-2 py-0.5">
                <div className="flex items-center gap-1.5">
                  {SWATCHES.map((c) => (
                    <button
                      key={c}
                      type="button"
                      aria-label={`Color ${c}`}
                      onClick={() => setColor(c)}
                      className={cn(
                        "h-6 w-6 rounded-full border transition-transform",
                        color === c ? "scale-110 border-primary ring-2 ring-primary/40" : "border-black/20 dark:border-white/25"
                      )}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                  <input
                    type="color"
                    aria-label="Custom color"
                    value={color}
                    onChange={(e) => setColor(e.target.value)}
                    className="h-6 w-6 cursor-pointer rounded-full border border-black/20 bg-transparent p-0 dark:border-white/25"
                  />
                </div>
                {tool === "draw" ? (
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">Size</span>
                    <Slider
                      className="w-28"
                      min={2}
                      max={30}
                      step={1}
                      value={[strokeWidth]}
                      onValueChange={(v) => setStrokeWidth(v[0] ?? 6)}
                    />
                    <span className="w-5 text-right text-xs tabular-nums text-muted-foreground">{strokeWidth}</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">Size</span>
                    <Slider
                      className="w-28"
                      min={3}
                      max={20}
                      step={1}
                      value={[textSizePct]}
                      onValueChange={(v) => setTextSizePct(v[0] ?? 7)}
                    />
                    <span className="w-8 text-right text-xs tabular-nums text-muted-foreground">{textSizePct}%</span>
                  </div>
                )}
                <div className="flex items-center gap-1.5">
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-8 rounded-full"
                    onClick={() => {
                      setTool(null);
                      setPendingTextPos(null);
                    }}
                  >
                    Done
                  </Button>
                </div>
              </div>
            )}
            {tool === "draw" ? (
              <p className="mt-1 text-center text-[11px] text-muted-foreground">
                Drag on the image to draw
              </p>
            ) : tool === "text" ? (
              <p className="mt-1 text-center text-[11px] text-muted-foreground">
                Click where the text should go, type it, press Enter
              </p>
            ) : null}
          </div>

          {/* footer */}
          <div className="flex items-center gap-2 border-t border-black/5 px-3 py-2.5 dark:border-white/10">
            <Button
              size="sm"
              variant="outline"
              className="h-8 gap-1.5 rounded-full border-destructive/40 text-destructive hover:bg-destructive/10 hover:text-destructive"
              disabled={busy}
              onClick={() => setRemoveConfirm(true)}
            >
              <Trash2 className="h-3.5 w-3.5" /> Remove image
            </Button>
            <div className="ml-auto flex items-center gap-2">
              <Button size="sm" variant="ghost" className="h-8 rounded-full" disabled={busy} onClick={closeImageEditor}>
                Cancel
              </Button>
              <Button size="sm" className="h-8 gap-1.5 rounded-full" disabled={busy || !ready} onClick={save}>
                {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
                Save
              </Button>
            </div>
          </div>
        </div>

        {/* remove confirm */}
        <AlertDialog open={removeConfirm} onOpenChange={setRemoveConfirm}>
          <AlertDialogContent onClick={(e) => e.stopPropagation()}>
            <AlertDialogHeader>
              <AlertDialogTitle>Remove this image?</AlertDialogTitle>
              <AlertDialogDescription>
                It will be removed from the note. You can undo this only before closing everything.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Keep it</AlertDialogCancel>
              <AlertDialogAction
                className="bg-destructive text-white hover:bg-destructive/90"
                onClick={removeImage}
              >
                Remove
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </DialogContent>
    </Dialog>
  );
}
