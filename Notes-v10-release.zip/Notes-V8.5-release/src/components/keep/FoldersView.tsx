"use client";

import { EmptyState } from "./EmptyState";
import { FolderDialog } from "./FolderDialog";
import { useKeepStore } from "./store";
import { folderTint } from "@/lib/keep-constants";
import type { NoteDTO } from "@/lib/types";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { FolderOpen, FolderPlus, MoreVertical, Pencil, StickyNote, Trash2 } from "lucide-react";
import { useTheme } from "next-themes";
import { useState } from "react";
import { useIsTouch } from "@/hooks/use-is-touch";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { useAttachmentUrl } from "./attachment-url";
import { markdownToPlain } from "@/core/markdown";
import type { AttachmentDTO } from "@/core/types";

function folderNotes(notes: NoteDTO[], folderId: string): NoteDTO[] {
  return notes
    .filter((n) => !n.trashed && !n.archived && !n.vaulted && n.folderId === folderId)
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
}

export function FoldersView() {
  const notes = useKeepStore((s) => s.notes);
  const folders = useKeepStore((s) => s.folders);
  const setView = useKeepStore((s) => s.setView);
  const deleteFolder = useKeepStore((s) => s.deleteFolder);
  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === "dark";
  const isTouch = useIsTouch();

  const [dialogOpen, setDialogOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [confirmId, setConfirmId] = useState<string | null>(null);

  if (folders.length === 0) {
    return (
      <div>
        <NewFolderCard onClick={() => setDialogOpen(true)} />
        <EmptyState
          icon={FolderOpen}
          title="No folders yet"
          subtitle="Create genre folders like Recipes, Work or Travel to organise your notes."
        />
        <FolderDialog open={dialogOpen} onOpenChange={setDialogOpen} />
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <h1 className="text-sm font-medium uppercase tracking-wider text-foreground/60">Folders</h1>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4">
        <NewFolderCard onClick={() => setDialogOpen(true)} />
        {folders.map((f) => {
          const fn = folderNotes(notes, f.id);
          const media = fn
            .flatMap((n) => n.attachments.map((att) => ({ note: n, att })))
            .slice(0, 4);
          const latest = fn[0];
          const tint = folderTint(f.color, isDark)[isDark ? "dark" : "light"];
          const snippet = latest
            ? latest.type === "list"
              ? latest.items.map((i) => `${i.checked ? "☑" : "☐"} ${i.text}`).join("  ·  ")
              : markdownToPlain(latest.content)
            : "";

          return (
            <div
              key={f.id}
              role="button"
              tabIndex={0}
              aria-label={`Open folder ${f.name}`}
              onClick={() => setView("folder", f.id)}
              onKeyDown={(e) => e.key === "Enter" && setView("folder", f.id)}
              className="group cursor-pointer overflow-hidden rounded-2xl border border-black/5 bg-card shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-lg dark:border-white/10"
            >
              {/* media collage */}
              {media.length > 0 ? (
                <div className="relative grid h-32 grid-cols-2 gap-0.5 overflow-hidden bg-black/5">
                  {media.slice(0, 4).map(({ note, att }) => (
                    <div key={`${note.id}-${att.file}`} className="relative overflow-hidden">
                      <FolderThumb dir={note.dir} att={att} />
                    </div>
                  ))}
                </div>
              ) : (
                <div
                  className="flex h-32 items-center justify-center text-5xl transition-transform group-hover:scale-105"
                  style={{ backgroundColor: tint }}
                >
                  {f.emoji}
                </div>
              )}

              <div className="p-4">
                <div className="flex items-center gap-2">
                  <span
                    className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-lg"
                    style={{ backgroundColor: tint }}
                  >
                    {f.emoji}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium">{f.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {fn.length} note{fn.length === 1 ? "" : "s"}
                      {fn.reduce((acc, n) => acc + n.attachments.length, 0) > 0
                        ? ` · ${fn.reduce((acc, n) => acc + n.attachments.length, 0)} media`
                        : ""}
                    </p>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <button
                        type="button"
                        aria-label={`Options for ${f.name}`}
                        className={cn(
                          "rounded-full p-1.5 transition-opacity hover:bg-accent",
                          // touch devices have no reliable :hover — keep the menu visible there
                          isTouch ? "opacity-90" : "opacity-0 group-hover:opacity-100 focus-visible:opacity-100"
                        )}
                        onClick={(e) => e.stopPropagation()}
                      >
                        <MoreVertical className="h-4 w-4" />
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
                      <DropdownMenuItem
                        onClick={() => {
                          setEditId(f.id);
                          setDialogOpen(true);
                        }}
                      >
                        <Pencil className="mr-2 h-4 w-4" /> Edit folder
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        className="text-destructive focus:text-destructive"
                        onClick={() => setConfirmId(f.id)}
                      >
                        <Trash2 className="mr-2 h-4 w-4" /> Delete folder
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                {latest ? (
                  <div className="mt-3 rounded-lg bg-accent/60 px-3 py-2">
                    <p className="truncate text-sm font-medium">
                      {latest.title || (latest.type === "list" ? "List" : "Untitled note")}
                    </p>
                    <p className="mt-0.5 line-clamp-2 text-xs leading-snug text-muted-foreground">
                      {snippet || "Empty note"}
                    </p>
                  </div>
                ) : (
                  <div className="mt-3 flex items-center gap-2 rounded-lg border border-dashed border-border px-3 py-2 text-xs text-muted-foreground">
                    <StickyNote className="h-3.5 w-3.5" /> No notes here yet
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <FolderDialog open={dialogOpen} onOpenChange={setDialogOpen} editId={editId} />

      <AlertDialog open={!!confirmId} onOpenChange={(o) => !o && setConfirmId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this folder?</AlertDialogTitle>
            <AlertDialogDescription>
              The folder will be removed. Notes inside are kept and simply lose their folder.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={() => {
                if (confirmId) {
                  deleteFolder(confirmId);
                  toast.success("Folder deleted");
                }
              }}
            >
              Delete folder
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function NewFolderCard({ onClick }: { onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label="Create new folder"
      className="flex h-full min-h-40 w-full flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-border p-4 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
    >
      <FolderPlus className="h-7 w-7" />
      <span className="text-sm font-medium">New folder</span>
      <span className="text-xs opacity-70">Group notes by genre</span>
    </button>
  );
}

/** Folder collage thumbnail with lazily-resolved local attachment URL. */
function FolderThumb({ dir, att }: { dir: string; att: AttachmentDTO }) {
  const url = useAttachmentUrl(dir, att);
  if (!url) return <div className="h-full w-full animate-pulse bg-black/10" />;
  return (
    <>
      <img src={url} alt={att.name} loading="lazy" className="h-full w-full object-cover" />
      {att.kind === "gif" ? (
        <span className="absolute bottom-1 left-1 rounded bg-black/60 px-1 text-[8px] font-bold text-white">
          GIF
        </span>
      ) : null}
    </>
  );
}
