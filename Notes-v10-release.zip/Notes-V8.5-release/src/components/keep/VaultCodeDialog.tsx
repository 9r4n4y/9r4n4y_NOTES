"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useKeepStore } from "./store";
import { KeyRound, Loader2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useBackLayer } from "@/lib/back-nav";

export function VaultCodeDialog() {
  const open = useKeepStore((s) => s.vaultCodePrompt);
  const setOpen = useKeepStore((s) => s.setVaultCodePrompt);
  const resolveVaultCode = useKeepStore((s) => s.resolveVaultCode);
  // V8 (bug #3): BACK dismisses the vault code prompt
  useBackLayer(open, () => setOpen(false));
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(false);

  async function submit() {
    if (!code) return;
    setBusy(true);
    const ok = await resolveVaultCode(code);
    setBusy(false);
    if (ok) {
      setCode("");
      setError(false);
      toast.success("Vault unlocked");
    } else {
      setError(true);
      toast.error("Wrong code");
    }
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!o) {
          setCode("");
          setError(false);
          setOpen(false);
        }
      }}
    >
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <KeyRound className="h-5 w-5" /> Enter vault code
          </DialogTitle>
          <DialogDescription>
            Type your secret code to unlock the vault.
          </DialogDescription>
        </DialogHeader>
        <Input
          type="password"
          autoFocus
          value={code}
          onChange={(e) => {
            setCode(e.target.value);
            setError(false);
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter") void submit();
          }}
          placeholder="Vault code"
          aria-invalid={error}
          className={error ? "border-destructive" : undefined}
        />
        {error ? <p className="text-xs text-destructive">Incorrect code. Try again.</p> : null}
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button onClick={() => void submit()} disabled={busy || !code}>
            {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Unlock
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
