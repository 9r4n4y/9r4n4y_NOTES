"use client";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FOLDER_TINTS } from "@/lib/keep-constants";
import { useKeepStore } from "./store";
import { useMemo, useState } from "react";
import { useTheme } from "next-themes";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { Check, Pencil } from "lucide-react";

const EMOJIS = [
  "📁", "⭐", "💼", "🏠", "❤️", "📚", "🎵", "🎬", "✈️", "🍳",
  "💪", "💡", "🎨", "🔬", "🌱", "🐶", "🎉", "⚽", "🕹️", "💰",
];

const TINT_KEYS = ["default", "blue", "red", "yellow", "green", "purple"];

/**
 * V8 (feature): count visible grapheme clusters so ANY emoji — including
 * multi-codepoint sequences like 👨‍👩‍👧, 🏳️‍🌈 or ↕️ with variation
 * selectors — counts as exactly one icon.
 */
function graphemeCount(value: string): number {
  if (!value) return 0;
  try {
    if (typeof Intl !== "undefined" && "Segmenter" in Intl) {
      const seg = new (Intl as unknown as { Segmenter: new () => { segment: (s: string) => Iterable<unknown> } }).Segmenter();
      let n = 0;
      for (const _ of seg.segment(value)) n++;
      return n;
    }
  } catch {
    /* fall through */
  }
  return Array.from(value).length;
}

/** Loose emoji-ish check: must contain at least one non-ASCII symbol char. */
function looksLikeEmoji(value: string): boolean {
  if (!value) return false;
  return /[^\u0000-\u007f]/.test(value) || /[\u2600-\u27bf]/.test(value);
}

export function FolderDialog({
  open,
  onOpenChange,
  editId,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  editId?: string | null;
}) {
  if (!open) return null;
  return <FolderDialogInner key={editId ?? "new"} open onOpenChange={onOpenChange} editId={editId ?? null} />;
}

function FolderDialogInner({
  onOpenChange,
  editId,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  editId: string | null;
}) {
  const folders = useKeepStore((s) => s.folders);
  const createFolder = useKeepStore((s) => s.createFolder);
  const updateFolder = useKeepStore((s) => s.updateFolder);
  const { resolvedTheme } = useTheme();

  const existing = editId ? folders.find((f) => f.id === editId) ?? null : null;
  const [name, setName] = useState(existing?.name ?? "");
  const [emoji, setEmoji] = useState(existing?.emoji ?? "📁");
  const [tint, setTint] = useState(existing?.color ?? "default");
  // custom emoji entry state (V8 feature)
  const [customOpen, setCustomOpen] = useState(false);
  const [customDraft, setCustomDraft] = useState("");
  const isPreset = EMOJIS.includes(emoji);

  const customError = useMemo(() => {
    const v = customDraft.trim();
    if (!v) return null;
    if (graphemeCount(v) > 2) return "Use a single emoji";
    if (!looksLikeEmoji(v)) return "That does not look like an emoji";
    return null;
  }, [customDraft]);

  function applyCustom() {
    const v = customDraft.trim();
    if (!v || customError) {
      toast.error(customError ?? "Type or paste an emoji first");
      return;
    }
    setEmoji(v);
    setCustomDraft("");
    setCustomOpen(false);
  }

  async function handleSave() {
    const trimmed = name.trim();
    if (!trimmed) {
      toast.error("Give your folder a name");
      return;
    }
    const safeEmoji = emoji.trim() || "📁";
    if (existing) {
      await updateFolder(existing.id, { name: trimmed, emoji: safeEmoji, color: tint });
      toast.success("Folder updated");
    } else {
      const created = await createFolder(trimmed, safeEmoji, tint);
      if (!created) {
        toast.error("Could not create folder");
        return;
      }
      toast.success(`Folder "${trimmed}" created`);
    }
    onOpenChange(false);
  }

  const isDark = resolvedTheme === "dark";

  return (
    <Dialog open onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md" onClick={(e) => e.stopPropagation()}>
        <DialogHeader>
          <DialogTitle>{existing ? "Edit folder" : "New folder"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <span
              className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full text-2xl"
              style={{
                backgroundColor: isDark
                  ? FOLDER_TINTS[tint]?.dark ?? FOLDER_TINTS.default.dark
                  : FOLDER_TINTS[tint]?.light ?? FOLDER_TINTS.default.light,
              }}
            >
              {emoji}
            </span>
            <Input
              placeholder="Folder name (e.g. Recipes, Work, Travel)"
              value={name}
              onChange={(e) => setName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSave()}
              autoFocus
            />
          </div>

          <div>
            <p className="mb-2 text-xs font-medium text-muted-foreground">Icon</p>
            <div className="grid grid-cols-10 gap-1">
              {EMOJIS.map((em) => (
                <button
                  key={em}
                  type="button"
                  onClick={() => setEmoji(em)}
                  className={cn(
                    "flex h-8 w-8 items-center justify-center rounded-md text-lg transition-transform hover:scale-110",
                    emoji === em && "bg-accent ring-1 ring-ring"
                  )}
                >
                  {em}
                </button>
              ))}
              {/* custom emoji tile (V8 feature) */}
              <button
                key="__custom__"
                type="button"
                aria-label="Choose a custom emoji"
                title="Choose any emoji"
                onClick={() => {
                  setCustomOpen((v) => !v);
                  setCustomDraft("");
                }}
                className={cn(
                  "flex h-8 w-8 items-center justify-center rounded-md border border-dashed border-border text-muted-foreground transition-transform hover:scale-110",
                  (!isPreset || customOpen) && "bg-accent ring-1 ring-ring"
                )}
              >
                {customOpen ? <Check className="h-4 w-4" /> : <Pencil className="h-4 w-4" />}
              </button>
            </div>

            {customOpen ? (
              <div className="mt-2 flex items-center gap-2 rounded-lg border bg-accent/40 px-2 py-2">
                <Input
                  value={customDraft}
                  onChange={(e) => setCustomDraft(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      applyCustom();
                    }
                  }}
                  placeholder="Type or paste any emoji…"
                  aria-label="Custom emoji"
                  className="h-8 flex-1 text-base"
                  maxLength={16}
                  autoFocus
                />
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-background text-lg">
                  {customDraft.trim() || emoji}
                </span>
                <Button size="sm" className="h-8 shrink-0" onClick={applyCustom} disabled={!!customError && !!customDraft.trim()}>
                  Use
                </Button>
              </div>
            ) : null}
            {customDraft.trim() && customError ? (
              <p className="mt-1 text-xs text-destructive">{customError}</p>
            ) : null}
            {!isPreset && !customOpen ? (
              <p className="mt-1 text-[11px] text-muted-foreground">Custom emoji in use — paste a new one any time.</p>
            ) : null}
          </div>

          <div>
            <p className="mb-2 text-xs font-medium text-muted-foreground">Colour</p>
            <div className="flex gap-2">
              {TINT_KEYS.map((k) => (
                <button
                  key={k}
                  type="button"
                  aria-label={k}
                  onClick={() => setTint(k)}
                  className={cn(
                    "h-8 w-8 rounded-full border transition-transform hover:scale-110",
                    tint === k && "ring-2 ring-ring ring-offset-2 ring-offset-background"
                  )}
                  style={{
                    backgroundColor: isDark
                      ? FOLDER_TINTS[k]?.dark ?? FOLDER_TINTS.default.dark
                      : FOLDER_TINTS[k]?.light ?? FOLDER_TINTS.default.light,
                    borderColor: "rgba(0,0,0,0.12)",
                  }}
                />
              ))}
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave}>{existing ? "Save changes" : "Create folder"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
