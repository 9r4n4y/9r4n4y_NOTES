"use client";

// ---------------------------------------------------------------------------
// FolderPickerDialog — Android in-app root-folder picker.
//
// The Android shell grants "All files access"; this dialog then navigates the
// real filesystem through the bridge (fsList / fsMkdir) and lets the user pick
// (or create) the folder the app should manage. Mirrors the behaviour of the
// browser's showDirectoryPicker so both platforms share one UX.
// ---------------------------------------------------------------------------

import { useCallback, useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Check, FolderPlus, Folder as FolderIcon, Loader2 } from "lucide-react";
import { getRepo } from "./store";
import type { DirEntry, FSAdapter } from "@/core/fs/adapter";
import type { AndroidFSAdapter } from "@/core/fs/android-fs";

/** Safe cast: the picker is only rendered on Android. */
function androidFs(fs: FSAdapter): AndroidFSAdapter {
  return fs as unknown as AndroidFSAdapter;
}
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export function FolderPickerDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const [path, setPath] = useState<string>("");
  const [entries, setEntries] = useState<DirEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState("");
  const [storageRoot, setStorageRoot] = useState("");

  const repo = getRepo();
  const fs = repo.fs;
  const isAndroid = fs.kind === "android";

  const navigate = useCallback(
    async (absPath: string) => {
      setLoading(true);
      try {
        const list = await androidFs(fs).listAbsolute(absPath === "" ? "/" : absPath);
        setEntries(list.filter((e) => e.kind === "dir" && !e.name.startsWith(".")));
        setPath(absPath);
      } catch (e) {
        toast.error(e instanceof Error ? e.message : "Could not open that folder");
      } finally {
        setLoading(false);
      }
    },
    [fs]
  );

  useEffect(() => {
    if (!open || !isAndroid) return;
    const android = androidFs(fs);
    const suggested = android.suggestedRoot();
    // start at the suggested root if it exists, else at storage root
    void (async () => {
      try {
        const a = androidFs(fs);
        await a.listAbsolute(suggested);
        setStorageRoot(android.storageRoot());
        setPath(suggested);
        const list = await a.listAbsolute(suggested);
        setEntries(list.filter((e) => e.kind === "dir" && !e.name.startsWith(".")));
      } catch {
        setStorageRoot(android.storageRoot());
        await navigate(android.storageRoot());
      }
    })();
  }, [open, isAndroid, fs, navigate]);

  if (!isAndroid) return null;

  const crumbs = path === "" ? [] : path.replace(new RegExp(`^${storageRoot}/?`), "").split("/").filter(Boolean);

  function goUp() {
    if (path === storageRoot || path === "") return;
    const idx = path.lastIndexOf("/");
    const parent = idx > storageRoot.length ? path.slice(0, idx) : storageRoot;
    void navigate(parent);
  }

  function selectCurrent() {
    androidFs(fs).setRoot(path || storageRoot);
    onOpenChange(false);
    void repo
      .tryRestoreRoot()
      .then(() => getRepo())
      .then((r) => r.scan())
      .then(() => {
        toast.success("Folder selected");
        window.dispatchEvent(new CustomEvent("notes:folder-changed"));
      })
      .catch(() => toast.error("Could not read the selected folder"));
  }

  async function createFolder() {
    const name = newName.trim();
    if (!name) return;
    setCreating(true);
    try {
      await androidFs(fs).makeAbsolute(`${path || storageRoot}/${name}`);
      setNewName("");
      setCreating(false);
      await navigate(`${path || storageRoot}/${name}`);
    } catch (e) {
      setCreating(false);
      toast.error(e instanceof Error ? e.message : "Could not create the folder");
    }
  }

  const displayPath = path.replace(new RegExp(`^${storageRoot}`), "") || "/";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Choose your notes folder</DialogTitle>
          <DialogDescription>
            Notes are stored as plain markdown folders you fully control. Pick an existing
            folder or create a new one.
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center gap-1 rounded-lg border bg-accent/50 px-2 py-1.5 text-xs">
          <button
            type="button"
            className="inline-flex h-7 w-7 items-center justify-center rounded hover:bg-black/10 disabled:opacity-30 dark:hover:bg-white/10"
            onClick={goUp}
            disabled={path === storageRoot || path === ""}
            aria-label="Go up one folder"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
          </button>
          <span className="truncate font-mono">
            {storageRoot.replace(/\/$/, "")}
            {displayPath}
          </span>
          {loading ? <Loader2 className="ml-auto h-3.5 w-3.5 animate-spin" /> : null}
        </div>

        <div className="max-h-64 min-h-32 overflow-y-auto rounded-lg border">
          {entries.length === 0 && !loading ? (
            <p className="p-4 text-center text-sm text-muted-foreground">No sub-folders here</p>
          ) : (
            entries.map((e) => (
              <button
                key={e.name}
                type="button"
                className="flex w-full items-center gap-2 px-3 py-2 text-left text-sm transition-colors hover:bg-accent"
                onClick={() => void navigate(`${path || storageRoot}/${e.name}`)}
              >
                <FolderIcon className="h-4 w-4 shrink-0 text-muted-foreground" />
                <span className="truncate">{e.name}</span>
              </button>
            ))
          )}
        </div>

        <div className="flex items-center gap-2">
          <Input
            placeholder="New folder name…"
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") void createFolder();
            }}
            className="h-9 text-sm"
          />
          <Button
            size="sm"
            variant="outline"
            className={cn("gap-1.5")}
            disabled={!newName.trim() || creating}
            onClick={() => void createFolder()}
          >
            {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : <FolderPlus className="h-4 w-4" />}
            Create
          </Button>
        </div>

        <Button className="w-full gap-2" onClick={selectCurrent}>
          <Check className="h-4 w-4" /> Use this folder
        </Button>
      </DialogContent>
    </Dialog>
  );
}
