"use client";

import { useCallback, useEffect, useRef, useState } from "react";

/**
 * Long-press drag-and-drop reordering for note cards.
 *
 * Works in both the masonry (CSS columns) grid and the list layout:
 *  - pointer/touch down on a card starts a 350 ms long-press timer
 *  - moving >12 px before activation cancels (that's a scroll)
 *  - on activation the card lifts (scale + shadow) and follows the pointer
 *  - when the pointer gets closer to another card's centre the list re-orders
 *    live (preview) — the dragged card stays glued to the pointer
 *  - on release the new order is committed via `onCommit`
 *
 * No external dependencies; haptic feedback uses the Vibration API when
 * available (the Android shell grants it through the system WebView).
 */

const LONG_PRESS_MS = 350;
const CANCEL_PX = 12;

export interface DragReorderApi {
  containerRef: React.RefObject<HTMLDivElement | null>;
  draggingId: string | null;
  handlePointerDown: (e: React.PointerEvent, id: string) => void;
}

interface DragState {
  pointerId: number;
  startY: number;
  grabOffsetY: number;
  lastPointerY: number;
  timer: ReturnType<typeof setTimeout> | null;
  active: boolean;
  cancelled: boolean;
  fromIndex: number;
  rects: DOMRect[];
  dragEl: HTMLElement | null;
}

interface Options {
  /** Ordered note ids currently rendered (preview order included). */
  itemIds: string[];
  enabled: boolean;
  /** Called during the drag whenever the preview order should change. */
  onPreview: (ids: string[]) => void;
  /** Called once on release with the final order. */
  onCommit: (ids: string[]) => void;
}

function currentTranslateY(el: HTMLElement): number {
  const m = el.style.transform.match(/translateY\((-?[\d.]+)px\)/);
  return m ? parseFloat(m[1]) : 0;
}

export function useDragReorder({ itemIds, enabled, onPreview, onCommit }: Options): DragReorderApi {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [draggingId, setDraggingId] = useState<string | null>(null);

  const st = useRef<DragState>({
    pointerId: -1,
    startY: 0,
    grabOffsetY: 0,
    lastPointerY: 0,
    timer: null,
    active: false,
    cancelled: false,
    fromIndex: -1,
    rects: [],
    dragEl: null,
  });

  const idsRef = useRef(itemIds);
  idsRef.current = itemIds;
  const enabledRef = useRef(enabled);
  enabledRef.current = enabled;
  const previewRef = useRef(onPreview);
  previewRef.current = onPreview;
  const commitRef = useRef(onCommit);
  commitRef.current = onCommit;

  const vibrate = useCallback(() => {
    try {
      if (typeof navigator !== "undefined" && "vibrate" in navigator) navigator.vibrate(18);
    } catch {
      /* ignore */
    }
  }, []);

  const clearVisuals = useCallback(() => {
    if (st.current.dragEl) {
      st.current.dragEl.style.transform = "";
      st.current.dragEl.style.zIndex = "";
      st.current.dragEl.style.willChange = "";
      st.current.dragEl.style.transition = "";
    }
    st.current.dragEl = null;
    document.body.classList.remove("drag-reorder-active");
  }, []);

  const finishDrag = useCallback(
    (commit: boolean) => {
      const s = st.current;
      if (s.timer) clearTimeout(s.timer);
      s.timer = null;
      const wasActive = s.active;
      s.active = false;
      s.pointerId = -1;
      setDraggingId(null);
      clearVisuals();

      if (wasActive && commit) {
        // swallow the click that follows pointerup so it doesn't open the editor
        document.addEventListener(
          "click",
          (e) => {
            e.stopPropagation();
            e.preventDefault();
          },
          { capture: true, once: true }
        );
        commitRef.current([...idsRef.current]);
      }
      s.fromIndex = -1;
    },
    [clearVisuals]
  );

  /** After a preview reorder the DOM slot of the dragged card moved — re-glue. */
  const retargetTransform = useCallback(() => {
    const s = st.current;
    const el = s.dragEl;
    if (!el || !s.active) return;
    el.style.transition = "none";
    const rect = el.getBoundingClientRect();
    const slotTop = rect.top - currentTranslateY(el);
    const dy = s.lastPointerY - s.grabOffsetY - slotTop;
    el.style.transform = `translateY(${dy}px) scale(1.03)`;
  }, []);

  const handlePointerDown = useCallback(
    (e: React.PointerEvent, id: string) => {
      if (!enabledRef.current) return;
      if (e.pointerType === "mouse" && e.button !== 0) return;
      const target = e.target as HTMLElement;
      // don't hijack interactions with the card's own controls
      if (target.closest("button, input, textarea, a, select")) return;
      // make sure the press landed on the card this handler belongs to
      const card = target.closest<HTMLElement>("[data-note-id]");
      if (!card || card.getAttribute("data-note-id") !== id) return;

      const s = st.current;
      s.pointerId = e.pointerId;
      s.startY = e.clientY;
      s.lastPointerY = e.clientY;
      s.cancelled = false;
      s.active = false;
      s.fromIndex = idsRef.current.indexOf(id);

      if (s.timer) clearTimeout(s.timer);
      s.timer = setTimeout(() => {
        if (s.cancelled || s.pointerId !== e.pointerId || s.fromIndex < 0) return;
        const container = containerRef.current;
        const dragEl = container?.querySelector<HTMLElement>(`[data-note-id="${id}"]`);
        if (!dragEl) return;

        // measure all card rects at activation
        const els = Array.from(container?.querySelectorAll<HTMLElement>("[data-note-id]") ?? []);
        s.rects = els.map((el) => el.getBoundingClientRect());
        s.dragEl = dragEl;
        s.active = true;
        s.grabOffsetY = s.startY - s.rects[s.fromIndex].top;

        vibrate();
        setDraggingId(id);
        document.body.classList.add("drag-reorder-active");
        dragEl.style.willChange = "transform";
        dragEl.style.transition = "none";
        dragEl.style.zIndex = "50";
        dragEl.style.transform = "translateY(0px) scale(1.03)";
      }, LONG_PRESS_MS);
    },
    [vibrate]
  );

  // global move / up listeners (drags continue outside the card bounds)
  useEffect(() => {
    if (!enabled) return;

    const findTargetIndex = (pointerY: number): number => {
      const s = st.current;
      let best = s.fromIndex;
      let bestDist = Infinity;
      s.rects.forEach((r, i) => {
        const mid = r.top + r.height / 2;
        const dist = Math.abs(pointerY - mid);
        if (dist < bestDist) {
          bestDist = dist;
          best = i;
        }
      });
      return best;
    };

    const onMove = (e: PointerEvent) => {
      const s = st.current;
      if (s.pointerId !== e.pointerId) return;
      s.lastPointerY = e.clientY;

      if (!s.active) {
        if (Math.abs(e.clientY - s.startY) > CANCEL_PX) {
          s.cancelled = true;
          if (s.timer) clearTimeout(s.timer);
        }
        return;
      }

      e.preventDefault(); // block scrolling while dragging

      const el = s.dragEl;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const slotTop = rect.top - currentTranslateY(el);
      const dy = e.clientY - s.grabOffsetY - slotTop;
      el.style.transform = `translateY(${dy}px) scale(1.03)`;

      const target = findTargetIndex(e.clientY);
      if (target !== s.fromIndex) {
        const ids = [...idsRef.current];
        const [moved] = ids.splice(s.fromIndex, 1);
        ids.splice(target, 0, moved);
        s.fromIndex = target;
        previewRef.current(ids);
        // after the re-render the element lands in a new slot — re-glue it
        requestAnimationFrame(() => retargetTransform());
      }
    };

    const onUp = (e: PointerEvent) => {
      const s = st.current;
      if (s.pointerId !== e.pointerId) return;
      finishDrag(s.active);
    };

    const onTouchMove = (e: TouchEvent) => {
      // pointermove preventDefault alone doesn't stop touch scrolling
      if (st.current.active) e.preventDefault();
    };

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && st.current.active) finishDrag(false);
    };

    window.addEventListener("pointermove", onMove, { passive: false });
    window.addEventListener("pointerup", onUp);
    window.addEventListener("pointercancel", onUp);
    document.addEventListener("touchmove", onTouchMove, { passive: false });
    window.addEventListener("keydown", onKeyDown);
    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onUp);
      document.removeEventListener("touchmove", onTouchMove);
      window.removeEventListener("keydown", onKeyDown);
      const s = st.current;
      if (s.timer) clearTimeout(s.timer);
    };
  }, [enabled, finishDrag, retargetTransform]);

  return { containerRef, draggingId, handlePointerDown };
}
