"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useKeepStore } from "./store";
import { useSettings } from "./settings-store";
import { cn } from "@/lib/utils";
import {
  Grid2x2,
  Menu,
  Monitor,
  Moon,
  Plus,
  Search,
  Sun,
  Rows3,
  X,
  Settings,
  LockOpen,
} from "lucide-react";
import { useTheme } from "next-themes";
import { useSyncExternalStore } from "react";

const emptySubscribe = () => () => {};

/** Hydration-safe mount flag without setState-in-effect. */
function useMounted() {
  return useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false
  );
}

export function TopBar({ onToggleSidebar }: { onToggleSidebar: () => void }) {
  const search = useKeepStore((s) => s.search);
  const setSearch = useKeepStore((s) => s.setSearch);
  const layout = useKeepStore((s) => s.layout);
  const setLayout = useKeepStore((s) => s.setLayout);
  const vaultOpen = useKeepStore((s) => s.vaultOpen);
  const setSettingsOpen = useKeepStore((s) => s.setSettingsOpen);
  const beginNewNote = useKeepStore((s) => s.beginNewNote);
  const settings = useSettings();
  const { theme, setTheme, resolvedTheme } = useTheme();
  const mounted = useMounted();

  return (
    <header className="sticky top-0 z-40 flex h-16 items-center gap-2 bg-background/80 px-3 backdrop-blur-xl md:px-5">
      <Button
        variant="ghost"
        size="icon"
        className="rounded-full transition-transform active:scale-90"
        onClick={onToggleSidebar}
        aria-label="Toggle sidebar"
      >
        <Menu className="h-5 w-5" />
      </Button>

      <a className="mr-2 flex select-none items-center gap-2" href="/" aria-label={settings.appName}>
        <span className="hidden text-xl font-medium tracking-tight text-foreground/85 sm:block">
          {mounted ? settings.appName : "Notes"}
        </span>
      </a>

      <div className="relative mx-auto w-full max-w-2xl">
        <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search notes, lists, labels…"
          aria-label="Search notes"
          className="h-11 rounded-full border-transparent bg-accent/90 pl-11 pr-10 text-sm shadow-sm transition-colors focus-visible:border-border focus-visible:bg-background"
        />
        {search ? (
          <button
            type="button"
            aria-label="Clear search"
            onClick={() => setSearch("")}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        ) : null}
      </div>

      <div className="ml-auto flex items-center gap-1">
        {vaultOpen ? (
          <span
            className="mr-1 hidden items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 text-xs font-medium text-emerald-600 dark:text-emerald-400 sm:flex"
            title="Vault unlocked — secret notes are visible"
          >
            <LockOpen className="h-3.5 w-3.5" /> Vault open
          </span>
        ) : null}

        <Button
          variant="default"
          size="sm"
          className="gap-1.5 rounded-full"
          onClick={() => beginNewNote()}
          aria-label="New note"
          title="New note"
        >
          <Plus className="h-4 w-4" />
          <span className="hidden sm:inline">New note</span>
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className="rounded-full transition-transform active:scale-90"
          onClick={() => setLayout(layout === "grid" ? "list" : "grid")}
          aria-label={layout === "grid" ? "Switch to list layout" : "Switch to grid layout"}
          title={layout === "grid" ? "List layout" : "Grid layout"}
        >
          {mounted && layout === "grid" ? <Rows3 className="h-5 w-5" /> : <Grid2x2 className="h-5 w-5" />}
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className="rounded-full transition-transform active:scale-90"
          onClick={() => setSettingsOpen(true)}
          aria-label="Settings"
          title="Settings"
        >
          <Settings className="h-5 w-5" />
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="rounded-full transition-transform active:scale-90" aria-label="Change theme">
              {mounted && resolvedTheme === "dark" ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-40">
            <DropdownMenuItem
              onClick={() => setTheme("light")}
              className={cn(mounted && theme === "light" && "bg-accent")}
            >
              <Sun className="mr-2 h-4 w-4" /> Light
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => setTheme("dark")}
              className={cn(mounted && theme === "dark" && "bg-accent")}
            >
              <Moon className="mr-2 h-4 w-4" /> Dark
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => setTheme("system")}
              className={cn(mounted && theme === "system" && "bg-accent")}
            >
              <Monitor className="mr-2 h-4 w-4" /> System
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
