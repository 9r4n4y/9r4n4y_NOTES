"use client";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useKeepStore } from "./store";
import { Check, Pencil, Plus, Trash2, X } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export function LabelsManager({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const labels = useKeepStore((s) => s.labels);
  const notes = useKeepStore((s) => s.notes);
  const createLabel = useKeepStore((s) => s.createLabel);
  const renameLabel = useKeepStore((s) => s.renameLabel);
  const deleteLabel = useKeepStore((s) => s.deleteLabel);

  const [newName, setNewName] = useState("");
  const [editId, setEditId] = useState<string | null>(null);
  const [editName, setEditName] = useState("");
  const [confirmId, setConfirmId] = useState<string | null>(null);

  const countFor = (id: string) =>
    notes.filter((n) => !n.trashed && n.labels.some((l) => l.id === id)).length;

  async function handleCreate() {
    const name = newName.trim();
    if (!name) return;
    const res = await createLabel(name);
    if (!res.ok) {
      toast.error(res.error ?? "Could not create label");
      return;
    }
    setNewName("");
    toast.success(`Label "${name}" created`);
  }

  async function handleRename() {
    if (!editId) return;
    const name = editName.trim();
    if (!name) return;
    const res = await renameLabel(editId, name);
    if (!res.ok) {
      toast.error(res.error ?? "Could not rename label");
      return;
    }
    setEditId(null);
    toast.success("Label renamed");
  }

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-md" onClick={(e) => e.stopPropagation()}>
          <DialogHeader>
            <DialogTitle>Edit labels</DialogTitle>
          </DialogHeader>

          <div className="flex items-center gap-2">
            <Input
              placeholder="Create new label…"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleCreate()}
            />
            <Button size="icon" onClick={handleCreate} aria-label="Create label" disabled={!newName.trim()}>
              <Plus className="h-4 w-4" />
            </Button>
          </div>

          <div className="max-h-72 space-y-1 overflow-y-auto">
            {labels.length === 0 ? (
              <p className="py-6 text-center text-sm text-muted-foreground">
                No labels yet. Create one above to start tagging notes.
              </p>
            ) : (
              labels.map((l) =>
                editId === l.id ? (
                  <div key={l.id} className="flex items-center gap-2">
                    <Input
                      value={editName}
                      autoFocus
                      onChange={(e) => setEditName(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") handleRename();
                        if (e.key === "Escape") setEditId(null);
                      }}
                    />
                    <Button size="icon" variant="ghost" onClick={handleRename} aria-label="Save name">
                      <Check className="h-4 w-4" />
                    </Button>
                    <Button size="icon" variant="ghost" onClick={() => setEditId(null)} aria-label="Cancel">
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <div
                    key={l.id}
                    className="flex items-center gap-3 rounded-lg px-2 py-2 hover:bg-accent"
                  >
                    <span className="flex-1 truncate text-sm">{l.name}</span>
                    <span className="text-xs text-muted-foreground">
                      {countFor(l.id)} note{countFor(l.id) === 1 ? "" : "s"}
                    </span>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-8 w-8"
                      aria-label={`Rename ${l.name}`}
                      onClick={() => {
                        setEditId(l.id);
                        setEditName(l.name);
                      }}
                    >
                      <Pencil className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-8 w-8 text-destructive hover:text-destructive"
                      aria-label={`Delete ${l.name}`}
                      onClick={() => setConfirmId(l.id)}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                )
              )
            )}
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!confirmId} onOpenChange={(o) => !o && setConfirmId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this label?</AlertDialogTitle>
            <AlertDialogDescription>
              It will be removed from all notes. The notes themselves are kept.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={() => {
                if (confirmId) deleteLabel(confirmId);
                toast.success("Label deleted");
              }}
            >
              Delete label
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
