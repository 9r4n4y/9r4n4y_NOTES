"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { TopBar } from "./TopBar";
import { Sidebar } from "./Sidebar";
import { Composer } from "./Composer";
import { NotesView } from "./NotesView";
import { FoldersView } from "./FoldersView";
import { NoteEditorView } from "./NoteEditorView";
import { ImageEditorHost } from "./ImageEditorDialog";
import { LabelsManager } from "./LabelsManager";
import { FolderDialog } from "./FolderDialog";
import { SettingsDialog } from "./SettingsDialog";
import { VaultCodeDialog } from "./VaultCodeDialog";
import { FolderPickerDialog } from "./FolderPickerDialog";
import { EmptyState } from "./EmptyState";
import { useKeepStore } from "./store";
import { hydrateSettings, useSettings } from "./settings-store";
import { addBackHandler, installBackNavigation, useBackLayer } from "@/lib/back-nav";
import { SystemBarsSync } from "./system-bars-sync";
import { cn } from "@/lib/utils";
import { Trash2, Lock, MoreVertical, Pencil } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { Loader2, WifiOff, FolderOpen, FolderCog, RefreshCcw, ShieldCheck } from "lucide-react";

declare global {
  interface Window {
    __flushLocalData?: () => void;
    __appPermissionsReturned?: () => void;
    __appReturnedFromLongPause?: () => void;
  }
}

function viewHeading(
  view: string,
  folderName?: string,
  labelName?: string
): string | undefined {
  switch (view) {
    case "archive":
      return "Archive";
    case "trash":
      return "Trash";
    case "vault":
      return "Vault";
    case "folder":
      return folderName;
    case "label":
      return labelName;
    default:
      return undefined;
  }
}

/** Full-viewport wallpaper layer driven by user settings. */
function WallpaperLayer() {
  const { wallpaper, wallpaperBlur, wallpaperDim, wallpaperFixed } = useSettings();
  if (!wallpaper) return null;
  return (
    <div
      aria-hidden
      className={`pointer-events-none inset-0 z-0 overflow-hidden ${wallpaperFixed ? "fixed" : "absolute"}`}
    >
      <img
        src={wallpaper}
        alt=""
        className="h-full w-full object-cover"
        style={{ filter: `blur(${wallpaperBlur}px)`, transform: wallpaperBlur > 0 ? "scale(1.06)" : undefined }}
      />
      <div className="absolute inset-0" style={{ background: `rgb(0 0 0 / ${wallpaperDim}%)` }} />
    </div>
  );
}

export function KeepApp() {
  const bootstrap = useKeepStore((s) => s.bootstrap);
  const loaded = useKeepStore((s) => s.loaded);
  const loadError = useKeepStore((s) => s.loadError);
  const storageStatus = useKeepStore((s) => s.storageStatus);
  const storageError = useKeepStore((s) => s.storageError);
  const chooseFolder = useKeepStore((s) => s.chooseFolder);
  const selectInAppStorage = useKeepStore((s) => s.selectInAppStorage);
  const reauthorize = useKeepStore((s) => s.reauthorize);
  const rescan = useKeepStore((s) => s.rescan);
  const view = useKeepStore((s) => s.view);
  const activeFolderId = useKeepStore((s) => s.activeFolderId);
  const activeLabelId = useKeepStore((s) => s.activeLabelId);
  const folders = useKeepStore((s) => s.folders);
  const labels = useKeepStore((s) => s.labels);
  const emptyTrash = useKeepStore((s) => s.emptyTrash);
  const deleteFolder = useKeepStore((s) => s.deleteFolder);
  const vaultOpen = useKeepStore((s) => s.vaultOpen);
  const settings = useSettings();

  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [folderDialogOpen, setFolderDialogOpen] = useState(false);
  const [folderDialogEditId, setFolderDialogEditId] = useState<string | null>(null);
  const [deleteFolderId, setDeleteFolderId] = useState<string | null>(null);
  const [labelsOpen, setLabelsOpen] = useState(false);
  const [emptyTrashConfirm, setEmptyTrashConfirm] = useState(false);
  const [folderPickerOpen, setFolderPickerOpen] = useState(false);

  // V8 (bug #3): BACK dismisses app surfaces bottom-up. The bottom-most
  // handler pops the main-view history (notes → folder → notes …); every
  // dialog/editor/lightbox pushes its own layer above it.
  useEffect(() => {
    installBackNavigation();
    return addBackHandler(() => useKeepStore.getState().backView());
  }, []);
  useBackLayer(mobileOpen, () => setMobileOpen(false));
  useBackLayer(!!deleteFolderId, () => setDeleteFolderId(null));
  useBackLayer(emptyTrashConfirm, () => setEmptyTrashConfirm(false));
  useBackLayer(folderDialogOpen, () => setFolderDialogOpen(false));
  useBackLayer(labelsOpen, () => setLabelsOpen(false));
  useBackLayer(folderPickerOpen, () => setFolderPickerOpen(false));
  const inVaultView = useKeepStore((s) => s.vaultOpen && s.view === "vault");
  useBackLayer(inVaultView, () => useKeepStore.getState().closeVault());

  useEffect(() => {
    hydrateSettings();
    bootstrap();
    try {
      const saved = localStorage.getItem("keep-layout");
      if (saved === "list" || saved === "grid") useKeepStore.getState().setLayout(saved);
    } catch {}
  }, []);

  // ---- keep the tab title in sync with the (editable) app name
  useEffect(() => {
    document.title = `${settings.appName} — Notes, Lists & Folders`;
  }, [settings.appName]);

  // ---- flush pending note writes when the tab/app goes away
  useEffect(() => {
    const flush = () => void useKeepStore.getState().flushAll();
    const onVis = () => {
      if (document.visibilityState === "hidden") flush();
    };
    window.addEventListener("beforeunload", flush);
    document.addEventListener("visibilitychange", onVis);
    window.__flushLocalData = flush;
    return () => {
      window.removeEventListener("beforeunload", flush);
      document.removeEventListener("visibilitychange", onVis);
      delete window.__flushLocalData;
    };
  }, []);

  // ---- Android: re-check All-Files-Access when returning from system settings
  useEffect(() => {
    if (storageStatus !== "reauth" && storageStatus !== "setup") return;
    const onVis = () => {
      if (document.visibilityState !== "visible") return;
      void useKeepStore.getState().reauthorize();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, [storageStatus]);

  // ---- Android: folder picker events (from setup + settings)
  useEffect(() => {
    const onPick = () => setFolderPickerOpen(true);
    window.addEventListener("notes:pick-folder", onPick);
    const onChanged = () => void rescan();
    window.addEventListener("notes:folder-changed", onChanged);
    return () => {
      window.removeEventListener("notes:pick-folder", onPick);
      window.removeEventListener("notes:folder-changed", onChanged);
    };
  }, [rescan]);

  // if the vault closes while inside it, jump back to Notes (guard for edge cases)
  useEffect(() => {
    if (!vaultOpen && view === "vault") useKeepStore.getState().setView("notes");
  }, [vaultOpen, view]);

  const activeFolder = folders.find((f) => f.id === activeFolderId);
  const activeLabel = labels.find((l) => l.id === activeLabelId);

  if (!loaded || storageStatus === "loading") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-3 text-muted-foreground">
          <Loader2 className="h-8 w-8 animate-spin" />
          <p className="text-sm">Loading your notes…</p>
        </div>
      </div>
    );
  }

  if (storageStatus === "setup") {
    return <StorageSetup onChoose={() => void chooseFolder()} onUseApp={() => void selectInAppStorage()} error={storageError} />;
  }

  if (storageStatus === "reauth") {
    return <StorageReauth onReauthorize={() => void reauthorize()} />;
  }

  if (loadError && storageStatus !== "ready") {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="flex max-w-sm flex-col items-center gap-3 text-center">
          <WifiOff className="h-8 w-8 text-muted-foreground" />
          <p className="font-medium">Could not load your notes</p>
          <p className="text-sm text-muted-foreground">There was a problem reading your notes folder.</p>
          <Button onClick={() => void rescan()}>Retry</Button>
        </div>
      </div>
    );
  }

  return (
    <div
      className={cn(
        "relative min-h-screen text-foreground",
        !settings.animations && "animations-off"
      )}
      style={{ fontSize: settings.fontSize === "lg" ? "1.05rem" : settings.fontSize === "sm" ? "0.92rem" : undefined }}
    >
      <WallpaperLayer />
      <SystemBarsSync />

      <div className="relative z-10">
        <TopBar onToggleSidebar={() => {
          if (window.innerWidth < 768) setMobileOpen((v) => !v);
          else setSidebarOpen((v) => !v);
        }} />

        <div className="flex">
          <Sidebar
            open={sidebarOpen}
            mobileOpen={mobileOpen}
            onCloseMobile={() => setMobileOpen(false)}
            onNewFolder={() => {
              setFolderDialogEditId(null);
              setFolderDialogOpen(true);
            }}
            onManageLabels={() => setLabelsOpen(true)}
          />

          <main className="min-w-0 flex-1 px-4 pb-24 pt-4 md:px-8">
            {view === "folders" ? (
              <FoldersView />
            ) : view === "trash" ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h1 className="text-sm font-medium uppercase tracking-wider text-foreground/60">Trash</h1>
                  <TrashButton onConfirm={() => setEmptyTrashConfirm(true)} />
                </div>
                <NotesView />
              </div>
            ) : view === "vault" ? (
              <div className="space-y-5">
                <div className="flex items-center gap-2">
                  <h1 className="flex items-center gap-2 text-sm font-medium uppercase tracking-wider text-foreground/60">
                    <Lock className="h-4 w-4" /> Vault
                  </h1>
                  <span className="rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.5 text-[10px] font-medium text-emerald-600 dark:text-emerald-400">
                    unlocked
                  </span>
                </div>
                <Composer />
                <NotesView />
              </div>
            ) : view === "folder" && activeFolder ? (
              <div className="space-y-5">
                <div className="flex items-center justify-between gap-2">
                  <h1 className="truncate text-sm font-medium uppercase tracking-wider text-foreground/60">
                    {activeFolder.emoji} {activeFolder.name}
                  </h1>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <button
                        type="button"
                        aria-label={`Manage folder ${activeFolder.name}`}
                        title="Manage folder"
                        className="rounded-full p-2 text-foreground/70 transition-colors hover:bg-accent hover:text-foreground"
                      >
                        <MoreVertical className="h-4 w-4" />
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem
                        onClick={() => {
                          setFolderDialogEditId(activeFolder.id);
                          setFolderDialogOpen(true);
                        }}
                      >
                        <Pencil className="mr-2 h-4 w-4" /> Edit folder
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        className="text-destructive focus:text-destructive"
                        onClick={() => setDeleteFolderId(activeFolder.id)}
                      >
                        <Trash2 className="mr-2 h-4 w-4" /> Delete folder
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
                <Composer />
                <NotesView />
              </div>
            ) : (
              <div className="space-y-5">
                <Composer />
                <NotesView
                  heading={viewHeading(
                    view,
                    activeFolder ? `${activeFolder.emoji} ${activeFolder.name}` : undefined,
                    activeLabel ? activeLabel.name : undefined
                  )}
                />
              </div>
            )}
          </main>
        </div>
      </div>

      <NoteEditorView />
      <ImageEditorHost />
      <LabelsManager open={labelsOpen} onOpenChange={setLabelsOpen} />
      <FolderDialog open={folderDialogOpen} onOpenChange={setFolderDialogOpen} editId={folderDialogEditId} />
      <SettingsDialog />
      <VaultCodeDialog />
      <FolderPickerDialog open={folderPickerOpen} onOpenChange={setFolderPickerOpen} />

      <AlertDialog open={!!deleteFolderId} onOpenChange={(o) => !o && setDeleteFolderId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this folder?</AlertDialogTitle>
            <AlertDialogDescription>
              The folder will be removed. Notes inside are kept and simply lose their folder.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={() => {
                if (deleteFolderId) {
                  deleteFolder(deleteFolderId);
                  toast.success("Folder deleted");
                }
              }}
            >
              Delete folder
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={emptyTrashConfirm} onOpenChange={setEmptyTrashConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Empty trash?</AlertDialogTitle>
            <AlertDialogDescription>
              All notes in the trash will be deleted permanently. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              onClick={() => {
                emptyTrash();
                toast.success("Trash emptied");
              }}
            >
              Empty trash
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function TrashButton({ onConfirm }: { onConfirm: () => void }) {
  const notes = useKeepStore((s) => s.notes);
  const count = notes.filter((n) => n.trashed).length;
  if (count === 0) return null;
  return (
    <Button variant="outline" size="sm" className="gap-2" onClick={onConfirm}>
      <Trash2 className="h-4 w-4" /> Empty trash
    </Button>
  );
}

/* ------------------------------------------------------------------ */
/* First-run storage setup (choose where notes live)                   */
/* ------------------------------------------------------------------ */

function StorageSetup({
  onChoose,
  onUseApp,
  error,
}: {
  onChoose: () => void;
  onUseApp: () => void;
  error: string;
}) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="w-full max-w-md space-y-5 text-center">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10">
          <FolderOpen className="h-8 w-8 text-primary" />
        </div>
        <div className="space-y-2">
          <h1 className="text-xl font-semibold">Where should your notes live?</h1>
          <p className="text-sm leading-relaxed text-muted-foreground">
            This app is fully local-first. Every note is a plain markdown folder
            (<code className="rounded bg-muted px-1">node.md</code> + attachments) that you
            own and can open with any editor. Choose the folder the app should manage.
          </p>
        </div>

        {error ? (
          <p className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs text-destructive">
            {error}
          </p>
        ) : null}

        <div className="space-y-2">
          <Button size="lg" className="w-full gap-2" onClick={onChoose}>
            <FolderCog className="h-4 w-4" /> Choose a folder
          </Button>
          <Button size="lg" variant="outline" className="w-full gap-2" onClick={onUseApp}>
            <ShieldCheck className="h-4 w-4" /> Use in-app local storage
          </Button>
        </div>

        <p className="text-xs leading-relaxed text-muted-foreground">
          &ldquo;Choose a folder&rdquo; gives you full control: on Android the app asks for
          All-files-access and lets you pick any folder on the phone; in Chrome/Edge you get
          the native folder picker. &ldquo;In-app storage&rdquo; keeps notes inside the app's
          own private space instead.
        </p>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Permission re-grant screen (web reload / Android without permission) */
/* ------------------------------------------------------------------ */

function StorageReauth({ onReauthorize }: { onReauthorize: () => void }) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="w-full max-w-md space-y-5 text-center">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-amber-500/10">
          <ShieldCheck className="h-8 w-8 text-amber-600" />
        </div>
        <div className="space-y-2">
          <h1 className="text-xl font-semibold">Access to your notes folder</h1>
          <p className="text-sm leading-relaxed text-muted-foreground">
            The app needs permission again to read and write your notes folder
            (browsers drop folder access between visits; Android needs
            All-files-access to be enabled).
          </p>
        </div>
        <Button size="lg" className="w-full gap-2" onClick={onReauthorize}>
          <RefreshCcw className="h-4 w-4" /> Grant access
        </Button>
        <p className="text-xs text-muted-foreground">
          On Android you may be taken to system settings — enable
          &ldquo;All files access&rdquo; for Notes, then come back.
        </p>
      </div>
    </div>
  );
}
