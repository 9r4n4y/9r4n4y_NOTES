import { KeepApp } from "@/components/keep/KeepApp";

export default function Home() {
  return <KeepApp />;
}
