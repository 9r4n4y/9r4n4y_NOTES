import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";
import { ThemeProvider } from "@/components/keep/theme-provider";

export const metadata: Metadata = {
  title: "Notes — Notes, Lists & Folders",
  description:
    "A fast, beautifully organised notepad inspired by Google Keep. Capture notes, checklists, photos and GIFs, file them into genre folders, personalise the look and hide secrets in the vault.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f1f3f4" },
    { media: "(prefers-color-scheme: dark)", color: "#111113" },
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="antialiased">
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster richColors position="bottom-left" closeButton />
        </ThemeProvider>
      </body>
    </html>
  );
}
