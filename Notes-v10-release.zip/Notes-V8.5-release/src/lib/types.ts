// Compatibility shim — all shared types now live in the platform-agnostic core.
export * from "@/core/types";
