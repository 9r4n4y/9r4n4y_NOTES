"use client";

// Vault secret-chamber helpers: code hashing + session-scoped open state.

export const VAULT_CODE_KEY = "notes-vault-code-hash"; // permanent (localStorage)
export const VAULT_SESSION_KEY = "notes-vault-open"; // session only (sessionStorage)

export const VAULT_OPEN_PHRASE = "open_vault";
export const VAULT_CLOSE_PHRASE = "close_vault";

async function sha256(text: string): Promise<string> {
  const bytes = new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

/** A vault code has been set (so open_vault will ask for it). */
export function vaultCodeExists(): boolean {
  try {
    return !!localStorage.getItem(VAULT_CODE_KEY);
  } catch {
    return false;
  }
}

/** Hash + permanently store the vault code. */
export async function setVaultCode(code: string): Promise<void> {
  const hash = await sha256(code);
  try {
    localStorage.setItem(VAULT_CODE_KEY, hash);
  } catch {
    // storage unavailable — ignore
  }
}

/** Verify a candidate code against the stored hash. */
export async function verifyVaultCode(code: string): Promise<boolean> {
  let stored: string | null = null;
  try {
    stored = localStorage.getItem(VAULT_CODE_KEY);
  } catch {
    return false;
  }
  if (!stored) return true; // no code set — anything passes
  const hash = await sha256(code);
  return hash === stored;
}

/** Read the session-scoped vault-open flag (client only). */
export function readVaultSession(): boolean {
  try {
    return sessionStorage.getItem(VAULT_SESSION_KEY) === "1";
  } catch {
    return false;
  }
}

export function writeVaultSession(open: boolean): void {
  try {
    if (open) sessionStorage.setItem(VAULT_SESSION_KEY, "1");
    else sessionStorage.removeItem(VAULT_SESSION_KEY);
  } catch {
    // ignore
  }
}
