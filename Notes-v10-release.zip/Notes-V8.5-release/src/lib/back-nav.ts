"use client";

import { useEffect, useRef } from "react";

// ---------------------------------------------------------------------------
// back-nav — unified BACK handling for the app's UI layers (V8, bug #3).
//
// One LIFO stack of "back handlers", consumed by:
//   • Android system back  → MainActivity evaluates window.__handleAndroidBack()
//     which runs the top handler. When nothing consumes the back press the
//     native shell does the app-home action (moveTaskToBack).
//   • Browser back (web)   → guarded history entries. Every UI layer pushes a
//     history entry on open; popstate closes the top layer; closing a layer
//     through its own UI consumes its history entry.
//
// Layers (in typical z-order): lightbox, image editor, note editor, dialogs,
// mobile drawer — plus a bottom "main view history" handler installed by
// KeepApp. The top-most handler wins, so BACK dismisses the surface the user
// actually sees, then the one below, and only exits when nothing is left.
// ---------------------------------------------------------------------------

type BackHandler = () => boolean;

interface StackEntry {
  id: number;
  handler: BackHandler;
}

const stack: StackEntry[] = [];
let seq = 0;

/** Register a handler. Returns an unregister function. */
export function addBackHandler(handler: BackHandler): () => void {
  const id = ++seq;
  stack.push({ id, handler });
  return () => removeBackHandler(id);
}

export function removeBackHandler(id: number): void {
  const idx = stack.findIndex((e) => e.id === id);
  if (idx >= 0) stack.splice(idx, 1);
}

/** Run the top-most handler. True when a layer consumed the back press. */
export function handleBack(): boolean {
  if (stack.length === 0) return false;
  try {
    return stack[stack.length - 1].handler();
  } catch (e) {
    console.error("back handler failed", e);
    return false;
  }
}

// ---------------------------------------------------------------- web history

let historyApiInstalled = false;
let guardDepth = 0;
let ignoreNextPop = false;

function currentEntryIsGuard(): boolean {
  try {
    const st = history.state as { notesGuard?: number } | null;
    return !!st && typeof st.notesGuard === "number";
  } catch {
    return false;
  }
}

function pushHistoryGuard(): void {
  guardDepth++;
  try {
    history.pushState({ notesGuard: guardDepth }, "");
  } catch {
    guardDepth--;
  }
}

function popHistoryGuard(): void {
  if (guardDepth <= 0) return;
  // only consume a real history entry when a guard entry is still the
  // current one — otherwise a UI close must never walk real history
  if (currentEntryIsGuard()) {
    guardDepth--;
    ignoreNextPop = true;
    try {
      history.back();
      return;
    } catch {
      ignoreNextPop = false;
    }
  }
  guardDepth--;
}

/**
 * Install the platform back integration. Idempotent; called from KeepApp's
 * mount effect (client only).
 */
export function installBackNavigation(): void {
  if (historyApiInstalled || typeof window === "undefined") return;
  historyApiInstalled = true;

  const w = window as unknown as {
    __handleAndroidBack?: () => boolean;
    __pushBackGuard?: () => void;
    __popBackGuard?: () => void;
    AndroidBridge?: unknown;
  };

  if (w.AndroidBridge) {
    // Android: the native shell asks JS whether the back press was consumed.
    w.__handleAndroidBack = () => handleBack();
    return;
  }

  // Web: browser back closes the top UI layer through guarded history
  // entries; with no layers open, back behaves like the browser always did.
  w.__pushBackGuard = pushHistoryGuard;
  w.__popBackGuard = popHistoryGuard;
  window.addEventListener("popstate", () => {
    if (ignoreNextPop) {
      ignoreNextPop = false;
      return;
    }
    // a real back press consumed a guard entry → close the layer that owned
    // it (works whether the user landed on the base page or a deeper guard)
    if (guardDepth > 0) {
      guardDepth--;
      handleBack();
    }
  });
}

/**
 * React hook: binds a UI layer's open state to the back stack. While `open`
 * is true the layer is the top-most back target (if registered last).
 */
export function useBackLayer(open: boolean, close: () => void): void {
  const closeRef = useRef(close);
  closeRef.current = close;

  useEffect(() => {
    if (!open) return;
    const remove = addBackHandler(() => {
      closeRef.current();
      return true;
    });
    // web history guard (no-op on Android)
    (window as unknown as { __pushBackGuard?: () => void }).__pushBackGuard?.();
    return () => {
      remove();
      (window as unknown as { __popBackGuard?: () => void }).__popBackGuard?.();
    };
  }, [open]);
}
