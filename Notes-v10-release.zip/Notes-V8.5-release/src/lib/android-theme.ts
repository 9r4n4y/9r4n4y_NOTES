"use client";

// ---------------------------------------------------------------------------
// android-theme — reliable Dark/Light/System theming inside the Android shell.
//
// Problem: next-themes detects "system" via window.matchMedia("(prefers-color-
// scheme: dark)"). In a WebView that query is not guaranteed to track the
// device's real UI mode across OEM/WebView versions, so "System" could behave
// like Light on a dark device (V8 bug #4).
//
// Fix: when the native bridge is present we install a matchMedia shim for the
// color-scheme query that is fed by the shell itself:
//   • AndroidBridge.isSystemDark()          — authoritative startup value
//   • window.__systemThemeChanged(dark)     — pushed by onConfigurationChanged
//     when the system theme changes while the app is running.
// next-themes keeps using its normal code path — it just sees a correctly
// reporting "media query". On web nothing is patched.
// ---------------------------------------------------------------------------

interface ShimMql {
  media: string;
  matches: boolean;
  onchange: unknown;
  addEventListener: (type: string, listener: (e: { matches: boolean }) => void) => void;
  removeEventListener: (type: string, listener: (e: { matches: boolean }) => void) => void;
  addListener: (listener: (e: { matches: boolean }) => void) => void;
  removeListener: (listener: (e: { matches: boolean }) => void) => void;
  dispatchEvent: () => boolean;
}

const SCHEME_QUERY = "prefers-color-scheme";
let installed = false;

export function installAndroidThemeShim(): void {
  if (installed || typeof window === "undefined") return;
  const bridge = (window as unknown as { AndroidBridge?: { isSystemDark?: () => boolean } })
    .AndroidBridge;
  if (!bridge) return; // web — native matchMedia is authoritative
  installed = true;

  const listeners = new Set<(e: { matches: boolean }) => void>();
  let systemDark = false;
  try {
    systemDark = bridge.isSystemDark?.() ?? false;
  } catch {
    systemDark = false;
  }

  const mql: ShimMql = {
    media: "(prefers-color-scheme: dark)",
    matches: systemDark,
    onchange: null,
    addEventListener: (_type, listener) => listeners.add(listener),
    removeEventListener: (_type, listener) => listeners.delete(listener),
    addListener: (listener) => listeners.add(listener),
    removeListener: (listener) => listeners.delete(listener),
    dispatchEvent: () => false,
  };

  const original = window.matchMedia.bind(window);
  window.matchMedia = ((query: string) => {
    if (typeof query === "string" && query.includes(SCHEME_QUERY)) {
      return mql as unknown as MediaQueryList;
    }
    return original(query);
  }) as typeof window.matchMedia;

  // native → JS push (system theme changed while running)
  (window as unknown as { __systemThemeChanged?: (dark: boolean) => void }).__systemThemeChanged =
    (dark: boolean) => {
      if (mql.matches === dark) return;
      mql.matches = dark;
      const event = { matches: dark, media: mql.media };
      listeners.forEach((l) => {
        try {
          l(event);
        } catch {
          /* listener error must not break others */
        }
      });
    };
}

/** True when running inside the Android shell. */
export function isAndroidShell(): boolean {
  return typeof window !== "undefined" && !!(window as unknown as { AndroidBridge?: unknown }).AndroidBridge;
}
