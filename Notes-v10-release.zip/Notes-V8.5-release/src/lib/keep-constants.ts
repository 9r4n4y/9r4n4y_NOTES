// Google Keep-inspired design constants

export interface KeepColor {
  key: string;
  name: string;
  light: string;
  dark: string;
  /** text color that stays readable on top of the note background */
  fgLight: string;
  fgDark: string;
  /** dot shown in pickers */
  swatch: string;
}

export const KEEP_COLORS: KeepColor[] = [
  {
    key: "default",
    name: "Default",
    light: "#ffffff",
    dark: "#1e1f20",
    fgLight: "#202124",
    fgDark: "#e3e3e3",
    swatch: "#ffffff",
  },
  {
    key: "blue",
    name: "Cerulean",
    light: "#aecbfa",
    dark: "#3b4a6b",
    fgLight: "#1f2b45",
    fgDark: "#e3e9f7",
    swatch: "#aecbfa",
  },
  {
    key: "brown",
    name: "Brown",
    light: "#e6c9a8",
    dark: "#57493a",
    fgLight: "#3f3222",
    fgDark: "#f1e7dc",
    swatch: "#e6c9a8",
  },
  {
    key: "gray",
    name: "Gray",
    light: "#e8eaed",
    dark: "#323232",
    fgLight: "#2d2f31",
    fgDark: "#e3e3e3",
    swatch: "#e8eaed",
  },
  {
    key: "teal",
    name: "Teal",
    light: "#a7ffeb",
    dark: "#2d554e",
    fgLight: "#1f4540",
    fgDark: "#ddf5ef",
    swatch: "#a7ffeb",
  },
  {
    key: "green",
    name: "Green",
    light: "#ccff90",
    dark: "#414d33",
    fgLight: "#31441c",
    fgDark: "#e7f4d7",
    swatch: "#ccff90",
  },
  {
    key: "pink",
    name: "Pink",
    light: "#fdcfe8",
    dark: "#5d3b51",
    fgLight: "#4d2438",
    fgDark: "#fbe3f0",
    swatch: "#fdcfe8",
  },
  {
    key: "purple",
    name: "Purple",
    light: "#d7aefb",
    dark: "#4b3d69",
    fgLight: "#3c2560",
    fgDark: "#eee3fb",
    swatch: "#d7aefb",
  },
  {
    key: "red",
    name: "Coral",
    light: "#f28b82",
    dark: "#66332f",
    fgLight: "#4d2320",
    fgDark: "#fde3e0",
    swatch: "#f28b82",
  },
  {
    key: "yellow",
    name: "Sand",
    light: "#fff475",
    dark: "#665f2e",
    fgLight: "#4a4514",
    fgDark: "#fff6cf",
    swatch: "#fff475",
  },
  {
    key: "orange",
    name: "Orange",
    light: "#fbbc04",
    dark: "#6f5311",
    fgLight: "#4d3a06",
    fgDark: "#ffe9b8",
    swatch: "#fbbc04",
  },
];

export function getColor(key: string, isDark: boolean): KeepColor {
  return KEEP_COLORS.find((c) => c.key === key) ?? KEEP_COLORS[0];
}

export function noteStyle(
  colorKey: string,
  isDark: boolean
): React.CSSProperties {
  const c = getColor(colorKey, isDark);
  return {
    backgroundColor: isDark ? c.dark : c.light,
    color: isDark ? c.fgDark : c.fgLight,
  };
}

export const FOLDER_EMOJIS = [
  "📁", "⭐", "💼", "🏠", "❤️", "📚", "🎵", "🎬", "✈️", "🍳",
  "💪", "💡", "🎨", "🔬", "🌱", "🐶", "🎉", "⚽", "🕹️", "💰",
];

export const FOLDER_TINTS: Record<string, { light: string; dark: string }> = {
  default: { light: "#f1f3f4", dark: "#2a2b2c" },
  blue: { light: "#d3e3fd", dark: "#394457" },
  red: { light: "#fadbd9", dark: "#54302d" },
  yellow: { light: "#fef0c0", dark: "#57502a" },
  green: { light: "#dff3d0", dark: "#3c4a2e" },
  purple: { light: "#ead3fc", dark: "#463a5e" },
};

export function folderTint(color: string, isDark: boolean) {
  return FOLDER_TINTS[color] ?? FOLDER_TINTS.default;
}

/** Max size (bytes) allowed for a raw GIF upload */
export const MAX_GIF_BYTES = 8 * 1024 * 1024;
