"use client";

/**
 * Saves a Blob to the user's device.
 * - Inside the Android APK: hands the bytes to the native bridge, which writes
 *   them into the phone's Downloads folder (MediaStore) — no permission prompt
 *   needed, works with all file managers.
 * - In a normal browser: falls back to the classic anchor-download.
 */
export async function saveBlob(name: string, blob: Blob): Promise<void> {
  const bridge = (window as unknown as {
    AndroidBridge?: {
      saveFile?: (name: string, base64: string) => void;
      hasAllFilesAccess?: () => boolean;
    };
  }).AndroidBridge;

  if (bridge?.saveFile) {
    // First export without the storage permission → show the friendly
    // permission explainer once (non-blocking; Android 10+ writes to
    // Downloads via MediaStore regardless).
    try {
      if (typeof bridge.hasAllFilesAccess === "function" && !bridge.hasAllFilesAccess()) {
        const KEY = "notes-perm-export-nudged";
        let nudged = false;
        try {
          nudged = sessionStorage.getItem(KEY) === "1";
        } catch { /* ignore */ }
        if (!nudged) {
          try { sessionStorage.setItem(KEY, "1"); } catch { /* ignore */ }
          window.dispatchEvent(new CustomEvent("notes:open-permissions"));
        }
      }
    } catch { /* ignore */ }

    const base64 = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = String(reader.result || "");
        const comma = result.indexOf(",");
        resolve(comma >= 0 ? result.slice(comma + 1) : result);
      };
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(blob);
    });
    bridge.saveFile(name, base64);
    return;
  }

  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}
