"use client";

import { useSyncExternalStore } from "react";

const emptySubscribe = () => () => {};

function match(query: string) {
  return () => typeof window !== "undefined" && window.matchMedia(query).matches;
}

const serverFalse = () => false;

/** True on touch-only devices (phones/tablets) where :hover never fires reliably. */
export function useIsTouch(): boolean {
  return useSyncExternalStore(
    emptySubscribe,
    match("(hover: none), (pointer: coarse)"),
    serverFalse
  );
}
