// ---------------------------------------------------------------------------
// Markdown <-> note model conversions + filesystem-safe naming.
//
// Disk format of a note:
//
//   <Root>/<Note Title>/node.md
//   <Root>/<Note Title>/attachment/<files>
//
// node.md = YAML front-matter (metadata) + markdown body (content).
// Checklist notes are plain markdown task lists (`- [ ] item`), so every
// other markdown tool can read them.
// ---------------------------------------------------------------------------

import { parseNoteFile, serializeFrontMatter, fm, KNOWN_KEYS } from "./frontmatter";
import type { ChecklistItemDTO, NoteDTO, NoteType } from "./types";

export const NOTE_FILE = "node.md";
export const ATTACHMENT_DIR = "attachment";
export const CONFIG_DIR = ".notes";
export const CONFIG_FILE = ".notes/config.json";

// ---------------------------------------------------------------- task lists

const TASK_RE = /^(\s*)([-*])\s+\[([ xX])\]\s?(.*)$/;

/** Extract markdown task-list items (`- [ ]` / `- [x]`) from a body. */
export function parseTaskItems(body: string): ChecklistItemDTO[] {
  const items: ChecklistItemDTO[] = [];
  for (const line of body.split("\n")) {
    const m = TASK_RE.exec(line);
    if (m) {
      items.push({
        id: `t${items.length}`,
        text: m[4].trim(),
        checked: m[3].toLowerCase() === "x",
        order: items.length,
      });
    }
  }
  return items;
}

/** Count tasks + done tasks (used for card badges). */
export function taskStats(body: string): { total: number; done: number } {
  let total = 0;
  let done = 0;
  for (const line of body.split("\n")) {
    const m = TASK_RE.exec(line);
    if (m) {
      total++;
      if (m[3].toLowerCase() === "x") done++;
    }
  }
  return { total, done };
}

/** Flip the checked state of the task at `index` (0-based). Immutable. */
export function toggleTaskLine(body: string, index: number, checked: boolean): string {
  let seen = -1;
  const lines = body.split("\n").map((line) => {
    const m = TASK_RE.exec(line);
    if (!m) return line;
    seen++;
    if (seen !== index) return line;
    return `${m[1]}${m[2]} [${checked ? "x" : " "}] ${m[4]}`;
  });
  return lines.join("\n");
}

/** Set the text of the task at `index` (keeps state). Immutable. */
export function setTaskText(body: string, index: number, text: string): string {
  let seen = -1;
  const lines = body.split("\n").map((line) => {
    const m = TASK_RE.exec(line);
    if (!m) return line;
    seen++;
    if (seen !== index) return line;
    return `${m[1]}${m[2]} [${m[3]}] ${text}`;
  });
  return lines.join("\n");
}

/** Build a task-list body from item drafts (composer / editor helper). */
export function tasksToBody(items: { text: string; checked: boolean }[]): string {
  return items.map((it) => `- [${it.checked ? "x" : " "}] ${it.text}`).join("\n");
}

/** Convert a plain-text body into task lines (text → checklist mode). */
export function textToListBody(body: string): string {
  return body
    .split("\n")
    .map((line) => {
      if (TASK_RE.test(line)) return line.replace(/\[( |x|X)\]/, (m) => m.toLowerCase());
      if (line.trim() === "") return line;
      return `- [ ] ${line.replace(/^\s*[-*+]\s+/, "")}`;
    })
    .join("\n");
}

/** Convert task lines back into plain lines (checklist → text mode). */
export function listToTextBody(body: string): string {
  return body.replace(/^(\s*)([-*])\s+\[([ xX])\]\s?/gm, "$1");
}

/** True when a body holds real content (task markers alone don't count). */
export function bodyHasRealContent(body: string): boolean {
  const stripped = body
    .replace(/^(\s*)([-*])\s+\[([ xX])\]\s?/gm, "")
    .replace(/\s/g, "");
  return stripped.length > 0;
}

// ------------------------------------------------------------- note <-> disk

export interface NoteDiskModel {
  id: string;
  title: string;
  type: NoteType;
  color: string;
  pinned: boolean;
  archived: boolean;
  trashed: boolean;
  vaulted: boolean;
  folder: string | null;
  labels: string[];
  order: number | null;
  created: string;
  updated: string;
  body: string;
}

/** Serialise a full note (front-matter + body) to the node.md text. */
export function noteToMarkdown(
  note: NoteDiskModel,
  extraMeta?: Record<string, string>
): string {
  const meta: Record<string, unknown> = {
    id: note.id,
    title: note.title,
    type: note.type === "list" ? "list" : "text",
    color: note.color || "default",
    pinned: note.pinned,
    archived: note.archived,
    trashed: note.trashed,
    vaulted: note.vaulted,
    folder: note.folder,
    labels: note.labels,
    order: note.order,
    created: note.created,
    updated: note.updated,
  };
  let yaml = serializeFrontMatter(meta);
  // preserve metadata we do not model (written by other tools), verbatim
  if (extraMeta) {
    for (const [key, raw] of Object.entries(extraMeta)) {
      if (!KNOWN_KEYS.has(key) && raw !== "" && /^[A-Za-z0-9_-]+$/.test(key)) {
        yaml += `\n${key}: ${raw}`;
      }
    }
  }
  const body = note.body.endsWith("\n") ? note.body : `${note.body}\n`;
  return `---\n${yaml}\n---\n\n${body}`;
}

export interface ParsedNoteResult {
  model: NoteDiskModel;
  /** keys we do not model but found on disk (preserved on write-back) */
  extraMeta: Record<string, string>;
  hadFrontMatter: boolean;
}

/** Parse node.md text into the disk model. Never throws. */
export function markdownToNote(text: string, dirName: string): ParsedNoteResult {
  const parsed = parseNoteFile(text);
  const m = parsed.meta as Record<string, unknown>;
  const type = String(m.type ?? "text") === "list" ? "list" : "text";
  const model: NoteDiskModel = {
    id: fm.str(m, "id") || generateId(),
    title: fm.str(m, "title") || dirName,
    type,
    color: fm.str(m, "color", "default") || "default",
    pinned: fm.bool(m, "pinned"),
    archived: fm.bool(m, "archived"),
    trashed: fm.bool(m, "trashed"),
    vaulted: fm.bool(m, "vaulted"),
    folder: fm.str(m, "folder") || null,
    labels: fm.strArray(m, "labels"),
    order: fm.num(m, "order"),
    created: fm.str(m, "created") || new Date().toISOString(),
    updated: fm.str(m, "updated") || new Date().toISOString(),
    body: parsed.body,
  };
  return { model, extraMeta: parsed.extra, hadFrontMatter: parsed.hadFrontMatter };
}

export function generateId(): string {
  try {
    if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  } catch {
    /* fall through */
  }
  return "n" + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
}

// ------------------------------------------------------------- safe naming

/**
 * Windows/Android forbidden characters + control chars. We replace them with
 * a full-width look-alike where one exists so titles stay readable, else "-".
 */
const CHAR_MAP: Record<string, string> = {
  "/": "／",
  "\\": "＼",
  ":": "：",
  "*": "＊",
  "?": "？",
  '"': "＂",
  "<": "＜",
  ">": "＞",
  "|": "｜",
  "\n": "-",
  "\r": "-",
  "\t": " ",
  "\0": "-",
};

/** Sanitise a note title into a folder/file name (no dedupe — see uniqueName). */
export function sanitizeName(input: string, maxLen = 80): string {
  let name = (input ?? "").replace(/[\\/:*?"<>|\n\r\t\0]/g, (ch) => CHAR_MAP[ch] ?? "-");
  // strip control characters
  name = name.replace(/[\u0000-\u001f\u007f]/g, "");
  // trailing dots / spaces break Windows & some Android FS layers
  name = name.replace(/[. ]+$/g, "").replace(/^\.+/, "");
  name = name.trim();
  if (name.length > maxLen) name = name.slice(0, maxLen).trim();
  if (name.replace(/[. ]+$/g, "") === "") name = "";
  return name;
}

/** Sanitise an attachment file name (keeps extension). */
export function sanitizeFileName(input: string, maxLen = 80): string {
  const clean = sanitizeName(input, maxLen);
  return clean || "file";
}

/**
 * Make `base` unique inside a collection of existing names.
 * Comparison is case-insensitive + accent-insensitive-ish (lowercase) so the
 * result is safe on case-folding filesystems (Windows, most Android).
 * Produces "Base", "Base (2)", "Base (3)"…
 */
export function uniqueName(base: string, existing: Iterable<string>, reservedSelf?: string): string {
  const taken = new Set<string>();
  for (const name of existing) {
    if (reservedSelf && name === reservedSelf) continue;
    taken.add(name.toLowerCase());
  }
  if (!taken.has(base.toLowerCase())) return base;
  const dot = base.lastIndexOf(".");
  const isFile = dot > 0 && base.length - dot <= 12; // looks like an extension
  const stem = isFile ? base.slice(0, dot) : base;
  const ext = isFile ? base.slice(dot) : "";
  for (let i = 2; i < 1000; i++) {
    const candidate = `${stem} (${i})${ext}`;
    if (!taken.has(candidate.toLowerCase())) return candidate;
  }
  return `${stem} (${Date.now().toString(36)})${ext}`;
}

// ------------------------------------------------------------- text helpers

/** Strip markdown syntax to plain text (search + previews). */
export function markdownToPlain(md: string): string {
  return md
    // strip optional titles from images/links first: ](path "title") → ](path)
    .replace(/(\]\([^)\s]+)\s+"[^"]*"/g, "$1")
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/`([^`]*)`/g, "$1")
    .replace(/!\[([^\]]*)\]\(([^)\s]+)\)/g, " ")
    .replace(/\[([^\]]*)\]\(([^)\s]+)\)/g, "$1")
    .replace(/^\s{0,3}#{1,6}\s+/gm, "")
    .replace(/^\s{0,3}>\s?/gm, "")
    .replace(/^\s{0,3}([-*_])\s*\1\s*\1[\s\S]*$/gm, "")
    .replace(/^\s*[-*+]\s+\[([ xX])\]\s?/gm, "")
    .replace(/^\s*[-*+]\s+/gm, "")
    .replace(/^\s*\d+\.\s+/gm, "")
    .replace(/(\*\*|__)(.*?)\1/g, "$2")
    .replace(/(\*|_)(.*?)\1/g, "$2")
    .replace(/(~~)(.*?)\1/g, "$2")
    .replace(/={2,}/g, "")
    .trim();
}

/**
 * Extract attachment paths referenced by a markdown body:
 * `![alt](attachment/x.png)` and `[link](attachment/x.png)`.
 * Paths in markdown are percent-encoded; returned paths are decoded.
 */
export function referencedAttachmentPaths(body: string): Set<string> {
  const out = new Set<string>();
  const re = /\[[^\]]*\]\(\s*([^)\s]+)[^)]*\)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(body)) !== null) {
    try {
      const target = decodeURIComponent(m[1]);
      if (target.startsWith(`${ATTACHMENT_DIR}/`)) out.add(target);
    } catch {
      /* malformed encoding — ignore */
    }
  }
  return out;
}

/** Encode an attachment path for safe inclusion in markdown (spaces, parens…). */
export function encodeAttachmentPath(file: string): string {
  return file
    .split("/")
    .map((seg) => encodeURIComponent(seg).replace(/[!'()*]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`))
    .join("/");
}

/** Decode a percent-encoded attachment path from markdown. */
export function decodeAttachmentPath(file: string): string {
  try {
    return file
      .split("/")
      .map((seg) => decodeURIComponent(seg))
      .join("/");
  } catch {
    return file;
  }
}

export { KNOWN_KEYS };
