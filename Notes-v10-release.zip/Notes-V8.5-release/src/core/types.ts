// ---------------------------------------------------------------------------
// Shared core types for the local-first Notes app.
// The note's markdown file (<root>/<Note Title>/node.md) is the single source
// of truth; these types describe the in-memory model derived from it.
// ---------------------------------------------------------------------------

export type NoteType = "text" | "list";

export type ViewKind =
  | "notes"
  | "archive"
  | "trash"
  | "folders"
  | "folder"
  | "label"
  | "vault";

export interface ChecklistItemDTO {
  id: string;
  text: string;
  checked: boolean;
  order: number;
}

/** An attachment lives inside the note folder: `attachment/<file>` */
export interface AttachmentDTO {
  /** file name inside the attachment/ folder (unique per note) */
  id: string;
  /** path relative to the note folder — always `attachment/<id>` */
  file: string;
  /** display / original file name */
  name: string;
  mime: string;
  kind: "image" | "gif";
  size: number;
  /** session object-URL used for display (never persisted) */
  url: string;
}

/** Label identity == its name (that is what is stored in node.md frontmatter). */
export interface LabelDTO {
  id: string;
  name: string;
}

/** Folder (genre) identity == its name (stored in node.md frontmatter). */
export interface FolderDTO {
  id: string;
  name: string;
  emoji: string;
  color: string;
}

export interface NoteDTO {
  /** stable UUID — lives in node.md frontmatter */
  id: string;
  /** folder name on disk (unique within the root); changes when renamed */
  dir: string;
  title: string;
  /** markdown body (frontmatter excluded) — source of truth for content */
  content: string;
  type: NoteType;
  color: string;
  pinned: boolean;
  archived: boolean;
  trashed: boolean;
  vaulted: boolean;
  folderId: string | null;
  folder?: FolderDTO | null;
  /** derived from markdown task-list lines when type === "list" */
  items: ChecklistItemDTO[];
  labels: LabelDTO[];
  attachments: AttachmentDTO[];
  /** manual drag-and-drop position (null = no manual order yet) */
  order: number | null;
  createdAt: string;
  updatedAt: string;
  /** unknown front-matter keys read from node.md, preserved on write-back */
  extraMeta?: Record<string, string>;
}

/** Shape of <root>/.notes/config.json — app-level metadata ONLY (never note data). */
export interface NotesConfig {
  version: 1;
  /** genre-folder definitions (emoji + tint); note→folder links live in node.md */
  folders: { name: string; emoji: string; color: string }[];
  /** known label names; note→label links live in node.md frontmatter */
  labels: string[];
}

export const DEFAULT_NOTES_CONFIG: NotesConfig = { version: 1, folders: [], labels: [] };
