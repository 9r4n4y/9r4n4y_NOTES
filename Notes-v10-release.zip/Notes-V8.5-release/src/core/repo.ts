// ---------------------------------------------------------------------------
// NoteRepository — every note/attachment operation on top of a FSAdapter.
//
// Disk layout (node.md is the single source of truth; no JSON for note data):
//
//   <Root>/
//   ├── Note Title 1/
//   │   ├── node.md                  ← YAML front-matter + markdown body
//   │   └── attachment/              ← only created when attachments exist
//   │       ├── image.png
//   │       └── animation.gif
//   ├── Note Title 2/
//   │   └── node.md
//   └── .notes/config.json           ← genre-folder emoji/tints + label names
//                                        (app-level metadata ONLY, never note data)
// ---------------------------------------------------------------------------

import {
  type DirEntry,
  type FSAdapter,
  basename,
  createMutex,
  dirname,
  joinPath,
  mimeForName,
} from "./fs/adapter";
import { rememberKind } from "./fs";
import {
  ATTACHMENT_DIR,
  CONFIG_DIR,
  CONFIG_FILE,
  NOTE_FILE,
  generateId,
  markdownToNote,
  noteToMarkdown,
  parseTaskItems,
  sanitizeFileName,
  sanitizeName,
  uniqueName,
} from "./markdown";
import { DEFAULT_NOTES_CONFIG, type AttachmentDTO, type NoteDTO, type NotesConfig } from "./types";

export interface ScanResult {
  notes: NoteDTO[];
  config: NotesConfig;
  /** folders that existed on disk but had no usable node.md (reported, not deleted) */
  skippedDirs: string[];
}

export interface PendingMedia {
  blob: Blob;
  name: string;
}

export interface CreateNoteInput {
  title?: string;
  content?: string;
  type?: "text" | "list";
  color?: string;
  pinned?: boolean;
  archived?: boolean;
  vaulted?: boolean;
  folderId?: string | null;
  labels?: string[];
  order?: number | null;
  media?: PendingMedia[];
}

/**
 * Local storage folder naming (V8):
 *
 *   [Archive_]FolderName(_LabelName...)_NoteTitle
 *
 * The on-disk note folder carries its metadata so the filesystem itself
 * describes the note (visible in any file manager / Obsidian). The INTERNAL
 * title in node.md front-matter stays the user-entered title — only the
 * folder name is derived. Components are underscore-separated in a fixed
 * order: archive flag, folder, labels (in note order), title.
 */
const ARCHIVE_PREFIX = "Archive";
const MAX_DIR_NAME = 120;

function safeComponent(value: string | null | undefined, fallback = ""): string {
  const clean = sanitizeName((value ?? "").trim(), 60);
  return clean || fallback;
}

/**
 * Compute the metadata-carrying directory base name for a note.
 * Pure string work — uniqueness is applied by the caller (uniqueName).
 */
export function storageDirBase(input: {
  title: string;
  archived?: boolean;
  folderId?: string | null;
  labels?: { name: string }[] | string[];
}): string {
  const parts: string[] = [];
  if (input.archived) parts.push(ARCHIVE_PREFIX);
  const folder = safeComponent(input.folderId, "");
  if (folder) parts.push(folder);
  if (input.labels) {
    for (const label of input.labels) {
      const name = typeof label === "string" ? label : label.name;
      const safe = safeComponent(name, "");
      if (safe) parts.push(safe);
    }
  }
  const title = safeComponent(input.title, "Untitled");
  parts.push(title);
  return sanitizeName(parts.join("_"), MAX_DIR_NAME) || "Untitled";
}

/** Same derivation for a full NoteDTO. */
export function noteStorageDir(note: {
  title: string;
  archived?: boolean;
  folderId?: string | null;
  labels?: { name: string }[] | string[];
}): string {
  return storageDirBase(note);
}

export class NoteRepository {
  readonly fs: FSAdapter;
  private urlCache = new Map<string, string>();
  /** serialise mutating operations so debounced saves never interleave */
  private writeLock = createMutex();

  constructor(fs: FSAdapter) {
    this.fs = fs;
  }

  // ------------------------------------------------------------------ roots

  get ready(): boolean {
    return this.fs.hasRoot();
  }

  async tryRestoreRoot(): Promise<boolean> {
    const ok = await this.fs.restoreRoot();
    if (ok) rememberKind(this.fs);
    return ok;
  }

  async pickRoot(): Promise<boolean> {
    const ok = await this.fs.pickRoot();
    if (ok) rememberKind(this.fs);
    return ok;
  }

  rootLabel(): string {
    return this.fs.rootLabel();
  }

  // ------------------------------------------------------------------- scan

  async scan(): Promise<ScanResult> {
    const notes: NoteDTO[] = [];
    const skippedDirs: string[] = [];
    const seenIds = new Set<string>();
    const rootEntries = await this.fs.listDir("");

    for (const entry of rootEntries) {
      if (entry.kind !== "dir") continue; // loose files are not our business
      if (entry.name.startsWith(".") || entry.name === CONFIG_DIR) continue;
      try {
        const files = await this.fs.listDir(entry.name);
        if (!files.some((f) => f.kind === "file" && f.name === NOTE_FILE)) {
          skippedDirs.push(entry.name);
          continue; // not a note folder — leave it untouched
        }
        const raw = await this.fs.readText(joinPath(entry.name, NOTE_FILE));
        const { model, extraMeta } = markdownToNote(raw, entry.name);

        // duplicated folder (user copy/pasted it) → give it a fresh identity
        let modelId = model.id;
        if (seenIds.has(modelId)) {
          modelId = generateId();
          model.id = modelId;
          await this.fs.writeText(
            joinPath(entry.name, NOTE_FILE),
            noteToMarkdown({ ...model, body: model.body })
          );
        }
        seenIds.add(modelId);

        const attachments = await this.listAttachments(entry.name);
        notes.push(this.toDTO(model, entry.name, attachments, extraMeta));
      } catch {
        skippedDirs.push(entry.name); // unreadable/corrupt — never crash the app
      }
    }

    const config = await this.loadConfig();
    return { notes, config, skippedDirs };
  }

  // -------------------------------------------------------------- note CRUD

  async createNote(input: CreateNoteInput): Promise<NoteDTO> {
    return this.writeLock(async () => {
      const existing = await this.listRootDirs();
      const base = storageDirBase({
        title: input.title?.trim() || "Untitled",
        archived: input.archived,
        folderId: input.folderId ?? null,
        labels: input.labels ?? [],
      });
      const dir = uniqueName(base, existing);

      const now = new Date().toISOString();
      const model = {
        id: generateId(),
        title: input.title?.trim() || dir,
        type: input.type === "list" ? "list" : "text",
        color: input.color || "default",
        pinned: input.pinned ?? false,
        archived: input.archived ?? false,
        trashed: false,
        vaulted: input.vaulted ?? false,
        folder: input.folderId ?? null,
        labels: input.labels ?? [],
        order: input.order ?? null,
        created: now,
        updated: now,
        body: input.content ?? "",
      } as const;

      await this.fs.makeDir(dir);
      await this.fs.writeText(joinPath(dir, NOTE_FILE), noteToMarkdown(model));

      const attachments: AttachmentDTO[] = [];
      for (const m of input.media ?? []) {
        attachments.push(await this.writeMediaFile(dir, m));
      }

      const dto = this.toDTO(
        model,
        dir,
        attachments,
        {}
      );
      return dto;
    });
  }

  /**
   * Persist the note (front-matter + body). Handles the title→folder rename.
   * Returns the (possibly new) directory name.
   */
  async saveNote(note: NoteDTO): Promise<string> {
    return this.writeLock(async () => {
      const targetDir = await this.resolveDirFor(note);
      note.dir = targetDir;
      const model = {
        id: note.id,
        title: note.title,
        type: note.type,
        color: note.color,
        pinned: note.pinned,
        archived: note.archived,
        trashed: note.trashed,
        vaulted: note.vaulted,
        folder: note.folderId,
        labels: note.labels.map((l) => l.name),
        order: note.order,
        created: note.createdAt,
        updated: note.updatedAt,
        body: note.content,
      };
      await this.fs.writeText(
        joinPath(targetDir, NOTE_FILE),
        noteToMarkdown(model, note.extraMeta)
      );
      return targetDir;
    });
  }

  /**
   * Rename the folder whenever the derived storage name changed — title,
   * archive flag, folder assignment or labels (V8 metadata naming).
   */
  private async resolveDirFor(note: NoteDTO): Promise<string> {
    const existing = await this.listRootDirs();
    const base = storageDirBase({
      title: note.title.trim() || note.dir || "Untitled",
      archived: note.archived,
      folderId: note.folderId,
      labels: note.labels,
    });
    const desired = uniqueName(base, existing, note.dir);
    if (desired === note.dir) return note.dir;
    await this.renameDir(note.dir, desired);
    return desired;
  }

  async renameDir(oldDir: string, newDir: string): Promise<void> {
    // fast path: native rename (Android adapter supports directories)
    try {
      await this.fs.rename(oldDir, newDir);
      this.rekeyUrls(oldDir, newDir);
      return;
    } catch {
      /* fall through to copy+delete (browser API cannot rename directories) */
    }
    await this.copyDir(oldDir, newDir);
    await this.fs.remove(oldDir, true);
    this.rekeyUrls(oldDir, newDir);
  }

  private async copyDir(srcDir: string, dstDir: string): Promise<void> {
    await this.fs.makeDir(dstDir);
    const entries = await this.fs.listDir(srcDir);
    for (const e of entries) {
      const from = joinPath(srcDir, e.name);
      const to = joinPath(dstDir, e.name);
      if (e.kind === "dir") {
        if (e.name === ATTACHMENT_DIR) {
          await this.copyDir(from, to);
        }
        continue;
      }
      const data = await this.fs.readBinary(from);
      await this.fs.writeBinary(to, data);
    }
  }

  async deleteNoteDir(dir: string): Promise<void> {
    return this.writeLock(async () => {
      try {
        await this.fs.remove(dir, true);
      } finally {
        this.invalidateDirUrls(dir);
      }
    });
  }

  async duplicateNote(source: NoteDTO): Promise<NoteDTO> {
    return this.writeLock(async () => {
      const existing = await this.listRootDirs();
      const base = storageDirBase({
        title: source.title || "Untitled",
        archived: source.archived,
        folderId: source.folderId,
        labels: source.labels,
      });
      const dir = uniqueName(base, existing);
      await this.copyDir(source.dir, dir);
      // fresh identity + Keep semantics (unpinned, not trashed)
      const now = new Date().toISOString();
      const model = {
        id: generateId(),
        title: source.title,
        type: source.type,
        color: source.color,
        pinned: false,
        archived: source.archived,
        trashed: false,
        vaulted: source.vaulted,
        folder: source.folderId,
        labels: source.labels.map((l) => l.name),
        order: source.order,
        created: now,
        updated: now,
        body: source.content,
      };
      await this.fs.writeText(joinPath(dir, NOTE_FILE), noteToMarkdown(model));
      const attachments = await this.listAttachments(dir);
      const dto = this.toDTO(model, dir, attachments, {});
      // give the copy its own object URLs so previews work instantly
      for (const att of dto.attachments) {
        const srcKey = `${source.dir}/${att.file}`;
        const cached = this.urlCache.get(srcKey);
        if (cached) this.urlCache.set(`${dir}/${att.file}`, cached);
      }
      return dto;
    });
  }

  // ------------------------------------------------------------ attachments

  async listAttachments(dir: string): Promise<AttachmentDTO[]> {
    const attDir = joinPath(dir, ATTACHMENT_DIR);
    let entries: DirEntry[];
    try {
      entries = await this.fs.listDir(attDir);
    } catch {
      return [];
    }
    const out: AttachmentDTO[] = [];
    for (const e of entries) {
      if (e.kind !== "file" || e.name.startsWith(".")) continue;
      const mime = mimeForName(e.name);
      out.push({
        id: e.name,
        file: `${ATTACHMENT_DIR}/${e.name}`,
        name: e.name,
        mime,
        kind: mime === "image/gif" ? "gif" : "image",
        size: e.size ?? 0,
        url: this.urlCache.get(`${dir}/${ATTACHMENT_DIR}/${e.name}`) ?? "",
      });
    }
    return out;
  }

  async addAttachment(note: NoteDTO, blob: Blob, name: string): Promise<AttachmentDTO> {
    return this.writeLock(async () => {
      // NOTE: pure — the store owns note state updates
      return this.writeMediaFile(note.dir, { blob, name });
    });
  }

  private async writeMediaFile(dir: string, media: PendingMedia): Promise<AttachmentDTO> {
    const attDir = joinPath(dir, ATTACHMENT_DIR);
    await this.fs.makeDir(attDir);
    const existing = (await this.fs.listDir(attDir).catch(() => [])).map((e) => e.name);
    const safe = sanitizeFileName(media.name || "image");
    const name = uniqueName(safe, existing);
    const path = joinPath(attDir, name);
    const data = new Uint8Array(await media.blob.arrayBuffer());
    await this.fs.writeBinary(path, data);
    const mime = media.blob.type || mimeForName(name);
    return {
      id: name,
      file: `${ATTACHMENT_DIR}/${name}`,
      name,
      mime,
      kind: mime === "image/gif" ? "gif" : "image",
      size: data.byteLength,
      url: "",
    };
  }

  async removeAttachment(note: NoteDTO, att: AttachmentDTO): Promise<void> {
    return this.writeLock(async () => {
      const path = joinPath(note.dir, att.file);
      try {
        await this.fs.remove(path, false);
      } catch {
        /* already gone */
      }
      const key = `${note.dir}/${att.file}`;
      const url = this.urlCache.get(key);
      if (url) {
        URL.revokeObjectURL(url);
        this.urlCache.delete(key);
      }
    });
  }

  /** Overwrite an attachment's bytes (image editor "save"). */
  async writeAttachment(note: NoteDTO, att: AttachmentDTO, blob: Blob): Promise<AttachmentDTO> {
    return this.writeLock(async () => {
      const path = joinPath(note.dir, att.file);
      const data = new Uint8Array(await blob.arrayBuffer());
      await this.fs.writeBinary(path, data);
      const key = `${note.dir}/${att.file}`;
      const old = this.urlCache.get(key);
      if (old) {
        URL.revokeObjectURL(old);
        this.urlCache.delete(key);
      }
      const mime = blob.type || att.mime;
      const url = URL.createObjectURL(blob);
      this.urlCache.set(key, url);
      return { ...att, mime, size: data.byteLength, url };
    });
  }

  /** Load (and cache) an object URL for display. */
  async ensureAttachmentUrl(dir: string, file: string): Promise<string> {
    const key = `${dir}/${file}`;
    const cached = this.urlCache.get(key);
    if (cached) return cached;
    try {
      const bytes = await this.fs.readBinary(joinPath(dir, file));
      const blob = new Blob([bytes as unknown as BlobPart], {
        type: mimeForName(basename(file)),
      });
      const url = URL.createObjectURL(blob);
      this.urlCache.set(key, url);
      return url;
    } catch {
      return "";
    }
  }

  async readAttachmentBlob(dir: string, file: string): Promise<Blob | null> {
    try {
      const bytes = await this.fs.readBinary(joinPath(dir, file));
      return new Blob([bytes as unknown as BlobPart], { type: mimeForName(basename(file)) });
    } catch {
      return null;
    }
  }

  private rekeyUrls(oldDir: string, newDir: string): void {
    for (const [key, url] of [...this.urlCache.entries()]) {
      if (key === oldDir || key.startsWith(`${oldDir}/`)) {
        this.urlCache.delete(key);
        this.urlCache.set(newDir + key.slice(oldDir.length), url);
      }
    }
  }

  private invalidateDirUrls(dir: string): void {
    for (const [key, url] of [...this.urlCache.entries()]) {
      if (key === dir || key.startsWith(`${dir}/`)) {
        URL.revokeObjectURL(url);
        this.urlCache.delete(key);
      }
    }
  }

  // ------------------------------------------------------- genre folders etc.

  async loadConfig(): Promise<NotesConfig> {
    try {
      const raw = await this.fs.readText(CONFIG_FILE);
      const parsed = JSON.parse(raw) as Partial<NotesConfig>;
      return {
        version: 1,
        folders: Array.isArray(parsed.folders)
          ? parsed.folders.filter((f) => f && typeof f.name === "string")
          : [],
        labels: Array.isArray(parsed.labels) ? parsed.labels.map(String) : [],
      };
    } catch {
      return { ...DEFAULT_NOTES_CONFIG, folders: [], labels: [] };
    }
  }

  async saveConfig(config: NotesConfig): Promise<void> {
    return this.writeLock(async () => {
      await this.fs.makeDir(CONFIG_DIR);
      await this.fs.writeText(CONFIG_FILE, JSON.stringify(config, null, 2));
    });
  }

  // ---------------------------------------------------------------- helpers

  private async listRootDirs(): Promise<string[]> {
    try {
      const entries = await this.fs.listDir("");
      return entries.map((e) => e.name);
    } catch {
      return [];
    }
  }

  private toDTO(
    model: {
      id: string;
      title: string;
      type: "text" | "list";
      color: string;
      pinned: boolean;
      archived: boolean;
      trashed: boolean;
      vaulted: boolean;
      folder: string | null;
      labels: string[];
      order: number | null;
      created: string;
      updated: string;
      body: string;
    },
    dir: string,
    attachments: AttachmentDTO[],
    extraMeta: Record<string, string>
  ): NoteDTO {
    return {
      id: model.id,
      dir,
      title: model.title,
      content: model.body,
      type: model.type,
      color: model.color,
      pinned: model.pinned,
      archived: model.archived,
      trashed: model.trashed,
      vaulted: model.vaulted,
      folderId: model.folder,
      folder: null,
      items: parseTaskItems(model.body),
      labels: model.labels.map((name) => ({ id: name, name })),
      attachments,
      order: model.order,
      createdAt: model.created,
      updatedAt: model.updated,
      extraMeta,
    };
  }
}

export { dirname, joinPath };
