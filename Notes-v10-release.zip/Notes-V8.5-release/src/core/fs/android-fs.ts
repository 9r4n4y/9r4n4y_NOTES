// ---------------------------------------------------------------------------
// Android adapter — talks to the native JS bridge (MainActivity.Bridge) which
// performs real java.io.File operations on phone storage after the user grants
// "All files access". All bridge calls are synchronous envelopes:
//   {"ok":true,"data":...} | {"ok":false,"error":"..."}
// Paths inside the bridge are ABSOLUTE; this adapter joins them with the
// user-selected root (persisted in localStorage).
// ---------------------------------------------------------------------------

import {
  type DirEntry,
  type FSAdapter,
  assertSafePath,
  base64ToBytes,
  bytesToBase64,
  dirname,
  splitPath,
} from "./adapter";

export interface AndroidBridge {
  hasAllFilesAccess?: () => boolean;
  requestAllFilesAccess?: () => void;
  fsInfo?: () => string;
  fsList?: (absPath: string) => string;
  fsReadText?: (absPath: string) => string;
  fsReadBase64?: (absPath: string) => string;
  fsWriteText?: (absPath: string, content: string) => string;
  fsWriteBase64?: (absPath: string, b64: string) => string;
  fsMkdir?: (absPath: string) => string;
  fsRename?: (oldAbs: string, newAbs: string) => string;
  fsDelete?: (absPath: string, recursive: boolean) => string;
  fsExists?: (absPath: string) => string;
  // existing shell bridge (kept for exports/status bar/etc.)
  saveFile?: (name: string, base64: string) => void;
  toast?: (msg: string) => void;
  vibrate?: (ms: number) => void;
  setStatusBarColors?: (hex: string, darkIcons: boolean) => void;
  setModalOpen?: (open: boolean) => void;
  closeApp?: () => void;
}

interface Envelope<T> {
  ok: boolean;
  data?: T;
  error?: string;
}

export function getBridge(): AndroidBridge | null {
  if (typeof window === "undefined") return null;
  const b = (window as unknown as { AndroidBridge?: AndroidBridge }).AndroidBridge;
  return b && typeof b.fsList === "function" ? b : null;
}

function call<T>(result: string | undefined, fallbackError: string): T {
  if (!result) throw new Error(fallbackError);
  let parsed: Envelope<T>;
  try {
    parsed = JSON.parse(result) as Envelope<T>;
  } catch {
    throw new Error(fallbackError);
  }
  if (!parsed.ok) throw new Error(parsed.error || fallbackError);
  return parsed.data as T;
}

interface FsInfo {
  storageRoot: string;
  appPrivateRoot: string;
  defaultRoot: string;
  hasAllFilesAccess: boolean;
}

export class AndroidFSAdapter implements FSAdapter {
  readonly kind = "android" as const;
  private bridge: AndroidBridge;
  private rootAbs: string | null = null;
  private info: FsInfo | null = null;

  constructor(bridge: AndroidBridge) {
    this.bridge = bridge;
    try {
      this.rootAbs = localStorage.getItem("notes-root-path");
    } catch {
      this.rootAbs = null;
    }
  }

  private fsInfo(): FsInfo {
    if (!this.info) {
      const data = call<FsInfo>(this.bridge.fsInfo?.(), "bridge unavailable");
      this.info = data;
    }
    return this.info!;
  }

  // ------------------------------------------------------------ root control

  storageRoot(): string {
    try {
      return this.fsInfo().storageRoot;
    } catch {
      return "/storage/emulated/0";
    }
  }

  /** Suggested default: <storage>/Documents/Notes (or app-private w/o permission). */
  suggestedRoot(): string {
    try {
      return this.fsInfo().defaultRoot;
    } catch {
      return "/storage/emulated/0/Documents/Notes";
    }
  }

  hasAllFilesAccess(): boolean {
    try {
      return this.bridge.hasAllFilesAccess?.() ?? false;
    } catch {
      return false;
    }
  }

  requestAllFilesAccess(): void {
    try {
      this.bridge.requestAllFilesAccess?.();
    } catch {
      /* ignore */
    }
  }

  appPrivateRoot(): string {
    try {
      return this.fsInfo().appPrivateRoot;
    } catch {
      return "";
    }
  }

  setRoot(absPath: string): void {
    this.rootAbs = absPath;
    try {
      localStorage.setItem("notes-root-path", absPath);
    } catch {
      /* ignore */
    }
  }

  getRoot(): string | null {
    return this.rootAbs;
  }

  /** Absolute listing used by the in-app folder picker dialog. */
  listAbsolute(absPath: string): Promise<DirEntry[]> {
    return Promise.resolve(call<DirEntry[]>(this.bridge.fsList?.(absPath), "Could not list folder"));
  }

  makeAbsolute(absPath: string): Promise<void> {
    return Promise.resolve(call<void>(this.bridge.fsMkdir?.(absPath), "Could not create folder"));
  }

  // ------------------------------------------------------------ FSAdapter api

  rootLabel(): string {
    return this.rootAbs ?? "";
  }

  hasRoot(): boolean {
    return !!this.rootAbs;
  }

  async needsPermission(): Promise<boolean> {
    if (!this.rootAbs) return false;
    // app-private roots work without any permission
    const priv = this.appPrivateRoot();
    if (priv && (this.rootAbs === priv || this.rootAbs.startsWith(priv + "/"))) return false;
    return !this.hasAllFilesAccess();
  }

  /**
   * The actual folder choice on Android happens through the in-app picker
   * (FolderPickerDialog → setRoot). pickRoot() falls back to the suggested
   * root so the app never gets stuck.
   */
  async pickRoot(): Promise<boolean> {
    if (this.rootAbs && (await this.exists(""))) return true;
    const suggested = this.suggestedRoot();
    try {
      await this.makeAbsolute(suggested);
      this.setRoot(suggested);
      return true;
    } catch {
      const priv = this.appPrivateRoot();
      if (priv) {
        try {
          await this.makeAbsolute(priv);
          this.setRoot(priv);
          return true;
        } catch {
          return false;
        }
      }
      return false;
    }
  }

  async restoreRoot(): Promise<boolean> {
    if (!this.rootAbs) return false;
    try {
      return await this.exists("");
    } catch {
      return false;
    }
  }

  private abs(path: string): string {
    const rel = assertSafePath(path);
    if (!this.rootAbs) throw new Error("No storage root selected");
    return rel.length === 0 ? this.rootAbs : `${this.rootAbs}/${rel}`;
  }

  async exists(path: string): Promise<boolean> {
    if (!this.rootAbs) return false;
    try {
      return call<boolean>(this.bridge.fsExists?.(this.abs(path)), "exists failed");
    } catch {
      return false;
    }
  }

  async listDir(path: string): Promise<DirEntry[]> {
    const entries = call<DirEntry[]>(this.bridge.fsList?.(this.abs(path)), "Could not read folder");
    return entries.sort((a, b) => a.name.localeCompare(b.name));
  }

  async readText(path: string): Promise<string> {
    return call<string>(this.bridge.fsReadText?.(this.abs(path)), "Could not read file");
  }

  async readBinary(path: string): Promise<Uint8Array> {
    const b64 = call<string>(this.bridge.fsReadBase64?.(this.abs(path)), "Could not read file");
    return base64ToBytes(b64);
  }

  async writeText(path: string, text: string): Promise<void> {
    call<void>(this.bridge.fsWriteText?.(this.abs(path), text), "Could not write file");
  }

  async writeBinary(path: string, data: Uint8Array): Promise<void> {
    call<void>(this.bridge.fsWriteBase64?.(this.abs(path), bytesToBase64(data)), "Could not write file");
  }

  async makeDir(path: string): Promise<void> {
    call<void>(this.bridge.fsMkdir?.(this.abs(path)), "Could not create folder");
  }

  async remove(path: string, recursive = true): Promise<void> {
    call<void>(this.bridge.fsDelete?.(this.abs(path), recursive), "Could not delete");
  }

  async rename(oldPath: string, newPath: string): Promise<void> {
    call<void>(
      this.bridge.fsRename?.(this.abs(oldPath), this.abs(newPath)),
      "Could not rename"
    );
  }

  /** Raw absolute remove used when cleaning broken roots. */
  removeAbsolute(absPath: string): Promise<void> {
    return Promise.resolve(call<void>(this.bridge.fsDelete?.(absPath, true), "Could not delete"));
  }
}

export { splitPath, dirname };
