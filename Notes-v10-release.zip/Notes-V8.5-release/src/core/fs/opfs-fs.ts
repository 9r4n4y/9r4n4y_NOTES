// ---------------------------------------------------------------------------
// OPFS adapter — fallback for browsers without the File System Access API
// (Firefox / Safari). Notes live in the browser's Origin Private File System,
// still 100% local and structured exactly like the on-disk layout. Users can
// import/export their notes from Settings → Storage.
// ---------------------------------------------------------------------------

import { HandleFSAdapter } from "./handle-fs";

export class OpfsFSAdapter extends HandleFSAdapter {
  readonly kind = "opfs" as const;

  async pickRoot(): Promise<boolean> {
    try {
      this.root = await navigator.storage.getDirectory();
      this.permissionNeeded = false;
      return true;
    } catch {
      return false;
    }
  }

  async restoreRoot(): Promise<boolean> {
    if (this.hasRoot()) return true;
    return this.pickRoot();
  }

  rootLabel(): string {
    return "In-app local storage (browser)";
  }
}

export function supportsOpfs(): boolean {
  return typeof navigator !== "undefined" && !!navigator.storage?.getDirectory;
}
