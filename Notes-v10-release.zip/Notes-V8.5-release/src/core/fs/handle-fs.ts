// ---------------------------------------------------------------------------
// Handle-based filesystem adapter (browser FileSystemDirectoryHandle).
//
// Shared implementation for:
//   - WebFSAdapter  → a real user-picked folder via showDirectoryPicker()
//   - OpfsFSAdapter → the Origin Private File System (fallback for browsers
//                     without the File System Access API)
// Both use identical handle-walking logic; only root acquisition differs.
// ---------------------------------------------------------------------------

import {
  type DirEntry,
  type FSAdapter,
  assertSafePath,
  dirname,
  splitPath,
} from "./adapter";

const ROOT_KEY = "notes-root-handle";
const HANDLE_DB = "notes-fs-db";
const HANDLE_STORE = "handles";

export class HandleFSAdapter implements FSAdapter {
  readonly kind: "web" | "opfs" = "web";
  protected root: FileSystemDirectoryHandle | null = null;
  /** When true the handle exists but the browser revoked read/write permission. */
  protected permissionNeeded = false;

  rootLabel(): string {
    return this.root?.name ?? "";
  }

  hasRoot(): boolean {
    return this.root != null && !this.permissionNeeded;
  }

  async needsPermission(): Promise<boolean> {
    return this.permissionNeeded;
  }

  async pickRoot(): Promise<boolean> {
    throw new Error("pickRoot must be implemented by subclasses");
  }

  async restoreRoot(): Promise<boolean> {
    return this.hasRoot();
  }

  // ----------------------------------------------------------------- lookup

  protected async dirHandleFor(path: string, create: boolean): Promise<FileSystemDirectoryHandle> {
    if (!this.root) throw new Error("No storage root selected");
    let dir = this.root;
    for (const segment of splitPath(assertSafePath(path))) {
      dir = await dir.getDirectoryHandle(segment, { create });
    }
    return dir;
  }

  protected async fileHandleFor(path: string, create: boolean): Promise<FileSystemFileHandle> {
    if (!this.root) throw new Error("No storage root selected");
    const parts = splitPath(assertSafePath(path));
    if (parts.length === 0) throw new Error("Empty path");
    const parent = await this.dirHandleFor(dirname(parts.join("/")), create);
    return parent.getFileHandle(parts[parts.length - 1], { create });
  }

  // -------------------------------------------------------------------- ops

  async exists(path: string): Promise<boolean> {
    if (!this.root) return false;
    try {
      const parts = splitPath(assertSafePath(path));
      if (parts.length === 0) return true;
      const parentPath = parts.slice(0, -1).join("/");
      const parent = await this.dirHandleFor(parentPath, false);
      const name = parts[parts.length - 1];
      try {
        await parent.getFileHandle(name, { create: false });
        return true;
      } catch {
        await parent.getDirectoryHandle(name, { create: false });
        return true;
      }
    } catch {
      return false;
    }
  }

  async listDir(path: string): Promise<DirEntry[]> {
    const dir = await this.dirHandleFor(path, false);
    const out: DirEntry[] = [];
    // @ts-expect-error — async iterator is standard but not in the TS lib yet
    for await (const [name, handle] of dir.entries()) {
      out.push({
        name,
        kind: handle.kind === "directory" ? "dir" : "file",
      });
    }
    out.sort((a, b) => a.name.localeCompare(b.name));
    return out;
  }

  async readText(path: string): Promise<string> {
    const file = await (await this.fileHandleFor(path, false)).getFile();
    return file.text();
  }

  async readBinary(path: string): Promise<Uint8Array> {
    const file = await (await this.fileHandleFor(path, false)).getFile();
    return new Uint8Array(await file.arrayBuffer());
  }

  async writeText(path: string, text: string): Promise<void> {
    await this.writeBinary(path, new TextEncoder().encode(text));
  }

  async writeBinary(path: string, data: Uint8Array): Promise<void> {
    const handle = await this.fileHandleFor(path, true);
    // createWritable() writes to a temp swap file and replaces the target on
    // close — an atomic-enough write for notes.
    const writable = await handle.createWritable();
    await writable.write(data as unknown as FileSystemWriteChunkType);
    await writable.close();
  }

  async makeDir(path: string): Promise<void> {
    await this.dirHandleFor(path, true);
  }

  async remove(path: string, recursive = true): Promise<void> {
    const parts = splitPath(assertSafePath(path));
    if (parts.length === 0) throw new Error("Cannot remove the root");
    const parent = await this.dirHandleFor(parts.slice(0, -1).join("/"), false);
    await parent.removeEntry(parts[parts.length - 1], { recursive });
  }

  /**
   * Rename/move a FILE via handle.move() (Chromium ≥ 111). Directory renames
   * are not supported by the API, so they are performed by the repository as
   * a recursive copy + delete using the regular operations.
   */
  async rename(oldPath: string, newPath: string): Promise<void> {
    const oldParts = splitPath(assertSafePath(oldPath));
    const newParts = splitPath(assertSafePath(newPath));
    if (oldParts.length === 0 || newParts.length === 0) throw new Error("Bad rename path");
    const oldParent = oldParts.slice(0, -1).join("/");
    const newParent = newParts.slice(0, -1).join("/");
    const oldName = oldParts[oldParts.length - 1];
    const newName = newParts[newParts.length - 1];

    const handle = await this.fileHandleFor(oldPath, false);
    const moveable = handle as FileSystemFileHandle & {
      move?: (nameOrDir: string | FileSystemDirectoryHandle) => Promise<void>;
    };
    if (typeof moveable.move !== "function") throw new Error("rename not supported");

    if (oldParent === newParent) {
      if (oldName === newName) return;
      await moveable.move(newName);
      return;
    }
    const targetDir = await this.dirHandleFor(newParent, true);
    await moveable.move(targetDir);
    if (oldName !== newName) {
      const moved = await (targetDir as FileSystemDirectoryHandle).getFileHandle(oldName, {
        create: false,
      });
      const movedMoveable = moved as FileSystemFileHandle & {
        move?: (name: string) => Promise<void>;
      };
      if (typeof movedMoveable.move === "function") await movedMoveable.move(newName);
    }
  }

  // -------------------------------------------------------- root persistence

  protected async persistHandle(handle: FileSystemDirectoryHandle): Promise<void> {
    try {
      const db = await openHandleDB();
      const tx = db.transaction(HANDLE_STORE, "readwrite");
      tx.objectStore(HANDLE_STORE).put(handle, ROOT_KEY);
    } catch {
      /* non-fatal — session-only root */
    }
  }

  protected async loadPersistedHandle(): Promise<FileSystemDirectoryHandle | null> {
    try {
      const db = await openHandleDB();
      return await new Promise((resolve, reject) => {
        const tx = db.transaction(HANDLE_STORE, "readonly");
        const req = tx.objectStore(HANDLE_STORE).get(ROOT_KEY);
        req.onsuccess = () => resolve((req.result as FileSystemDirectoryHandle) ?? null);
        req.onerror = () => reject(req.error);
      });
    } catch {
      return null;
    }
  }
}

function openHandleDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(HANDLE_DB, 1);
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains(HANDLE_STORE)) {
        req.result.createObjectStore(HANDLE_STORE);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
