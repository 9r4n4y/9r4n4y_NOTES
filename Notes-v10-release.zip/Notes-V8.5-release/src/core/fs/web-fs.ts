// ---------------------------------------------------------------------------
// Web adapter — a REAL user-chosen local folder via the File System Access API
// (Chrome / Edge / Opera). The handle is persisted in IndexedDB so the same
// folder is reattached on the next visit (permission must be re-granted with
// a user gesture after a restart — standard browser behaviour).
// ---------------------------------------------------------------------------

import { HandleFSAdapter } from "./handle-fs";

interface WindowWithFSA {
  showDirectoryPicker?: (options?: {
    mode?: "read" | "readwrite";
    id?: string;
    startIn?: string;
  }) => Promise<FileSystemDirectoryHandle>;
}

export class WebFSAdapter extends HandleFSAdapter {
  readonly kind = "web" as const;

  async pickRoot(): Promise<boolean> {
    const picker = (window as unknown as WindowWithFSA).showDirectoryPicker;
    if (!picker) return false;
    try {
      const handle = await picker({ mode: "readwrite", id: "notes-root" });
      this.root = handle;
      this.permissionNeeded = false;
      await this.persistHandle(handle);
      return true;
    } catch {
      return false; // user cancelled
    }
  }

  async restoreRoot(): Promise<boolean> {
    if (this.hasRoot()) return true;
    const handle = await this.loadPersistedHandle();
    if (!handle) return false;
    // query current permission state without prompting
    const query = (
      handle as FileSystemHandle & {
        queryPermission?: (d: { mode: "read" | "readwrite" }) => Promise<PermissionState>;
      }
    ).queryPermission;
    if (typeof query === "function") {
      const state = await query.call(handle, { mode: "readwrite" });
      if (state === "granted") {
        this.root = handle;
        this.permissionNeeded = false;
        return true;
      }
    }
    this.root = handle;
    this.permissionNeeded = true;
    return false;
  }

  /** Must be called from a user gesture; re-requests read/write permission. */
  async reauthorize(): Promise<boolean> {
    const handle = this.root ?? (await this.loadPersistedHandle());
    if (!handle) return false;
    const request = (
      handle as FileSystemHandle & {
        requestPermission?: (d: { mode: "read" | "readwrite" }) => Promise<PermissionState>;
      }
    ).requestPermission;
    if (typeof request !== "function") return false;
    try {
      const state = await request.call(handle, { mode: "readwrite" });
      if (state === "granted") {
        this.root = handle;
        this.permissionNeeded = false;
        return true;
      }
    } catch {
      /* dismissed */
    }
    return false;
  }
}

export function supportsFileSystemAccess(): boolean {
  return (
    typeof window !== "undefined" &&
    typeof (window as unknown as WindowWithFSA).showDirectoryPicker === "function"
  );
}
