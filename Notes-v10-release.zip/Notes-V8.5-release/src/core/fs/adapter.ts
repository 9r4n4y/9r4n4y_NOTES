// ---------------------------------------------------------------------------
// Platform filesystem adapter contract.
//
// Every path used by the app is ROOT-RELATIVE and POSIX-style, e.g.
//   "Shopping/node.md"
//   "Shopping/attachment/image.png"
//   ".notes/config.json"
// The adapter is responsible for resolving those against the user-chosen root
// on its platform (browser directory handle / absolute path on Android).
// ---------------------------------------------------------------------------

export interface DirEntry {
  name: string;
  kind: "file" | "dir";
  size?: number;
}

export interface FSAdapter {
  /** Which implementation is active (drives UI copy + settings display). */
  readonly kind: "web" | "opfs" | "android";
  /** Human-readable location, e.g. "…/Documents/MyNotes" or "In-app storage". */
  rootLabel(): string;
  /** True when a root is selected AND currently usable. */
  hasRoot(): boolean;
  /** True when the underlying storage needs a permission re-grant (web only). */
  needsPermission(): Promise<boolean>;

  /**
   * Ask the user to pick the root folder (native dialog on web, in-app
   * dialog backed by the bridge on Android). Resolves true when a root is
   * ready to use.
   */
  pickRoot(): Promise<boolean>;

  /** Re-attach to the previously chosen root without prompting. */
  restoreRoot(): Promise<boolean>;

  // ---- entry operations (all paths root-relative) ----
  exists(path: string): Promise<boolean>;
  listDir(path: string): Promise<DirEntry[]>;
  readText(path: string): Promise<string>;
  readBinary(path: string): Promise<Uint8Array>;
  writeText(path: string, text: string): Promise<void>;
  writeBinary(path: string, data: Uint8Array): Promise<void>;
  /** mkdir -p */
  makeDir(path: string): Promise<void>;
  remove(path: string, recursive?: boolean): Promise<void>;
  /** Rename within the same parent (dir rename may be copy+delete under the hood). */
  rename(oldPath: string, newPath: string): Promise<void>;
}

// ------------------------------------------------------------ path helpers

export function joinPath(...parts: (string | null | undefined)[]): string {
  const cleaned = parts
    .filter((p): p is string => !!p && p.length > 0)
    .map((p) => p.replace(/^\/+|\/+$/g, ""))
    .filter((p) => p.length > 0);
  return cleaned.join("/");
}

export function splitPath(path: string): string[] {
  return path
    .split("/")
    .map((p) => p.trim())
    .filter((p) => p.length > 0);
}

export function basename(path: string): string {
  const parts = splitPath(path);
  return parts[parts.length - 1] ?? "";
}

export function dirname(path: string): string {
  const parts = splitPath(path);
  parts.pop();
  return parts.join("/");
}

/** Guard every incoming path: no absolute, no traversal, no empty segments. */
export function assertSafePath(path: string): string {
  const trimmed = (path ?? "").trim().replace(/^\/+/, "");
  if (trimmed.includes("..")) throw new Error(`Unsafe path: ${path}`);
  if (/[\u0000-\u001f]/.test(trimmed)) throw new Error(`Unsafe path: ${path}`);
  return trimmed;
}

// ------------------------------------------------------------ misc helpers

export function mimeForName(name: string): string {
  const ext = name.slice(name.lastIndexOf(".") + 1).toLowerCase();
  switch (ext) {
    case "png":
      return "image/png";
    case "jpg":
    case "jpeg":
      return "image/jpeg";
    case "gif":
      return "image/gif";
    case "webp":
      return "image/webp";
    case "svg":
      return "image/svg+xml";
    case "bmp":
      return "image/bmp";
    case "avif":
      return "image/avif";
    case "pdf":
      return "application/pdf";
    case "txt":
    case "md":
      return "text/plain";
    case "json":
      return "application/json";
    case "mp4":
      return "video/mp4";
    case "webm":
      return "video/webm";
    case "mp3":
      return "audio/mpeg";
    case "wav":
      return "audio/wav";
    case "ogg":
      return "audio/ogg";
    default:
      return "application/octet-stream";
  }
}

export function bytesToBase64(bytes: Uint8Array): string {
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

export function base64ToBytes(b64: string): Uint8Array {
  const binary = atob(b64);
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
  return out;
}

/** Serialise a tiny async mutex used to prevent interleaved disk writes. */
export function createMutex() {
  let tail: Promise<unknown> = Promise.resolve();
  return function run<T>(task: () => Promise<T>): Promise<T> {
    const result = tail.then(task, task);
    tail = result.catch(() => undefined);
    return result;
  };
}
