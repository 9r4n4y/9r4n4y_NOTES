// ---------------------------------------------------------------------------
// Minimal YAML front-matter serialisation for node.md
//
// We deliberately support a tiny, well-defined subset of YAML:
//   key: "string" | true | false | number | null | ["a", "b"]
// All strings are emitted JSON-double-quoted, which is valid YAML. Unknown
// keys found while parsing are preserved verbatim and written back, so the
// app never destroys metadata it does not understand (e.g. from Obsidian).
// ---------------------------------------------------------------------------

export interface FrontMatter {
  [key: string]: string | number | boolean | null | string[];
  /** unknown keys, preserved on write-back */
}

function quote(value: string): string {
  return JSON.stringify(value);
}

/** Serialise key/value pairs to `---`-fenced YAML text (no trailing fence). */
export function serializeFrontMatter(entries: Record<string, unknown>): string {
  const lines: string[] = [];
  for (const [key, value] of Object.entries(entries)) {
    if (value === undefined) continue;
    if (value === null) lines.push(`${key}: null`);
    else if (typeof value === "string") lines.push(`${key}: ${quote(value)}`);
    else if (typeof value === "number" || typeof value === "boolean") lines.push(`${key}: ${value}`);
    else if (Array.isArray(value)) lines.push(`${key}: [${value.map(quote).join(", ")}]`);
    else lines.push(`${key}: ${quote(String(value))}`);
  }
  return lines.join("\n");
}

function parseScalar(raw: string): string | number | boolean | null | string[] {
  const value = raw.trim();
  if (value === "" || value === "null" || value === "~") return null;
  if (value === "true") return true;
  if (value === "false") return false;
  if (value.startsWith("[") && value.endsWith("]")) {
    // array of quoted strings — JSON is compatible with what we emit
    try {
      const parsed = JSON.parse(value);
      if (Array.isArray(parsed)) return parsed.map((v) => String(v));
    } catch {
      /* fall through to naive split for hand-written yaml like [a, b] */
    }
    const inner = value.slice(1, -1).trim();
    if (!inner) return [];
    return inner
      .split(",")
      .map((piece) => piece.trim())
      .filter((piece) => piece.length > 0)
      .map((piece) => {
        if (
          (piece.startsWith('"') && piece.endsWith('"')) ||
          (piece.startsWith("'") && piece.endsWith("'"))
        )
          return piece.slice(1, -1);
        return piece;
      });
  }
  if (
    (value.startsWith('"') && value.endsWith('"') && value.length >= 2) ||
    (value.startsWith("'") && value.endsWith("'") && value.length >= 2)
  ) {
    const unquoted = value.slice(1, -1);
    if (value.startsWith('"')) {
      try {
        return JSON.parse(value) as string;
      } catch {
        return unquoted;
      }
    }
    return unquoted;
  }
  // plain number?
  if (/^-?\d+(\.\d+)?$/.test(value)) {
    const num = Number(value);
    if (Number.isFinite(num)) return num;
  }
  return value;
}

export interface ParsedNoteFile {
  meta: Record<string, string | number | boolean | null | string[]>;
  /** raw unknown-key lines preserved for write-back */
  extra: Record<string, string>;
  body: string;
  hadFrontMatter: boolean;
}

/**
 * Parse `---\n…\n---\n<body>`. Tolerates CRLF, BOM and missing front-matter.
 * When the fence is broken (no closing `---`) the whole file is treated as
 * the body so user content is never lost.
 */
export function parseNoteFile(text: string): ParsedNoteFile {
  const clean = text.replace(/^\uFEFF/, "").replace(/\r\n/g, "\n");
  if (!clean.startsWith("---")) {
    return { meta: {}, extra: {}, body: clean, hadFrontMatter: false };
  }
  const lines = clean.split("\n");
  if (lines[0].trim() !== "---") {
    return { meta: {}, extra: {}, body: clean, hadFrontMatter: false };
  }
  let closeIndex = -1;
  for (let i = 1; i < lines.length; i++) {
    const t = lines[i].trim();
    if (t === "---" || t === "...") {
      closeIndex = i;
      break;
    }
  }
  if (closeIndex === -1) {
    // broken fence — treat entire content as body
    return { meta: {}, extra: {}, body: clean, hadFrontMatter: false };
  }
  const meta: ParsedNoteFile["meta"] = {};
  const extra: Record<string, string> = {};
  for (let i = 1; i < closeIndex; i++) {
    const line = lines[i];
    if (!line.trim() || line.trim().startsWith("#")) continue;
    const idx = line.indexOf(":");
    if (idx <= 0) continue;
    const key = line.slice(0, idx).trim();
    const raw = line.slice(idx + 1);
    const parsed = parseScalar(raw);
    meta[key] = parsed;
    // remember raw form of keys we do not model so we can preserve them
    if (!(key in KNOWN_KEYS)) extra[key] = raw.trim();
  }
  const body = lines.slice(closeIndex + 1).join("\n");
  return { meta, extra, body, hadFrontMatter: true };
}

export const KNOWN_KEYS = new Set([
  "id",
  "title",
  "type",
  "color",
  "pinned",
  "archived",
  "trashed",
  "vaulted",
  "folder",
  "labels",
  "order",
  "created",
  "updated",
]);

function str(meta: Record<string, unknown>, key: string, fallback = ""): string {
  const v = meta[key];
  if (typeof v === "string" && v.length > 0) return v;
  if (typeof v === "number") return String(v);
  return fallback;
}

function bool(meta: Record<string, unknown>, key: string): boolean {
  return meta[key] === true || meta[key] === "true";
}

/** Typed accessor helpers over a parsed front-matter map. */
export const fm = {
  str,
  bool,
  num(meta: Record<string, unknown>, key: string): number | null {
    const v = meta[key];
    if (typeof v === "number" && Number.isFinite(v)) return v;
    if (typeof v === "string" && v.trim() !== "" && Number.isFinite(Number(v))) return Number(v);
    return null;
  },
  strArray(meta: Record<string, unknown>, key: string): string[] {
    const v = meta[key];
    if (Array.isArray(v)) return v.map((x) => String(x)).filter((x) => x.length > 0);
    if (typeof v === "string" && v.trim() !== "") {
      const parsed = parseScalar(v);
      if (Array.isArray(parsed)) return parsed;
    }
    return [];
  },
};
