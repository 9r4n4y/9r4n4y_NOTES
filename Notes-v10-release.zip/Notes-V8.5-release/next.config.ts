import type { NextConfig } from "next";

// STATIC_EXPORT=true  → fully client-side static build (used for the Android APK).
// The API routes are removed from that build and replaced by a local IndexedDB
// backend (src/components/keep/local-api-install.ts).
const isStatic = process.env.STATIC_EXPORT === "true";

const nextConfig: NextConfig = {
  ...(isStatic
    ? {
        output: "export" as const,
        images: { unoptimized: true },
        distDir: ".next-static",
      }
    : {
        output: "standalone" as const,
      }),
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
};

export default nextConfig;
