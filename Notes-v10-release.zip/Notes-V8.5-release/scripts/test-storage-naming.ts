/**
 * V8 unit test: local storage folder naming + rename integrity.
 * Run: bun /home/z/my-project/notes-v8/scripts/test-storage-naming.ts
 *
 * Uses an in-memory FSAdapter implementation to verify:
 *  - normal note            → "Title"
 *  - note + folder          → "Folder_Title"
 *  - note + label           → "Label_Title"
 *  - archived note          → "Archive_Title"
 *  - archived+folder+label  → "Archive_Folder_Label_Title"
 *  - multiple labels        → "Archive_F_L1_L2_Title"
 *  - metadata changes rename the folder without data loss
 *  - attachments survive renames
 *  - collisions are deduped (" (2)")
 *  - unsafe characters are sanitised
 */
import { NoteRepository, storageDirBase, type ScanResult } from "../src/core/repo";
import { type DirEntry, type FSAdapter, joinPath } from "../src/core/fs/adapter";

class MemFS implements FSAdapter {
  readonly kind = "web" as const;
  files = new Map<string, string>(); // text files
  bins = new Map<string, Uint8Array>();
  dirs = new Set<string>();

  rootLabel() { return "mem"; }
  hasRoot() { return true; }
  async needsPermission() { return false; }
  async pickRoot() { return true; }
  async restoreRoot() { return true; }

  async exists(path: string) {
    return this.files.has(path) || this.bins.has(path) || this.dirs.has(path);
  }
  async listDir(path: string): Promise<DirEntry[]> {
    const prefix = path === "" ? "" : path + "/";
    const names = new Set<string>();
    for (const key of [...this.files.keys(), ...this.bins.keys(), ...this.dirs.keys()]) {
      if (!key.startsWith(prefix)) continue;
      const rest = key.slice(prefix.length);
      if (!rest) continue;
      const seg = rest.split("/")[0];
      const full = prefix + seg;
      const isDir = this.dirs.has(full) || rest.includes("/");
      names.add(isDir ? `d:${seg}` : `f:${seg}`);
    }
    return [...names].map((n) => {
      const [kind, ...rest] = n.split(":");
      const name = rest.join(":");
      return { name, kind: kind === "d" ? ("dir" as const) : ("file" as const), size: 1 };
    });
  }
  async readText(path: string) {
    const v = this.files.get(path);
    if (v === undefined) throw new Error("not found " + path);
    return v;
  }
  async readBinary(path: string) {
    const v = this.bins.get(path);
    if (v !== undefined) return v;
    const text = this.files.get(path);
    if (text !== undefined) return new TextEncoder().encode(text);
    throw new Error("not found " + path);
  }
  async writeText(path: string, text: string) {
    this.files.set(path, text);
    const dir = path.split("/").slice(0, -1).join("/");
    if (dir) this.dirs.add(dir);
  }
  async writeBinary(path: string, data: Uint8Array) {
    this.bins.set(path, data);
    const dir = path.split("/").slice(0, -1).join("/");
    if (dir) this.dirs.add(dir);
  }
  async makeDir(path: string) {
    this.dirs.add(path);
  }
  async remove(path: string, recursive = true) {
    const prefix = path + "/";
    for (const key of [...this.files.keys()]) if (key.startsWith(prefix) || key === path) this.files.delete(key);
    for (const key of [...this.bins.keys()]) if (key.startsWith(prefix) || key === path) this.bins.delete(key);
    for (const key of [...this.dirs]) if (key.startsWith(prefix) || key === path) this.dirs.delete(key);
  }
  async rename(oldPath: string, newPath: string) {
    if (!this.files.has(joinPath(oldPath, "node.md")) && !this.dirs.has(oldPath)) {
      // match real FS: source must exist
      if (![...this.files.keys(), ...this.bins.keys(), ...this.dirs].some((k) => k.startsWith(oldPath + "/"))) {
        throw new Error("source missing: " + oldPath);
      }
    }
    const prefix = oldPath + "/";
    for (const key of [...this.files.keys()]) {
      if (key.startsWith(prefix)) { this.files.set(newPath + key.slice(oldPath.length), this.files.get(key)!); this.files.delete(key); }
    }
    for (const key of [...this.bins.keys()]) {
      if (key.startsWith(prefix)) { this.bins.set(newPath + key.slice(oldPath.length), this.bins.get(key)!); this.bins.delete(key); }
    }
    for (const key of [...this.dirs]) {
      if (key.startsWith(prefix)) { this.dirs.add(newPath + key.slice(oldPath.length)); this.dirs.delete(key); }
      else if (key === oldPath) { this.dirs.add(newPath); this.dirs.delete(key); }
    }
  }
}

let failures = 0;
function check(name: string, actual: unknown, expected: unknown) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (!ok) {
    failures++;
    console.log(`FAIL ${name}\n  expected: ${JSON.stringify(expected)}\n  actual:   ${JSON.stringify(actual)}`);
  } else {
    console.log(`ok   ${name} → ${JSON.stringify(actual)}`);
  }
}

// ---- pure naming derivation ----
check("plain title", storageDirBase({ title: "Shopping List" }), "Shopping List");
check("folder only", storageDirBase({ title: "Todo", folderId: "Work" }), "Work_Todo");
check("label only", storageDirBase({ title: "Todo", labels: ["urgent"] }), "urgent_Todo");
check("archived only", storageDirBase({ title: "Todo", archived: true }), "Archive_Todo");
check("archived+folder", storageDirBase({ title: "Todo", archived: true, folderId: "Work" }), "Archive_Work_Todo");
check("folder+label", storageDirBase({ title: "Todo", folderId: "Work", labels: ["urgent"] }), "Work_urgent_Todo");
check(
  "full combo",
  storageDirBase({ title: "Todo", archived: true, folderId: "Work", labels: ["urgent", "q4"] }),
  "Archive_Work_urgent_q4_Todo"
);
check(
  "unsafe chars sanitised",
  storageDirBase({ title: "a/b:c*d", folderId: "My/Dir" }),
  "My／Dir_a／b：c＊d"
);
check("empty title", storageDirBase({ title: "" }), "Untitled");
check("collision differs by reserved self", "Archive_Work_Todo (2)", "Archive_Work_Todo (2)");

// ---- repository behaviour ----
async function repoTests() {
  const fs = new MemFS();
  const repo = new NoteRepository(fs);

  // 1. create a normal note
  const n1 = await repo.createNote({ title: "Plan", content: "hello world" });
  check("create normal → dir", n1.dir, "Plan");

  // 2. move into a folder + add a label → dir updates on save
  n1.folderId = "Work";
  n1.labels = [{ id: "urgent", name: "urgent" }];
  const dir2 = await repo.saveNote(n1);
  check("folder+label rename on save", dir2, "Work_urgent_Plan");
  check("frontmatter title intact", (await fs.readText("Work_urgent_Plan/node.md")).includes('title: "Plan"'), true);

  // 3. archive → prefix
  n1.archived = true;
  const dir3 = await repo.saveNote(n1);
  check("archive prefix rename", dir3, "Archive_Work_urgent_Plan");

  // 4. attachment survives the rename chain
  await repo.addAttachment(n1, new Blob([new Uint8Array([1, 2, 3])], { type: "image/png" }), "photo.png");
  const attsBefore = await repo.listAttachments(dir3);
  check("attachment written", attsBefore.length, 1);
  const bytes = await fs.readBinary("Archive_Work_urgent_Plan/attachment/photo.png");
  check("attachment bytes intact", [...bytes], [1, 2, 3]);

  // 5. rename title → folder renames, attachment follows
  n1.title = "Master Plan";
  const dir4 = await repo.saveNote(n1);
  check("title rename", dir4, "Archive_Work_urgent_Master Plan");
  const attsAfter = await repo.listAttachments(dir4);
  check("attachment follows rename", attsAfter.map((a) => a.name), ["photo.png"]);
  check("old dir gone", await fs.exists("Archive_Work_urgent_Plan"), false);

  // 6. collision: second note with same metadata → " (2)"
  const n2 = await repo.createNote({ title: "Master Plan", folderId: "Work", labels: ["urgent"], archived: true });
  check("collision deduped", n2.dir, "Archive_Work_urgent_Master Plan (2)");

  // 7. remove label → prefix drops
  n1.labels = [];
  const dir5 = await repo.saveNote(n1);
  check("label removed from name", dir5, "Archive_Work_Master Plan");

  // 8. unarchive + remove folder → plain title
  n1.archived = false;
  n1.folderId = null;
  const dir6 = await repo.saveNote(n1);
  check("back to plain name", dir6, "Master Plan");

  // 9. scan finds everything (no data loss)
  const scan: ScanResult = await repo.scan();
  check("scan count", scan.notes.length, 2);
  check("scan has no skipped", scan.skippedDirs, []);
  const scanned = scan.notes.find((n) => n.id === n1.id);
  check("scan title intact", scanned?.title, "Master Plan");
  check("scan attachments intact", scanned?.attachments.map((a) => a.name), ["photo.png"]);

  // 10. legacy note with plain dir: still loads; renames only on save
  fs.files.set("Old Note/node.md", `---\nid: "legacy-1"\ntitle: "Old Note"\n---\n\nbody\n`);
  const scan2 = await repo.scan();
  const legacy = scan2.notes.find((n) => n.title === "Old Note");
  check("legacy note scanned with plain dir", legacy?.dir, "Old Note");
  if (legacy) {
    legacy.folderId = "Personal";
    const newDir = await repo.saveNote(legacy);
    check("legacy migrates on save", newDir, "Personal_Old Note");
    check("legacy content intact", (await fs.readText("Personal_Old Note/node.md")).includes("body"), true);
  }

  // 11. duplicate note keeps metadata naming
  const copy = await repo.duplicateNote({ ...n1, dir: dir6 });
  check("duplicate naming", copy.dir, "Master Plan (2)");
}

await repoTests();

if (failures > 0) {
  console.log(`\n${failures} FAILURES`);
  process.exit(1);
}
console.log("\nALL STORAGE NAMING TESTS PASSED");
