#!/bin/bash
# Downloads and sets up the minimal Android build toolchain (no Gradle):
# build-tools 35.0.0 (aapt2, d8, zipalign, apksigner) + platform android-34.
set -euo pipefail

SDK=/home/z/my-project/android-sdk
mkdir -p "$SDK"

echo "[1/4] Downloading command-line tools..."
cd "$SDK"
if [ ! -f cmdline-tools.zip ]; then
  curl -sS -o cmdline-tools.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
fi
echo "[2/4] Unpacking..."
rm -rf cmdline-tools
unzip -q cmdline-tools.zip -d cmdline-tools
mv -f cmdline-tools/cmdline-tools cmdline-tools/latest 2>/dev/null || true

echo "[3/4] Accepting licenses + installing build-tools;35.0.0 platforms;android-34..."
yes | cmdline-tools/latest/bin/sdkmanager --sdk_root="$SDK" --licenses > /dev/null 2>&1 || true
yes | cmdline-tools/latest/bin/sdkmanager --sdk_root="$SDK" "build-tools;35.0.0" "platforms;android-34" > /dev/null

echo "[4/4] Verifying..."
ls "$SDK/build-tools/35.0.0/" | head -8
ls "$SDK/platforms/android-34/android.jar"
echo "SDK SETUP COMPLETE"
