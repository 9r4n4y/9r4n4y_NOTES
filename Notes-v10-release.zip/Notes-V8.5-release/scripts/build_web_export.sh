#!/bin/bash
# Builds the static web export of the unified source and copies it into
# android/assets/ so build_apk.sh can package it into the APK.
#
# Usage:  STATIC_EXPORT=true bun run export:web   (or)  bash scripts/build_web_export.sh
set -euo pipefail

HERE="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$HERE/.next-static"
ASSETS="$HERE/android/assets"

cd "$HERE"

# 1. install dependencies if needed
if [ ! -d node_modules ]; then
  echo "[1/4] Installing dependencies..."
  if command -v bun >/dev/null 2>&1; then bun install; else npm install; fi
fi

# 2. static export (client-only app — no API routes exist anymore)
echo "[2/4] Building static export..."
STATIC_EXPORT=true npx next build

# 3. copy into android assets
echo "[3/4] Copying export into android/assets..."
rm -rf "$ASSETS"
mkdir -p "$ASSETS"
cp -r "$OUT"/. "$ASSETS/"
find "$ASSETS" -name "*.map" -delete 2>/dev/null || true

echo "[4/4] Done. Web export also available at $OUT"
