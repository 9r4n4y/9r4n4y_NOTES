# Build Guide

## Prerequisites

| Tool | Used for | Install |
|---|---|---|
| Node.js 20+ **or** Bun | web build | bun.sh / nodejs.org |
| JDK 21 (`javac`, `jar`, `keytool`) | APK compile | Temurin 21 — or set `JAVA_HOME` to any JDK 21 |
| Android build-tools 35.0.0 + platform android-34 | APK packaging | `bash scripts/setup-sdk.sh` (≈ 600 MB, one time) |

`setup-sdk.sh` downloads the Android command-line tools into
`./android-sdk/` and installs `build-tools;35.0.0` + `platforms;android-34`
via `sdkmanager` (licenses accepted automatically). No Gradle, no Android
Studio needed.

## 1. Web application

```bash
bun install                     # once
STATIC_EXPORT=true npx next build
```

The ready-to-host static site lands in `.next-static/`. Serve it with any
static file server (or `bun run dev` for development on port 3000).

## 2. Android APK

```bash
bash scripts/build_web_export.sh   # builds the export AND copies it into android/assets/
bash scripts/build_apk.sh          # aapt2 → javac → d8 → zipalign → apksigner
```

Result: `out/Notes.apk` (signed with `keystore/notes.keystore`,
alias `notes`, store password `notesapp123` — replace for production).

Environment overrides:

```bash
ANDROID_SDK=/path/to/sdk JAVA_HOME=/path/to/jdk bash scripts/build_apk.sh
```

## 3. Version bump

Edit `scripts/build_apk.sh` (`--version-code` / `--version-name`), then rebuild.

## Pipeline notes (learned the hard way)

- build-tools **35.0.0** — 34.0.0's `d8` NPEs on JDK-21 class files.
- No lambdas in the shell code: `javac -source 8 -target 8` + anonymous
  classes only (`android.jar` is a compile stub without
  `LambdaMetafactory`); inner classes therefore cannot declare `static`
  methods.
- `zipalign` runs **before** `apksigner` (sign-then-align breaks v2 signatures).
- `.map` files are stripped from the APK assets to keep it lean.
