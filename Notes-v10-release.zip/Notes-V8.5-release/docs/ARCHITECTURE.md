# Architecture — One Codebase, Two Platforms

## 1. The unified source

There is exactly **one application source tree** (`src/`). It compiles to a
100 % client-side static bundle (`next build` with `output: "export"`). The
same bundle is:

- deployed as the **web application** (any static host, or `bun run dev`), and
- embedded into the **Android APK** (`android/assets/`), served by the native
  shell over a private origin (`https://appassets.androidplatform.net`).

There are no server routes, no Prisma/SQLite, and no IndexedDB note storage.
Nothing but the platform filesystem adapters differ between platforms.

## 2. Layered design

```
┌──────────────────────────────────────────────────────────────┐
│ UI (src/components/keep/**)                                  │
│ Keep-style views, cards, editor, dialogs, settings           │
├──────────────────────────────────────────────────────────────┤
│ State (src/components/keep/store.ts)                         │
│ Zustand store: optimistic updates, debounced autosave,       │
│ draft-note materialisation, vault, search, views             │
├──────────────────────────────────────────────────────────────┤
│ Core (src/core/**) — platform-agnostic                       │
│ NoteRepository  → all note/folder/attachment operations      │
│ markdown.ts     → note ↔ node.md, task lists, safe names     │
│ frontmatter.ts  → YAML metadata round-trip                   │
├──────────────────────────────────────────────────────────────┤
│ Platform adapters (src/core/fs/**)                           │
│ FSAdapter ← WebFSAdapter (File System Access API)            │
│           ← OpfsFSAdapter (Origin Private File System)       │
│           ← AndroidFSAdapter (native JS bridge → java.io)    │
├──────────────────────────────────────────────────────────────┤
│ Platform                                                     │
│ Browser            │  Android WebView shell (MainActivity)   │
└──────────────────────────────────────────────────────────────┘
```

Every adapter implements the same contract (`FSAdapter`):

```ts
pickRoot() / restoreRoot()          // user-selected root folder
exists / listDir / readText / readBinary
writeText / writeBinary / makeDir / remove / rename
```

All app paths are **root-relative POSIX paths** (`"Shopping List/node.md"`),
so the core never knows which platform it runs on.

### Web (`web-fs.ts`)
- Root chosen via `showDirectoryPicker({ mode: "readwrite" })`.
- The directory handle is persisted in IndexedDB; on the next visit the app
  asks the browser to re-grant permission (browser policy) through the
  "Grant access" screen.

### Web fallback (`opfs-fs.ts`)
- Browsers without the File System Access API use the Origin Private File
  System with the exact same folder layout. Import/export (ZIP) provides
  portability.

### Android (`android-fs.ts` + `MainActivity.java`)
- The shell exposes a synchronous JS bridge (`window.AndroidBridge`) with
  envelope-returning methods: `fsInfo, fsList, fsReadText, fsReadBase64,
  fsWriteText, fsWriteBase64, fsMkdir, fsRename, fsDelete, fsExists`.
- Writes are atomic (temp file + rename). Deletes are recursive.
- Permissions: `MANAGE_EXTERNAL_STORAGE` (All files access) on Android 11+,
  legacy `WRITE_EXTERNAL_STORAGE` below that, plus
  `android:requestLegacyExternalStorage` for ≤ Android 10.
- The root folder is picked with the **in-app FolderPickerDialog**, which
  browses the real filesystem through the bridge (same UX as the browser
  picker). The chosen absolute path persists in `localStorage`.

## 3. Data flow (autosave)

1. User types → TipTap serialises to Markdown (`tiptap-markdown`).
2. Store applies the change optimistically and debounces 600 ms.
3. `NoteRepository.saveNote()` regenerates `node.md`
   (front-matter + body) and writes it atomically.
4. Title changes trigger a **folder rename** (native rename on Android,
   copy+delete on browsers that cannot rename directories).
5. Flush points: editor close, tab hidden, `beforeunload`, Android
   `onDestroy` (`window.__flushLocalData`).

New notes are **drafts in memory** and materialise to disk on the first
real content — an abandoned empty note never pollutes the filesystem.

## 4. Attachments

- Stored under `<note>/attachment/` (created on demand).
- Markdown references are relative and percent-encoded:
  `![alt](attachment/photo%20copy.png)`.
- The editor swaps object-URLs in for display and swaps back to paths when
  serialising — the file on disk never contains a `blob:` URL.
- Deleting an attachment removes the file; deleting a note removes the whole
  folder.

## 5. What is intentionally NOT stored in JSON/DB

Note content, title, colour, pin/archive/trash/vault state, folder assignment,
labels, order, timestamps — all live inside `node.md`. The only JSON file is
`.notes/config.json`, which holds **app-level metadata that cannot live in a
single note**: genre-folder emoji/tints and the list of label names.

## 6. V8 additions

### Metadata storage names

Note folders embed their metadata (see README). The derivation lives in
`src/core/repo.ts` (`storageDirBase`):

```
[Archive_]FolderName(_LabelName…)_NoteTitle
```

`saveNote()` recomputes the name on every persist and renames the folder
(native rename on Android, copy+delete on the web) when it changed — so the
name always reflects archive/folder/label/title state. The title inside
`node.md` is never modified. Notes created before V8 keep their plain folder
name until their next save.

### Unified BACK handling (`src/lib/back-nav.ts`)

A LIFO stack of UI layers (lightbox, image editor, note editor, dialogs,
mobile drawer) over a bottom "main view history" handler:

- **Android** — `MainActivity.onBackPressed()` evaluates
  `window.__handleAndroidBack()`; when the web layer consumes the press the
  top layer closes. Only an unconsumed press reaches `moveTaskToBack`.
- **Web** — every layer pushes a guarded history entry on open; the browser
  back button closes the top layer; closing a layer through its own UI
  consumes its entry. With no layers open, browser back behaves as before.

### Theme + system bars (`src/lib/android-theme.ts`)

Inside the shell, the `prefers-color-scheme` media query is backed by the
native ui mode (`AndroidBridge.isSystemDark()`, live updates via
`window.__systemThemeChanged` pushed from `onConfigurationChanged`).
next-themes keeps its normal code path. `SystemBarsSync` mirrors the resolved
theme into the Android status/navigation bars (`setSystemBars`) and the
WebView background; `values-night` styles give the shell a correct dark
cold-start appearance.
