# Notes — Unified Local-First Markdown Notes App (Version 8)

A Google Keep–style notepad with a **full Markdown editor**, storing every note
as **plain files on your own device** — no server, no database, no cloud.

One codebase compiles into both the **web application** and the **Android APK**.

---

## Highlights

- **Markdown editor (TipTap)** — titles + rich writing area with formatting
  controls for **bold, italic, underline, strikethrough, inline code, headings
  (H1–H4), bullet/numbered lists, checklists, quotes, code blocks, links,
  images, dividers**, plus undo/redo and clear-formatting. Formatting toggles
  work the way you expect: turn one on and everything you type carries it;
  turn it off and you're back to normal text.
- **Your files, your disk** — each note is a real folder on the filesystem:

  ```
  Selected Root Folder/
  ├── Archive_Work_important_Shopping List/   ← metadata storage name
  │   ├── node.md          ← YAML front-matter + Markdown body (source of truth)
  │   └── attachment/      ← only created when attachments exist
  │       ├── image.png
  │       └── animation.gif
  ├── Notes/               ← plain title when no metadata applies
  │   └── node.md
  └── .notes/
      └── config.json      ← genre-folder emoji/tints + label names (app metadata only)
  ```

- **Local-only architecture** — there is no server, no Prisma/SQLite, no
  IndexedDB note store, no JSON note backups. `node.md` is the single source
  of truth; close the app, copy the folder to another device, open it in
  Obsidian — everything survives.
- **Everything else you loved from V5** — Keep's 11 colours, pin, archive,
  trash / restore / delete-forever / empty trash, duplicate, drag-to-reorder,
  genre folders with emoji + tint, labels, search across everything, grid/list
  layouts, image editor (crop / draw / text / undo), lightbox, GIF support,
  export to ZIP, light/dark/system themes, wallpaper personalisation, the
  hidden **Vault** (`open_vault` / `close_vault`), and more.

## What's new in Version 8

- **Bug fixes** — the Markdown link input is now a real always-on-top dialog
  (tap-safe, keyboard-safe); batch image uploads go to the attachments area
  only (no phantom duplicate inside the note body); Android system BACK
  navigates through the app (editor → list, dialogs, views) before ever
  exiting; Dark/Light/System themes correctly drive the Android status and
  navigation bars (including live system-theme changes); the editor's
  jump-to-top/bottom buttons now work reliably with the keyboard open or
  closed.
- **Metadata storage names** — every note folder on disk now embeds its own
  metadata, so the filesystem itself describes the note:

  ```
  Archive_FolderName_LabelName_NoteTitle/
  ├── node.md                 ← the note title inside stays exactly as typed
  └── attachment/
  ```

  The name updates automatically when you archive/unarchive, move notes
  between folders, add/remove labels or rename a note. Attachments travel
  with the folder; notes created before V8 migrate on their next save.
- **Custom folder emoji** — folders are no longer limited to the preset icon
  list: tap the pencil tile and type or paste ANY emoji (including complex
  sequences). Presets, colour tints, rename and persistence all still work.

---

## Platforms & storage

| Platform | Where notes live | Root selection |
|---|---|---|
| **Android APK** | Real phone storage via `java.io.File` (All-files-access) | In-app folder picker over the whole filesystem, or the app-private fallback |
| **Chrome / Edge** | A real folder you pick (File System Access API) | Native `showDirectoryPicker` dialog |
| **Firefox / Safari** | In-app private storage (OPFS) with the identical on-disk layout | One click; import/export via Settings |

The web app and the Android app are the **same code, same UI, same behaviour** —
only the filesystem adapter underneath differs.

## Android filesystem permissions

On first launch the app explains why it needs storage access and requests
**All files access** (Android 11+: `MANAGE_EXTERNAL_STORAGE`; Android ≤10:
classic read/write storage permissions with legacy storage enabled). You then
choose the exact folder the app manages. Without the permission the app still
works inside its own private storage (`Android/data/com.notes.app/files/Notes`),
and Settings → Storage lets you change location at any time.

## Quick start (web)

```bash
bun install          # or npm install
bun run dev          # http://localhost:3000
```

First run: choose a folder (Chrome/Edge) or in-app storage. Then create notes.

## Building

| Artifact | Command | Output |
|---|---|---|
| Web (static site) | `STATIC_EXPORT=true npx next build` | `.next-static/` |
| Android APK | `bash scripts/setup-sdk.sh` once, then `bash scripts/build_apk.sh` | `out/Notes.apk` |

Check `docs/BUILD.md` for the complete toolchain guide and `docs/ARCHITECTURE.md`
for how the unified codebase + platform adapters work.

## Project layout

```
├── src/
│   ├── app/                  # Next.js shell (single page)
│   ├── core/                 # platform-agnostic core (shared by web + APK)
│   │   ├── types.ts          #   note / folder / label / attachment models
│   │   ├── frontmatter.ts    #   YAML front-matter for node.md
│   │   ├── markdown.ts       #   note↔markdown, task lists, safe file names
│   │   ├── fs/               #   FSAdapter + web / opfs / android adapters
│   │   └── repo.ts           #   NoteRepository (all disk operations)
│   ├── components/keep/      # UI (Keep-style) + TipTap markdown editor
│   └── lib/                  # design constants, vault, save-blob helpers
├── android/                  # WebView shell: manifest, res, MainActivity (JS bridge)
├── scripts/                  # build_apk.sh, build_web_export.sh, setup-sdk.sh
└── keystore/                 # signing keystore for the APK
```

## The note file format

```markdown
---
id: "9f1c6f2e-…"          # stable identity (survives renames)
title: "Shopping List"
type: "text"              # "text" | "list" (list = checklist presentation)
color: "blue"
pinned: false
archived: false
trashed: false
vaulted: false
folder: "Work"            # genre-folder name or null
labels: ["important"]
order: null               # manual drag position
created: "2026-09-17T06:28:57.761Z"
updated: "2026-09-17T06:30:29.884Z"
---

bold text *italic* normal

# Heading

- [ ] buy milk
- [x] buy eggs

![photo](attachment/photo.png)
```

Checklists are plain Markdown task lists. Attachment links are relative
(`attachment/…`, percent-encoded when needed), so the folder is portable to
any Markdown editor.

## Edge cases handled

- duplicate note titles → folders deduped as `"Title (2)"`, `"Title (3)"`…
- filesystem-invalid characters → replaced with full-width look-alikes
- very long titles → truncated (folder ≤ 80 chars)
- missing `node.md` → folder skipped (never crashes, never deleted)
- moved/renamed folders externally → re-created identity from front-matter on
  rescan (Settings → Storage → Rescan)
- copied note folders → fresh note IDs assigned on next scan
- failed writes → debounced queue + flush on app hide/close
