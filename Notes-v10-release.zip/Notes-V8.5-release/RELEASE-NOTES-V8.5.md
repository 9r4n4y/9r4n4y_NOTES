# Notes App — Version 8.5 Release Notes

**Version 8.5 (versionCode 9)** — builds on Version 8 with two fixes: a
structural fix for the batch-upload image duplication, and a complete rebuild
of search highlighting & navigation.

---

## Fixed in 8.5

### 1. Batch image upload — images can NEVER auto-enter the note body (regression of V8 bug #2)

Users reported that when batch-uploading 3, 4 or 2 images, the **last image
still ended up inside the note body**. Root cause: V8 kept an "insert" pick
mode that could be triggered by the editor toolbar's Insert-image button AND
by the image **paste** handler. Pasting an image used to *discard* the pasted
file, open the file picker instead, and — if the picker was cancelled (no
`change` event fires on cancel) — leave the pick-mode poisoned to "insert".
The next batch upload then auto-inserted images into the note body. On
Android, WebViews can additionally re-deliver the last file of a batch as a
second `change` event.

V8.5 makes auto-insertion **structurally impossible**:

- The "insert" pick-mode and its `pickModeRef` flag are removed entirely.
  Every upload path — footer media picker, editor toolbar "Add image",
  composer "note with image" shortcut, and image paste — stores images into
  the **attachments area only**.
- The paste handler no longer discards pasted images or opens the file
  picker: pasted images are now stored as attachments (with a toast).
- A **dedupe guard** was added to attachment storage: the same image
  (name + size) can never be stored twice in one note, neutralising the
  Android WebView double-`change` delivery that duplicated the last file.
- An image is placed into the note body only by the explicit per-thumbnail
  **"Insert into note"** button (one deliberate action per image).

Verified: batches of 1/2/3/5 images via every path → 0 images in the body,
correct attachment counts, duplicate re-uploads blocked, close/reopen
persistence intact.

### 2. Search highlighting + Up/Down navigation (every search surface)

The in-note search bar previously only **counted** matches in the markdown
source (e.g. 102, 96, 3) — the Up/Down buttons changed the number but always
scrolled to the *first* match, and nothing was visually highlighted.

V8.5 rebuilds find-in-note on top of a TipTap/ProseMirror **decoration
extension** (`search-highlight.ts`):

- **Every occurrence of the searched word is highlighted** in the rendered
  note (amber `search-hit` marks; view-only decorations — they never reach
  the saved markdown).
- The **active match gets a strong highlight with an outline** and the view
  **scrolls directly to it** (positioned at ⅓ of the *visual* viewport, so
  the Android keyboard never covers the match).
- **Up/Down buttons and Enter / Shift+Enter** now move the active highlight
  match-by-match with wrap-around; the counter (e.g. `3/102`) always shows
  the index of the highlighted match — the counter *is* the navigation.
- The match count is computed from the **rendered document**, so the counter
  always matches what is highlighted.
- Typing a new query jumps to the first match; closing the search (✕ or
  Escape) or switching notes clears all highlights.
- **Notes-list search now highlights too**: every occurrence of the query in
  card titles, text previews and checklist items is wrapped in the same
  highlight style (`search-chip`), consistent with the in-note search.

---

## Carried over from Version 8

- Link dialog rebuilt as a portalled Radix Popover (never overlapped/hidden).
- Batch uploads stay in the attachments area (see #1 for the V8.5 hardening).
- Android system BACK: closes overlays → note editor → navigates the app's
  view history; only exits when nothing is left. Browser Back on Web is
  preserved.
- Theme + Android system bars: Light/Dark/System all keep the status bar and
  navigation bar in sync (incl. `values-night` cold-start theme and runtime
  system-theme change events).
- Scroll Up/Down jump buttons: visibility no longer depends on the keyboard
  state (scroll listener + ResizeObserver + settle re-checks).
- Local storage naming: `Archive_Folder_Labels_Title` folder names with live
  renames, collision-safe duplicates, and legacy migration.
- Custom folder emoji: any emoji via keyboard input, validated with
  `Intl.Segmenter`, live preview, persisted, editable.

---

## Build

- Web: `STATIC_EXPORT=true npx next build` → `.next-static/`
- APK: `bash scripts/build_web_export.sh && ANDROID_SDK=<sdk> bash scripts/build_apk.sh`
  (needs build-tools 35.0.0, platform android-34, JDK 21; version pinned in
  `scripts/build_apk.sh`: versionCode 9, versionName 8.5)
- The ZIP contains the exact source that produced the shipped APK
  (`release/Notes-V8.5.apk` inside the ZIP).
