package com.notes.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Notes — self-contained WebView shell (local-first filesystem edition).
 *
 * Serves the static Notes app from assets over a private https origin
 * (appassets.androidplatform.net) so localStorage / IndexedDB / WebCrypto all
 * behave like a real website. The JS bridge exposes REAL local-filesystem
 * operations (java.io.File) used by the app after the user grants
 * "All files access": list/read/write/mkdir/rename/delete — so notes live as
 * <Root>/<Note Title>/node.md + attachment/ on phone storage, fully under the
 * user's control. Also provides native file saving, back-button coordination
 * and status-bar theming.
 */
public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String ORIGIN = "https://" + HOST;
    private static final int FILE_CHOOSER_REQUEST = 1001;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private volatile boolean overlayOpen = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setLoadsImagesAutomatically(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        CookieManager.getInstance().setAcceptCookie(true);

        webView.setBackgroundColor(isSystemDark() ? Color.parseColor("#111113") : Color.parseColor("#F1F3F4"));

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return Assets.serve(MainActivity.this, request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if (HOST.equals(url.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, url));
                } catch (Exception ignored) { }
                return true;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    webView.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            webView.loadUrl(ORIGIN + "/index.html");
                        }
                    }, 400);
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                return true; // swallow console noise
            }
        });

        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");
        setContentView(webView);
        webView.loadUrl(ORIGIN + "/index.html");
    }

    // ------------------------------------------------------------ file chooser

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback != null) {
                Uri[] results = null;
                if (resultCode == RESULT_OK && data != null) {
                    if (data.getClipData() != null) {
                        int n = data.getClipData().getItemCount();
                        results = new Uri[n];
                        for (int i = 0; i < n; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                    } else if (data.getData() != null) {
                        results = new Uri[]{data.getData()};
                    }
                }
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    // ------------------------------------------------------------ back button

    /**
     * V8 (bug #3): the UI layer stack lives in JS (src/lib/back-nav.ts).
     * BACK first offers the press to the web app — it closes the top-most
     * surface (lightbox → image editor → note editor → dialogs → main-view
     * history). Only when nothing consumes the press does the shell do the
     * app-home action, so real navigation always wins over exiting.
     */
    @Override
    public void onBackPressed() {
        webView.evaluateJavascript(
            "window.__handleAndroidBack ? String(window.__handleAndroidBack()) : 'false'",
            new ValueCallback<String>() {
                @Override
                public void onReceiveValue(String value) {
                    if (value == null || !value.contains("true")) {
                        moveTaskToBack(true); // app-like home behaviour, state stays warm
                    }
                }
            });
    }

    // ------------------------------------------------------------ lifecycle

    @Override
    protected void onResume() {
        super.onResume();
        // returning from the All-files-access settings page → re-check
        webView.evaluateJavascript(
            "window.__appPermissionsReturned && window.__appPermissionsReturned();", null);
    }

    /**
     * V8 (bug #4): the system theme can change while the app is running.
     * uiMode is declared in android:configChanges, so we get this callback
     * instead of a recreation — push the new value into the web app.
     */
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        final boolean dark = isSystemDark();
        webView.evaluateJavascript(
            "window.__systemThemeChanged && window.__systemThemeChanged(" + dark + ");", null);
    }

    private boolean isSystemDark() {
        int mask = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return mask == Configuration.UI_MODE_NIGHT_YES;
    }

    @Override
    protected void onDestroy() {
        try {
            webView.evaluateJavascript("window.__flushLocalData && window.__flushLocalData();", null);
        } catch (Exception ignored) { }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    // ------------------------------------------------------------ asset server

    /** Minimal asset server: https://appassets.androidplatform.net/** → assets/** */
    public static class Assets {

        static WebResourceResponse serve(Context ctx, Uri url) {
            if (url == null || !HOST.equals(url.getHost())) return null; // let WebView handle it
            String path = url.getPath();
            if (path == null) return notFound();
            if (path.equals("/") || path.isEmpty()) path = "/index.html";
            if (path.contains("..")) return notFound();
            String rel = path.startsWith("/") ? path.substring(1) : path;
            if (rel.isEmpty()) rel = "index.html";
            try {
                InputStream in = ctx.getAssets().open(rel);
                return new WebResourceResponse(mimeFor(rel), null, in);
            } catch (IOException e) {
                return notFound();
            }
        }

        static String mimeFor(String file) {
            String lower = file.toLowerCase();
            if (lower.endsWith(".js") || lower.endsWith(".mjs")) return "text/javascript";
            if (lower.endsWith(".css")) return "text/css";
            if (lower.endsWith(".html")) return "text/html";
            if (lower.endsWith(".json") || lower.endsWith(".webmanifest")) return "application/json";
            if (lower.endsWith(".svg")) return "image/svg+xml";
            if (lower.endsWith(".png")) return "image/png";
            if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
            if (lower.endsWith(".gif")) return "image/gif";
            if (lower.endsWith(".webp")) return "image/webp";
            if (lower.endsWith(".ico")) return "image/x-icon";
            if (lower.endsWith(".woff2")) return "font/woff2";
            if (lower.endsWith(".woff")) return "font/woff";
            if (lower.endsWith(".ttf")) return "font/ttf";
            if (lower.endsWith(".otf")) return "font/otf";
            if (lower.endsWith(".txt") || lower.endsWith(".map")) return "text/plain";
            String ext = MimeTypeMapWrapper.getExtension(file);
            if (ext != null) {
                String m = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
                if (m != null) return m;
            }
            return "application/octet-stream";
        }

        static WebResourceResponse notFound() {
            try {
                return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", null,
                        new ByteArrayInputStream(new byte[0]));
            } catch (Throwable t) {
                return null;
            }
        }
    }

    /** Indirection to keep the import list tidy. */
    static class MimeTypeMapWrapper {
        static String getExtension(String file) {
            int dot = file.lastIndexOf('.');
            return dot < 0 ? null : file.substring(dot + 1);
        }
    }

    // ------------------------------------------------------------ JS bridge

    public class Bridge {

        /** JS reports dialog/menu open-state so BACK closes it first. */
        @JavascriptInterface
        public void setModalOpen(boolean open) {
            overlayOpen = open;
        }

        @JavascriptInterface
        public boolean hasAllFilesAccess() {
            if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
            if (Build.VERSION.SDK_INT >= 29) return true; // scoped storage covers our writes
            return checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE")
                    == PackageManager.PERMISSION_GRANTED;
        }

        @JavascriptInterface
        public void requestAllFilesAccess() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (Build.VERSION.SDK_INT >= 30) {
                            Intent i = new Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                    Uri.parse("package:" + getPackageName()));
                            startActivity(i);
                        } else {
                            requestPermissions(new String[]{
                                    "android.permission.WRITE_EXTERNAL_STORAGE",
                                    "android.permission.READ_EXTERNAL_STORAGE"}, 2002);
                        }
                    } catch (Exception e) {
                        try {
                            startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                        } catch (Exception ignored) { }
                    }
                }
            });
        }

        // ------------------------------------------------ filesystem bridge
        // All operations return {"ok":true,"data":...} or {"ok":false,"error":"..."}
        // and use ABSOLUTE paths. They run on a WebView background thread.

        private String err(String message) {
            try {
                JSONObject o = new JSONObject();
                o.put("ok", false);
                o.put("error", message);
                return o.toString();
            } catch (Exception e) {
                return "{\"ok\":false,\"error\":\"error\"}";
            }
        }

        @JavascriptInterface
        public String fsInfo() {
            try {
                JSONObject o = new JSONObject();
                File storage = Environment.getExternalStorageDirectory();
                String storageRoot = storage != null ? storage.getAbsolutePath() : "/storage/emulated/0";
                o.put("ok", true);
                JSONObject data = new JSONObject();
                data.put("storageRoot", storageRoot);
                File priv = getExternalFilesDir(null);
                data.put("appPrivateRoot", priv != null ? new File(priv, "Notes").getAbsolutePath() : "");
                data.put("defaultRoot", storageRoot + "/Documents/Notes");
                data.put("hasAllFilesAccess", hasAllFilesAccess());
                o.put("data", data);
                return o.toString();
            } catch (Exception e) {
                return err(e.getMessage());
            }
        }

        @JavascriptInterface
        public String fsList(String absPath) {
            try {
                File dir = new File(safe(absPath));
                File[] children = dir.listFiles();
                JSONArray arr = new JSONArray();
                if (children != null) {
                    for (File c : children) {
                        JSONObject e = new JSONObject();
                        e.put("name", c.getName());
                        e.put("kind", c.isDirectory() ? "dir" : "file");
                        e.put("size", c.length());
                        arr.put(e);
                    }
                }
                JSONObject o = new JSONObject();
                o.put("ok", true);
                o.put("data", arr);
                return o.toString();
            } catch (Exception e) {
                return err(e.getMessage());
            }
        }

        @JavascriptInterface
        public String fsReadText(String absPath) {
            try {
                String text = readAll(new File(safe(absPath)));
                JSONObject o = new JSONObject();
                o.put("ok", true);
                o.put("data", text == null ? "" : text);
                return o.toString();
            } catch (Exception e) {
                return err(e.getMessage());
            }
        }

        @JavascriptInterface
        public String fsReadBase64(String absPath) {
            try {
                byte[] bytes = readAllBytes(new File(safe(absPath)));
                JSONObject o = new JSONObject();
                o.put("ok", true);
                o.put("data", Base64.encodeToString(bytes, Base64.NO_WRAP));
                return o.toString();
            } catch (Exception e) {
                return err(e.getMessage());
            }
        }

        @JavascriptInterface
        public String fsWriteText(String absPath, String content) {
            try {
                writeAtomic(new File(safe(absPath)), content.getBytes(StandardCharsets.UTF_8));
                JSONObject o = new JSONObject();
                o.put("ok", true);
                o.put("data", true);
                return o.toString();
            } catch (Exception e) {
                return err(e.getMessage());
            }
        }

        @JavascriptInterface
        public String fsWriteBase64(String absPath, String b64) {
            try {
                byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                writeAtomic(new File(safe(absPath)), bytes);
                JSONObject o = new JSONObject();
                o.put("ok", true);
                o.put("data", true);
                return o.toString();
            } catch (Exception e) {
                return err(e.getMessage());
            }
        }

        @JavascriptInterface
        public String fsMkdir(String absPath) {
            try {
                File dir = new File(safe(absPath));
                if (!dir.isDirectory() && !dir.mkdirs() && !dir.isDirectory()) {
                    throw new IOException("could not create " + absPath);
                }
                JSONObject o = new JSONObject();
                o.put("ok", true);
                o.put("data", true);
                return o.toString();
            } catch (Exception e) {
                return err(e.getMessage());
            }
        }

        @JavascriptInterface
        public String fsRename(String oldAbs, String newAbs) {
            try {
                File from = new File(safe(oldAbs));
                File to = new File(safe(newAbs));
                if (to.exists()) throw new IOException("target already exists");
                if (!from.renameTo(to)) throw new IOException("rename failed");
                JSONObject o = new JSONObject();
                o.put("ok", true);
                o.put("data", true);
                return o.toString();
            } catch (Exception e) {
                return err(e.getMessage());
            }
        }

        @JavascriptInterface
        public String fsDelete(String absPath, boolean recursive) {
            try {
                File target = new File(safe(absPath));
                if (target.isDirectory() && !recursive) {
                    throw new IOException("folder delete requires recursive");
                }
                if (target.exists() && !deleteRecursively(target)) {
                    throw new IOException("delete failed");
                }
                JSONObject o = new JSONObject();
                o.put("ok", true);
                o.put("data", true);
                return o.toString();
            } catch (Exception e) {
                return err(e.getMessage());
            }
        }

        @JavascriptInterface
        public String fsExists(String absPath) {
            try {
                JSONObject o = new JSONObject();
                o.put("ok", true);
                o.put("data", new File(safe(absPath)).exists());
                return o.toString();
            } catch (Exception e) {
                return err(e.getMessage());
            }
        }

        // ------------------------------------------------ other helpers

        /** Saves bytes into Downloads/Notes/<name> (visible to all file managers). */
        @JavascriptInterface
        public void saveFile(final String name, final String base64) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                final String where = writeToDownloads(safeName(name), bytes);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, "Saved to " + where, Toast.LENGTH_LONG).show();
                    }
                });
            } catch (final Exception e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, "Save failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            }
        }

        @JavascriptInterface
        public void toast(final String msg) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void vibrate(int ms) {
            try {
                android.os.Vibrator v = (android.os.Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null) v.vibrate(ms);
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public void setStatusBarColors(String hex, final boolean darkIcons) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Window w = getWindow();
                        w.setStatusBarColor(Color.parseColor(hex));
                        View d = w.getDecorView();
                        int flags = d.getSystemUiVisibility();
                        if (darkIcons) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                        else flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                        d.setSystemUiVisibility(flags);
                    } catch (Exception ignored) { }
                }
            });
        }

        /** Authoritative system dark-mode probe (V8 bug #4). */
        @JavascriptInterface
        public boolean isSystemDark() {
            return MainActivity.this.isSystemDark();
        }

        /**
         * V8 (bug #4): sync BOTH system bars + icon contrast with the app's
         * resolved theme (called from the web layer on theme changes).
         */
        @JavascriptInterface
        public void setSystemBars(final String statusHex, final String navHex,
                                  final boolean darkStatusIcons, final boolean darkNavIcons) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Window w = getWindow();
                        w.setStatusBarColor(Color.parseColor(statusHex));
                        w.setNavigationBarColor(Color.parseColor(navHex));
                        View d = w.getDecorView();
                        int flags = d.getSystemUiVisibility();
                        if (darkStatusIcons) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                        else flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                        if (Build.VERSION.SDK_INT >= 26) {
                            if (darkNavIcons) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                            else flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                        }
                        d.setSystemUiVisibility(flags);
                    } catch (Exception ignored) { }
                }
            });
        }

        /** Keep the WebView's own background in theme (overscroll areas). */
        @JavascriptInterface
        public void setWebViewBackground(final String hex) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        webView.setBackgroundColor(Color.parseColor(hex));
                    } catch (Exception ignored) { }
                }
            });
        }

        @JavascriptInterface
        public void closeApp() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    finishAndRemoveTask();
                }
            });
        }

        // ------------------------------------------------ fs io helpers

        private String safe(String path) throws IOException {
            if (path == null || path.trim().isEmpty()) throw new IOException("empty path");
            String p = path.trim();
            if (p.contains("..")) throw new IOException("unsafe path");
            return p;
        }

        private boolean deleteRecursively(File f) {
            File[] children = f.isDirectory() ? f.listFiles() : null;
            if (children != null) {
                for (File c : children) {
                    if (!deleteRecursively(c)) return false;
                }
            }
            return f.delete();
        }

        private byte[] readAllBytes(File f) throws IOException {
            try (InputStream in = new FileInputStream(f)) {
                java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                return out.toByteArray();
            }
        }

        private String readAll(File f) throws IOException {
            if (!f.exists()) return null;
            return new String(readAllBytes(f), StandardCharsets.UTF_8);
        }

        private void writeAtomic(File target, byte[] bytes) throws IOException {
            File tmp = new File(target.getParentFile(), target.getName() + ".tmp");
            try (FileOutputStream fos = new FileOutputStream(tmp)) {
                fos.write(bytes);
            }
            if (!tmp.renameTo(target)) {
                try (FileOutputStream fos = new FileOutputStream(target)) {
                    fos.write(bytes);
                }
                //noinspection ResultOfMethodCallIgnored
                tmp.delete();
            }
        }

        private String safeName(String name) {
            String clean = (name == null ? "" : name).replaceAll("[\\\\/:*?\"<>|\\n\\r]+", "_").trim();
            if (clean.isEmpty()) clean = "export";
            return clean.length() > 120 ? clean.substring(0, 120) : clean;
        }

        private String uniqueName(File dir, String name) {
            File f = new File(dir, name);
            if (!f.exists()) return name;
            int dot = name.lastIndexOf('.');
            String base = dot < 0 ? name : name.substring(0, dot);
            String ext = dot < 0 ? "" : name.substring(dot);
            for (int i = 1; i < 999; i++) {
                File c = new File(dir, base + " (" + i + ")" + ext);
                if (!c.exists()) return c.getName();
            }
            return "file-" + System.currentTimeMillis() + ext;
        }

        private String writeToDownloads(String name, byte[] bytes) throws IOException {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name);
                cv.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, Assets.mimeFor(name));
                cv.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH,
                        Environment.DIRECTORY_DOWNLOADS + "/Notes");
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) throw new IOException("could not create file");
                try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                    if (os == null) throw new IOException("stream unavailable");
                    os.write(bytes);
                }
                return "Downloads/Notes/" + name;
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS), "Notes");
                if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("could not create folder");
                File target = new File(dir, uniqueName(dir, name));
                try (FileOutputStream fos = new FileOutputStream(target)) {
                    fos.write(bytes);
                }
                return "Downloads/Notes/" + target.getName();
            }
        }
    }
}
