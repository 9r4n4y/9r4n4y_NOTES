"use client";

import * as React from "react";
import ReactMarkdown, { defaultUrlTransform } from "react-markdown";
import remarkGfm from "remark-gfm";
import remarkMath from "remark-math";
import rehypeRaw from "rehype-raw";
import rehypeKatex from "rehype-katex";
import {
  Bold,
  Braces,
  Code,
  Eye,
  Heading1,
  Heading2,
  Heading3,
  ImagePlus,
  Images,
  Italic,
  Link2,
  Link2Off,
  ListPlus,
  List,
  ListChecks,
  ListOrdered,
  Minus,
  PenLine,
  Quote,
  Redo2,
  RemoveFormatting,
  Strikethrough,
  Table2,
  Underline as UnderlineIcon,
  Undo2,
  Maximize2,
} from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { decodeAttachmentPath, encodeAttachmentPath, stripMarkdownFormat, toggleTaskLine } from "@/core/markdown";
import { preprocessMathMarkdown } from "@/lib/math-pre";
import { useSettings } from "../settings-store";

/** Result payload of the in-note find bar (count + active match). */
export interface SearchResults {
  /** total matches in the note (0 when the query is empty) */
  count: number;
  /** currently active match index (0-based) */
  active: number;
}

/**
 * Notenoid Markdown editor surface.
 *
 * The persisted document remains plain Markdown. Edit mode is intentionally a
 * transparent textarea so existing files, folders, labels, task lists and
 * front-matter stay untouched. Preview mode uses GitHub-Flavored Markdown,
 * including tables, task lists and strikethrough. Attachments continue to be
 * owned by NoteEditorView and are only inserted when the user explicitly asks.
 *
 * V5: edit ↔ preview toggles restore the viewport by TEXT ANCHOR (the block /
 * line that sits at the same relative viewport position before the toggle is
 * re-pinned to the same position after the swap) instead of a raw scrollTop —
 * the two modes have completely different heights, so a raw pixel offset used
 * to land in an entirely different place.
 */

export interface MarkdownEditorHandle {
  focus: () => void;
  insertImage: (url: string, alt?: string) => void;
  /** V5: insert one image, or several arranged in a responsive grid, at the caret. */
  insertImages: (items: { url: string; alt?: string }[]) => void;
  /** V5: remove every markdown reference to a display URL (image + empty grid wrapper). */
  removeImageReference: (url: string) => void;
  /** V5: push a pending throttled store update right now (app hide / close). */
  flushPendingPush: () => void;
  getMarkdown: () => string;
  getScrollElement: () => HTMLElement | null;
  registerUrl: (url: string, file: string) => void;
  setSearchQuery: (query: string) => void;
  goToMatch: (index: number) => void;
}

interface ToolbarProps {
  editor: HTMLTextAreaElement | null;
  preview: boolean;
  onTogglePreview: () => void;
  onPickImages: () => void;
  onInsertAtCursor: () => void;
  onAction: (action: string, value?: string, label?: string) => void;
}

function ToolButton({
  onClick,
  active,
  disabled,
  label,
  children,
}: {
  onClick?: () => void;
  active?: boolean;
  disabled?: boolean;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      disabled={disabled}
      onMouseDown={(e) => e.preventDefault()}
      onClick={onClick}
      className={cn(
        "inline-flex h-8 min-w-8 shrink-0 items-center justify-center rounded-md px-1.5 text-foreground/75 transition-colors duration-150 hover:bg-black/10 hover:text-foreground disabled:opacity-30 dark:hover:bg-white/10",
        active && "bg-foreground/10 text-foreground dark:bg-white/15"
      )}
    >
      {children}
    </button>
  );
}

function Toolbar({ editor, preview, onTogglePreview, onPickImages, onInsertAtCursor, onAction }: ToolbarProps) {
  const [linkOpen, setLinkOpen] = React.useState(false);
  const [linkUrl, setLinkUrl] = React.useState("");
  const [linkLabel, setLinkLabel] = React.useState("");
  const [multiOpen, setMultiOpen] = React.useState(false);
  const [multiSelection, setMultiSelection] = React.useState<string[]>([]);
  const linkInputRef = React.useRef<HTMLInputElement | null>(null);

  const applyLink = () => {
    const url = linkUrl.trim();
    if (!url) return;
    onAction("link", url, linkLabel.trim());
    setLinkOpen(false);
  };

  const multiOptions = [
    ["bold", "Bold"], ["italic", "Italic"], ["underline", "Underline"],
    ["strike", "Strikethrough"], ["code", "Inline code"],
    ["h1", "Heading 1"], ["h2", "Heading 2"], ["h3", "Heading 3"],
  ] as const;
  const applyMulti = () => {
    onAction("multi", multiSelection.join(","));
    setMultiOpen(false);
    setMultiSelection([]);
  };

  return (
    <div className="relative border-b border-black/5 bg-background/60 backdrop-blur dark:border-white/10">
      <div className="flex items-center gap-0.5 overflow-x-auto px-2 py-1.5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        <ToolButton label={preview ? "Edit Markdown" : "Preview rendered note"} active={preview} onClick={onTogglePreview}>
          {preview ? <PenLine className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
        </ToolButton>
        <ToolButton label="Bold" onClick={() => onAction("bold")}><Bold className="h-4 w-4" /></ToolButton>
        <ToolButton label="Italic" onClick={() => onAction("italic")}><Italic className="h-4 w-4" /></ToolButton>
        <ToolButton label="Underline" onClick={() => onAction("underline")}><UnderlineIcon className="h-4 w-4" /></ToolButton>
        <ToolButton label="Strikethrough" onClick={() => onAction("strike")}><Strikethrough className="h-4 w-4" /></ToolButton>
        <ToolButton label="Inline code" onClick={() => onAction("code")}><Code className="h-4 w-4" /></ToolButton>
        <span className="mx-1 h-5 w-px shrink-0 bg-black/10 dark:bg-white/15" />
        <ToolButton label="Heading 1" onClick={() => onAction("h1")}><Heading1 className="h-4 w-4" /></ToolButton>
        <ToolButton label="Heading 2" onClick={() => onAction("h2")}><Heading2 className="h-4 w-4" /></ToolButton>
        <ToolButton label="Heading 3" onClick={() => onAction("h3")}><Heading3 className="h-4 w-4" /></ToolButton>
        <ToolButton label="Body text" onClick={() => onAction("paragraph")}><Braces className="h-4 w-4 rotate-90" /></ToolButton>
        <span className="mx-1 h-5 w-px shrink-0 bg-black/10 dark:bg-white/15" />
        <ToolButton label="Bullet list" onClick={() => onAction("ul")}><List className="h-4 w-4" /></ToolButton>
        <ToolButton label="Numbered list" onClick={() => onAction("ol")}><ListOrdered className="h-4 w-4" /></ToolButton>
        <ToolButton label="Checklist" onClick={() => onAction("todo")}><ListChecks className="h-4 w-4" /></ToolButton>
        <ToolButton label="Quote" onClick={() => onAction("quote")}><Quote className="h-4 w-4" /></ToolButton>
        <ToolButton label="Code block" onClick={() => onAction("codeblock")}><Braces className="h-4 w-4" /></ToolButton>
        <span className="mx-1 h-5 w-px shrink-0 bg-black/10 dark:bg-white/15" />
        <Popover modal open={linkOpen} onOpenChange={(open) => {
          if (open) setLinkUrl("");
          setLinkOpen(open);
        }}>
          <PopoverTrigger asChild>
            <span className="inline-flex shrink-0"><ToolButton label="Add link"><Link2 className="h-4 w-4" /></ToolButton></span>
          </PopoverTrigger>
          <PopoverContent align="start" side="bottom" sideOffset={6} collisionPadding={8} className="z-[70] w-[min(92vw,26rem)] rounded-xl p-2 shadow-xl" onOpenAutoFocus={(e) => {
            e.preventDefault();
            requestAnimationFrame(() => { linkInputRef.current?.focus(); linkInputRef.current?.select(); });
          }}>
            <div className="space-y-2">
              <input ref={linkInputRef} value={linkLabel} onChange={(e) => setLinkLabel(e.target.value)} placeholder="Link text (optional)" aria-label="Link text" className="w-full rounded-md bg-transparent px-2 py-1.5 text-sm outline-none ring-1 ring-black/10 focus:ring-foreground/30 dark:ring-white/15" />
              <div className="flex items-center gap-2">
                <input value={linkUrl} onChange={(e) => setLinkUrl(e.target.value)} onKeyDown={(e) => {
                  if (e.key === "Enter") { e.preventDefault(); applyLink(); }
                  if (e.key === "Escape") setLinkOpen(false);
                }} inputMode="url" placeholder="https://…" aria-label="Link URL" className="min-w-0 flex-1 rounded-md bg-transparent px-2 py-1.5 text-sm outline-none ring-1 ring-black/10 focus:ring-foreground/30 dark:ring-white/15" />
                <button type="button" onClick={applyLink} className="shrink-0 rounded-md bg-foreground px-3 py-1.5 text-sm font-medium text-background">Apply</button>
                <button type="button" onClick={() => setLinkOpen(false)} className="shrink-0 rounded-md px-2 py-1.5 text-sm text-muted-foreground">Cancel</button>
              </div>
            </div>
          </PopoverContent>
        </Popover>
        <ToolButton label="Remove link" onClick={() => onAction("remove-link")}><Link2Off className="h-4 w-4" /></ToolButton>
        <ToolButton label="Add image (saved to attachments)" onClick={onPickImages}><ImagePlus className="h-4 w-4" /></ToolButton>
        <ToolButton label="Insert image at cursor — several become a tidy grid" onClick={onInsertAtCursor}><Images className="h-4 w-4" /></ToolButton>
        <ToolButton label="Divider" onClick={() => onAction("hr")}><Minus className="h-4 w-4" /></ToolButton>
        <ToolButton label="Insert table" onClick={() => onAction("table")}><Table2 className="h-4 w-4" /></ToolButton>
        <ToolButton label="Clear formatting" onClick={() => onAction("clear")}><RemoveFormatting className="h-4 w-4" /></ToolButton>
        <Popover modal open={multiOpen} onOpenChange={setMultiOpen}>
          <PopoverTrigger asChild>
            <span className="inline-flex shrink-0"><ToolButton label="Choose multiple formats"><ListPlus className="h-4 w-4" /></ToolButton></span>
          </PopoverTrigger>
          <PopoverContent align="end" side="bottom" sideOffset={6} collisionPadding={8} className="z-[70] w-56 rounded-xl p-3 shadow-xl">
            <p className="mb-2 text-sm font-medium">Apply multiple formats</p>
            <div className="grid grid-cols-2 gap-1.5">
              {multiOptions.map(([value, label]) => <label key={value} className="flex items-center gap-2 rounded-md px-1.5 py-1 text-xs hover:bg-accent"><input type="checkbox" checked={multiSelection.includes(value)} onChange={(e) => setMultiSelection((current) => e.target.checked ? [...current, value] : current.filter((item) => item !== value))} />{label}</label>)}
            </div>
            <button type="button" disabled={multiSelection.length === 0} onClick={applyMulti} className="mt-3 w-full rounded-md bg-foreground px-3 py-1.5 text-sm font-medium text-background disabled:opacity-40">Done</button>
          </PopoverContent>
        </Popover>
        <span className="mx-1 h-5 w-px shrink-0 bg-black/10 dark:bg-white/15" />
        <ToolButton label="Undo" onClick={() => onAction("undo")}><Undo2 className="h-4 w-4" /></ToolButton>
        <ToolButton label="Redo" onClick={() => onAction("redo")}><Redo2 className="h-4 w-4" /></ToolButton>
        <span className="flex-1" />
      </div>
    </div>
  );
}

export interface MarkdownEditorProps {
  value: string;
  onChange: (markdown: string) => void;
  fileToUrl: (file: string) => string;
  urlToFile: Map<string, string>;
  onRequestInsertImages: () => void;
  /** V5: open the "insert image at cursor" picker (grid for multiples). */
  onRequestInsertAtCursor?: () => void;
  onPasteImages?: (files: File[]) => void;
  onSearchResults?: (results: SearchResults) => void;
  handleRef?: React.RefObject<MarkdownEditorHandle | null>;
  beforeContent?: React.ReactNode;
  placeholder?: string;
  autoFocus?: boolean;
  initialPreview?: boolean;
  /** Identity of the open note — keeps scroll position across remounts. */
  stateKey?: string;
  /** Tap on an inline preview image (lightbox with edit + download). */
  onOpenImage?: (url: string, alt: string) => void;
}

/* --------------------------------------------------------------- V4 fixes
 * The editor used to be remounted (React key change) the moment a brand-new
 * note materializes on disk (store switches editorNoteId from __draft__ to
 * the real id). That remount reset the local preview state — typing the first
 * word "auto-switched" edit ↔ preview. These module-level holders survive
 * remounts so mode + scroll are NEVER changed by anything but the user.
 */
let lastPreviewState: boolean | null = null;
const scrollMemory = new Map<string, number>();
let lastEditorScrollTop = 0;
let lastEditorStateKey: string | null = null;

/* ------------------------------------------------------------------ V6
 * Anchor-based scroll sync between edit and preview — EXACT edition.
 *
 * The rendered preview carries data-src-line attributes (the markdown source
 * line each block starts at, provided by react-markdown's hast positions).
 * That gives a lossless two-way mapping between textarea lines and preview
 * blocks:
 *
 *   edit → preview: visible textarea line at the probe (35% viewport) →
 *                   last block whose data-src-line ≤ line+1 → pin it
 *   preview → edit: block at the probe → its data-src-line → scroll the
 *                   textarea so that exact line sits at the probe
 *
 * No text heuristics, no proportional guesses — switching modes lands the
 * viewport on the very same content, every time, on every platform.
 */
interface ModeAnchor {
  from: "edit" | "preview";
  /** viewport probe as a fraction of the scroll container height */
  ratio: number;
  /** 0-based markdown line index at the probe */
  lineIndex: number;
  /** 1-based source line of the preview block at the probe (preview→edit) */
  blockSrcLine: number;
  /** Exact vertical offset inside that block at the viewport probe. */
  blockOffset?: number;
}
let lastModeAnchor: ModeAnchor | null = null;

const PROBE_RATIO = 0.35;

/** Safe URL transform for the preview: keep local attachment/blob/data-image
 * URLs that react-markdown's default sanitizer would strip (they made every
 * inline image render as an "unavailable" chip). Everything else still goes
 * through the stock sanitizer so javascript:/vbscript: links stay blocked. */
function previewUrlTransform(url: string): string {
  if (!url) return url;
  if (/^(blob:|data:image\/|attachment\/)/i.test(url)) return url;
  if (/^\/?[\w.@%-]+(\/[\w.@%-]*)*$/.test(url) && !url.includes(":")) return url; // relative paths
  return defaultUrlTransform(url);
}

const EMPTY_TASK_LIST_HTML = '<ul data-type="taskList"><li data-type="taskItem" data-checked="false"><p></p></li></ul>';

/* ------------------------------------------------------------------ V6
 * Source-line plumbing for the preview: react-markdown gives every node its
 * markdown position; we surface it as data-src-line on block elements so the
 * scroll anchor system can map textarea lines ↔ preview blocks exactly.
 */
interface PositionalNode {
  position?: { start?: { line?: number } };
}

function srcLineAttr(node?: PositionalNode): { "data-src-line"?: number } {
  const line = node?.position?.start?.line;
  return line ? { "data-src-line": line } : {};
}

function lineBlock(tag: string) {
  // react-markdown hands each component its own ExtraProps shape; we only
  // need `node` (position) and forward everything else to the DOM element.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return function LineBlock(props: any) {
    const { node, children, ...rest } = props;
    return React.createElement(tag, { ...rest, ...srcLineAttr(node) }, children);
  };
}

/* ------------------------------------------------------------------ V6
 * Display-math upgrade: remark-math only marks FENCED $$ blocks (own lines)
 * as display math; the common single-line form `$$…$$` stays inline. Every
 * mainstream renderer (Obsidian, GitHub, Pandoc) shows single-line $$ as a
 * display block, so we upgrade math-inline whose raw source starts with `$$`
 * before KaTeX sees it. Runs BEFORE rehype-raw (positions intact).
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function rehypeUpgradeDisplayMath(): any {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const walk = (node: any, src: string) => {
    if (!node) return;
    if (node.type === "element") {
      const cls = node.properties?.className;
      if (Array.isArray(cls) && cls.includes("math-inline") && node.position?.start?.offset != null) {
        if (src.slice(node.position.start.offset).startsWith("$$")) {
          node.properties.className = cls
            .filter((c: string) => c !== "math-inline")
            .concat("math-display");
        }
      }
      for (const child of node.children ?? []) walk(child, src);
    } else if (node.type === "root") {
      for (const child of node.children ?? []) walk(child, src);
    }
  };
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return (tree: any, file: { value?: string }) => {
    walk(tree, String(file.value ?? ""));
  };
}

export const MarkdownEditor = React.memo(function MarkdownEditor({
  value,
  onChange,
  fileToUrl,
  urlToFile,
  onRequestInsertImages,
  onRequestInsertAtCursor,
  onPasteImages,
  onSearchResults,
  handleRef,
  beforeContent,
  placeholder,
  autoFocus,
  initialPreview = true,
  stateKey,
  onOpenImage,
}: MarkdownEditorProps) {
  const scrollRef = React.useRef<HTMLDivElement | null>(null);
  const textareaRef = React.useRef<HTMLTextAreaElement | null>(null);
  const previewRef = React.useRef<HTMLDivElement | null>(null);
  const urlToFileRef = React.useRef(urlToFile);
  const searchQueryRef = React.useRef("");
  const [preview, setPreviewState] = React.useState(() => lastPreviewState ?? initialPreview);
  const [draft, setDraft] = React.useState(value === EMPTY_TASK_LIST_HTML ? "- [ ] " : value);
  const [searchQuery, setSearchQuery] = React.useState("");
  const [searchIndex, setSearchIndex] = React.useState(0);
  const [copiedCode, setCopiedCode] = React.useState<string | null>(null);
  const appSettings = useSettings();
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const katexPlugins: any[] = appSettings.mathEnabled
    ? [[rehypeKatex, { throwOnError: false, strict: false, errorColor: "#ef4444" }]]
    : [];
  const pendingAnchorRef = React.useRef<ModeAnchor | null>(null);
  const pinRafRef = React.useRef(0);
  const stopPinRef = React.useRef<() => void>(() => {});
  /** The position the ACTIVE settle-pin is holding (null when idle). Captures
   * read this instead of the transient DOM scroll — textarea/preview heights
   * settle over a few frames, and a capture during that window must see the
   * INTENDED position, not the clamped-to-0 intermediate one. */
  const pinTargetRef = React.useRef<number | null>(null);

  /* --- V5 (paste/typing perf): throttle store propagation ---------------
   * Every keystroke used to flow straight into the zustand store, which
   * re-rendered the whole app behind the editor — freezing on large pastes.
   * The textarea now updates instantly (local draft) while store pushes are
   * throttled (leading + trailing 140ms). Programmatic edits push
   * immediately. The value-sync effect below ignores its own echoes. */
  const lastPushedRef = React.useRef<string | null>(null);
  const draftRef = React.useRef(draft);
  draftRef.current = draft;
  const pushTimerRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const pushThrottleRef = React.useRef(0);
  const pushNow = React.useCallback((text: string) => {
    lastPushedRef.current = text;
    pushThrottleRef.current = Date.now();
    onChange(text);
  }, [onChange]);
  const pushThrottled = React.useCallback((text: string) => {
    lastPushedRef.current = text;
    const now = Date.now();
    const since = now - pushThrottleRef.current;
    if (since >= 140) {
      pushThrottleRef.current = now;
      onChange(text);
      return;
    }
    if (pushTimerRef.current) return;
    pushTimerRef.current = setTimeout(() => {
      pushTimerRef.current = null;
      pushThrottleRef.current = Date.now();
      lastPushedRef.current = draftRef.current;
      onChange(draftRef.current);
    }, 140 - since);
  }, [onChange]);
  const flushPendingPush = React.useCallback(() => {
    if (pushTimerRef.current) {
      clearTimeout(pushTimerRef.current);
      pushTimerRef.current = null;
      lastPushedRef.current = draftRef.current;
      onChange(draftRef.current);
    }
  }, [onChange]);

  const setPreview = React.useCallback((updater: (current: boolean) => boolean) => {
    setPreviewState((current) => {
      const next = updater(current);
      lastPreviewState = next;
      return next;
    });
  }, []);

  /** Keep the viewport pinned to the anchor while the freshly rendered mode
   * settles (async images, fonts, code highlight all change the height —
   * they used to clamp the restored scroll and throw the user to the top).
   * Runs ~2s or until the user scrolls by themselves. */
  const startScrollPin = React.useCallback((getTarget: () => number | null) => {
    stopPinRef.current();
    const el = scrollRef.current;
    if (!el) return;
    let frames = 0;
    let stableFrames = 0;
    let lastSet = -1;
    const stop = () => {
      cancelAnimationFrame(pinRafRef.current);
      ro.disconnect();
      el.removeEventListener("scroll", onUserScroll);
      pinTargetRef.current = null;
      stopPinRef.current = () => {};
    };
    const onUserScroll = () => {
      if (lastSet >= 0 && Math.abs(el.scrollTop - lastSet) > 6) stop();
    };
    const tick = () => {
      const target = getTarget();
      if (target == null) { frames++; if (frames < 120) pinRafRef.current = requestAnimationFrame(tick); else stop(); return; }
      // V6: the user (or a programmatic scroll) moved the viewport away from
      // the pinned position → hand control back IMMEDIATELY. This prevents
      // the settle-pin from ever fighting/clobbering an external scroll that
      // races a frame ahead of the scroll event.
      if (lastSet >= 0 && Math.abs(el.scrollTop - lastSet) > 6) { stop(); return; }
      const max = Math.max(0, el.scrollHeight - el.clientHeight);
      const clamped = Math.max(0, Math.min(target, max));
      if (Math.abs(el.scrollTop - clamped) > 1) {
        el.scrollTop = clamped;
        lastSet = clamped;
        stableFrames = 0;
      } else {
        // position already correct — approve it so the user-scroll guard is
        // armed even when the pin never had to move the viewport
        lastSet = el.scrollTop;
        stableFrames++;
      }
      frames++;
      // stop once the position has held steady for a while (heights settled)
      if (stableFrames > 45 || frames >= 120) stop();
      else pinRafRef.current = requestAnimationFrame(tick);
    };
    const ro = new ResizeObserver(() => { stableFrames = 0; });
    stopPinRef.current = stop;
    el.addEventListener("scroll", onUserScroll, { passive: true });
    ro.observe(el);
    if (el.firstElementChild) ro.observe(el.firstElementChild);
    pinRafRef.current = requestAnimationFrame(tick);
  }, []);

  /** Top-level preview blocks that carry a source-line anchor, in DOM order. */
  const getLineBlocks = React.useCallback((): HTMLElement[] => {
    const root = previewRef.current;
    if (!root) return [];
    const out: HTMLElement[] = [];
    for (const child of Array.from(root.children) as HTMLElement[]) {
      if (child.hasAttribute("data-src-line")) out.push(child);
      else {
        // wrappers rendered by plugins (e.g. KaTeX spans) — look one level down
        const nested = child.querySelector<HTMLElement>("[data-src-line]");
        if (nested) out.push(nested);
      }
    }
    return out;
  }, []);

  const makeAnchorGetter = React.useCallback((): (() => number | null) => {
    const anchor = pendingAnchorRef.current;
    if (!anchor) return () => null;
    if (anchor.from === "edit") {
      // restore into PREVIEW: pin the block that starts at/after the captured
      // source line — data-src-line makes this an exact, lossless lookup
      return () => {
        const el = scrollRef.current;
        if (!el) return null;
        const blocks = getLineBlocks();
        if (blocks.length === 0) return 0;
        const want = anchor.lineIndex + 1; // 1-based source line
        let block = blocks[blocks.length - 1];
        for (const b of blocks) {
          const line = Number(b.getAttribute("data-src-line"));
          if (line >= want) {
            block = b;
            break;
          }
        }
        const blockTop = block.getBoundingClientRect().top - el.getBoundingClientRect().top;
        const offset = anchor.blockOffset ?? 0;
        return el.scrollTop + blockTop + offset - el.clientHeight * anchor.ratio;
      };
    }
    // restore into EDIT: scroll so the recorded source line is back at the probe
    return () => {
      const el = scrollRef.current;
      const ta = textareaRef.current;
      if (!el || !ta) return null;
      const style = getComputedStyle(ta);
      const lh = Number.parseFloat(style.lineHeight) || 24;
      const taTop = ta.getBoundingClientRect().top - el.getBoundingClientRect().top + el.scrollTop;
      return taTop + anchor.lineIndex * lh - el.clientHeight * anchor.ratio;
    };
  }, [getLineBlocks]);

  /** Capture where the viewport currently is, relative to the CONTENT. */
  const captureAnchor = React.useCallback((): ModeAnchor | null => {
    const el = scrollRef.current;
    if (!el) return null;
    const elRect = el.getBoundingClientRect();
    const probeY = elRect.top + elRect.height * PROBE_RATIO;
    const ratioC = Math.min(0.95, Math.max(0.05, (probeY - elRect.top) / Math.max(1, elRect.height)));
    const lines = draft.split("\n");
    // V6: when a settle-pin is holding/restoring a position, the DOM scroll
    // may lag behind the intended one for a few frames — measure against the
    // INTENDED position so captures are never fooled by the transient one.
    const effectiveScroll = pinTargetRef.current ?? el.scrollTop;
    const scrollCorrection = effectiveScroll - el.scrollTop;
    if (preview) {
      // preview → anchor = rendered block at the probe (exact source line)
      const blocks = getLineBlocks();
      if (blocks.length === 0) return { from: "preview", ratio: ratioC, lineIndex: 0, blockSrcLine: 1, blockOffset: 0 };
      // probe position within the CONTENT = viewport offset + scroll
      // (or the position the settle-pin is heading to)
      const probeContentY = (probeY - elRect.top) + effectiveScroll;
      let block = blocks[0];
      for (const b of blocks) {
        const r = b.getBoundingClientRect();
        const absTop = r.top - elRect.top + el.scrollTop;
        const absBottom = r.bottom - elRect.top + el.scrollTop;
        if (absBottom > probeContentY) {
          block = b;
          break;
        }
      }
      const srcLine = Number(block.getAttribute("data-src-line")) || 1;
      const blockRect = block.getBoundingClientRect();
      const blockOffset = probeY - blockRect.top;
      return { from: "preview", ratio: ratioC, lineIndex: Math.max(0, srcLine - 1), blockSrcLine: srcLine, blockOffset };
    }
    // edit → anchor = textarea line at the probe
    const ta = textareaRef.current;
    if (!ta) return null;
    const taRect = ta.getBoundingClientRect();
    const style = getComputedStyle(ta);
    const lh = Number.parseFloat(style.lineHeight) || 24;
    const lineIndex = Math.max(
      0,
      Math.min(lines.length - 1, Math.floor((probeY - taRect.top + scrollCorrection) / lh))
    );
    return { from: "edit", ratio: ratioC, lineIndex, blockSrcLine: lineIndex + 1 };
  }, [draft, preview, getLineBlocks]);

  const togglePreview = React.useCallback(() => {
    // remember EXACTLY which content anchor is at the probe; re-pinned after
    const anchor = captureAnchor();
    if (anchor) {
      lastModeAnchor = anchor;
      pendingAnchorRef.current = anchor;
      scrollMemory.set(stateKey ?? "editor", scrollRef.current?.scrollTop ?? 0);
    }
    setPreview((current) => !current);
  }, [setPreview, captureAnchor, stateKey]);

  /** Re-pin the viewport to the pending anchor (mode switch, image resize…). */
  const runAnchorRestore = React.useCallback(() => {
    if (pendingAnchorRef.current == null) return;
    startScrollPin(makeAnchorGetter());
    pendingAnchorRef.current = null;
  }, [makeAnchorGetter, startScrollPin]);

  React.useEffect(() => { urlToFileRef.current = urlToFile; }, [urlToFile]);

  // per-note scroll memory: survives remounts (draft → real note) and lets a
  // reopened note start where the user last was — never at the top
  React.useEffect(() => {
    const el = scrollRef.current;
    let target: number | null = null;
    if (stateKey && scrollMemory.has(stateKey)) {
      target = scrollMemory.get(stateKey) ?? null;
    } else if (lastEditorStateKey === stateKey || lastEditorStateKey === "__draft__") {
      target = lastEditorScrollTop; // same note (or materialized draft) — keep position
    }
    if (el && target != null && target > 2) {
      const getTarget = () => {
        const cur = scrollRef.current;
        if (!cur) return null;
        // raw intent — the settle-pin clamps for the actual scroll and keeps
        // re-applying as the content grows (field-sizing textarea, images)
        return target!;
      };
      // V6: apply the remembered position SYNCHRONOUSLY — an async-only pin
      // left a window where a fast mode toggle captured a stale position and
      // then clobbered the restore (the "switch back jumps to top" bug).
      const max = Math.max(0, el.scrollHeight - el.clientHeight);
      el.scrollTop = Math.max(0, Math.min(target, max));
      startScrollPin(getTarget);
    }
    return () => {
      const current = scrollRef.current;
      if (current) {
        lastEditorScrollTop = current.scrollTop;
        if (stateKey) scrollMemory.set(stateKey, current.scrollTop);
      }
      lastEditorStateKey = stateKey ?? null;
      stopPinRef.current();
    };
  }, [stateKey, startScrollPin]);

  const toDisplay = React.useCallback((md: string) => md.replace(/(!?\[([^\]]*)\])\(\s*(attachment\/[^)\s]+)((?:\s+"[^"]*")?)\s*\)/g, (full, label: string, alt: string, file: string, title: string) => {
    const decoded = decodeAttachmentPath(file);
    const url = fileToUrl(decoded) || fileToUrl(file);
    // Attachment links are rendered as images even when older notes stored
    // them as `[filename](attachment/...)` instead of `![alt](...)`.
    return url ? `![${alt || decoded.split("/").pop() || "Attached image"}](${url}${title})` : full;
  }), [fileToUrl]);

  const fromDisplay = React.useCallback((md: string) => {
    let out = md.replace(/\]\(\s*(blob:[^)\s]+|data:[^)\s]+)((?:\s+"[^"]*")?)\s*\)/g, (full, url: string, title: string) => {
      const file = urlToFileRef.current.get(url);
      return file ? `](${encodeAttachmentPath(file)}${title})` : full;
    });
    // V5: HTML grid images — persist blob/data URLs back to attachment paths
    out = out.replace(/(<img\b[^>]*?\bsrc=")(blob:[^"]+|data:[^"]+)(")/gi, (full, head: string, url: string, tail: string) => {
      const file = urlToFileRef.current.get(url);
      return file ? `${head}${encodeAttachmentPath(file)}${tail}` : full;
    });
    return out;
  }, []);

  /* ------------------------------------------------- undo/redo history (V4)
   * The native textarea undo stack never sees programmatic changes (toolbar
   * buttons, task ticks, image inserts) and React's controlled value breaks
   * it anyway. A snapshot history records EVERY change — typing is coalesced
   * into word-ish chunks, every button action is its own step.
   */
  interface HistoryEntry { text: string; selStart: number; selEnd: number }
  const histRef = React.useRef<{
    entries: HistoryEntry[];
    index: number;
    lastCommitAt: number;
    lastKind: string;
  }>({ entries: [], index: -1, lastCommitAt: 0, lastKind: "" });

  const resetHistory = React.useCallback((text: string) => {
    histRef.current = { entries: [{ text, selStart: 0, selEnd: 0 }], index: 0, lastCommitAt: 0, lastKind: "" };
  }, []);
  React.useEffect(() => { resetHistory(value === EMPTY_TASK_LIST_HTML ? "- [ ] " : value); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const commitHistory = React.useCallback((text: string, kind: "type" | "action") => {
    const h = histRef.current;
    const el = textareaRef.current;
    const entry: HistoryEntry = {
      text,
      selStart: el?.selectionStart ?? 0,
      selEnd: el?.selectionEnd ?? 0,
    };
    const now = Date.now();
    if (kind === "type" && h.lastKind === "type" && now - h.lastCommitAt < 650) {
      h.entries[h.index] = entry; // coalesce a continuous typing burst
    } else {
      h.entries = h.entries.slice(0, h.index + 1);
      h.entries.push(entry);
      if (h.entries.length > 300) h.entries.shift();
      h.index = h.entries.length - 1;
    }
    h.lastCommitAt = now;
    h.lastKind = kind;
  }, []);

  React.useEffect(() => {
    const normalized = value === EMPTY_TASK_LIST_HTML ? "- [ ] " : value;
    // our own throttled echo → do not reset the local draft
    if (normalized === lastPushedRef.current) return;
    if (normalized !== draft) {
      setDraft(normalized);
      resetHistory(normalized); // external change (note switch) — fresh baseline
    }
  }, [value]); // eslint-disable-line react-hooks/exhaustive-deps

  React.useEffect(() => {
    if (!autoFocus || preview) return;
    // V4: preventScroll — plain focus() scrolled the fresh textarea (whose top
    // is the container top) into view, throwing the viewport to the very top
    // on every preview→edit toggle. The scroll pin keeps the position.
    requestAnimationFrame(() => textareaRef.current?.focus({ preventScroll: true }));
  }, [autoFocus, preview]);

  const emitSearch = React.useCallback((query: string, preferred = 0) => {
    const q = query.trim().normalize("NFKC").toLocaleLowerCase();
    if (!q) {
      onSearchResults?.({ count: 0, active: 0 });
      return;
    }
    const matches: number[] = [];
    const searchable = draft.normalize("NFKC").toLocaleLowerCase();
    let at = searchable.indexOf(q);
    while (at !== -1) {
      matches.push(at);
      at = searchable.indexOf(q, at + Math.max(1, q.length));
    }
    const index = matches.length ? ((preferred % matches.length) + matches.length) % matches.length : 0;
    setSearchIndex(index);
    onSearchResults?.({ count: matches.length, active: index });
    if (matches[index] != null && textareaRef.current && !preview) {
      const el = textareaRef.current;
      const match = matches[index];
      // Never focus the editor or select the match: doing either steals focus
      // from the search field and makes the next typed character replace text.
      el.setSelectionRange(match, match);
      const line = draft.slice(0, match).split("\n").length - 1;
      const lineHeight = Number.parseFloat(getComputedStyle(el).lineHeight) || 24;
      const container = scrollRef.current;
      if (container) {
        const target = el.offsetTop + line * lineHeight - container.clientHeight * 0.35;
        container.scrollTo({ top: Math.max(0, target), behavior: "smooth" });
      }
    }
  }, [draft, onSearchResults, preview]);

  const applyHistoryEntry = React.useCallback((entry: HistoryEntry) => {
    setDraft(entry.text);
    pushNow(entry.text);
    if (searchQueryRef.current) emitSearch(searchQueryRef.current, searchIndex);
    const el = textareaRef.current;
    if (el) {
      requestAnimationFrame(() => {
        el.focus();
        const start = Math.max(0, Math.min(entry.selStart, entry.text.length));
        const end = Math.max(start, Math.min(entry.selEnd, entry.text.length));
        try { el.setSelectionRange(start, end); } catch { /* detached */ }
      });
    }
  }, [emitSearch, onChange, searchIndex]);

  const doUndoRef = React.useRef(() => {});
  const doRedoRef = React.useRef(() => {});
  const doUndo = React.useCallback(() => {
    const h = histRef.current;
    if (h.index <= 0) return;
    h.index--;
    h.lastKind = "";
    applyHistoryEntry(h.entries[h.index]);
  }, [applyHistoryEntry]);
  const doRedo = React.useCallback(() => {
    const h = histRef.current;
    if (h.index >= h.entries.length - 1) return;
    h.index++;
    h.lastKind = "";
    applyHistoryEntry(h.entries[h.index]);
  }, [applyHistoryEntry]);
  React.useEffect(() => { doUndoRef.current = doUndo; doRedoRef.current = doRedo; }, [doUndo, doRedo]);

  React.useImperativeHandle(handleRef, () => ({
    focus: () => textareaRef.current?.focus(),
    registerUrl: (url, file) => { urlToFileRef.current = new Map(urlToFileRef.current).set(url, file); },
    flushPendingPush,
    setSearchQuery: (query) => {
      searchQueryRef.current = query;
      setSearchQuery(query);
      emitSearch(query, 0);
    },
    goToMatch: (index) => {
      setSearchIndex(index);
      emitSearch(searchQueryRef.current, index);
    },
    insertImage: (url, alt = "") => {
      const el = textareaRef.current;
      const snippet = `![${alt}](${url})`;
      // V4: in preview mode the textarea is not mounted — previously the
      // "Insert into note" button silently did nothing. Fall back to
      // appending the image at the end of the note body.
      if (!el) {
        const base = draft.replace(/\n*$/, "");
        const next = `${base}\n\n${snippet}\n`;
        const clean = fromDisplay(next);
        setDraft(clean); pushNow(clean); commitHistory(clean, "action");
        return;
      }
      const s = el.selectionStart;
      const next = `${draft.slice(0, s)}\n${snippet}\n${draft.slice(el.selectionEnd)}`;
      const clean = fromDisplay(next);
      setDraft(clean); pushNow(clean); commitHistory(clean, "action");
      requestAnimationFrame(() => {
        const scrollTop = scrollRef.current?.scrollTop ?? 0;
        el.setSelectionRange(s + clean.slice(s).indexOf("\n", 1) + 1, s + clean.slice(s).indexOf("\n", 1) + 1);
        if (scrollRef.current) scrollRef.current.scrollTop = scrollTop;
      });
    },
    insertImages: (items) => {
      if (!items || items.length === 0) return;
      const el = textareaRef.current;
      let snippet: string;
      if (items.length === 1) {
        snippet = `![${items[0].alt || items[0].url}](${items[0].url})`;
      } else {
        // V5: several images at the cursor become a compact grid. The grid is
        // plain HTML whose <img src> round-trips to attachment/ paths on disk,
        // so node.md stays portable to Obsidian & friends.
        const cols = items.length <= 4 ? 2 : 3;
        const imgs = items
          .map((it) => `<img src="${it.url}" alt="${(it.alt || "image").replace(/"/g, "&quot;")}">`)
          .join("\n");
        snippet = `<div class="img-grid" data-cols="${cols}">\n${imgs}\n</div>`;
      }
      if (!el) {
        const base = draft.replace(/\n*$/, "");
        const next = `${base}\n\n${snippet}\n`;
        const clean = fromDisplay(next);
        setDraft(clean); pushNow(clean); commitHistory(clean, "action");
        return;
      }
      const s = el.selectionStart;
      const e = el.selectionEnd;
      const before = draft.slice(0, s);
      const after = draft.slice(e);
      const padBefore = before && !before.endsWith("\n") ? "\n\n" : before ? "\n" : "";
      const padAfter = after && !after.startsWith("\n") ? "\n\n" : after ? "\n" : "";
      const next = `${before}${padBefore}${snippet}${padAfter}${after}`;
      const clean = fromDisplay(next);
      setDraft(clean); pushNow(clean); commitHistory(clean, "action");
      const caret = before.length + padBefore.length + snippet.length;
      requestAnimationFrame(() => {
        const scrollTop = scrollRef.current?.scrollTop ?? 0;
        try { el.setSelectionRange(caret, caret); } catch { /* detached */ }
        if (scrollRef.current) scrollRef.current.scrollTop = scrollTop;
      });
    },
    removeImageReference: (url) => {
      if (!url) return;
      // the draft may hold either display URLs or persisted attachment paths
      const cands = new Set<string>([url]);
      const file = urlToFileRef.current.get(url);
      if (file) {
        cands.add(file);
        try { cands.add(encodeAttachmentPath(file)); } catch { /* ignore */ }
      }
      let next = draft;
      for (const cand of cands) {
        const esc = cand.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        next = next.replace(new RegExp(`!\\[[^\\]]*\\]\\(\\s*${esc}[^)]*\\)\\s*`, "g"), "");
        next = next.replace(new RegExp(`\\s*<img\\b[^>]*\\bsrc="${esc}"[^>]*>\\s*`, "gi"), "");
      }
      // collapse now-empty grid wrappers
      next = next.replace(/<div class="img-grid"[^>]*>\s*<\/div>\s*/gi, "");
      // tidy leftover blank runs
      next = next.replace(/\n{3,}/g, "\n\n");
      if (next !== draft) {
        const clean = fromDisplay(next);
        setDraft(clean); pushNow(clean); commitHistory(clean, "action");
      }
    },
    getMarkdown: () => draft,
    getScrollElement: () => scrollRef.current,
  }), [draft, emitSearch, fromDisplay, handleRef, onChange, searchQuery, commitHistory, pushNow, flushPendingPush]);

  function updateDraft(next: string, kind: "type" | "action" = "action") {
    const clean = fromDisplay(next);
    setDraft(clean);
    if (kind === "type") pushThrottled(clean);
    else pushNow(clean);
    commitHistory(clean, kind);
    if (searchQueryRef.current) emitSearch(searchQueryRef.current, searchIndex);
  }

  function replaceSelection(replacement: string, cursorOffset = replacement.length) {
    const el = textareaRef.current;
    if (!el) return;
    const s = el.selectionStart, e = el.selectionEnd;
    updateDraft(`${draft.slice(0, s)}${replacement}${draft.slice(e)}`);
    requestAnimationFrame(() => { el.focus(); const p = s + cursorOffset; el.setSelectionRange(p, p); });
  }

  function wrap(before: string, after = before, placeholder = "text") {
    const el = textareaRef.current; if (!el) return;
    const s = el.selectionStart, e = el.selectionEnd;
    const selected = draft.slice(s, e) || placeholder;
    const replacement = `${before}${selected}${after}`;
    updateDraft(`${draft.slice(0, s)}${replacement}${draft.slice(e)}`);
    // Never leave the textarea selection highlighted after a toolbar action.
    // With no selection, put the caret between the opening and closing marks;
    // with selected text, put it after the complete formatted text.
    const cursor = s === e ? s + before.length : s + replacement.length;
    requestAnimationFrame(() => { el.focus(); el.setSelectionRange(cursor, cursor); });
  }

  function prefix(prefix: string) {
    const el = textareaRef.current; if (!el) return;
    const s = el.selectionStart, e = el.selectionEnd;
    const start = draft.lastIndexOf("\n", s - 1) + 1;
    // Prefixes are line syntax. If there is no selection, insert at the
    // current line and leave the caret immediately after the prefix.
    if (s === e) {
      const line = draft.slice(start, draft.indexOf("\n", s) === -1 ? draft.length : draft.indexOf("\n", s));
      const marker = /^(#{1,6}\s+|[-*+]\s+|\d+[.)]\s+|>\s+)/.exec(line)?.[0] ?? "";
      const nextPrefix = prefix === "" ? "" : prefix;
      const insert = marker && (prefix.startsWith("#") || /^\d/.test(prefix) || prefix === "> ") ? nextPrefix : prefix;
      const next = `${draft.slice(0, start)}${insert}${draft.slice(start)}`;
      updateDraft(next);
      requestAnimationFrame(() => { el.focus(); const p = s + insert.length; el.setSelectionRange(p, p); });
      return;
    }
    const segment = draft.slice(start, e);
    const patched = segment.split("\n").map((line) => line.startsWith(prefix) ? line : `${prefix}${line}`).join("\n");
    updateDraft(`${draft.slice(0, start)}${patched}${draft.slice(e)}`);
    requestAnimationFrame(() => { el.focus(); const p = start + patched.length; el.setSelectionRange(p, p); });
  }

  function paragraph() {
    const el = textareaRef.current; if (!el) return;
    const s = el.selectionStart, e = el.selectionEnd;
    const start = draft.lastIndexOf("\n", s - 1) + 1;
    const end = draft.indexOf("\n", Math.max(s, e));
    const lineEnd = end === -1 ? draft.length : end;
    const line = draft.slice(start, lineEnd);
    const cleaned = line.replace(/^(#{1,6}\s+|[-*+]\s+|\d+[.)]\s+|>\s+)/, "");
    updateDraft(`${draft.slice(0, start)}${cleaned}${draft.slice(lineEnd)}`);
    requestAnimationFrame(() => { el.focus(); const p = start + Math.min(Math.max(s - start, 0), cleaned.length); el.setSelectionRange(p, p); });
  }

  function handleEditorKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    // V4: undo/redo shortcuts go through OUR history (native stack is broken
    // by the controlled textarea + programmatic toolbar changes)
    if ((e.ctrlKey || e.metaKey) && !e.altKey) {
      const key = e.key.toLowerCase();
      if (key === "z") {
        e.preventDefault();
        if (e.shiftKey) doRedo(); else doUndo();
        return;
      }
      if (key === "y") {
        e.preventDefault();
        doRedo();
        return;
      }
    }
    if (e.key !== "Enter" || e.shiftKey || e.altKey || e.ctrlKey || e.metaKey) return;
    const el = e.currentTarget;
    const s = el.selectionStart, end = el.selectionEnd;
    if (s !== end) return;
    const lineStart = draft.lastIndexOf("\n", s - 1) + 1;
    const line = draft.slice(lineStart, s);
    const bullet = /^(\s*)([-*+])\s+(.*)$/.exec(line);
    const numbered = /^(\s*)(\d+)([.)])\s+(.*)$/.exec(line);
    const task = /^(\s*)([-*+])\s+\[[ xX]\]\s*(.*)$/.exec(line);
    if (!bullet && !numbered) return;
    e.preventDefault();
    // Enter on an empty list item exits the list instead of creating noise.
    const isEmpty = task ? !task[3].trim() : bullet ? !bullet[3].trim() : !numbered![4].trim();
    const continuation = isEmpty
      ? ""
      : task
        ? `${task[1]}${task[2]} [ ] `
        : bullet
          ? `${bullet[1]}${bullet[2]} `
          : `${numbered![1]}${Number(numbered![2]) + 1}${numbered![3]} `;
    const next = `${draft.slice(0, s)}\n${isEmpty ? "" : continuation}${draft.slice(end)}`;
    updateDraft(next);
    requestAnimationFrame(() => { el.focus(); const p = s + 1 + continuation.length; el.setSelectionRange(p, p); });
  }

  function table() {
    const value = "| Column 1 | Column 2 | Column 3 |\n| --- | --- | --- |\n| Row 1 | Value | Value |\n| Row 2 | Value | Value |";
    const el = textareaRef.current;
    if (!el) return;
    const s = el.selectionStart, e = el.selectionEnd;
    const separator = s > 0 && draft[s - 1] !== "\n" ? "\n\n" : "";
    replaceSelection(`${separator}${value}\n`);
  }

  function action(actionName: string, replacement?: string, label?: string) {
    switch (actionName) {
      case "bold": return wrap("**", "**", "");
      case "italic": return wrap("*", "*", "");
      case "underline": return wrap("<u>", "</u>", "");
      case "strike": return wrap("~~", "~~", "");
      case "code": return wrap("`", "`", "");
      case "h1": return prefix("# ");
      case "h2": return prefix("## ");
      case "h3": return prefix("### ");
      case "paragraph": return paragraph();
      case "ul": return prefix("- ");
      case "ol": return prefix("1. ");
      case "todo": return prefix("- [ ] ");
      case "quote": return prefix("> ");
      case "codeblock": return wrap("```\n", "\n```", "");
      case "multi": {
        const el = textareaRef.current; if (!el) return;
        const s = el.selectionStart, e = el.selectionEnd;
        const selected = draft.slice(s, e);
        const formats = (replacement ?? "").split(",").filter(Boolean);
        let content = selected;
        let before = "";
        let after = "";
        for (const format of formats) {
          if (format === "bold") { before += "**"; after = "**" + after; }
          else if (format === "italic") { before += "*"; after = "*" + after; }
          else if (format === "underline") { before += "<u>"; after = "</u>" + after; }
          else if (format === "strike") { before += "~~"; after = "~~" + after; }
          else if (format === "code") { before += "`"; after = "`" + after; }
          else if (format === "h1") before = "# " + before;
          else if (format === "h2") before = "## " + before;
          else if (format === "h3") before = "### " + before;
        }
        const replacementText = `${before}${content}${after}`;
        updateDraft(`${draft.slice(0, s)}${replacementText}${draft.slice(e)}`);
        const cursor = s === e ? s + before.length : s + replacementText.length;
        requestAnimationFrame(() => { el.focus(); el.setSelectionRange(cursor, cursor); });
        return;
      }
      case "hr": return replaceSelection("\n\n---\n");
      case "table": return table();
      case "replace-selection": return replaceSelection(replacement ?? "");
      case "link": {
        const el = textareaRef.current; if (!el) return;
        const s = el.selectionStart, e = el.selectionEnd;
        const selected = label || draft.slice(s, e) || "";
        return replaceSelection(replacement ? `[${selected}](${replacement})` : selected);
      }
      case "remove-link": return updateDraft(draft.replace(/\[([^\]]+)\]\(([^)]+)\)/g, "$1"));
      case "clear": {
        // V4: strip EVERY markdown special character. With a selection, only
        // the selected span is rewritten; without one, the whole note.
        const el = textareaRef.current;
        if (el && el.selectionStart !== el.selectionEnd) {
          const s = el.selectionStart, e = el.selectionEnd;
          const segment = draft.slice(s, e);
          const atLineStart = s === 0 || draft[s - 1] === "\n";
          const lines = segment.split("\n");
          const stripped = lines
            .map((line, i) => (i === 0 && !atLineStart ? stripLineLevel(line, false) : stripLineLevel(line, true)))
            .join("\n");
          const cleaned = stripMarkdownFormat(stripped);
          updateDraft(`${draft.slice(0, s)}${cleaned}${draft.slice(e)}`);
          requestAnimationFrame(() => { el.focus(); const p = s + cleaned.length; el.setSelectionRange(p, p); });
          return;
        }
        return updateDraft(stripMarkdownFormat(draft));
      }
      case "undo": return doUndo();
      case "redo": return doRedo();
    }
  }

  /** Line-start syntax stripping for the selection-aware clear action.
   * Prefix markers are only removed from lines that actually START inside the
   * selection (a mid-line selection must not lose its leading list marker). */
  function stripLineLevel(line: string, allowPrefix: boolean) {
    if (!allowPrefix) return line;
    return line
      .replace(/^\s{0,3}>\s?/, "")
      .replace(/^\s{0,3}#{1,6}\s+/, "")
      .replace(/^(\s*)[-*+]\s+\[[ xX]\]\s*/, "$1")
      .replace(/^(\s*)[-*+]\s+/, "$1")
      .replace(/^(\s*)\d+[.)]\s+/, "$1");
  }

  const copyCode = React.useCallback(async (code: string) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopiedCode(code);
      window.setTimeout(() => setCopiedCode((current) => current === code ? null : current), 1400);
    } catch {
      /* Clipboard may be unavailable in restricted WebViews. */
    }
  }, []);
  const previewContent = React.useMemo(() => toDisplay(draft), [draft, toDisplay]);
  // V7: normalise math delimiters (\[ \], \( \), bare equations) before the
  // markdown pipeline — same line count, so scroll anchors stay valid.
  const mathReadyContent = React.useMemo(
    () => (appSettings.mathEnabled ? preprocessMathMarkdown(previewContent) : previewContent),
    [previewContent, appSettings.mathEnabled]
  );
  const highlightedPreviewContent = React.useMemo(() => {
    const query = searchQuery.trim();
    if (!preview || !query) return mathReadyContent;
    const escaped = query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const escapeHtml = (text: string) => text.replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[char] ?? char);
    return mathReadyContent.replace(new RegExp(escaped, "giu"), (match) => `<mark class="search-hit">${escapeHtml(match)}</mark>`);
  }, [preview, mathReadyContent, searchQuery]);
  React.useEffect(() => {
    if (!preview || !searchQuery.trim()) return;
    const matches = Array.from(scrollRef.current?.querySelectorAll("mark.search-hit") ?? []);
    matches.forEach((match, index) => match.classList.toggle("search-hit-active", index === searchIndex));
    const match = matches[searchIndex];
    const container = scrollRef.current;
    if (match && container) {
      const r = match.getBoundingClientRect();
      const c = container.getBoundingClientRect();
      container.scrollTo({ top: Math.max(0, container.scrollTop + r.top - c.top - container.clientHeight * 0.35), behavior: "smooth" });
    }
  }, [preview, previewContent, searchIndex, searchQuery]);

  const actionHandler = React.useCallback(
    (actionName: string, replacement?: string, label?: string) => action(actionName, replacement, label),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [draft, doUndo, doRedo]
  );

  /* ------------------------------------------------------------ V10 image sizing
   * Size metadata is scoped to the selected Markdown object:
   *   - a normal Markdown image stores size=NN on that image only;
   *   - an HTML img-grid stores data-size=NN on that grid only.
   * The old always-visible overlay was removed. A long press (or context menu)
   * opens the control so reading and scrolling never show a large logo/button.
   */
  const [sizingFor, setSizingFor] = React.useState<string | null>(null);
  const [menuPosition, setMenuPosition] = React.useState<{ left: number; top: number } | null>(null);
  const longPressTimerRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const suppressClickRef = React.useRef(false);

  const parseImageSize = (title?: string): number | null => {
    if (!title) return null;
    const m = /(?:^|\s)size=(\d{1,3})\b/.exec(title);
    if (!m) return null;
    const n = Number(m[1]);
    return n >= 10 && n <= 100 ? n : null;
  };
  const parseGridSize = (props: Record<string, unknown>): number | null => {
    const raw = props["data-size"];
    const n = typeof raw === "number" ? raw : Number(raw);
    return Number.isFinite(n) && n >= 10 && n <= 100 ? n : null;
  };
  const sourceLineOf = (node: PositionalNode | undefined): number | undefined => node?.position?.start?.line;
  const lineAt = (text: string, index: number) => text.slice(0, index).split("\n").length;

  const setImageSize = React.useCallback(
    (target: { kind: "image" | "grid"; displayUrl?: string; sourceLine?: number }, size: number | null) => {
      let next = draft;
      if (target.kind === "grid") {
        const gridRe = /<div\b([^>]*\bclass=(?:"img-grid"|'img-grid')[^>]*)>/gi;
        let changed = false;
        next = next.replace(gridRe, (full, attrs: string, offset: number) => {
          if (changed || (target.sourceLine && lineAt(draft, offset) !== target.sourceLine)) return full;
          changed = true;
          let updated = attrs.replace(/\sdata-size=(?:"[^" ]*"|'[^' ]*')/i, "");
          if (size != null) updated += ` data-size="${size}"`;
          return `<div${updated}>`;
        });
      } else {
        // Update the exact Markdown image occurrence by its source line. Do
        // not depend on a blob URL lookup: the persisted draft may contain an
        // attachment path while the preview contains a resolved blob URL.
        let changed = false;
        const imageRe = /(!\[[^\]]*\]\(\s*)([^)\s]+)((?:\s+"[^"]*")?)(\s*\))/g;
        next = next.replace(imageRe, (full, head: string, url: string, oldTitle: string, tail: string, offset: number) => {
          if (changed || (target.sourceLine && lineAt(draft, offset) !== target.sourceLine)) return full;
          const displayUrl = target.displayUrl ?? "";
          const file = urlToFileRef.current.get(displayUrl);
          const decodedUrl = url;
          const matchesTarget = decodedUrl === displayUrl || decodedUrl === file || decodedUrl === (file ? encodeAttachmentPath(file) : "");
          if (!matchesTarget) return full;
          changed = true;
          return size == null ? `${head}${url}${tail}` : `${head}${url} "size=${size}"${tail}`;
        });
      }
      if (next === draft) return;
      const anchor = captureAnchor();
      if (anchor) pendingAnchorRef.current = anchor;
      const clean = fromDisplay(next);
      setDraft(clean);
      pushNow(clean);
      commitHistory(clean, "action");
    },
    [draft, captureAnchor, commitHistory, fromDisplay, pushNow]
  );

  const openSizingAt = React.useCallback((key: string, clientX: number, clientY: number) => {
    // Fixed positioning prevents the menu from being re-laid out with the
    // image when its width changes. Clamp against the viewport so it never
    // opens partly off-screen on a phone or desktop edge.
    const menuWidth = 198;
    const menuHeight = 132;
    const gap = 10;
    const maxLeft = Math.max(gap, window.innerWidth - menuWidth - gap);
    const maxTop = Math.max(gap, window.innerHeight - menuHeight - gap);
    const left = Math.max(gap, Math.min(clientX - menuWidth / 2, maxLeft));
    const top = Math.max(gap, Math.min(clientY - menuHeight - 12, maxTop));
    setMenuPosition({ left, top });
    setSizingFor(key);
  }, []);
  const beginLongPress = React.useCallback((key: string, event: React.PointerEvent) => {
    if (event.pointerType === "mouse" && event.button !== 0) return;
    if (longPressTimerRef.current) clearTimeout(longPressTimerRef.current);
    const { clientX, clientY } = event;
    longPressTimerRef.current = setTimeout(() => {
      suppressClickRef.current = true;
      openSizingAt(key, clientX, clientY);
    }, 520);
  }, [openSizingAt]);
  const endLongPress = React.useCallback(() => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  }, []);
  const openSizingFromContext = React.useCallback((key: string, event: React.MouseEvent) => {
    event.preventDefault();
    openSizingAt(key, event.clientX, event.clientY);
  }, [openSizingAt]);
  const closeAfterClickGuard = React.useCallback(() => {
    if (!suppressClickRef.current) return false;
    suppressClickRef.current = false;
    return true;
  }, []);

  const renderImageSizeMenu = (
    key: string,
    target: { kind: "image" | "grid"; displayUrl?: string; sourceLine?: number },
    size: number | null
  ) => sizingFor === key ? (
    <span
      className="md-image-menu"
      style={menuPosition ? { left: `${menuPosition.left}px`, top: `${menuPosition.top}px` } : undefined}
      onPointerDown={(e) => e.stopPropagation()}
      onClick={(e) => e.stopPropagation()}
    >
      <span className="md-image-menu-title">Image width</span>
      <span className="md-image-menu-row">
        {[['S', 35], ['M', 55], ['L', 75], ['Full', 100]].map(([label, value]) => (
          <button key={label as string} type="button" className={cn("md-image-menu-preset", size === value && "md-image-menu-preset-active")} onClick={() => setImageSize(target, value as number)}>{label}</button>
        ))}
        <button type="button" className={cn("md-image-menu-preset", size == null && "md-image-menu-preset-active")} onClick={() => setImageSize(target, null)}>Auto</button>
      </span>
      <input type="range" min={20} max={100} step={5} value={size ?? 60} aria-label="Image width percent" onChange={(e) => setImageSize(target, Number(e.target.value))} />
      <span className="md-image-menu-value">{size == null ? "Auto" : `${size}%`}</span>
      <button type="button" className="md-image-menu-done" onClick={() => { setSizingFor(null); setMenuPosition(null); }}>Done</button>
    </span>
  ) : null;

  // apply any pending anchor after EVERY render (mode switches, image
  // resizes, task ticks — anything that must not move the viewport)
  React.useEffect(() => {
    runAnchorRestore();
  });

  return (
    <div className="md-editor flex min-h-0 flex-1 flex-col">
      <div className="sticky top-0 z-20 shrink-0">
        <Toolbar editor={textareaRef.current} preview={preview} onTogglePreview={togglePreview} onPickImages={onRequestInsertImages} onInsertAtCursor={() => onRequestInsertAtCursor?.()} onAction={actionHandler} />
      </div>
      <div ref={scrollRef} className="min-h-0 flex-1 overflow-y-auto px-4 pb-8 pt-2">
        {beforeContent}
        {preview ? (
          <div ref={previewRef} className="md-preview md-prose min-h-[40vh]" aria-label="Rendered Markdown preview">
            <ReactMarkdown
              remarkPlugins={[remarkGfm, ...(appSettings.mathEnabled ? [remarkMath] : [])]}
              rehypePlugins={[
                rehypeUpgradeDisplayMath,
                rehypeRaw,
                ...katexPlugins,
              ]}
              urlTransform={previewUrlTransform}
              components={{
                // V6: block-level elements carry their markdown source line so
                // edit ↔ preview switches (and image resizes) can pin the
                // viewport to the EXACT same content — no more jumps.
                p: lineBlock("p"),
                h1: lineBlock("h1"),
                h2: lineBlock("h2"),
                h3: lineBlock("h3"),
                h4: lineBlock("h4"),
                h5: lineBlock("h5"),
                h6: lineBlock("h6"),
                ul: lineBlock("ul"),
                ol: lineBlock("ol"),
                blockquote: lineBlock("blockquote"),
                hr: lineBlock("hr"),
                div: ({ node, children, className, ...props }) => {
                  const isGrid = typeof className === "string" && className.split(/\s+/).includes("img-grid");
                  if (!isGrid) return <div {...props} className={className} {...srcLineAttr(node)}>{children}</div>;
                  const sourceLine = sourceLineOf(node);
                  const key = `grid:${sourceLine ?? "unknown"}`;
                  const size = parseGridSize(props as Record<string, unknown>);
                  const style = { ...(props.style as React.CSSProperties | undefined), ...(size ? { width: `${size}%` } : {}) };
                  return (
                    <>
                      <div {...props} className={className} style={style} {...srcLineAttr(node)} onPointerDown={(e) => beginLongPress(key, e)} onPointerUp={endLongPress} onPointerCancel={endLongPress} onContextMenu={(e) => openSizingFromContext(key, e)}>{children}</div>
                      {renderImageSizeMenu(key, { kind: "grid", sourceLine }, size)}
                    </>
                  );
                },
                table: ({ node, children, ...props }) => (
                  <div
                    {...props}
                    className="md-table-wrap"
                    {...srcLineAttr(node)}
                  >
                    <table>{children}</table>
                  </div>
                ),
                pre: ({ node, children }) => {
                  const codeElement = React.Children.toArray(children).find((child) => React.isValidElement(child));
                  const text = codeElement && React.isValidElement(codeElement)
                    ? String((codeElement.props as { children?: React.ReactNode }).children).replace(/\n$/, "")
                    : "";
                  return (
                    <div className="md-code-wrap" {...srcLineAttr(node)}>
                      <pre>{children}</pre>
                      <button type="button" className="md-code-copy" onClick={() => void copyCode(text)} aria-label="Copy code">
                        {copiedCode === text ? "Copied" : "Copy"}
                      </button>
                    </div>
                  );
                },
                code: ({ children, className, ...props }) => <code {...props} className={cn(className, "md-code-content")}>{children}</code>,
                input: ({ checked, disabled, ...props }) => (
                  // V4: `disabled` is destructured OUT — react-markdown marks
                  // GFM task checkboxes disabled, which made ticking impossible
                  // in the preview. Toggles now write straight back to the note.
                  <input
                    {...props}
                    type="checkbox"
                    checked={!!checked}
                    aria-label={checked ? "Completed task" : "Incomplete task"}
                    onChange={(event) => {
                      const inputs = Array.from(
                        event.currentTarget.closest(".md-preview")?.querySelectorAll('input[type="checkbox"]') ?? []
                      );
                      const index = inputs.indexOf(event.currentTarget);
                      if (index >= 0) {
                        const anchor = captureAnchor();
                        if (anchor) pendingAnchorRef.current = anchor;
                        updateDraft(toggleTaskLine(draft, index, event.currentTarget.checked));
                      }
                    }}
                  />
                ),
                img: ({ src, alt, title, node, ...props }) => {
                  const raw = typeof src === "string" ? src : "";
                  const resolved = raw.startsWith("attachment/")
                    ? fileToUrl(decodeAttachmentPath(raw)) || fileToUrl(raw)
                    : raw;
                  if (!resolved) return <span className="md-image-missing">{alt || "Image unavailable"}</span>;
                  const imgProps = props as unknown as React.ImgHTMLAttributes<HTMLImageElement>;
                  const sourceLine = sourceLineOf(node as PositionalNode | undefined);
                  const size = parseImageSize(typeof title === "string" ? title : undefined);
                  const key = `image:${sourceLine ?? "unknown"}:${resolved}`;
                  const target = { kind: "image" as const, displayUrl: resolved, sourceLine };
                  return (
                    <span className="md-image-wrap" data-sizable={resolved} onPointerDown={(e) => beginLongPress(key, e)} onPointerUp={endLongPress} onPointerCancel={endLongPress} onContextMenu={(e) => openSizingFromContext(key, e)}>
                      <img {...imgProps} src={resolved} alt={alt ?? ""} loading="lazy" data-size={size ?? undefined} style={size ? { width: `${size}%`, maxWidth: "100%" } : undefined} className="md-inline-image" onClick={(event) => { if (closeAfterClickGuard()) { event.preventDefault(); event.stopPropagation(); return; } event.preventDefault(); event.stopPropagation(); onOpenImage?.(resolved, alt ?? ""); }} />
                      {renderImageSizeMenu(key, target, size)}
                    </span>
                  );
                },
                a: ({ href, children, ...props }) => {
                  const rawHref = typeof href === "string" ? href : "";
                  const attachmentUrl = rawHref.startsWith("attachment/")
                    ? fileToUrl(decodeAttachmentPath(rawHref)) || fileToUrl(rawHref)
                    : rawHref.startsWith("blob:") || rawHref.startsWith("data:")
                      ? rawHref
                      : "";
                  if (attachmentUrl) {
                    const alt = React.Children.toArray(children).filter((child) => typeof child === "string").join(" ");
                    const imgProps = props as unknown as React.ImgHTMLAttributes<HTMLImageElement>;
                    return (
                      <img
                        {...imgProps}
                        src={attachmentUrl}
                        alt={alt || "Attached image"}
                        className="md-inline-image"
                        onClick={(event) => {
                          event.preventDefault();
                          event.stopPropagation();
                          onOpenImage?.(attachmentUrl, alt || "Attached image");
                        }}
                      />
                    );
                  }
                  const normalizedHref = /^(https?:\/\/|mailto:|tel:|sms:|geo:)/i.test(rawHref)
                    ? rawHref
                    : /^(www\.)|^[^\s/?#]+\.[^\s/?#]+$/i.test(rawHref)
                      ? `https://${rawHref}`
                      : rawHref;
                  return <a {...props} href={normalizedHref} target="_blank" rel="noopener noreferrer">{children}</a>;
                },
              }}
            >{highlightedPreviewContent || "*Nothing to preview yet.*"}</ReactMarkdown>
          </div>
        ) : (
          <textarea
            ref={textareaRef}
            value={draft}
            onChange={(e) => updateDraft(e.target.value, "type")}
            onKeyDown={handleEditorKeyDown}
            onPaste={(e) => {
              const files = e.clipboardData.files;
              if (files.length > 0 && [...files].every((f) => f.type.startsWith("image/"))) {
                e.preventDefault();
                onPasteImages?.(Array.from(files));
              }
            }}
            placeholder={placeholder ?? "Start writing…"}
            spellCheck
            className="md-textarea min-h-[40vh] w-full resize-none bg-transparent text-[0.925rem] leading-[1.65] outline-none"
          />
        )}
      </div>
    </div>
  );
});

export function buildUrlToFileMap(attachments: { file: string; url: string }[]): Map<string, string> {
  const map = new Map<string, string>();
  for (const a of attachments) if (a.url) map.set(a.url, a.file);
  return map;
}
