# Notenoid v19

## Search highlight fix

- Fixed in-note search highlighting while the note is in **editing mode**.
- Search rectangles are measured from the exact editor text mirror and rendered above the textarea with click-through hitboxes.
- Strengthened stacking, transparency, and theme styles so highlights remain visible in Chromium and Android WebView.
- Preview search, arrow navigation, global search, tables, code, and note editing remain unchanged.

## Build identity

- Package version: `19.0.0`
- Android version name: `19.0`
- Android version code: `190`
