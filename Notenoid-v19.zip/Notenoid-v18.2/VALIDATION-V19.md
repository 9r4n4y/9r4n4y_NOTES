# Notenoid v19 validation

- `npm run typecheck` — PASS.
- `TEST_URL=http://localhost:3000 node test/search-e2e.mjs` — PASS.
- `TEST_URL=http://localhost:3000 node test/smoke.mjs` — PASS.
- Search regression confirms edit mode paints all five source matches and an active match; preview arrows still navigate inline code, fenced code, tilde-fenced code, and plain text; global code/checklist search remains covered.
- Screenshot proof: `v19-edit-search-highlight.png` visibly shows the active `SeekNeedle` match highlighted while the textarea is in editing mode.
- Production static export — PASS.
- APK package: `com.notes.app`.
- APK version name: `19.0`; version code: `190`; min SDK 24; target SDK 34.
- APK `zipalign` and APK v2/v3 signature verification — PASS.
