# Notenoid v17.1 architecture

## Data flow

```
Editor / store / import-export services
  → NoteRepository (logical Markdown folders)
    → EncryptedFS (logical paths, encrypted index, immutable objects)
      → AndroidFSAdapter / WebFSAdapter / OpfsFSAdapter (physical ciphertext)
```

The repository still works with logical `Note Title/node.md` and `attachment/...` paths. These are not plaintext physical directories after encryption setup. The physical store is `notenoid.encrypted/` with a recovery header, encrypted index checkpoints and opaque ciphertext objects.

## Components

- `src/core/security/crypto.ts`: versioned AES-GCM, password derivation and binary encodings.
- `src/core/security/encrypted-fs.ts`: encrypted adapter, migration, checkpoint commits, recovery, writer coordination and coherent encrypted backup snapshots.
- `src/core/security/preferences.ts`: in-memory preferences backed by encrypted index commits; flush errors are surfaced.
- `src/core/security/remember.ts`: Android device wrapping or browser non-extractable CryptoKey persistence.
- `src/core/security/backup.ts`: readable export/import and encrypted disaster-recovery copy services.
- `src/lib/vault.ts`: independent vault key and password/answer wrapping; compatible credential migration.
- `src/core/repo.ts`: note conversion, attachments, naming and logical repository operations; locked vault placeholders avoid reading inner-encrypted data.
- `src/components/keep/EncryptionSetup.tsx`: first-run seed setup, migration warning and folder recovery.
- `src/components/keep/ExportDialog.tsx`, `ImportDialog.tsx`: explicit readable/encrypted backup choices and vault-password gates.
- `src/components/keep/editor/`: Markdown editing, safe preview, source-mapped word selection and centering.
- `android/src/com/notes/app/MainActivity.java`: Android WebView, native filesystem, device-key wrapping, file export and system-back integration.
- `scripts/recover.py`: independent Python recovery implementation of the documented storage format.

## Persistence boundaries

Sensitive settings and vault records live in the encrypted index. Public bootstrap information still identifies the selected storage adapter/root and permission handle. Static assets, cryptographic headers and filesystem counts/sizes are not secret payloads. Ordinary exports, explicit attachment downloads, recovered files and copied text are deliberately readable outside the encrypted store.

The app has no remote encryption service. All key operations execute locally. Browser automatic unlock is weaker than device-backed key protection. Cross-profile/device simultaneous editing and a compromised app/OS are outside the protection claim. Read `SECURITY.md` before assessing the design.
