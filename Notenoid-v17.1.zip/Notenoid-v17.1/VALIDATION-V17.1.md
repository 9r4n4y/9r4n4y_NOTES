# Notenoid v17.1 — validation record

## Regression reproduced and fixed

The before screenshot (`test/evidence/markdown-images-before-v17.1.png`) shows a single uploaded Markdown image rendered as a filename/alt chip while the same note's HTML image grid renders pictures.

Cause: the v17 preview's `toDisplay()` changed local Markdown attachment URLs into `blob:` object URLs before `rehype-sanitize`. The default schema allows only `http` and `https` for `src`, so it stripped `blob:`. The custom image component then had no `src` and rendered its missing-image fallback with the Markdown alt text (usually the filename). The grid's raw HTML kept its relative `attachment/...` URL through sanitization and resolved it to a local object URL afterward, which is why the grid path worked.

Fix: keep the relative `attachment/...` URL through sanitization and let the custom `<img>` renderer resolve it to the cached local object URL after sanitization. No URL scheme was added to the sanitizer allowlist.

## Image upload / browser verification

The Playwright test `npm run test:images` was run against both the dev app and the production static export copied into `android/assets/` (the web payload packaged inside the APK). Final recorded production-export run: `test/results/markdown-images-v17.1.txt`.

- Single image uploaded using **Insert image at cursor** → `![single-upload.png](attachment/single-upload.png)` → renders as an image with natural size **420×260**.
- Two images uploaded using the same picker → portable `img-grid` HTML → both render as **320×320** tiles in a two-column grid.
- Each image completes loading with nonzero `naturalWidth`; **0** `.md-image-missing` filename fallbacks and **0** page errors.
- Legacy `[single-upload.png](attachment/single-upload.png)` links also render as images.
- After screenshot: `test/evidence/markdown-images-v17.1.png`; reproduced before screenshot: `test/evidence/markdown-images-before-v17.1.png`.
- General Markdown smoke suite passes against the production export: `test/results/smoke-v17.1.txt`.

## Build / tests / package

- `npm run typecheck` — PASS.
- ESLint on `src/components/keep/editor/MarkdownEditor.tsx` and `test/markdown-image-e2e.mjs` — **0 errors**; the existing source file reports 10 non-blocking unused-disable warnings.
- `npm run test:smoke` — PASS.
- `npm run test:images` — PASS against the production static export; see the results and screenshot above.
- `npm run test:security` — PASS, all **61** storage/security/backup scenario groups.
- `npm run test:storage` — PASS.
- `npm run test:recovery` — PASS (independent Python recovery, including binary attachments).
- Static export copied to `android/assets/` — PASS.
- APK: `com.notes.app`, version **17.1**, version code **171**, min SDK 24 / target SDK 34; `zipalign -c 4` — PASS; `apksigner verify` — PASS. Certificate SHA-256 matches v17 so a v17 installation can update in place. Details: `test/results/apk-build-v17.1.txt`.
- APK SHA-256: `0fcda482cd3583f3110342458c77fb8254dfc9de100514c71dd8edee6a00ec14`.

## Scope / limitations

Playwright screenshots/tests exercise Chromium against the app code, including the production static export used inside the APK. The APK was built, metadata-inspected, zip-alignment checked, and signature-verified. No physical Android device or emulator was available here, so native installation, OEM WebView, and actual device storage/Keystore behavior were not runtime-validated in this turn.
