# Notenoid v17.1

Local-first Markdown notes with encrypted storage, automatic device unlock, seed-password recovery, and a separately encrypted vault. Android version **17.1**, version code **171**, package `com.notes.app`.

**v17.1 fixes Markdown attachment images that showed only their alt/name text.** The preview now keeps local `attachment/...` paths through sanitization and resolves them afterward. See `RELEASE-NOTES-V17.1.md`, `VALIDATION-V17.1.md`, and the before/after screenshots under `test/evidence/`.

## Before installing

**Back up your notes first.** Encryption migration changes the on-disk format. Save a readable backup somewhere private, and retain it until you have verified the encrypted installation and a recovery copy. Do not uninstall an existing app simply to bypass an APK signature error—private app data may be deleted.

**v17.1 uses the same signing key as v17** (`keystore/release.keystore`, password `notenoid17`, alias `notes`), so it can update a v17 installation. The original v17 APK used a new key because no private v16 keystore was distributed; Android refuses updates signed by a different key, so upgrading from versions before v17 requires uninstalling first — **back up/export your notes before doing that**, because uninstalling deletes app-private storage. The key is a source-distributed convenience key, **not a secret production identity**; keep it (included in the source ZIP) so future versions can install as updates over v17. See `docs/BUILD.md`.

## How storage works

1. Choose a storage folder / grant access, or choose in-app storage.
2. Enter and confirm a **seed password** once (minimum 3 characters). Keep it safely outside the app.
3. Existing app-managed notes, attachments, settings and vault credentials are migrated. Encrypted copies are verified before their readable originals are removed.
4. A device key remembers automatic unlocking. The seed password itself is not stored. Android uses Android Keystore; browsers store a non-extractable CryptoKey in IndexedDB.
5. Normal use and exports/imports do not ask for the seed again. If a device cannot save its automatic-unlock key, the app explicitly warns that the seed will be required on the next launch; it never falls back to plaintext storage.

Your selected folder now contains **`notenoid.encrypted/`**. Keep this entire directory together, including `key.json`, the encrypted index, and `objects/`. Logical note names, note contents, media, labels/folder definitions, app preferences and vault credentials are encrypted. See the security document for unavoidable public format metadata and automatic-unlock limitations.

**External folders and backups matter:** uninstalling or clearing an app/browser can erase app-private storage itself. A password cannot recover deleted files. An external chosen folder or an encrypted recovery copy is needed to survive that situation.

## Recover after a reset or reinstall

Choose the same external storage folder, or the `notenoid.encrypted` directory itself. The app detects its encrypted format and offers **Recover your encrypted notes**. Enter the original seed password.

Notes, attachments, preferences, vault password configuration, and security questions are restored. You do not set up the vault again. The vault stays locked until you use its existing password, just as it should. Automatic storage unlock is remembered again after recovery.

Forgot the seed password? On the recovery screen choose **Forgot seed password?** and answer one of your vault security questions (available once questions are configured). There is no cloud recovery service.

## Vault

The vault has its own random encryption key, separate from storage encryption. Its existing password and answer-based recovery are preserved during migration. Change the password using the current password, or reset it with at least one correct recorded answer. Change security questions using the current password and one existing answer.

**Either answer can recover the vault key — and, since v17, also the seed password. A guessable answer weakens everything.** Passwords and answers require a minimum of 3 characters. Existing credentials remain valid after migration.

## Export and import

- **Export readable ZIP:** no seed prompt. Exports ordinary notes and vault notes as readable Markdown plus attachments. Vault notes (including vaulted trash) are always included, and require the vault password. A wrong password or unreadable note stops export rather than silently omitting it.
- **Important:** the readable ZIP, including its vault note files, has **no content encryption**. Anyone with it can read those notes. The vault credential record in the ZIP does not protect plaintext exported notes.
- **Import backup:** automatically encrypts imported content into local storage. Vault imports require the source vault password. If the destination already has a different vault, its password is also required; existing destination credentials are not replaced. A fresh vault can restore the backup's original credential/recovery configuration. No seed prompt.
- **Save encrypted recovery copy:** explicitly produces a separate encrypted ZIP of the complete storage state, including trash, settings, attachments and vault credentials. Extract it and choose its folder for recovery. It is not a readable-note import.
- Readable imports preserve existing notes, number colliding directories, and reject malformed/unsafe archives. Expanded archive limit: 128 MiB; compressed input limit: 256 MiB; entry limit: 20,000. Split larger readable archives into smaller exports.

## Independent recovery, without the app

```sh
python -m pip install -r scripts/requirements-recovery.txt
python scripts/recover.py /path/to/notenoid.encrypted /path/to/new-recovered-folder
# To also decrypt vault contents, enter its separate password:
python scripts/recover.py /path/to/notenoid.encrypted /path/to/new-full-recovery --include-vault
```

The utility prompts securely; do not put passwords in command-line arguments. Output must be a new directory. Ordinary recovered files are plaintext; without the vault password its files are preserved separately encrypted. See `docs/RECOVERY.md`.

## Tested and limitations

See **`VALIDATION-V17.md`** and the included `test/results/` logs. Tests cover storage, migration interruption, tampering, recovery, imports/exports, vault password/question management, vault media upload, the exact-word selection workflow, every editor shortcut (recording rules, conflicts, reset, persistence), the instant/Done word-tap modes, the 3-character credential minimums, and answer-based seed recovery.

No claim of “unhackable,” “zero bugs,” or exhaustive device coverage is made. This is not an independent security audit. A physical Android device/emulator was not available for runtime testing; Android Keystore integration and filesystem behavior still need device validation. Encryption does not protect an automatically unlocked app against someone who can use it, malicious app updates, a compromised OS/browser profile, or decrypted exports.

Build instructions: `docs/BUILD.md`. Storage format/threat model: `docs/SECURITY.md`. Word selection remains documented in `docs/SELECTION.md`.
