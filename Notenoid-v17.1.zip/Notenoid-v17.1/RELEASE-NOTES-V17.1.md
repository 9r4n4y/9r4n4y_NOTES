# Notenoid v17.1

Android version code **171** · Package **com.notes.app**

## Markdown image preview fix

- Fixes local attachment images in Markdown preview that showed the filename/alt text instead of the picture.
- Keeps `attachment/...` destinations as safe relative URLs through `rehype-sanitize`; the custom image renderer resolves the attachment to its local object URL **after** sanitization.
- The same fix covers legacy `[filename](attachment/...)` notes that Notenoid promotes to image previews.
- No extra URL schemes are added to the sanitizer allowlist. The existing image grid upload path continues to render.

## Exact cause

The v17 preview's `toDisplay()` transformed an attachment Markdown URL into a `blob:` URL before the sanitizer ran. `rehype-sanitize` uses the default schema, which allows only `http` and `https` for `src`; it removed the `blob:` value. The image component then received no `src` and intentionally rendered its missing-image fallback using the Markdown alt text (usually the filename). That is why the attachment thumbnail worked and a raw-HTML image grid could work, while a normal Markdown image showed only its name: the grid kept its relative `attachment/...` URL until the image component resolved it after sanitization.

## Verification

- `npm run test:images`: single-image upload (420×260), two-file grid upload (two 320×320 tiles), no `.md-image-missing` placeholders, and backward compatibility for `[filename](attachment/...)`.
- Screenshot evidence: `test/evidence/markdown-images-before-v17.1.png` (reproduces the name-only bug) and `test/evidence/markdown-images-v17.1.png` (single image and grid both render).
- APK version: 17.1 / version code 171, signed with the same v17 key to allow v17 → v17.1 updates.
