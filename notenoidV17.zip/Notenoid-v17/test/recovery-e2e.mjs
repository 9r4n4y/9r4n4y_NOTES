// v17 forgot-seed e2e — full browser flow: 3-char seed + 3-char vault password
// + 3-char answers, then "Forgot seed password?" unlocks storage with only a
// security answer after the remembered device key is gone.
import { chromium } from "@playwright/test";
import assert from "node:assert/strict";

const browser = await chromium.launch({ headless: true });
const errors = [];
const page = await browser.newPage();
page.on("pageerror", (e) => errors.push(e.message));

const SEED = "abc"; // v17 minimum: 3 characters
const VAULT_PASS = "vlt"; // v17 minimum: 3 characters
const ANSWER = "sun"; // v17 minimum: 3 characters

await page.goto(process.env.TEST_URL || "http://localhost:3000");
await page.getByText("Use in-app local storage").click();
await page.getByLabel("Seed password", { exact: true }).fill(SEED);
await page.getByLabel("Confirm seed password", { exact: true }).fill(SEED);
await page.getByRole("checkbox").check();
await page.getByRole("button", { name: "Encrypt local storage", exact: true }).click();
await page.getByText("New note — tap to write").click();
const ta = page.locator("textarea.md-textarea");
await page.getByRole("button", { name: "Edit Markdown", exact: true }).click();
await ta.waitFor();
await ta.fill("# Forgot-seed test\n\nSECRET_BODY_SENTINEL_4812");
await page.getByRole("button", { name: "Back to notes", exact: true }).click();
await page.waitForTimeout(800);

// ---- set up the vault with 3-char credentials (sidebar → Vault) ----
const nav = page.getByRole("navigation", { name: "Main navigation" });
const navBox = await nav.boundingBox();
if (navBox && navBox.x < 0)
  await page.getByRole("button", { name: "Toggle sidebar" }).click();
await page.getByRole("button", { name: /^Vault/ }).first().click();
await page.getByPlaceholder("At least 3 characters", { exact: true }).fill(VAULT_PASS);
await page.getByPlaceholder("Repeat it", { exact: true }).fill(VAULT_PASS);
const answerInputs = page.getByPlaceholder("Your answer");
await answerInputs.nth(0).fill(ANSWER);
await answerInputs.nth(1).fill("moon");
await page.getByRole("button", { name: "Protect my notes", exact: true }).click();
await page.getByText("Vault ready").waitFor();
console.log("PASS 3-char vault password and 3-char answers accepted in the UI");

// no seed-recovery warning should remain after questions were recorded
await page.getByRole("button", { name: "Settings", exact: true }).last().click();
await page.getByRole("button", { name: "Vault" }).click();
await page.waitForTimeout(500);
assert.equal(await page.getByText("Seed recovery is not configured").count(), 0, "no missing-seed-recovery banner");
console.log("PASS Settings → Vault reports seed recovery as configured");
await page.keyboard.press("Escape");
await page.waitForTimeout(400);

// ---- lose the remembered device key, keep the encrypted folder ----
await page.evaluate(
  () =>
    new Promise((resolve, reject) => {
      const r = indexedDB.deleteDatabase("notenoid-device-keys");
      r.onsuccess = resolve;
      r.onerror = () => reject(r.error);
    }),
);
await page.reload();
await page.getByRole("heading", { name: "Recover your encrypted notes" }).waitFor();

// ---- forgot seed password → wrong answer rejected ----
await page.getByRole("button", { name: "Forgot seed password?" }).click();
await page.getByRole("heading", { name: "Forgot seed password" }).waitFor();
await page.getByPlaceholder("Answer").first().fill("wrong answer");
await page.getByRole("button", { name: "Unlock with answer" }).click();
await page.getByText("That answer did not match").waitFor();
console.log("PASS wrong security answer is rejected on the forgot-seed screen");

// ---- correct answer unlocks the storage without the seed ----
await page.getByPlaceholder("Answer").first().fill(ANSWER.toUpperCase());
await page.getByRole("button", { name: "Unlock with answer" }).click();
await page.getByText("New note — tap to write").waitFor({ timeout: 20000 });
await page.getByText("Forgot-seed test").first().waitFor();
await page.getByText("Forgot-seed test").first().click();
await page.getByText("SECRET_BODY_SENTINEL_4812").first().waitFor();
console.log("PASS correct security answer unlocks the encrypted folder and restores notes");

// ---- the original seed keeps working too ----
await page.getByRole("button", { name: "Back to notes", exact: true }).click();
await page.waitForTimeout(600);
await page.evaluate(
  () =>
    new Promise((resolve, reject) => {
      const r = indexedDB.deleteDatabase("notenoid-device-keys");
      r.onsuccess = resolve;
      r.onerror = () => reject(r.error);
    }),
);
await page.reload();
await page.getByRole("heading", { name: "Recover your encrypted notes" }).waitFor();
await page.getByLabel("Seed password", { exact: true }).fill(SEED);
await page.getByRole("button", { name: "Recover encrypted folder" }).click();
await page.getByText("New note — tap to write").waitFor({ timeout: 20000 });
console.log("PASS the original 3-char seed still unlocks the folder");

assert.deepEqual(errors, []);
console.log("\nFORGOT-SEED SUITE PASSED — 3-char credentials and answer-based seed recovery verified end to end.");
await browser.close();
