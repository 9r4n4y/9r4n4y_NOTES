import { chromium } from "@playwright/test";
import assert from "node:assert/strict";
import JSZip from "jszip";
import { readFile } from "node:fs/promises";
const browser = await chromium.launch({ headless: true });
const url = process.env.TEST_URL || "http://localhost:3001";
const seed = "amber lantern meadow orbit copper river",
  password = "VaultPasswordInBrowser!2026";
const errors = [];
async function start() {
  const context = await browser.newContext({
    viewport: { width: 393, height: 851 },
    hasTouch: true,
    isMobile: true,
    acceptDownloads: true,
  });
  const page = await context.newPage();
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto(url);
  await page.getByText("Use in-app local storage").click();
  await page.getByLabel("Seed password", { exact: true }).fill(seed);
  await page.getByLabel("Confirm seed password", { exact: true }).fill(seed);
  await page.getByRole("checkbox").check();
  await page
    .getByRole("button", { name: "Encrypt local storage", exact: true })
    .click();
  await page
    .getByRole("button", { name: "New note", exact: true })
    .first()
    .waitFor();
  return { page, context };
}
async function sidebar(page) {
  const nav = page.getByRole("navigation", { name: "Main navigation" });
  if (
    (await nav.getAttribute("class")).split(/\s+/).includes("-translate-x-full")
  )
    await page.getByRole("button", { name: "Toggle sidebar" }).click();
}
async function settings(page) {
  await page
    .getByRole("button", { name: "Settings", exact: true })
    .last()
    .click();
}
async function enterVault(page, pass) {
  await sidebar(page);
  await page
    .getByRole("button", { name: /^Vault/ })
    .first()
    .click();
  await page.getByPlaceholder("Vault password", { exact: true }).fill(pass);
  await page.getByRole("button", { name: "Unlock", exact: true }).click();
  await page
    .getByPlaceholder("Vault password", { exact: true })
    .waitFor({ state: "hidden" });
  await sidebar(page);
  await page
    .getByRole("button", { name: /^Vault/ })
    .first()
    .click();
}
try {
  const { page, context } = await start();
  await sidebar(page);
  await page
    .getByRole("button", { name: /^Vault/ })
    .first()
    .click();
  await page
    .getByPlaceholder("At least 3 characters", { exact: true })
    .fill(password);
  await page.getByPlaceholder("Repeat it", { exact: true }).fill(password);
  await page
    .getByPlaceholder("Your answer")
    .nth(0)
    .fill("private school answer phrase");
  await page
    .getByPlaceholder("Your answer")
    .nth(1)
    .fill("private family answer phrase");
  await page
    .getByRole("button", { name: "Protect my notes", exact: true })
    .click();
  await page
    .getByText("Set up vault protection", { exact: true })
    .waitFor({ state: "hidden" });
  await sidebar(page);
  await page
    .getByRole("button", { name: /^Vault/ })
    .first()
    .click();
  await page
    .getByRole("button", { name: "New note", exact: true })
    .first()
    .click();
  await page
    .getByRole("button", { name: "Edit Markdown", exact: true })
    .click();
  await page.getByPlaceholder("Title", { exact: true }).fill("Vault UI title");
  await page.locator("textarea.md-textarea").fill("VAULT_UI_SENTINEL_CONTENT");
  const png = Buffer.from(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aCfoAAAAASUVORK5CYII=",
    "base64",
  );
  await page
    .locator('input[type=file][accept="image/*,.gif"]')
    .last()
    .setInputFiles({
      name: "vault-upload.png",
      mimeType: "image/png",
      buffer: png,
    });
  await page.waitForTimeout(800);
  await page
    .getByRole("img", { name: "vault-upload.png", exact: true })
    .last()
    .click();
  const mediaDownload = page.waitForEvent("download");
  await page.getByRole("button", { name: "Download", exact: true }).click();
  const downloadedMedia = await mediaDownload;
  assert.deepEqual(await readFile(await downloadedMedia.path()), png);
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Close", exact: true })
    .last()
    .click();
  console.log(
    "PASS touch UI: individual vault attachment download decrypts exact original bytes",
  );
  await page
    .getByRole("button", { name: "Back to notes", exact: true })
    .click();
  await page.waitForTimeout(400);
  await sidebar(page);
  await page.getByRole("button", { name: "Lock vault", exact: true }).click();
  await page.reload();
  await page
    .getByRole("button", { name: "New note", exact: true })
    .first()
    .waitFor();
  assert.equal(
    await page.getByLabel("Seed password", { exact: true }).count(),
    0,
  );
  assert(
    !(await page.locator("body").innerText()).includes(
      "VAULT_UI_SENTINEL_CONTENT",
    ),
  );
  console.log(
    "PASS touch UI: create vault, upload attachment, lock, reload, auto-unlock storage without unlocking vault",
  );
  await settings(page);
  await page
    .getByRole("button", { name: "Export", exact: true })
    .first()
    .click();
  await page.getByLabel(/I understand the readable ZIP/).check();
  await page.getByLabel("Export vault password").fill("wrong");
  await page
    .getByRole("button", { name: "Export readable ZIP", exact: true })
    .click();
  await page
    .getByRole("alert")
    .filter({ hasText: "Correct vault password" })
    .waitFor();
  await page.getByLabel("Export vault password").fill(password);
  const downloaded = page.waitForEvent("download");
  await page
    .getByRole("button", { name: "Export readable ZIP", exact: true })
    .click();
  const download = await downloaded;
  const bytes = await readFile(await download.path());
  const zip = await JSZip.loadAsync(bytes);
  assert(
    (await zip.file("_vault/Vault UI title/node.md").async("string")).includes(
      "VAULT_UI_SENTINEL_CONTENT",
    ),
  );
  const media = Object.values(zip.files).find(
    (f) => f.name.startsWith("_vault/Vault UI title/attachment/") && !f.dir,
  );
  assert(media);
  assert.deepEqual(Buffer.from(await media.async("uint8array")), png);
  console.log(
    "PASS touch UI: wrong export password rejected; readable ZIP includes vault content and uploaded media, no seed prompt",
  );
  await page
    .getByRole("heading", { name: "Export notes", exact: true })
    .waitFor({ state: "hidden" });
  await page.getByRole("button", { name: "Close", exact: true }).last().click();
  const physical = await page.evaluate(async () => {
    const root = await navigator.storage.getDirectory();
    const paths = [],
      texts = [];
    async function walk(dir, prefix = "") {
      for await (const [name, h] of dir.entries()) {
        const p = prefix + name;
        paths.push(p);
        if (h.kind === "directory") await walk(h, p + "/");
        else texts.push(await (await h.getFile()).text());
      }
    }
    await walk(root);
    return { paths, texts, local: { ...localStorage } };
  });
  for (const secret of [
    "Vault UI title",
    "VAULT_UI_SENTINEL_CONTENT",
    "vault-upload.png",
    "private school answer phrase",
    password,
    seed,
  ])
    assert(!JSON.stringify(physical).includes(secret));
  console.log(
    "PASS browser physical storage scan: fixture secrets absent from raw OPFS files, names and localStorage",
  );
  await settings(page);
  await page
    .getByRole("button", { name: "Export", exact: true })
    .first()
    .click();
  const opaqueDownload = page.waitForEvent("download");
  await page
    .getByRole("button", { name: "Save encrypted recovery copy", exact: true })
    .click();
  const opaque = await opaqueDownload;
  const opaqueBytes = await readFile(await opaque.path());
  const opaqueZip = await JSZip.loadAsync(opaqueBytes);
  assert(opaqueZip.file("notenoid.encrypted/key.json"));
  assert(!opaqueBytes.includes(Buffer.from("VAULT_UI_SENTINEL_CONTENT")));
  await page
    .getByRole("heading", { name: "Export notes", exact: true })
    .waitFor({ state: "hidden" });
  await page.getByRole("button", { name: "Close", exact: true }).last().click();
  console.log(
    "PASS touch UI: encrypted recovery ZIP downloads without seed/vault prompt and retains opaque container",
  );
  // Simulate lost device-key storage while retaining the encrypted folder.
  await page.evaluate(
    () =>
      new Promise((resolve, reject) => {
        const r = indexedDB.deleteDatabase("notenoid-device-keys");
        r.onsuccess = resolve;
        r.onerror = () => reject(r.error);
      }),
  );
  await page.reload();
  await page
    .getByRole("heading", { name: "Recover your encrypted notes" })
    .waitFor();
  await page.getByLabel("Seed password", { exact: true }).fill("wrong");
  await page.getByRole("button", { name: "Recover encrypted folder" }).click();
  await page
    .getByRole("alert")
    .filter({ hasText: "Incorrect seed password" })
    .waitFor();
  await page.getByLabel("Seed password", { exact: true }).fill(seed);
  await page.getByRole("button", { name: "Recover encrypted folder" }).click();
  await page
    .getByRole("button", { name: "New note", exact: true })
    .first()
    .waitFor();
  assert.equal(
    await page.getByText("Set up vault protection", { exact: true }).count(),
    0,
  );
  await enterVault(page, password);
  await page.getByText("Vault UI title", { exact: true }).first().waitFor();
  console.log(
    "PASS touch UI: seed-only folder recovery restores existing vault password/questions without setup",
  );
  const otherTab = await context.newPage();
  await otherTab.goto(url);
  await otherTab
    .getByText("Could not load your notes", { exact: true })
    .waitFor();
  await otherTab.close();
  console.log(
    "PASS browser multi-tab guard: second writer is refused without changing data",
  );
  await context.close();
  const second = await start();
  const p = second.page;
  await settings(p);
  await p.getByRole("button", { name: "Import", exact: true }).first().click();
  await p.getByLabel("Backup ZIP").setInputFiles({
    name: "readable.zip",
    mimeType: "application/zip",
    buffer: bytes,
  });
  await p.getByLabel("Import vault password").fill("wrong");
  await p.getByRole("button", { name: "Import all found notes" }).click();
  await p
    .getByRole("alert")
    .filter({ hasText: "Incorrect source vault password" })
    .waitFor();
  await p.getByLabel("Import vault password").fill(password);
  await p.getByRole("button", { name: "Import all found notes" }).click();
  await p.getByRole("status").filter({ hasText: "1 notes restored" }).waitFor();
  await p.getByRole("button", { name: "Close", exact: true }).last().click();
  await p.waitForTimeout(250);
  await p.getByRole("button", { name: "Close", exact: true }).last().click();
  await p.waitForTimeout(250);
  await enterVault(p, password);
  await p.getByText("Vault UI title", { exact: true }).first().waitFor();
  console.log(
    "PASS touch UI: vault ZIP import rejects wrong password, restores note/media/credentials, unlocks with original password",
  );
  // Question recovery is performed through the actual dialog, not a test hook.
  await sidebar(p);
  await p.getByRole("button", { name: "Lock vault", exact: true }).click();
  await sidebar(p);
  await p
    .getByRole("button", { name: /^Vault/ })
    .first()
    .click();
  await p.getByRole("button", { name: "Forgot password", exact: true }).click();
  await p
    .getByPlaceholder("Answer", { exact: true })
    .nth(0)
    .fill("private school answer phrase");
  await p
    .getByPlaceholder("At least 3 characters", { exact: true })
    .fill("RecoveredBrowserPassword!2026");
  await p
    .getByPlaceholder("Repeat new password", { exact: true })
    .fill("RecoveredBrowserPassword!2026");
  await p.getByRole("button", { name: "Reset password", exact: true }).click();
  await p
    .getByPlaceholder("Repeat new password", { exact: true })
    .waitFor({ state: "hidden" });
  await p.reload();
  await enterVault(p, "RecoveredBrowserPassword!2026");
  await p.getByText("Vault UI title", { exact: true }).first().waitFor();
  console.log(
    "PASS touch UI: security-answer password reset retains imported vault data through reload",
  );
  await settings(p);
  await p.getByRole("button", { name: "Vault", exact: true }).click();
  await p.getByRole("button", { name: "Change password", exact: true }).click();
  await p
    .getByPlaceholder("Current password", { exact: true })
    .fill("RecoveredBrowserPassword!2026");
  await p
    .getByPlaceholder("New password (min 3 characters)", { exact: true })
    .fill("ChangedFromSettings!2026");
  await p
    .getByPlaceholder("Repeat new password", { exact: true })
    .fill("ChangedFromSettings!2026");
  await p.getByRole("button", { name: "Save password", exact: true }).click();
  await p
    .getByPlaceholder("New password (min 3 characters)", { exact: true })
    .waitFor({ state: "hidden" });
  await p
    .getByRole("button", { name: "Security questions", exact: true })
    .click();
  await p
    .getByPlaceholder("Current password", { exact: true })
    .fill("ChangedFromSettings!2026");
  await p
    .getByPlaceholder("Current answer (at least one required)")
    .nth(0)
    .fill("private school answer phrase");
  await p
    .getByPlaceholder("New answer", { exact: true })
    .nth(0)
    .fill("new UI recovery phrase one");
  await p
    .getByPlaceholder("New answer", { exact: true })
    .nth(1)
    .fill("new UI recovery phrase two");
  await p.getByRole("button", { name: "Save questions", exact: true }).click();
  await p
    .getByPlaceholder("New answer", { exact: true })
    .first()
    .waitFor({ state: "hidden" });
  await p.getByRole("button", { name: "Close", exact: true }).last().click();
  await p.reload();
  await enterVault(p, "ChangedFromSettings!2026");
  await p.getByText("Vault UI title", { exact: true }).first().waitFor();
  await sidebar(p);
  await p.getByRole("button", { name: "Lock vault", exact: true }).click();
  await sidebar(p);
  await p
    .getByRole("button", { name: /^Vault/ })
    .first()
    .click();
  await p.getByRole("button", { name: "Forgot password", exact: true }).click();
  await p
    .getByPlaceholder("Answer", { exact: true })
    .nth(0)
    .fill("private school answer phrase");
  await p
    .getByPlaceholder("At least 3 characters", { exact: true })
    .fill("FinalBrowserVaultPassword!2026");
  await p
    .getByPlaceholder("Repeat new password", { exact: true })
    .fill("FinalBrowserVaultPassword!2026");
  await p.getByRole("button", { name: "Reset password", exact: true }).click();
  await p
    .getByText(
      "At least one answer must be correct. You may leave the other answer blank or incorrect.",
      { exact: true },
    )
    .waitFor();
  await p
    .getByPlaceholder("Answer", { exact: true })
    .nth(0)
    .fill("new UI recovery phrase one");
  await p.getByRole("button", { name: "Reset password", exact: true }).click();
  await p
    .getByPlaceholder("Repeat new password", { exact: true })
    .waitFor({ state: "hidden" });
  console.log(
    "PASS touch UI: Settings password change, question replacement, old-answer rejection, new-answer recovery",
  );
  assert.deepEqual(errors, [], "no runtime errors");
  await second.context.close();
} finally {
  await browser.close();
}
