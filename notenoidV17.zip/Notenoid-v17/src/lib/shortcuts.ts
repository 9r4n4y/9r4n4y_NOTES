"use client";

// ---------------------------------------------------------------------------
// Configurable keyboard shortcuts for every Markdown editor action (v17).
//
// • A shortcut is a SET of 2–4 keys held together (e.g. Shift+X, Ctrl+Shift+K).
// • Defaults cover every toolbar action; the Preview/Edit toggle is Shift+X.
// • Users can rebind anything in Settings → Shortcuts (record any combination,
//   minimum 2 and maximum 4 keys).
// • Matching is exact-set: the currently held keys must equal the combo, so a
//   2-key combo never fires when extra modifiers are down.
// • Keys are normalised physically (event.code) so Shift+1 stays "1" instead
//   of becoming "!" on US layouts, and letters ignore caps/shift case.
// ---------------------------------------------------------------------------

/** Minimum number of keys in a shortcut combination. */
export const SHORTCUT_MIN_KEYS = 2;
/** Maximum number of keys in a shortcut combination. */
export const SHORTCUT_MAX_KEYS = 4;

export interface ShortcutActionInfo {
  id: string;
  label: string;
  /** Short helper shown under the action name in Settings. */
  hint: string;
  /** Default combination (canonical order: Ctrl, Alt, Shift, Meta, then keys). */
  defaults: string[];
}

export const SHORTCUT_ACTIONS: ShortcutActionInfo[] = [
  { id: "preview", label: "Preview / Edit toggle", hint: "Switch between the rendered preview and the Markdown editor", defaults: ["Shift", "X"] },
  { id: "bold", label: "Bold", hint: "**bold**", defaults: ["Ctrl", "B"] },
  { id: "italic", label: "Italic", hint: "*italic*", defaults: ["Ctrl", "I"] },
  { id: "underline", label: "Underline", hint: "<u>underline</u>", defaults: ["Ctrl", "Shift", "U"] },
  { id: "strike", label: "Strikethrough", hint: "~~strikethrough~~", defaults: ["Ctrl", "Shift", "S"] },
  { id: "code", label: "Inline code", hint: "`code`", defaults: ["Ctrl", "`"] },
  { id: "h1", label: "Heading 1", hint: "# heading", defaults: ["Ctrl", "Shift", "1"] },
  { id: "h2", label: "Heading 2", hint: "## heading", defaults: ["Ctrl", "Shift", "2"] },
  { id: "h3", label: "Heading 3", hint: "### heading", defaults: ["Ctrl", "Shift", "3"] },
  { id: "paragraph", label: "Body text", hint: "Remove heading/list/quote markers from the line", defaults: ["Ctrl", "Shift", "0"] },
  { id: "ul", label: "Bullet list", hint: "- item", defaults: ["Ctrl", "Shift", "8"] },
  { id: "ol", label: "Numbered list", hint: "1. item", defaults: ["Ctrl", "Shift", "7"] },
  { id: "todo", label: "Checklist", hint: "- [ ] task", defaults: ["Ctrl", "Shift", "L"] },
  { id: "quote", label: "Quote", hint: "> quoted text", defaults: ["Ctrl", "Shift", "9"] },
  { id: "codeblock", label: "Code block", hint: "``` fenced code ```", defaults: ["Ctrl", "Shift", "`"] },
  { id: "link", label: "Add link", hint: "Open the link popover", defaults: ["Ctrl", "K"] },
  { id: "remove-link", label: "Remove links", hint: "Strip every link, keep the text", defaults: ["Ctrl", "Shift", "K"] },
  { id: "image", label: "Add image", hint: "Pick an image to attach to the note", defaults: ["Ctrl", "Alt", "I"] },
  { id: "insert-image", label: "Insert image at cursor", hint: "Pick from attachments, several become a grid", defaults: ["Ctrl", "Alt", "G"] },
  { id: "hr", label: "Divider", hint: "Horizontal rule", defaults: ["Ctrl", "Shift", "-"] },
  { id: "table", label: "Insert table", hint: "3-column starter table", defaults: ["Ctrl", "Shift", "M"] },
  { id: "clear", label: "Clear formatting", hint: "Strip Markdown syntax", defaults: ["Ctrl", "Alt", "N"] },
  { id: "undo", label: "Undo", hint: "Step back in the editor history", defaults: ["Ctrl", "Z"] },
  { id: "redo", label: "Redo", hint: "Step forward in the editor history", defaults: ["Ctrl", "Y"] },
];

export const SHORTCUT_ACTION_IDS = new Set(SHORTCUT_ACTIONS.map((a) => a.id));

export function defaultShortcuts(): Record<string, string[]> {
  const out: Record<string, string[]> = {};
  for (const a of SHORTCUT_ACTIONS) out[a.id] = [...a.defaults];
  return out;
}

/** Modifiers in canonical display/storage order. */
const MODIFIER_ORDER = ["Ctrl", "Alt", "Shift", "Meta"] as const;
export const MODIFIER_KEYS = new Set<string>(MODIFIER_ORDER);

/** Sort a combination into canonical order (modifiers first, then other keys). */
export function canonicalCombo(keys: Iterable<string>): string[] {
  const all = [...new Set(keys)];
  const mods = MODIFIER_ORDER.filter((m) => all.includes(m));
  const rest = all.filter((k) => !MODIFIER_KEYS.has(k));
  return [...mods, ...rest];
}

/** Normalise a physical key event into one stable key name. */
export function normalizeKeyEvent(event: { key: string; code?: string }): string {
  const key = event.key;
  if (key === "Shift") return "Shift";
  if (key === "Control") return "Ctrl";
  if (key === "Alt") return "Alt";
  if (key === "Meta" || key === "OS") return "Meta";
  if (key === " ") return "Space";
  const code = event.code ?? "";
  if (/^Key[A-Z]$/.test(code)) return code.slice(3);
  if (/^Digit\d$/.test(code)) return code.slice(5);
  if (/^Numpad\d$/.test(code)) return code.slice(6);
  const codeSymbols: Record<string, string> = {
    Backquote: "`", Minus: "-", Equal: "=", Comma: ",", Period: ".",
    Slash: "/", Semicolon: ";", Quote: "'", BracketLeft: "[",
    BracketRight: "]", Backslash: "\\",
  };
  if (codeSymbols[code]) return codeSymbols[code];
  if (key.length === 1) return key.toUpperCase();
  return key; // Enter, Escape, Backspace, Tab, ArrowUp, F1…F12, etc.
}

/** Validate + canonicalise a recorded combination. Returns null when invalid. */
export function validCombo(keys: Iterable<string>): string[] | null {
  const combo = canonicalCombo(keys);
  if (combo.length < SHORTCUT_MIN_KEYS || combo.length > SHORTCUT_MAX_KEYS) return null;
  if (combo.some((k) => !k || /\s/.test(k))) return null;
  return combo;
}

/** Sanitise persisted shortcut settings: known ids, valid 2–4 key combos. */
export function sanitizeShortcuts(saved: unknown): Record<string, string[]> {
  const out = defaultShortcuts();
  if (!saved || typeof saved !== "object") return out;
  for (const [id, keys] of Object.entries(saved as Record<string, unknown>)) {
    if (!SHORTCUT_ACTION_IDS.has(id)) continue;
    if (!Array.isArray(keys)) continue;
    const combo = validCombo(keys.map((k) => String(k)));
    if (combo) out[id] = combo;
  }
  return out;
}

/** Human-readable form, e.g. ["Ctrl","Shift","K"] → "Ctrl + Shift + K". */
export function formatCombo(keys: string[] | null | undefined): string {
  if (!keys || keys.length === 0) return "Not set";
  return keys.join(" + ");
}

/** Find the action id whose combination exactly equals the held key set. */
export function matchShortcut(
  held: Set<string>,
  shortcuts: Record<string, string[]>
): string | null {
  if (held.size < SHORTCUT_MIN_KEYS) return null;
  for (const [id, combo] of Object.entries(shortcuts)) {
    if (!combo || combo.length !== held.size) continue;
    let all = true;
    for (const k of combo) if (!held.has(k)) { all = false; break; }
    if (all) return id;
  }
  return null;
}

/** Which other action already uses this combination (conflict detection)? */
export function findConflict(
  actionId: string,
  combo: string[],
  shortcuts: Record<string, string[]>
): string | null {
  for (const [id, other] of Object.entries(shortcuts)) {
    if (id === actionId) continue;
    if (other && other.length === combo.length && canonicalCombo(other).every((k, i) => canonicalCombo(combo)[i] === k)) return id;
  }
  return null;
}

/**
 * Tracks the set of physically held keys from keydown/keyup events.
 * A combination is complete once every pressed key is released again —
 * the largest held set during the press is the recorded combination.
 */
export class KeyTracker {
  private held = new Set<string>();

  keydown(event: KeyboardEvent): Set<string> {
    this.held.add(normalizeKeyEvent(event));
    return new Set(this.held);
  }

  keyup(event: KeyboardEvent): void {
    this.held.delete(normalizeKeyEvent(event));
  }

  get size(): number {
    return this.held.size;
  }

  clear(): void {
    this.held.clear();
  }
}
