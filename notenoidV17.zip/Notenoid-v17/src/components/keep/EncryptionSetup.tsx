"use client";
import { useBackLayer } from "@/lib/back-nav";
import { toast } from "sonner";
import { useState } from "react";
import { ShieldCheck, Loader2, ShieldQuestion, ArrowLeft } from "lucide-react";
import { getRepo, useKeepStore } from "./store";
import {
  EncryptedFS,
  legacyPreferences,
  clearLegacyPreferences,
} from "@/core/security/encrypted-fs";
import { questionText } from "@/lib/vault";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
export function EncryptionSetup() {
  const fs = getRepo().fs as EncryptedFS;
  const [password, setPassword] = useState(""),
    [repeat, setRepeat] = useState(""),
    [confirmed, setConfirmed] = useState(false),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  // v17: "Forgot seed password?" — recovery with a security answer
  const [forgot, setForgot] = useState(false),
    [forgotQuestions, setForgotQuestions] = useState<string[]>([]),
    [answers, setAnswers] = useState<string[]>([]),
    [forgotBusy, setForgotBusy] = useState(false),
    [forgotError, setForgotError] = useState("");
  useBackLayer(busy, () => {});
  const recover = fs.state === "recover";
  async function openForgot() {
    setForgotError("");
    setAnswers(["", ""]);
    try {
      const info = await fs.readSeedRecovery();
      setForgotQuestions(info?.questions ?? []);
    } catch {
      setForgotQuestions([]);
    }
    setForgot(true);
  }
  async function recoverByAnswers() {
    if (forgotBusy) return;
    setForgotBusy(true);
    setForgotError("");
    try {
      const ok = await fs.recoverByAnswers(
        forgotQuestions.map((id, i) => ({ id, answer: answers[i] ?? "" })),
      );
      if (!ok) {
        setForgotError(
          "That answer did not match. Try your other security answer.",
        );
        return;
      }
      if (fs.warning) toast.warning(fs.warning, { duration: Infinity });
      clearLegacyPreferences();
      setPassword("");
      setRepeat("");
      setForgot(false);
      toast.success("Storage unlocked with your security answer");
      await useKeepStore.getState().rescan();
    } catch (e) {
      setForgotError(
        e instanceof Error ? e.message : "Recovery failed. Nothing was changed.",
      );
      await fs.prepare().catch(() => {});
    } finally {
      setForgotBusy(false);
    }
  }
  async function submit() {
    if (busy) return;
    setBusy(true);
    setError("");
    try {
      if (recover) await fs.recover(password);
      else {
        if (password !== repeat) throw Error("Seed passwords do not match");
        await fs.initialize(password, legacyPreferences());
      }
      if (fs.warning) toast.warning(fs.warning, { duration: Infinity });
      clearLegacyPreferences();
      setPassword("");
      setRepeat("");
      await useKeepStore.getState().rescan();
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : "Storage setup failed. Keep your original folder.",
      );
      await fs.prepare().catch(() => {});
    } finally {
      setBusy(false);
    }
  }
  return (
    <main className="flex min-h-screen items-center justify-center bg-background px-6 py-10">
      <section className="w-full max-w-md space-y-5">
        <ShieldCheck className="h-10 w-10 text-primary" />
        {recover && forgot ? (
          <>
            <div>
              <h1 className="text-2xl font-semibold">Forgot seed password</h1>
              <p className="mt-2 text-sm text-muted-foreground">
                Answer one of your vault security questions to unlock this
                encrypted folder. The other answer may be left blank.
              </p>
            </div>
            {forgotQuestions.length === 0 ? (
              <p className="rounded-lg border p-3 text-sm">
                Seed recovery is not configured for this folder. Security
                questions are recorded when you set up the vault or re-save its
                questions in Settings.
              </p>
            ) : (
              <div className="space-y-3">
                {forgotQuestions.map((id, i) => (
                  <label key={id} className="block text-sm">
                    {questionText(id)}
                    <Input
                      aria-label={questionText(id)}
                      value={answers[i] ?? ""}
                      onChange={(e) =>
                        setAnswers((current) => {
                          const next = current.length >= 2 ? [...current] : ["", ""];
                          next[i] = e.target.value;
                          return next;
                        })
                      }
                      disabled={forgotBusy}
                      autoComplete="off"
                      placeholder="Answer"
                    />
                  </label>
                ))}
                {forgotError ? (
                  <p role="alert" className="text-sm text-destructive">
                    {forgotError}
                  </p>
                ) : null}
                <Button
                  className="w-full"
                  disabled={forgotBusy || !answers.some((a) => a.trim())}
                  onClick={() => void recoverByAnswers()}
                >
                  {forgotBusy ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Unlocking…
                    </>
                  ) : (
                    "Unlock with answer"
                  )}
                </Button>
              </div>
            )}
            <Button
              variant="ghost"
              className="gap-1.5"
              disabled={forgotBusy}
              onClick={() => { setForgot(false); setForgotError(""); }}
            >
              <ArrowLeft className="h-4 w-4" /> Back to seed password
            </Button>
          </>
        ) : (
          <>
            <div>
              <h1 className="text-2xl font-semibold">
                {recover
                  ? "Recover your encrypted notes"
                  : "Protect your local notes"}
              </h1>
              <p className="mt-2 text-sm text-muted-foreground">
                {recover
                  ? "An encrypted Notenoid folder was found. Restore it exactly as it was using its original seed password — or a security answer if you forgot it. Your vault keeps its separate password and security questions."
                  : "Choose a seed password (minimum 3 characters). All app-managed notes, attachments and preferences will be encrypted locally. Existing notes will be verified before their readable originals are removed."}
              </p>
            </div>
            <p className="rounded-lg border p-3 text-sm">
              <strong>Remember this password.</strong> If you forget it, you can
              unlock the folder again with a vault security answer (when
              questions are configured). Keep a backup of your notes too.
            </p>
            <label className="block text-sm">
              Seed password
              <Input
                aria-label="Seed password"
                type="password"
                autoComplete={recover ? "current-password" : "new-password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={busy}
              />
            </label>
            {!recover && (
              <>
                <label className="block text-sm">
                  Confirm seed password
                  <Input
                    aria-label="Confirm seed password"
                    type="password"
                    autoComplete="new-password"
                    value={repeat}
                    onChange={(e) => setRepeat(e.target.value)}
                    disabled={busy}
                  />
                </label>
                <label className="flex items-start gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={confirmed}
                    onChange={(e) => setConfirmed(e.target.checked)}
                    disabled={busy}
                  />
                  <span>
                    I saved my seed password and backed up any existing notes.
                  </span>
                </label>
              </>
            )}
            <p className="text-xs text-muted-foreground">
              Automatic unlock will be remembered on this device. Anyone able to
              open this app can read ordinary notes. Android uses Keystore; browser
              automatic unlock relies on browser-profile security.
              Uninstalling/clearing app-private storage can delete the files
              themselves—keep an external folder or an encrypted backup.
            </p>
            {error && (
              <p role="alert" className="text-sm text-destructive">
                {error}
              </p>
            )}
            <Button
              className="w-full"
              disabled={
                busy ||
                !password ||
                (!recover &&
                  (!confirmed || password.length < 3 || password !== repeat))
              }
              onClick={() => void submit()}
            >
              {busy ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Encrypting / verifying…
                </>
              ) : recover ? (
                "Recover encrypted folder"
              ) : (
                "Encrypt local storage"
              )}
            </Button>
            {recover ? (
              <Button
                variant="outline"
                className="w-full gap-1.5"
                disabled={busy}
                onClick={() => void openForgot()}
              >
                <ShieldQuestion className="h-4 w-4" /> Forgot seed password?
              </Button>
            ) : null}
            {busy && (
              <p className="text-xs text-muted-foreground">
                Keep the app open until verification finishes. Large attachment
                collections can take time.
              </p>
            )}
          </>
        )}
      </section>
    </main>
  );
}
