"use client";

// ---------------------------------------------------------------------------
// Settings — General / Appearance / Search & Notes / Vault / About.
// additions:
//   • Appearance: UI text scale + note text scale (separate), app & note
//     fonts (14 choices incl. monospace), 24-theme gallery, math toggle,
//     image-grid width (single images are per-image now).
//   • Vault tab is always visible — set up / change the password, manage the
//     two security questions, lock now. The vault protects private notes.
//   • General: Import (restore a backup ZIP) next to Export.
// ---------------------------------------------------------------------------

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { useKeepStore } from "./store";
import {
  DEFAULT_SETTINGS,
  resetSettings,
  updateSettings,
  useSettings,
  type Density,
} from "./settings-store";
import { ExportDialog } from "./ExportDialog";
import { ImportDialog } from "./ImportDialog";
import { VaultSetupDialog } from "./VaultDialogs";
import { getRepo } from "./store";
import { useBackLayer } from "@/lib/back-nav";
import { FONT_CHOICES } from "@/lib/fonts";
import { THEMES, getTheme } from "@/lib/themes";
import { cn } from "@/lib/utils";
import {
  Brush,
  Check,
  Download,
  FolderCog,
  HardDrive,
  Image as ImageIcon,
  Info,
  Keyboard,
  KeyRound,
  Loader2,
  Lock,
  RefreshCcw,
  RotateCcw,
  Search,
  ShieldQuestion,
  Sparkles,
  SquarePen,
  Upload,
  X,
  LockOpen,
  SquareSigma,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import {
  vaultPasswordExists,
  changeVaultPassword,
  setSecurityQuestions,
  getSecurityQuestionIds,
  questionText,
  SECURITY_QUESTIONS,
  seedRecovery,
} from "@/lib/vault";
import {
  SHORTCUT_ACTIONS,
  SHORTCUT_MIN_KEYS,
  SHORTCUT_MAX_KEYS,
  defaultShortcuts,
  formatCombo,
  validCombo,
  findConflict,
  KeyTracker,
} from "@/lib/shortcuts";

type Tab = "general" | "appearance" | "search" | "shortcuts" | "vault" | "about";

const TABS: { key: Tab; label: string }[] = [
  { key: "general", label: "General" },
  { key: "appearance", label: "Appearance" },
  { key: "search", label: "Search & Notes" },
  { key: "shortcuts", label: "Shortcuts" },
  { key: "vault", label: "Vault" },
  { key: "about", label: "About app" },
];

async function fileToCompressedDataUrl(file: File, maxSize = 1600): Promise<string> {
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = reject;
      el.src = dataUrl;
    });
    const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
    const w = Math.max(1, Math.round(img.width * scale));
    const h = Math.max(1, Math.round(img.height * scale));
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) return dataUrl;
    ctx.drawImage(img, 0, 0, w, h);
    return canvas.toDataURL("image/jpeg", 0.82);
  } catch {
    return dataUrl;
  }
}

export function SettingsDialog() {
  const open = useKeepStore((s) => s.settingsOpen);
  const setSettingsOpen = useKeepStore((s) => s.setSettingsOpen);
  // (bug #3): BACK closes settings
  useBackLayer(open, () => setSettingsOpen(false));
  // Keyed remount: fresh state (name draft, active tab, vault state) on every
  // open — no setState-in-effect needed.
  if (!open) return null;
  return <SettingsBody />;
}

function SettingsBody() {
  const setOpen = useKeepStore((s) => s.setSettingsOpen);
  const vaultOpen = useKeepStore((s) => s.vaultOpen);
  const vaultSetupOpen = useKeepStore((s) => s.vaultSetupOpen);
  const closeVault = useKeepStore((s) => s.closeVault);
  const requestVaultAccess = useKeepStore((s) => s.requestVaultAccess);
  const settings = useSettings();

  const [tab, setTab] = useState<Tab>("general");
  const [nameDraft, setNameDraft] = useState(settings.appName);
  const [exportOpen, setExportOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  // vault management panels
  const [showChangePass, setShowChangePass] = useState(false);
  const [showQuestions, setShowQuestions] = useState(false);
  const [curPass, setCurPass] = useState("");
  const [newPass, setNewPass] = useState("");
  const [newPass2, setNewPass2] = useState("");
  const [currentQuestionIds, setCurrentQuestionIds] = useState<string[]>(() => getSecurityQuestionIds());
  const [currentQuestionAnswers, setCurrentQuestionAnswers] = useState(["", ""]);
  const [qIds, setQIds] = useState<[string, string]>([SECURITY_QUESTIONS[0].id, SECURITY_QUESTIONS[1].id]);
  const [qAnswers, setQAnswers] = useState(["", ""]);
  const [vaultBusy, setVaultBusy] = useState(false);
  const [hasCode, setHasCode] = useState(() => vaultPasswordExists());
  // — refresh vault existence when the first-run setup dialog closes, so
  // the Vault tab switches to the management view without reopening Settings.
  useEffect(() => {
    if (vaultSetupOpen) return;
    const refreshVaultManagement = window.setTimeout(() => {
      setHasCode(vaultPasswordExists());
      setCurrentQuestionIds(getSecurityQuestionIds());
    }, 0);
    return () => window.clearTimeout(refreshVaultManagement);
  }, [vaultSetupOpen, importOpen]);
  const fileRef = useRef<HTMLInputElement>(null);

  async function pickWallpaper(file: File) {
    if (!file.type.startsWith("image/")) {
      toast.error("Choose an image file");
      return;
    }
    try {
      const dataUrl = await fileToCompressedDataUrl(file);
      updateSettings({ wallpaper: dataUrl });
      toast.success("Wallpaper applied");
    } catch {
      toast.error("Could not load that image");
    }
  }

  async function saveNewPassword() {
    setVaultBusy(true);
    try {
      if (newPass.length < 3) {
        toast.error("The new password must be at least 3 characters");
        return;
      }
      if (newPass !== newPass2) {
        toast.error("The two new passwords do not match");
        return;
      }
      const ok = await changeVaultPassword(curPass, newPass);
      if (!ok) {
        toast.error("Current password is incorrect");
        return;
      }
      setCurPass("");
      setNewPass("");
      setNewPass2("");
      setShowChangePass(false);
      toast.success("Vault password changed");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not update vault protection");
    } finally {
      setVaultBusy(false);
    }
  }

  async function saveQuestions() {
    if (qIds[0] === qIds[1]) {
      toast.error("Pick two different security questions");
      return;
    }
    if (qAnswers.some((a) => a.trim().length < 3)) {
      toast.error("Please answer both new security questions (at least 3 characters each)");
      return;
    }
    if (!curPass) {
      toast.error("Enter your current vault password");
      return;
    }
    if (currentQuestionIds.length === 2 && !currentQuestionAnswers.some((a) => a.trim())) {
      toast.error("Answer at least one current security question");
      return;
    }
    setVaultBusy(true);
    let ok = false;
    try { ok = await setSecurityQuestions(
      curPass,
      currentQuestionIds.map((id, i) => ({ id, answer: currentQuestionAnswers[i] ?? "" })),
      [
        { id: qIds[0], answer: qAnswers[0] },
        { id: qIds[1], answer: qAnswers[1] },
      ]
    );
    } catch (error) { toast.error(error instanceof Error ? error.message : "Vault update failed"); }
    setVaultBusy(false);
    if (!ok) {
      toast.error("Password or at least one current security answer is incorrect");
      return;
    }
    setCurPass("");
    setCurrentQuestionAnswers(["", ""]);
    setQAnswers(["", ""]);
    setCurrentQuestionIds(getSecurityQuestionIds());
    setShowQuestions(false);
    setHasCode(vaultPasswordExists());
    toast.success("Security questions updated");
  }

  const vaultLockedBadge = (
    <span className="ml-auto hidden text-[10px] text-muted-foreground sm:inline">
      {vaultOpen ? "unlocked" : hasCode ? "locked" : "not set up"}
    </span>
  );

  return (
    <>
      <Dialog open onOpenChange={setOpen}>
        <DialogContent className="flex h-[85vh] max-w-2xl flex-col overflow-hidden p-0 sm:h-[600px]">
          <DialogHeader className="px-5 pt-5">
            <DialogTitle>Settings</DialogTitle>
            <DialogDescription>Make the app truly yours.</DialogDescription>
          </DialogHeader>

          <div className="flex min-h-0 flex-1 flex-col sm:flex-row">
            {/* tab rail */}
            <div className="flex shrink-0 gap-1 overflow-x-auto border-b px-3 py-2 sm:w-44 sm:flex-col sm:border-b-0 sm:border-r sm:py-3">
              {TABS.map((t) => (
                <button
                  key={t.key}
                  type="button"
                  onClick={() => setTab(t.key)}
                  className={`flex items-center gap-2 whitespace-nowrap rounded-lg px-3 py-2 text-sm transition-colors ${
                    tab === t.key
                      ? "bg-accent font-medium text-foreground"
                      : "text-muted-foreground hover:bg-accent/60 hover:text-foreground"
                  }`}
                >
                  {t.key === "general" ? <Sparkles className="h-4 w-4" /> : null}
                  {t.key === "appearance" ? <Brush className="h-4 w-4" /> : null}
                  {t.key === "search" ? <Search className="h-4 w-4" /> : null}
                  {t.key === "shortcuts" ? <Keyboard className="h-4 w-4" /> : null}
                  {t.key === "vault" ? <KeyRound className="h-4 w-4" /> : null}
                  {t.key === "about" ? <Info className="h-4 w-4" /> : null}
                  {t.label}
                  {t.key === "vault" ? vaultLockedBadge : null}
                </button>
              ))}
            </div>

            {/* tab body */}
            <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">
              {tab === "general" ? (
                <div className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="app-name">App name</Label>
                    <div className="flex gap-2">
                      <Input
                        id="app-name"
                        value={nameDraft}
                        maxLength={24}
                        onChange={(e) => setNameDraft(e.target.value)}
                        placeholder="Notenoid"
                      />
                      <Button
                        variant="secondary"
                        onClick={() => {
                          const name = nameDraft.trim() || "Notenoid";
                          updateSettings({ appName: name });
                          setNameDraft(name);
                          toast.success(`App renamed to “${name}”`);
                        }}
                      >
                        Save
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Renames the app everywhere — header, tab title and exports.
                    </p>
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Confirm before deleting</p>
                      <p className="text-xs text-muted-foreground">
                        Ask before moving notes to trash (undo toast is always available)
                      </p>
                    </div>
                    <Switch
                      checked={settings.confirmBeforeDelete}
                      onCheckedChange={(v) => updateSettings({ confirmBeforeDelete: v })}
                    />
                  </div>

                  <Separator />

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium">Backup &amp; restore</p>
                        <p className="text-xs text-muted-foreground">
                          Export notes as a ZIP or import a backup back into the app
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Button variant="outline" size="sm" onClick={() => setExportOpen(true)}>
                        <Download className="mr-2 h-4 w-4" /> Export
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => setImportOpen(true)}>
                        <Upload className="mr-2 h-4 w-4" /> Import
                      </Button>
                    </div>
                    <p className="text-xs leading-relaxed text-muted-foreground">
                      Readable ZIPs contain unencrypted notes, attachments, folders and labels, including vault notes after password verification. Encrypted recovery copies also preserve settings, trash and vault credentials.
                    </p>
                  </div>

                  <Separator />

                  {/* ---- local storage ---- */}
                  <StorageSection />

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-destructive">Reset appearance settings</p>
                      <p className="text-xs text-muted-foreground">
                        Restore name, wallpaper, theme and all toggles to defaults
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        resetSettings();
                        setNameDraft(DEFAULT_SETTINGS.appName);
                        toast.success("Settings reset");
                      }}
                    >
                      <RotateCcw className="mr-2 h-4 w-4" /> Reset
                    </Button>
                  </div>
                </div>
              ) : null}

              {tab === "appearance" ? (
                <div className="space-y-6">
                  <ThemeGallery />

                  <Separator />

                  <div className="space-y-2">
                    <p className="text-sm font-medium">Custom wallpaper</p>
                    {settings.wallpaper ? (
                      <div className="relative overflow-hidden rounded-lg border">
                        <img src={settings.wallpaper} alt="Wallpaper preview" className="h-28 w-full object-cover" />
                        <button
                          type="button"
                          aria-label="Remove wallpaper"
                          className="absolute right-2 top-2 flex h-7 w-7 items-center justify-center rounded-full bg-black/60 text-white hover:bg-black/80"
                          onClick={() => {
                            updateSettings({ wallpaper: null });
                            toast.success("Wallpaper removed");
                          }}
                        >
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => fileRef.current?.click()}
                        className="flex h-24 w-full flex-col items-center justify-center gap-1 rounded-lg border border-dashed text-sm text-muted-foreground transition-colors hover:bg-accent/50"
                      >
                        <ImageIcon className="h-5 w-5" />
                        Upload an image
                      </button>
                    )}
                    <input
                      ref={fileRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        if (f) void pickWallpaper(f);
                        e.target.value = "";
                      }}
                    />
                    {settings.wallpaper ? (
                      <Button variant="outline" size="sm" onClick={() => fileRef.current?.click()}>
                        Replace image
                      </Button>
                    ) : null}
                  </div>

                  {settings.wallpaper ? (
                    <>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Label>Background blur</Label>
                          <span className="text-xs text-muted-foreground">{settings.wallpaperBlur}px</span>
                        </div>
                        <Slider
                          min={0}
                          max={40}
                          step={1}
                          value={[settings.wallpaperBlur]}
                          onValueChange={([v]) => updateSettings({ wallpaperBlur: v })}
                        />
                      </div>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Label>Background dim</Label>
                          <span className="text-xs text-muted-foreground">{settings.wallpaperDim}%</span>
                        </div>
                        <Slider
                          min={0}
                          max={80}
                          step={5}
                          value={[settings.wallpaperDim]}
                          onValueChange={([v]) => updateSettings({ wallpaperDim: v })}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm font-medium">Fixed wallpaper</p>
                          <p className="text-xs text-muted-foreground">Keep it still while scrolling</p>
                        </div>
                        <Switch
                          checked={settings.wallpaperFixed}
                          onCheckedChange={(v) => updateSettings({ wallpaperFixed: v })}
                        />
                      </div>
                    </>
                  ) : null}

                  <Separator />

                  <div className="space-y-2">
                    <Label>Note spacing</Label>
                    <Select value={settings.density} onValueChange={(v) => updateSettings({ density: v as Density })}>
                      <SelectTrigger className="w-full">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="compact">Compact — snug grid</SelectItem>
                        <SelectItem value="cozy">Cozy — balanced (default)</SelectItem>
                        <SelectItem value="spacious">Spacious — airy layout</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* ---- text sizes (separate sliders) ---- */}
                  <div className="space-y-4 rounded-lg border bg-accent/20 p-3">
                    <div>
                      <p className="text-sm font-medium">Text sizes</p>
                      <p className="text-xs text-muted-foreground">
                        App scale changes the whole interface. Note scale changes only the
                        writing inside notes — editor and preview together.
                      </p>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label>App text size</Label>
                        <span className="text-xs tabular-nums text-muted-foreground">{settings.uiScale}%</span>
                      </div>
                      <Slider
                        min={70}
                        max={150}
                        step={5}
                        value={[settings.uiScale]}
                        onValueChange={([v]) => updateSettings({ uiScale: v })}
                      />
                      <p className="text-[11px] leading-snug text-muted-foreground">
                        Applies everywhere: buttons, menus, dialogs, cards — nothing is left out.
                      </p>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label>Note text size (markdown)</Label>
                        <span className="text-xs tabular-nums text-muted-foreground">{settings.markdownScale}%</span>
                      </div>
                      <Slider
                        min={70}
                        max={170}
                        step={5}
                        value={[settings.markdownScale]}
                        onValueChange={([v]) => updateSettings({ markdownScale: v })}
                      />
                      <p className="text-[11px] leading-snug text-muted-foreground">
                        Only the note body — editor text and the rendered preview (headings,
                        lists, checklists scale proportionally).
                      </p>
                    </div>
                  </div>

                  {/* ---- fonts ---- */}
                  <div className="space-y-4">
                    <div>
                      <p className="text-sm font-medium">Fonts</p>
                      <p className="text-xs text-muted-foreground">
                        14 fonts including monospace — separate choices for the app and your notes.
                      </p>
                    </div>
                    <div className="space-y-2">
                      <Label>App font</Label>
                      <FontSelect
                        value={settings.appFont}
                        onChange={(v) => updateSettings({ appFont: v })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Note font</Label>
                      <FontSelect
                        value={settings.noteFont}
                        onChange={(v) => updateSettings({ noteFont: v })}
                      />
                    </div>
                  </div>

                  <Separator />

                  {/* ---- media: grid width only (single images are per-image) ---- */}
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Images in notes</p>
                    <div className="flex items-center justify-between">
                      <Label>Image grid width</Label>
                      <span className="text-xs tabular-nums text-muted-foreground">{settings.mediaGridWidth}%</span>
                    </div>
                    <Slider
                      min={40}
                      max={100}
                      step={5}
                      value={[settings.mediaGridWidth]}
                      onValueChange={([v]) => updateSettings({ mediaGridWidth: v })}
                    />
                    <p className="text-[11px] leading-snug text-muted-foreground">
                      Single images have their own size button directly on the image in the
                      preview — tap it to set Small / Medium / Large / Full or any width.
                    </p>
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="flex items-center gap-1.5 text-sm font-medium">
                        <SquareSigma className="h-4 w-4" /> Math formulas
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Render $…$ and $$…$$ (LaTeX) beautifully in the preview
                      </p>
                    </div>
                    <Switch
                      checked={settings.mathEnabled}
                      onCheckedChange={(v) => updateSettings({ mathEnabled: v })}
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Animations</p>
                      <p className="text-xs text-muted-foreground">
                        Card entrances, hover lifts and micro-motion
                      </p>
                    </div>
                    <Switch
                      checked={settings.animations}
                      onCheckedChange={(v) => updateSettings({ animations: v })}
                    />
                  </div>
                </div>
              ) : null}

              {tab === "search" ? (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Include Archive in search</p>
                      <p className="text-xs text-muted-foreground">
                        Searching from the main view also surfaces archived notes. The Archive
                        page always searches its own notes regardless.
                      </p>
                    </div>
                    <Switch
                      checked={settings.searchIncludeArchive}
                      onCheckedChange={(v) => updateSettings({ searchIncludeArchive: v })}
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Ask before Preview/Edit toggle</p>
                      <p className="text-xs text-muted-foreground">
                        After tapping the toggle, tap one exact word and the mode switches around it. Turn this off to switch instantly, like before. The Preview shortcut (default Shift+X) follows the same rule.
                      </p>
                    </div>
                    <Switch
                      checked={settings.confirmModeToggle}
                      onCheckedChange={(v) => updateSettings({ confirmModeToggle: v })}
                    />
                  </div>

                  <div className={`flex items-center justify-between rounded-lg border px-3 py-2.5 transition-opacity ${settings.confirmModeToggle ? "" : "pointer-events-none opacity-50"}`}>
                    <div>
                      <p className="text-sm font-medium">Require Done after word tap</p>
                      <p className="text-xs text-muted-foreground">
                        On: tap the word, check its highlight, then press Done. Off: tapping the word switches the mode immediately — no Done needed.
                      </p>
                    </div>
                    <Switch
                      checked={settings.confirmWordSelection}
                      onCheckedChange={(v) => updateSettings({ confirmWordSelection: v })}
                    />
                  </div>

                  <Separator />

                  <div className="rounded-lg border bg-accent/30 px-3 py-3 text-xs leading-relaxed text-muted-foreground">
                    <p className="mb-1 font-medium text-foreground">Search covers</p>
                    Titles, note bodies, checklist items, labels, folder names and image file
                    names — in every view (Notes, Folders, Archive, Trash and Vault). The editor
                    also has its own find-in-note search with highlights.
                  </div>
                </div>
              ) : null}

              {tab === "shortcuts" ? (
                <div className="space-y-5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-sm font-medium">Editor shortcuts</p>
                      <p className="text-xs leading-relaxed text-muted-foreground">
                        Every Markdown action has a shortcut — the Preview/Edit
                        toggle uses <b>Shift + X</b> by default. Press{" "}
                        <b>Record</b> on any action, hold the keys you want
                        together ({SHORTCUT_MIN_KEYS}–{SHORTCUT_MAX_KEYS} keys),
                        then release them.
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="shrink-0 gap-1.5"
                      onClick={() => {
                        updateSettings({ shortcuts: defaultShortcuts() });
                        toast.success("Shortcuts reset to defaults");
                      }}
                    >
                      <RotateCcw className="h-3.5 w-3.5" /> Reset all
                    </Button>
                  </div>
                  <div className="divide-y rounded-lg border">
                    {SHORTCUT_ACTIONS.map((action) => (
                      <ShortcutRow
                        key={action.id}
                        action={action}
                        combo={settings.shortcuts[action.id] ?? action.defaults}
                        onSave={(combo) => {
                          const conflict = findConflict(action.id, combo, settings.shortcuts);
                          if (conflict) {
                            const other = SHORTCUT_ACTIONS.find((a) => a.id === conflict);
                            toast.error(`Already used by “${other?.label ?? conflict}”. Pick different keys.`);
                            return;
                          }
                          updateSettings({ shortcuts: { ...settings.shortcuts, [action.id]: combo } });
                          toast.success(`${action.label}: ${formatCombo(combo)}`);
                        }}
                      />
                    ))}
                  </div>
                  <p className="text-[11px] leading-relaxed text-muted-foreground">
                    Shortcuts only work inside the note editor. If a shortcut
                    uses only Shift plus a letter, that capital letter can still
                    be typed with Caps Lock. Combos including Ctrl, Alt or Meta
                    always trigger.
                  </p>
                </div>
              ) : null}

              {tab === "vault" ? (
                <div className="space-y-6">
                  <div className="rounded-lg border bg-accent/30 px-3 py-3 text-sm leading-relaxed">
                    <p className="flex items-center gap-1.5 font-medium">
                      <KeyRound className="h-4 w-4" /> Use vault to protect your notes
                    </p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      Private notes kept in the vault are hidden from every view and search
                      until the vault is unlocked with your password. After unlocking once, it
                      stays open until the app closes.
                    </p>
                  </div>

                  {!hasCode ? (
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium">Set up protection</p>
                        <p className="text-xs text-muted-foreground">
                          Create a password and your two security questions
                        </p>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => useKeepStore.getState().setVaultSetupOpen(true)}
                      >
                        <Lock className="mr-2 h-4 w-4" /> Set up vault
                      </Button>
                    </div>
                  ) : (
                    <>
                      <SeedRecoveryHint key={`${hasCode}|${currentQuestionIds.join(",")}`} />
                      <div className="flex items-center justify-between rounded-lg border border-emerald-500/30 bg-emerald-500/5 px-3 py-2.5 text-sm">
                        <span className="flex items-center gap-2">
                          {vaultOpen ? (
                            <>
                              <LockOpen className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                              Vault is unlocked in this session.
                            </>
                          ) : (
                            <>
                              <Lock className="h-4 w-4" /> Vault is locked.
                            </>
                          )}
                        </span>
                        {vaultOpen ? (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              closeVault();
                              toast.success("Vault locked");
                            }}
                          >
                            <Lock className="mr-2 h-4 w-4" /> Lock now
                          </Button>
                        ) : (
                          <Button variant="outline" size="sm" onClick={() => requestVaultAccess()}>
                            Unlock
                          </Button>
                        )}
                      </div>

                      <div className="space-y-3">
                        <Button
                          variant="outline"
                          size="sm"
                          className="gap-2"
                          onClick={() => {
                            setShowChangePass((v) => !v);
                            setShowQuestions(false);
                          }}
                        >
                          <SquarePen className="h-4 w-4" /> {showChangePass ? "Hide" : "Change password"}
                        </Button>
                        {showChangePass ? (
                          <div className="space-y-3 rounded-lg border p-3">
                            <p className="text-xs text-muted-foreground">Use your current vault password to choose a new password. If you forgot it, close this panel and use “Forgot password” when unlocking the vault.</p>
                            <Input type="password" value={curPass} onChange={(e) => setCurPass(e.target.value)} placeholder="Current password" autoComplete="current-password" />
                            <Input type="password" value={newPass} onChange={(e) => setNewPass(e.target.value)} placeholder="New password (min 3 characters)" autoComplete="new-password" />
                            <Input type="password" value={newPass2} onChange={(e) => setNewPass2(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") void saveNewPassword(); }} placeholder="Repeat new password" autoComplete="new-password" />
                            <div className="flex justify-end gap-2">
                              <Button variant="ghost" size="sm" onClick={() => setShowChangePass(false)}>Cancel</Button>
                              <Button size="sm" onClick={() => void saveNewPassword()} disabled={vaultBusy}>{vaultBusy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null} Save password</Button>
                            </div>
                          </div>
                        ) : null}
                      </div>

                      <div className="space-y-3">
                        <Button
                          variant="outline"
                          size="sm"
                          className="gap-2"
                          onClick={() => {
                            setShowQuestions((v) => !v);
                            setShowChangePass(false);
                          }}
                        >
                          <ShieldQuestion className="h-4 w-4" /> {showQuestions ? "Hide" : "Security questions"}
                        </Button>
                        {showQuestions ? (
                          <div className="space-y-3 rounded-lg border p-3">
                            <p className="text-xs text-muted-foreground">To replace both questions, enter the current password and answer at least one of the existing questions correctly. The second existing answer may be wrong or blank.</p>
                            <Input type="password" value={curPass} onChange={(e) => setCurPass(e.target.value)} placeholder="Current password" autoComplete="current-password" />
                            {currentQuestionIds.length === 2 ? (
                              <div className="space-y-2 rounded-md border bg-accent/20 p-2.5">
                                {currentQuestionIds.map((id, i) => (
                                  <div key={id} className="space-y-1">
                                    <Label className="text-xs">{questionText(id)}</Label>
                                    <Input value={currentQuestionAnswers[i] ?? ""} onChange={(e) => setCurrentQuestionAnswers((current) => current.map((value, j) => j === i ? e.target.value : value))} autoComplete="off" placeholder="Current answer (at least one required)" />
                                  </div>
                                ))}
                              </div>
                            ) : null}
                            <p className="text-xs font-medium">Choose the replacement questions</p>
                            {[0, 1].map((slot) => (
                              <div key={slot} className="grid gap-2 sm:grid-cols-2">
                                <Select value={qIds[slot]} onValueChange={(v) => setQIds((current) => slot === 0 ? [v, current[1]] : [current[0], v])}>
                                  <SelectTrigger aria-label={`New security question ${slot + 1}`}><SelectValue /></SelectTrigger>
                                  <SelectContent>{SECURITY_QUESTIONS.map((q) => <SelectItem key={q.id} value={q.id} disabled={(qIds[0] === q.id || qIds[1] === q.id) && qIds[slot] !== q.id}>{q.text}</SelectItem>)}</SelectContent>
                                </Select>
                                <Input value={qAnswers[slot] ?? ""} onChange={(e) => setQAnswers((current) => current.map((value, j) => j === slot ? e.target.value : value))} autoComplete="off" placeholder="New answer" />
                              </div>
                            ))}
                            <div className="flex justify-end gap-2">
                              <Button variant="ghost" size="sm" onClick={() => setShowQuestions(false)}>Cancel</Button>
                              <Button size="sm" onClick={() => void saveQuestions()} disabled={vaultBusy}>{vaultBusy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null} Save questions</Button>
                            </div>
                          </div>
                        ) : null}
                      </div>
                    </>
                  )}

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium">Export vault</p>
                      <p className="text-xs text-muted-foreground">
                        Vault notes can be included in a backup — the export asks for the
                        password first
                      </p>
                    </div>
                    <Button variant="outline" size="sm" onClick={() => setExportOpen(true)}>
                      <Download className="mr-2 h-4 w-4" /> Export
                    </Button>
                  </div>
                </div>
              ) : null}

              {tab === "about" ? (
                <div className="space-y-4 text-sm">
                  <div>
                    <p className="flex items-center gap-2 font-medium">
                      {settings.appName}
                      <span className="rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.5 text-[10px] font-semibold tracking-wide text-emerald-600 dark:text-emerald-400">
                        v17.0
                      </span>
                    </p>
                    <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                      A fast, private notepad inspired by Google Keep. Everything below works
                      offline-first and saves automatically.
                    </p>
                  </div>

                  <Separator />

                  <ul className="space-y-2 text-xs leading-relaxed">
                    <li><b>Notes &amp; lists</b> — tap “Take a note”. Switch type with the checklist icon. Unlimited length.</li>
                    <li><b>Full-screen editor</b> — notes open in a dedicated full-screen view with a back arrow; typing stays anchored even when the keyboard opens.</li>
                    <li><b>Organise</b> — pin, 29 colours, labels (sidebar), folders (genres) with preview cards, archive, trash with undo.</li>
                    <li><b>Reorder</b> — long-press a note and drag it anywhere in the list; the arrangement is remembered.</li>
                    <li><b>Find in note</b> — the magnifier inside the editor highlights every match; jump between them with ↑ / ↓.</li>
                    <li><b>Media</b> — add images &amp; GIFs from the toolbar; click any image to view, edit or download. Size each image with its own button.</li>
                    <li><b>Math</b> — write LaTeX between $…$, $$…$, \[…\] or \(…\) — or just type a bare equation like E = mc^2 — and the preview renders it beautifully (toggle in Settings).</li>
                    <li><b>Search</b> — the top bar searches everywhere: titles, bodies, checklists, labels, folders, file names.</li>
                    <li><b>Shortcuts</b> — every Markdown action (bold, headings, lists, links, tables, undo…) has a keyboard shortcut. Preview/Edit is Shift+X, and all of them can be re-recorded in Settings → Shortcuts with any 2–4 key combination.</li>
                    <li><b>Layout &amp; style</b> — grid/list toggle, {THEMES.length} hand-tuned themes, fonts, text scales, dark/light in the moon/sun menu.</li>
                    <li><b>Backup</b> — Settings → Export downloads a ZIP (notes + images + folders + labels); Import restores it.</li>
                    <li><b>Vault</b> — protect your notes with a password and two security questions. Change the password with the current one, or reset it by answering the security questions — no current password needed.</li>
                  </ul>

                  <Separator />

                  <p className="text-xs text-muted-foreground">Made to feel instant on phone and desktop.</p>
                </div>
              ) : null}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <ExportDialog open={exportOpen} onOpenChange={setExportOpen} />
      <ImportDialog open={importOpen} onOpenChange={setImportOpen} />
      <VaultSetupDialog />
    </>
  );
}

/* ------------------------------------------------------------------ */
/* Theme gallery                                                       */
/* ------------------------------------------------------------------ */

const GROUP_LABELS: Record<string, string> = {
  classic: "Classic",
  light: "Light & colourful",
  dark: "Dark UI",
  contrast: "High contrast",
  comfy: "Comfy palettes",
  special: "Special",
};

function ThemeGallery() {
  const settings = useSettings();
  const groups = ["classic", "light", "dark", "contrast", "comfy", "special"] as const;
  return (
    <div className="space-y-4">
      <div>
        <p className="text-sm font-medium">Theme</p>
        <p className="text-xs text-muted-foreground">
          {THEMES.length + 1} themes, applied to every corner of the app. Note colours you set
          per note stay independent.
        </p>
      </div>
      {/* system option */}
      <button
        type="button"
        onClick={() => updateSettings({ themeId: "system" })}
        className={cn(
          "flex w-full items-center gap-3 rounded-xl border px-3 py-2.5 text-left transition-colors",
          settings.themeId === "system" ? "border-ring ring-1 ring-ring" : "hover:bg-accent/60"
        )}
      >
        <span className="flex h-8 w-14 shrink-0 overflow-hidden rounded-md border">
          <span className="h-full w-1/2 bg-[#f1f3f4]" />
          <span className="h-full w-1/2 bg-[#1f2023]" />
        </span>
        <span className="flex-1 text-sm font-medium">Follow system</span>
        {settings.themeId === "system" ? <Check className="h-4 w-4" /> : null}
      </button>

      {groups.map((group) => {
        const themes = THEMES.filter((t) => t.group === group);
        if (themes.length === 0) return null;
        return (
          <div key={group} className="space-y-2">
            <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
              {GROUP_LABELS[group]}
            </p>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {themes.map((t) => {
                const active = settings.themeId === t.id;
                return (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => updateSettings({ themeId: t.id })}
                    className={cn(
                      "group relative flex flex-col gap-1.5 rounded-xl border p-2 text-left transition-colors",
                      active ? "border-ring ring-1 ring-ring" : "hover:bg-accent/60"
                    )}
                  >
                    <span
                      className="flex h-9 w-full overflow-hidden rounded-md border"
                      style={{ background: t.swatch[0] }}
                    >
                      <span className="m-auto h-4 w-8 rounded" style={{ background: t.swatch[1] }} />
                      <span className="m-auto h-4 w-3 rounded" style={{ background: t.swatch[2] }} />
                    </span>
                    <span className="flex items-center gap-1 text-xs font-medium">
                      {t.name}
                      {active ? <Check className="ml-auto h-3.5 w-3.5" /> : null}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Font selects                                                        */
/* ------------------------------------------------------------------ */

function FontSelect({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const active = FONT_CHOICES.find((f) => f.id === value) ?? FONT_CHOICES[0];
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className="w-full">
        <SelectValue>
          <span style={{ fontFamily: active.stack }}>{active.name}</span>
        </SelectValue>
      </SelectTrigger>
      <SelectContent className="max-h-72">
        {FONT_CHOICES.map((f) => (
          <SelectItem key={f.id} value={f.id}>
            <span style={{ fontFamily: f.stack }}>{f.name}</span>
            <span className="ml-2 text-[10px] uppercase tracking-wide text-muted-foreground">{f.kind}</span>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

/* ------------------------------------------------------------------ */
/* Storage section — shows where notes live + change/rescan actions    */
/* ------------------------------------------------------------------ */

function StorageSection() {
  const storageKind = useKeepStore((s) => s.storageKind);
  const rootLabel = useKeepStore((s) => s.rootLabel);
  const changeFolder = useKeepStore((s) => s.changeFolder);
  const rescan = useKeepStore((s) => s.rescan);
  const [busy, setBusy] = useState(false);

  const kindLabel =
    storageKind === "android"
      ? "Phone storage (real files)"
      : storageKind === "web"
        ? "Local folder (real files)"
        : "In-app local storage";

  return (
    <div className="flex items-center justify-between gap-3">
      <div className="min-w-0">
        <p className="flex items-center gap-1.5 text-sm font-medium">
          <HardDrive className="h-3.5 w-3.5" /> Storage
        </p>
        <p className="truncate text-xs text-muted-foreground" title={rootLabel}>
          {kindLabel}
          {rootLabel ? ` — ${rootLabel}` : ""}
        </p>
        <p className="mt-0.5 text-[11px] leading-snug text-muted-foreground">
          Each note = a folder with node.md + attachment/
        </p>
      </div>
      <div className="flex shrink-0 flex-col gap-1.5">
        <Button
          variant="outline"
          size="sm"
          className="gap-1.5"
          disabled={busy}
          onClick={() => {
            setBusy(true);
            void changeFolder().finally(() => setBusy(false));
          }}
        >
          <FolderCog className="h-3.5 w-3.5" /> Change
        </Button>
        <Button
          variant="outline"
          size="sm"
          className="gap-1.5"
          disabled={busy}
          onClick={() => {
            setBusy(true);
            void rescan().finally(() => {
              setBusy(false);
              toast.success("Notes folder rescanned");
            });
          }}
        >
          {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCcw className="h-3.5 w-3.5" />}
          Rescan
        </Button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Shortcut recorder row (Settings → Shortcuts)                        */
/* ------------------------------------------------------------------ */

function ShortcutRow({
  action,
  combo,
  onSave,
}: {
  action: { id: string; label: string; hint: string; defaults: string[] };
  combo: string[];
  onSave: (combo: string[]) => void;
}) {
  const [recording, setRecording] = useState(false);
  const [held, setHeld] = useState<string[]>([]);
  const [error, setError] = useState("");
  const settings = useSettings();
  const onSaveRef = useRef(onSave);
  useEffect(() => {
    onSaveRef.current = onSave;
  });

  useEffect(() => {
    if (!recording) return;
    const tracker = new KeyTracker();
    let max: string[] = [];
    let done = false;
    const finish = (cancelled: boolean) => {
      if (done) return;
      done = true;
      window.removeEventListener("keydown", onKeyDown, true);
      window.removeEventListener("keyup", onKeyUp, true);
      window.removeEventListener("blur", cancel);
      setRecording(false);
      setHeld([]);
      if (cancelled) return;
      const validated = validCombo(max);
      if (!validated) {
        setError(
          max.length < SHORTCUT_MIN_KEYS
            ? `Hold at least ${SHORTCUT_MIN_KEYS} keys together`
            : `At most ${SHORTCUT_MAX_KEYS} keys per shortcut`,
        );
        return;
      }
      setError("");
      onSaveRef.current(validated);
    };
    const onKeyDown = (event: KeyboardEvent) => {
      event.preventDefault();
      event.stopPropagation();
      if (event.key === "Escape") {
        finish(true);
        return;
      }
      const nowHeld = [...tracker.keydown(event)];
      if (nowHeld.length > max.length) max = nowHeld;
      setHeld(nowHeld);
    };
    const onKeyUp = (event: KeyboardEvent) => {
      event.preventDefault();
      event.stopPropagation();
      tracker.keyup(event);
      if (tracker.size === 0) finish(false);
    };
    const cancel = () => finish(true);
    window.addEventListener("keydown", onKeyDown, true);
    window.addEventListener("keyup", onKeyUp, true);
    window.addEventListener("blur", cancel);
    return () => {
      window.removeEventListener("keydown", onKeyDown, true);
      window.removeEventListener("keyup", onKeyUp, true);
      window.removeEventListener("blur", cancel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [recording]);

  const conflictWith = findConflict(action.id, combo, settings.shortcuts);
  const conflictLabel = SHORTCUT_ACTIONS.find((a) => a.id === conflictWith)?.label;

  return (
    <div className="flex items-center gap-3 px-3 py-2.5">
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium">{action.label}</p>
        <p className="truncate text-xs text-muted-foreground">{action.hint}</p>
        {error ? (
          <p className="text-xs text-destructive">{error}</p>
        ) : conflictLabel ? (
          <p className="text-xs text-amber-600 dark:text-amber-400">
            Same keys as “{conflictLabel}” — only one can fire.
          </p>
        ) : null}
      </div>
      <button
        type="button"
        aria-label={`Record shortcut for ${action.label}`}
        className={`shrink-0 rounded-md border px-3 py-1.5 text-xs font-medium tabular-nums transition-colors ${
          recording
            ? "animate-pulse border-primary bg-primary/10 text-primary"
            : "hover:bg-accent"
        }`}
        onClick={() => {
          setError("");
          setHeld([]);
          setRecording((v) => !v);
        }}
      >
        {recording
          ? held.length > 0
            ? `${held.join(" + ")} …`
            : "Press keys…"
          : formatCombo(combo)}
      </button>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Seed-recovery status hint (Settings → Vault)                        */
/* Shows when the on-disk answer slots are missing or out of sync with  */
/* the current vault questions — re-saving the questions fixes both.    */
/* ------------------------------------------------------------------ */

function SeedRecoveryHint() {
  const [state, setState] = useState<"ok" | "stale" | "missing" | "busy">("busy");
  const hasCode = vaultPasswordExists();
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        if (!seedRecovery.status) {
          if (alive) setState("missing");
          return;
        }
        const status = await seedRecovery.status();
        if (!alive) return;
        if (!status || status.slots.length === 0) {
          setState("missing");
          return;
        }
        const vaultIds = getSecurityQuestionIds().join("|");
        const slotIds = [...status.slots].map((s) => s.id).sort().join("|");
        setState(vaultIds === slotIds ? "ok" : "stale");
      } catch {
        if (alive) setState("missing");
      }
    })();
    return () => {
      alive = false;
    };
  }, [hasCode]);
  if (state === "busy" || state === "ok" || !hasCode) return null;
  return (
    <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2.5 text-xs leading-relaxed text-amber-700 dark:text-amber-400">
      {state === "missing" ? (
        <>
          <b>Forgot seed password?</b> Answer-based seed recovery is not
          configured for this storage yet. Re-save your security questions
          below (or unlock once with the seed password first) to record the
          recovery answers.
        </>
      ) : (
        <>
          <b>Seed recovery is out of date.</b> The stored recovery answers no
          longer match your current security questions. Re-save your questions
          below to keep “Forgot seed password” working.
        </>
      )}
    </div>
  );
}
