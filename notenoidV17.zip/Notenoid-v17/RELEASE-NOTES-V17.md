# Notenoid v17.0

Android version code **170** · Package **com.notes.app**

## Configurable editor shortcuts (new)

- Every Markdown toolbar action now has a keyboard shortcut, including the **Preview/Edit toggle (Shift+X by default)**.
- Settings → **Shortcuts** lists all 24 actions with their current combination.
- Press **Record**, hold any key combination of **2–4 keys** together, release — it is saved instantly.
  - Minimum 2 keys and maximum 4 keys are enforced; a single key or five keys are rejected with a message.
  - Duplicate combinations are refused and name the conflicting action.
  - Escape cancels recording; **Reset all** restores the defaults.
- Defaults: Shift+X preview · Ctrl+B/I bold/italic · Ctrl+Shift+U/S underline/strikethrough · Ctrl+` inline code · Ctrl+Shift+1/2/3 headings · Ctrl+Shift+0 body text · Ctrl+Shift+8/7/L bullet/numbered/checklist · Ctrl+Shift+9 quote · Ctrl+Shift+` code block · Ctrl+K / Ctrl+Shift+K add/remove link · Ctrl+Alt+I add image · Ctrl+Alt+G insert image at cursor · Ctrl+Shift+- divider · Ctrl+Shift+M table · Ctrl+Alt+N clear formatting · Ctrl+Z / Ctrl+Y undo/redo.
- Shortcuts take priority over typing (v16 Shift+X behaviour). A capital letter used by a Shift-combo can still be typed with Caps Lock. Combos are matched as an exact set of held keys, so extra modifiers never mis-fire.
- Shortcuts are stored inside the encrypted settings and persist across reloads.

## Word-tap Done confirmation (new setting)

- The exact-word Preview/Edit toggle gained **“Require Done after word tap”** (Settings → Search & Notes).
  - On (default): tap the word, check its highlight, press **Done** — the v16 flow.
  - **Off: tapping the word switches the mode immediately — no Done press needed.** The banner reads “Tap one word — the mode switches instantly” and only offers Cancel.
- Works in both directions (preview → edit and edit → preview) and with the Shift+X shortcut path.

## Shorter minimum credentials (changed)

- **All passwords — the seed password, the vault password (create/change/reset) — and all security answers now require a minimum of 3 characters** (previously 16 for the seed and 8 for the vault). This is a deliberate convenience trade-off requested for v17.

## Forgot seed password (new)

- The recovery screen (“Recover your encrypted notes”) now offers **“Forgot seed password?”**.
- Answer **one** of your two vault security questions correctly (the other may stay blank) and the encrypted folder unlocks **without the seed**.
- How it works: whenever answers are known (vault setup, security-question change, answer-based vault password reset), the storage layer rewrites `notenoid.encrypted/seed-recovery.json` with slots that wrap the raw storage key under each answer. The file is public like `key.json`, but its slots are AES-256-GCM sealed and bound to the storage id and question id.
- The raw storage key needed to rebuild slots is available after seed entry, from a self-sealed copy inside the encrypted index, or on Android directly from the Keystore bridge — so slots rebuild even on device-key-auto-unlocked sessions.
- Security-question changes automatically rebind the seed-recovery slots; old answers stop working. Settings → Vault shows a banner whenever the slots are missing or out of date and how to fix them.
- Encrypted recovery copies include `seed-recovery.json`, so answer-based seed recovery works from backups too.
- A wrong answer is rejected; a tampered slot fails authentication and unlocks nothing.

## Everything else

- All v16 storage, vault, backup, import and exact-word-selection behaviour is retained; see `RELEASE-NOTES-V16.md`.
- `VALIDATION-V17.md` lists the complete test matrix used for this release.

## Read before using

See `docs/SECURITY.md`, `docs/RECOVERY.md` and `docs/BUILD.md`. Three-character passwords and answer-based seed recovery are noticeably weaker than the previous policy — they are provided because they were explicitly requested. This is not an independent security audit and no claim of zero bugs is made.
