# Notenoid v17 — validation record

Everything below was executed against the exact source in this archive. Commands refer to the repo root.

## Type & lint safety

| Check | Command | Result |
| --- | --- | --- |
| TypeScript | `npm run typecheck` (`tsc --noEmit`) | PASS — 0 errors |
| ESLint (changed files) | `npx eslint <v17 files>` | PASS — 0 errors (pre-existing v16 warnings unchanged) |

## Security / storage (Node, `fake-indexeddb`)

`npm run test:security` → `tsx test/security/run.ts` — **61 scenario groups PASS**, including the complete v16 matrix (encrypted migration, tamper rejection, interrupted-migration resume, concurrent checkpoints, device-key auto-unlock, vault move in/out, backups/imports, legacy verifier migration) plus the new v17 groups:

- 2-character seed rejected; **3-character seed accepted**
- 2-character vault password rejected; **3-character vault password accepted**
- 2-character security answer rejected; **3-character answers accepted**
- vault setup records both questions into `seed-recovery.json`
- encrypted backup carries `seed-recovery.json`
- bridge detaches on close
- wrong security answer cannot unlock the seed
- **correct security answer unlocks storage without the seed** (answers are case/whitespace-normalised)
- original 3-character seed still unlocks after answer-based recovery
- security-question change rebinds seed recovery; the retired answer stops working
- tampered seed-recovery slot fails authentication
- Android Keystore bridge rebuilds seed recovery without a typed seed

## Browser e2e (Playwright/Chromium against `next dev`)

| Suite | Command | Result |
| --- | --- | --- |
| Smoke (rendering, KaTeX, code copy, task toggle, save/reload) | `npm run test:smoke` | PASS |
| Exact-word selection, desktop + touch (v16 regression) | `npm run test:selection` | PASS — all 10 offsets, both directions, centring, pulse timer |
| **Shortcuts (v17)** | `npm run test:shortcuts` | PASS — see below |
| **Word-tap Done setting (v17)** | `npm run test:wordtap` | PASS |
| **Forgot seed (v17)** | `npm run test:recovery-e2e` | PASS |
| Security UI (vault flows, exports, reload, multi-tab) | `TEST_URL=http://localhost:3000 npm run test:security-ui` | PASS — 10/10 |

Shortcuts suite verifies every action in a real browser: Shift+X preview toggle both ways (also while the textarea is focused), Ctrl+B/I, Ctrl+Shift+U/S, Ctrl+`, Ctrl+Shift+1/2/3/0, bullet/numbered/checklist/quote, Ctrl+Shift+` code block, Ctrl+K link popover + Ctrl+Shift+K removal, divider, table, clear formatting, Ctrl+Alt+I file picker, Ctrl+Alt+G insert picker, Ctrl+Z/Ctrl+Y undo/redo, recording a 2-key combo, 1-key rejection, 5-key rejection, 4-key acceptance, duplicate-combination rejection naming the conflict, Escape cancel, Reset all, rebinding (old combo released), and persistence across reload.

Word-tap suite verifies instant switching in both directions with `Require Done` off (no Done button, exact occurrence anchored, pulse overlay) and the v16 Done flow after re-enabling the setting through the real UI.

Forgot-seed suite verifies 3-char seed/vault-password/answers in the UI, the configured banner state, wrong-answer rejection, answer-based unlock restoring notes, and the original seed still working afterwards.

## Independent recovery utility

`npm run test:recovery` → `python3 test/security/offline-recovery.py` — PASS. `scripts/recover.py` ignores the new `seed-recovery.json` container file and recovers ordinary + vault content exactly as before.

## Storage naming

`npm run test:storage` — PASS (unchanged).

## Android build

- Web export: `STATIC_EXPORT=true next build --webpack` → `android/assets/`
- APK: `scripts/build_apk.sh` (aapt2/d8/zipalign/apksigner pipeline, version code **170**, version name **17.0**)
- `apksigner verify` — signature verified
- `aapt dump badging` — package `com.notes.app`, versionCode 170, versionName 17.0 (see `test/results/apk-metadata.txt`)

## Known limitations

- A physical Android device was not available; Android Keystore behaviour is covered by the bridge simulation test, not hardware.
- Shortcuts fire while the editor is open and take priority over typing (v16 Shift+X parity). Use Caps Lock for a capital letter that a Shift-combo also uses, or rebind that action.
- Shift-only combinations cannot be typed as capitals while the editor is open; Ctrl/Alt/Meta combinations never conflict with typing.
- On desktop browsers, seed-recovery slot rebuilds after a security-question change require either one seed entry (the self-sealed pref) or the Android Keystore bridge; Settings → Vault displays a banner whenever slots are missing or stale. On Android the bridge always supplies the key.
- Short credentials (3 characters) and answer-based seed recovery reduce security by design; they were explicitly requested for this release.

## Logs

Final captured logs live in `test/results/`:

- `security.txt` — typecheck, 61 security/storage/backup scenario groups, storage naming, independent Python recovery
- `browser-v17.txt` — smoke, shortcuts, word-tap Done setting, forgot-seed e2e (36 PASS lines)
- `selection.txt` — selection suite (all offsets, desktop + touch) and the v16 security-ui battery (31 PASS lines)
- `apk-build.txt` — aapt badging, apksigner certificate digests, packaged v17 feature strings
- `dependencies.txt` — `npm ls --depth=0` tree
